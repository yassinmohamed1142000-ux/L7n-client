#!/usr/bin/env bash
# Compiles ONLY the Minecraft-free core (com.reaper.client.core) plus the tests with a plain JDK and runs them.
# Needs: a JDK (17+) and a Gson jar (set GSON=/path/to/gson.jar; Gradle's cache has one).
# Optional arguments name the suites to run (Core Gui Hud HudEditor Features Waypoints Panels Sorter Screenshots Chat Adapter Baritone Commands Wiring); none = all.
set -euo pipefail
cd "$(dirname "$0")/.."
GSON="${GSON:-/opt/gradle-8.14.3/lib/gson-2.10.jar}"
OUT="${OUT:-build/core-tests}"
rm -rf "$OUT" && mkdir -p "$OUT"
javac -encoding UTF-8 -Xlint:all,-serial -d "$OUT" -cp "$GSON" \
  $(find src/main/java/com/reaper/client/core -name '*.java') $(find src/test/java -name '*.java')
PREVIEWS="${PREVIEWS:-build/previews}"
java -Djava.awt.headless=true -Dreaper.preview.dir="$PREVIEWS" -cp "$OUT:$GSON" com.reaper.client.tests.AllTests "$@"
