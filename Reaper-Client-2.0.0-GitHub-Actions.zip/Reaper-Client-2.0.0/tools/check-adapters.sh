#!/usr/bin/env bash
# Type-checks everything in src/main/java (the tested core AND the game layer: mc/, mixin/, ReaperClient) against the
# hand-written API stubs in tools/api-stubs instead of the real game. It catches typos, wrong argument counts, missing
# imports, bad generics and unhandled exceptions in the code that cannot be unit-tested without Minecraft.
#
# It does NOT prove that the real game has the methods the stubs claim: the stubs follow what 26.x reference sources
# show. docs/API-AUDIT.md lists every game call with its evidence and which ones are not confirmed. The real check is
# always `./gradlew build`.
#
# Needs: a JDK (21+), git (only when no Brigadier is found), and these jars (found automatically in Gradle's cache after
# a first build, or set GSON, SLF4J, BRIGADIER to a jar or a directory of classes):
#   gson, slf4j-api, brigadier
set -euo pipefail
cd "$(dirname "$0")/.."

OUT="${OUT:-build/api-check}"
CACHE="${GRADLE_USER_HOME:-$HOME/.gradle}/caches"

find_jar() {   # $1 = file name glob, $2.. = extra directories to look in
  local glob="$1"; shift
  local dir hit
  for dir in "$CACHE" "$@"; do
    [ -d "$dir" ] || continue
    hit="$(find "$dir" -name "$glob" -not -name '*sources*' 2>/dev/null | sort | tail -n 1)"
    [ -n "$hit" ] && { echo "$hit"; return 0; }
  done
  return 1
}

GSON="${GSON:-$(find_jar 'gson-2*.jar' /opt/gradle-*/lib || true)}"
SLF4J="${SLF4J:-$(find_jar 'slf4j-api-*.jar' /opt/gradle-*/lib || true)}"
[ -n "$GSON" ]  || { echo "gson jar not found: set GSON=/path/to/gson.jar"; exit 2; }
[ -n "$SLF4J" ] || { echo "slf4j-api jar not found: set SLF4J=/path/to/slf4j-api.jar"; exit 2; }

BRIGADIER="${BRIGADIER:-$(find_jar 'brigadier-*.jar' || true)}"
rm -rf "$OUT" && mkdir -p "$OUT/classes"
if [ -z "$BRIGADIER" ]; then
  echo "No Brigadier jar found; compiling Mojang's open-source Brigadier from GitHub for the check."
  git clone --depth 1 https://github.com/Mojang/brigadier.git "$OUT/brigadier-src" >/dev/null 2>&1
  mkdir -p "$OUT/brigadier"
  javac -nowarn -d "$OUT/brigadier" $(find "$OUT/brigadier-src/src/main/java" -name '*.java') >/dev/null 2>&1
  BRIGADIER="$OUT/brigadier"
fi

STUBS=$(find tools/api-stubs/src -name '*.java')
SOURCES=$(find src/main/java -name '*.java')
javac -encoding UTF-8 --release 21 -Xlint:all,-serial,-processing -Werror -d "$OUT/classes" \
  -cp "$GSON:$SLF4J:$BRIGADIER" $STUBS $SOURCES
echo "OK: $(echo "$SOURCES" | wc -l) source files type-check against $(echo "$STUBS" | wc -l) API stubs (no errors, no warnings)."
