# API stubs

These files are **not** Minecraft, Fabric or Mixin. They are tiny hand-written stand-ins that declare only the classes
and members Reaper's game layer (`com.reaper.client.mc`, `com.reaper.client.mixin`, `ReaperClient`) uses, so that
`tools/check-adapters.sh` can run `javac` over that code without the game.

What the check is good for: spelling mistakes, wrong argument counts and types, missing imports, bad generics,
unhandled checked exceptions, lambdas that do not fit their interface, and overrides whose signature differs from the
one the stub declares.

What it cannot do: tell whether the real game has a member. A stub is only as correct as the evidence behind it. The
signatures were taken from the sources of other mods and libraries that build against 26.1.x or later 26.x versions
(Wurst 26.1.2, Fabric API, malilib, Mod Menu, Baritone's 26.1 branch, Meteor) and from the open-source Brigadier library;
`docs/API-AUDIT.md` lists, call by call, where each one was seen and which ones could not be confirmed.

The authoritative check is always `./gradlew build` against the real game.

Brigadier is not stubbed: the script uses the real library (from Gradle's cache, or compiled from Mojang's open-source
repository when no jar is found). The SLF4J and Gson jars are real as well.
