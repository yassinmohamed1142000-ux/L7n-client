package com.llamalad7.mixinextras.sugar;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import java.lang.annotation.*;
@Target(ElementType.PARAMETER) @Retention(RetentionPolicy.CLASS)
public @interface Local { boolean argsOnly() default false; int ordinal() default -1; }
