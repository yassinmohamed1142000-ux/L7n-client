package com.llamalad7.mixinextras.injector;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import java.lang.annotation.*;
import org.spongepowered.asm.mixin.injection.At;
@Target(ElementType.METHOD) @Retention(RetentionPolicy.RUNTIME)
public @interface ModifyReturnValue { String[] method(); At[] at(); boolean remap() default true; int require() default -1; }
