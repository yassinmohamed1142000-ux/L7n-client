package com.mojang.blaze3d.platform;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class InputConstants {
    public enum Type {
        KEYSYM;
    }
    public static final class Key {
        public int getValue() { return 0; }
        public net.minecraft.network.chat.Component getDisplayName() { return null; }
    }
}
