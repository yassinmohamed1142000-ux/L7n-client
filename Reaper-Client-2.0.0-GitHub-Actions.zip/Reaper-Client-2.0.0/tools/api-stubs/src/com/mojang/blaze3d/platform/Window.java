package com.mojang.blaze3d.platform;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class Window {
    public long handle() { return 0; }
    public int getGuiScaledWidth() { return 0; }
    public int getGuiScaledHeight() { return 0; }
}
