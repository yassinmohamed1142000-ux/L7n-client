package com.mojang.blaze3d.platform;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class NativeImage implements AutoCloseable {
    public NativeImage(int width, int height, boolean zero) { }
    public static NativeImage read(java.io.InputStream in) throws java.io.IOException { return null; }
    public int getWidth() { return 0; }
    public int getHeight() { return 0; }
    public int getPixel(int x, int y) { return 0; }
    public void setPixel(int x, int y, int abgr) { }
    @Override public void close() { }
}
