package net.fabricmc.fabric.api.client.command.v2;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.network.chat.Component;
public interface FabricClientCommandSource {
    void sendFeedback(Component message);
    void sendError(Component message);
}
