package net.fabricmc.fabric.api.client.networking.v1;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
public final class ClientPlayConnectionEvents {
    public static final Event<Join> JOIN = null;
    public static final Event<Disconnect> DISCONNECT = null;
    @FunctionalInterface public interface Join { void onPlayReady(ClientPacketListener handler, PacketSender sender, Minecraft client); }
    @FunctionalInterface public interface Disconnect { void onPlayDisconnect(ClientPacketListener handler, Minecraft client); }
}
