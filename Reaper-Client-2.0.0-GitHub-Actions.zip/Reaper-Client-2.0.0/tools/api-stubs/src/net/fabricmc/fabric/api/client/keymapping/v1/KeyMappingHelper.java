package net.fabricmc.fabric.api.client.keymapping.v1;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
public final class KeyMappingHelper {
    public static KeyMapping registerKeyMapping(KeyMapping keyMapping) { return keyMapping; }
    public static InputConstants.Key getBoundKeyOf(KeyMapping keyMapping) { return null; }
}
