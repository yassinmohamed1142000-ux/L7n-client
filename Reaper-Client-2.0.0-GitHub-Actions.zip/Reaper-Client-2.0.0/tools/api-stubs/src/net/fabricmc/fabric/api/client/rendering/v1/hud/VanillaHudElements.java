package net.fabricmc.fabric.api.client.rendering.v1.hud;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.resources.Identifier;
public final class VanillaHudElements {
    public static final Identifier CHAT = null;
    public static final Identifier CROSSHAIR = null;
}
