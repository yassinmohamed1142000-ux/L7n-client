package net.fabricmc.fabric.api.event;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public abstract class Event<T> { public abstract void register(T listener); }
