package net.fabricmc.fabric.api.client.screen.v1;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import java.util.List;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
public final class Screens {
    public static List<AbstractWidget> getWidgets(Screen screen) { return null; }
}
