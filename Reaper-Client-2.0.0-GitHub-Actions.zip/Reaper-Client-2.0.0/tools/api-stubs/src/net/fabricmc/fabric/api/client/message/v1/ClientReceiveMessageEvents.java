package net.fabricmc.fabric.api.client.message.v1;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.PlayerChatMessage;
import java.time.Instant;
public final class ClientReceiveMessageEvents {
    public static final Event<Chat> CHAT = null;
    public static final Event<Game> GAME = null;
    @FunctionalInterface public interface Chat {
        void onReceiveChatMessage(Component message, PlayerChatMessage signedMessage, GameProfile sender, ChatType.Bound params, Instant receptionTimestamp);
    }
    @FunctionalInterface public interface Game { void onReceiveGameMessage(Component message, boolean overlay); }
}
