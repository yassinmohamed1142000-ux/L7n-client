package net.fabricmc.fabric.api.client.screen.v1;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.fabricmc.fabric.api.event.Event;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
public final class ScreenEvents {
    public static final Event<AfterInit> AFTER_INIT = null;
    public static Event<AfterTick> afterTick(Screen screen) { return null; }
    @FunctionalInterface public interface AfterInit { void afterInit(Minecraft client, Screen screen, int scaledWidth, int scaledHeight); }
    @FunctionalInterface public interface AfterTick { void afterTick(Screen screen); }
}
