package net.fabricmc.fabric.api.client.event.lifecycle.v1;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.fabricmc.fabric.api.event.Event;
import net.minecraft.client.Minecraft;
public final class ClientTickEvents {
    public static final Event<EndTick> END_CLIENT_TICK = null;
    @FunctionalInterface public interface EndTick { void onEndTick(Minecraft client); }
}
