package net.fabricmc.fabric.api.client.rendering.v1.hud;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import java.util.function.Function;
import net.minecraft.resources.Identifier;
public final class HudElementRegistry {
    public static void attachElementBefore(Identifier beforeThis, Identifier identifier, HudElement element) { }
    public static void replaceElement(Identifier identifier, Function<HudElement, HudElement> replacer) { }
}
