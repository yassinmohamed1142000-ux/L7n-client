package net.fabricmc.loader.api;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import java.nio.file.Path;
import java.util.Optional;
public interface FabricLoader {
    static FabricLoader getInstance() { return null; }
    Path getConfigDir();
    Path getGameDir();
    Optional<ModContainer> getModContainer(String id);
}
