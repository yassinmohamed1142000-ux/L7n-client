package net.minecraft.resources;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public final class Identifier {
    public static Identifier fromNamespaceAndPath(String namespace, String path) { return null; }
}
