package net.minecraft;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class Util {
    public static OS getPlatform() { return null; }
    public enum OS { ; public void openFile(java.io.File file) { } }
}
