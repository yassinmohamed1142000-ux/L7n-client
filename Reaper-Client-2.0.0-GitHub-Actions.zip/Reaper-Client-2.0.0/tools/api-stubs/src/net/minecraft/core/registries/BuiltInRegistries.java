package net.minecraft.core.registries;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.core.Registry;
import net.minecraft.world.item.Item;
public class BuiltInRegistries { public static final Registry<Item> ITEM = null; }
