package net.minecraft.core;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public interface Holder<T> { java.util.Optional<net.minecraft.resources.ResourceKey<T>> unwrapKey(); }
