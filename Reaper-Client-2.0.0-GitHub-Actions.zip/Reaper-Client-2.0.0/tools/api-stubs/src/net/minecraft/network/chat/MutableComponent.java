package net.minecraft.network.chat;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public interface MutableComponent extends Component {
    MutableComponent withStyle(net.minecraft.ChatFormatting formatting);
    MutableComponent setStyle(Style style);
    MutableComponent append(Component other);
}
