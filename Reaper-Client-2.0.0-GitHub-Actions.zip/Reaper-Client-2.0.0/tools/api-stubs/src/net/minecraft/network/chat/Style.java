package net.minecraft.network.chat;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class Style {
    public static final Style EMPTY = null;
    public Style withColor(int rgb) { return this; }
    public Style withColor(net.minecraft.ChatFormatting formatting) { return this; }
}
