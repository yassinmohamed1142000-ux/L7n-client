package net.minecraft.world.entity;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.core.BlockPos;
public class Entity {
    public double xOld, yOld, zOld;
    public double getX() { return 0; }
    public double getY() { return 0; }
    public double getZ() { return 0; }
    public float getViewYRot(float partial) { return 0; }
    public float getViewXRot(float partial) { return 0; }
    public float getEyeHeight(Pose pose) { return 0; }
    public Pose getPose() { return null; }
    public boolean isSprinting() { return false; }
    public boolean isShiftKeyDown() { return false; }
    public boolean isSwimming() { return false; }
    public boolean isSpectator() { return false; }
    public BlockPos blockPosition() { return null; }
    public java.util.UUID getUUID() { return null; }
    public void sendSystemMessage(net.minecraft.network.chat.Component message) { }
}
