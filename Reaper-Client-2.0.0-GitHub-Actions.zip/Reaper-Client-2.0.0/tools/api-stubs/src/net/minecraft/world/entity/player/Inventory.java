package net.minecraft.world.entity.player;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class Inventory { public void setSelectedSlot(int slot) { } }
