package net.minecraft.world.item;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public final class ItemStack {
    public boolean isEmpty() { return true; }
    public net.minecraft.network.chat.Component getHoverName() { return null; }
    public boolean isDamageableItem() { return false; }
    public int getMaxDamage() { return 0; }
    public int getDamageValue() { return 0; }
    public int getCount() { return 0; }
    public int getMaxStackSize() { return 0; }
    public Item getItem() { return null; }
    public static boolean isSameItemSameComponents(ItemStack a, ItemStack b) { return false; }
}
