package net.minecraft.world.inventory;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.world.item.ItemStack;
public abstract class AbstractContainerMenu {
    public final java.util.List<Slot> slots = new java.util.ArrayList<>();
    public final int containerId = 0;
    public ItemStack getCarried() { return null; }
}
