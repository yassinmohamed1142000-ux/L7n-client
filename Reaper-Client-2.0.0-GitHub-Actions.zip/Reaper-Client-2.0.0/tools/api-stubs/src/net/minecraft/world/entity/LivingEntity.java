package net.minecraft.world.entity;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.world.item.ItemStack;
public class LivingEntity extends Entity {
    public boolean isFallFlying() { return false; }
    public ItemStack getItemBySlot(EquipmentSlot slot) { return null; }
    public ItemStack getMainHandItem() { return null; }
    public ItemStack getOffhandItem() { return null; }
}
