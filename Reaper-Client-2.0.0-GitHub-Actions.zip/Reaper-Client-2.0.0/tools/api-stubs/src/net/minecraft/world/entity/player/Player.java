package net.minecraft.world.entity.player;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.world.entity.LivingEntity;
public class Player extends LivingEntity {
    public net.minecraft.world.inventory.AbstractContainerMenu containerMenu;
    public Abilities getAbilities() { return null; }
    public com.mojang.authlib.GameProfile getGameProfile() { return null; }
}
