package net.minecraft.client.gui;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class Font { public final int lineHeight = 9; public int width(String text) { return 0; } }
