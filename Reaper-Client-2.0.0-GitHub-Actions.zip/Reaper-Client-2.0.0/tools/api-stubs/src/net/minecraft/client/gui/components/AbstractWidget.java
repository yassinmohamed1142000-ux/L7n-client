package net.minecraft.client.gui.components;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public abstract class AbstractWidget {
    public boolean visible = true, active = true;
    public void setX(int x) { }
    public void setY(int y) { }
}
