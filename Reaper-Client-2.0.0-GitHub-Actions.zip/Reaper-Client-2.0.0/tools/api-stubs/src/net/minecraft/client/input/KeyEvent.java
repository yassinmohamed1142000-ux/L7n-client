package net.minecraft.client.input;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public record KeyEvent(int key, int scancode, int modifiers) {
    public boolean hasShiftDown() { return false; }
    public boolean hasControlDown() { return false; }
}
