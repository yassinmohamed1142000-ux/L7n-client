package net.minecraft.client.gui.screens;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.*;
import net.minecraft.network.chat.Component;
public abstract class Screen {
    public int width, height;
    protected Screen(Component title) { }
    public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) { }
    public void extractBackground(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) { }
    public boolean isPauseScreen() { return true; }
    public boolean shouldCloseOnEsc() { return true; }
    public void removed() { }
    public boolean keyPressed(KeyEvent event) { return false; }
    public boolean charTyped(CharacterEvent event) { return false; }
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) { return false; }
    public boolean mouseReleased(MouseButtonEvent event) { return false; }
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) { return false; }
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) { return false; }
}
