package net.minecraft.client.renderer.texture;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class DynamicTexture extends AbstractTexture {
    public DynamicTexture(java.util.function.Supplier<String> label, com.mojang.blaze3d.platform.NativeImage image) { }
}
