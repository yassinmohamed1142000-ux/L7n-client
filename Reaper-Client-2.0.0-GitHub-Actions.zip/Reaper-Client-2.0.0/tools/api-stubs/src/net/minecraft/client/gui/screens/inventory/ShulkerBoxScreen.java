package net.minecraft.client.gui.screens.inventory;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.world.inventory.ShulkerBoxMenu;
public class ShulkerBoxScreen extends AbstractContainerScreen<ShulkerBoxMenu> { }
