package net.minecraft.client.gui;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.client.gui.Font;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import com.mojang.blaze3d.pipeline.RenderPipeline;
public class GuiGraphicsExtractor {
    public int guiWidth() { return 0; }
    public int guiHeight() { return 0; }
    public void fill(int x0, int y0, int x1, int y1, int color) { }
    public void fillGradient(int x0, int y0, int x1, int y1, int colorFrom, int colorTo) { }
    public void text(Font font, String text, int x, int y, int color, boolean shadow) { }
    public void enableScissor(int x0, int y0, int x1, int y1) { }
    public void disableScissor() { }
    public org.joml.Matrix3x2fStack pose() { return null; }
    public void item(ItemStack stack, int x, int y) { }
    public void itemDecorations(Font font, ItemStack stack, int x, int y) { }
    public void blit(RenderPipeline pipeline, Identifier texture, int x, int y, float u, float v, int w, int h, int texW, int texH) { }
    public void blit(RenderPipeline pipeline, Identifier texture, int x, int y, float u, float v, int w, int h, int texW, int texH, int color) { }
}
