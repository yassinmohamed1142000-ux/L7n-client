package net.minecraft.client.input;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public record MouseButtonInfo(int button, int modifiers) { }
