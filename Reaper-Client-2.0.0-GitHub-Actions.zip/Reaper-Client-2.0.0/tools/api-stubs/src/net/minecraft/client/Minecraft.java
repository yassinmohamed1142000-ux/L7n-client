package net.minecraft.client;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.server.IntegratedServer;
public class Minecraft {
    public static Minecraft getInstance() { return null; }
    public Screen screen;
    public ClientLevel level;
    public LocalPlayer player;
    public Options options;
    public Font font;
    public Gui gui;
    public KeyboardHandler keyboardHandler;
    public MultiPlayerGameMode gameMode;
    public com.mojang.blaze3d.platform.Window getWindow() { return null; }
    public boolean hasSingleplayerServer() { return false; }
    public IntegratedServer getSingleplayerServer() { return null; }
    public ServerData getCurrentServer() { return null; }
    public ClientPacketListener getConnection() { return null; }
    public DeltaTracker getDeltaTracker() { return null; }
    public TextureManager getTextureManager() { return null; }
    public void setScreen(Screen screen) { }
    public boolean isRunning() { return false; }
}
