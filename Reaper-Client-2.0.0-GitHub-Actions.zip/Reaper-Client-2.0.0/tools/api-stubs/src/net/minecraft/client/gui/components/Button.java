package net.minecraft.client.gui.components;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.network.chat.Component;
public class Button extends AbstractWidget {
    public static Builder builder(Component message, OnPress onPress) { return null; }
    public interface OnPress { void onPress(Button button); }
    public static class Builder {
        public Builder bounds(int x, int y, int width, int height) { return this; }
        public Button build() { return null; }
    }
}
