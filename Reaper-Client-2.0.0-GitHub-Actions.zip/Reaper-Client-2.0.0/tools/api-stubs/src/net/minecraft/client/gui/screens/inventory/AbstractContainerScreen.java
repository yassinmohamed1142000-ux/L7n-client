package net.minecraft.client.gui.screens.inventory;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.world.inventory.AbstractContainerMenu;
public abstract class AbstractContainerScreen<T extends AbstractContainerMenu> extends net.minecraft.client.gui.screens.Screen {
    protected AbstractContainerScreen() { super(null); }
    public T getMenu() { return null; }
}
