package net.minecraft.client.multiplayer;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
public class ClientLevel {
    public ResourceKey<Level> dimension() { return null; }
    public Holder<Biome> getBiome(BlockPos pos) { return null; }
    public int getBrightness(LightLayer layer, BlockPos pos) { return 0; }
    public long getOverworldClockTime() { return 0; }
}
