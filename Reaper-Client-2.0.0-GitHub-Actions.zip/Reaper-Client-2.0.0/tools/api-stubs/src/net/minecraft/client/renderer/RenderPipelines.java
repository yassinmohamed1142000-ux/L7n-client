package net.minecraft.client.renderer;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class RenderPipelines { public static final com.mojang.blaze3d.pipeline.RenderPipeline GUI_TEXTURED = null; }
