package net.minecraft.client;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import net.minecraft.client.OptionInstance;
public class Options {
    public boolean hideGui;
    public KeyMapping keyUp, keyLeft, keyDown, keyRight, keyJump, keyShift, keySprint;
    public OptionInstance<Double> gamma() { return null; }
    public CameraType getCameraType() { return null; }
}
