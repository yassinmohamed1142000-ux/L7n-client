package net.minecraft.client;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import com.mojang.blaze3d.platform.InputConstants;
public class KeyMapping {
    public KeyMapping(String name, InputConstants.Type type, int keyCode, Category category) { }
    public boolean consumeClick() { return false; }
    public boolean isDown() { return false; }
    public static final class Category {
        public static Category register(net.minecraft.resources.Identifier id) { return null; }
    }
}
