package net.minecraft.util;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class ARGB { public static int white(float alpha) { return 0; } }
