package net.minecraft.util;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class Mth {
    public static float lerp(float delta, float a, float b) { return 0; }
    public static double lerp(double delta, double a, double b) { return 0; }
}
