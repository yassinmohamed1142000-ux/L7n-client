package org.joml;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class Matrix3x2fStack extends Matrix3x2f {
    public Matrix3x2fStack pushMatrix() { return this; }
    public Matrix3x2fStack popMatrix() { return this; }
}
