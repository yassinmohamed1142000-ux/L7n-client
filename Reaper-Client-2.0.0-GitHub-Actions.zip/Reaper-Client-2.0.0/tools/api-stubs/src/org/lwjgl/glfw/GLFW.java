package org.lwjgl.glfw;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class GLFW {
    public static final int GLFW_KEY_UNKNOWN = -1;
    public static final int GLFW_KEY_Z = 90;
    public static final int GLFW_KEY_RIGHT_SHIFT = 344;
    public static final int GLFW_PRESS = 1;
    public static final int GLFW_MOUSE_BUTTON_LEFT = 0, GLFW_MOUSE_BUTTON_RIGHT = 1, GLFW_MOUSE_BUTTON_MIDDLE = 2;
    public static int glfwGetKey(long window, int key) { return 0; }
    public static int glfwGetMouseButton(long window, int button) { return 0; }
}
