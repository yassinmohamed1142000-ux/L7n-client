package org.spongepowered.asm.mixin;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import java.lang.annotation.*;
@Target({ElementType.METHOD, ElementType.FIELD}) @Retention(RetentionPolicy.RUNTIME)
public @interface Shadow { String prefix() default "shadow$"; boolean remap() default true; String[] aliases() default {}; }
