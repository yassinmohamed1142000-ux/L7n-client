package org.spongepowered.asm.mixin.injection.callback;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

public class CallbackInfo { public void cancel() { } }
