package org.spongepowered.asm.mixin.injection;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import java.lang.annotation.*;
@Target(ElementType.METHOD) @Retention(RetentionPolicy.RUNTIME)
public @interface Inject { String[] method(); At[] at() default {}; boolean cancellable() default false; boolean remap() default true; int require() default -1; }
