package org.spongepowered.asm.mixin.injection;
// Type-checking stub. NOT the real class: only the members Reaper uses, with the signatures found in 26.x reference sources.
// See tools/api-stubs/README.md and docs/API-AUDIT.md.

import java.lang.annotation.*;
@Target({}) @Retention(RetentionPolicy.RUNTIME)
public @interface At { String value(); String target() default ""; String id() default ""; int ordinal() default -1; boolean remap() default true; }
