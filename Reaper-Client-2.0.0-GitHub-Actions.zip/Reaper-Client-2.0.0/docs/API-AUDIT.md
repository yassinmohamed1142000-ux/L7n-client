# Reaper Client: API audit

Written 2026-11-21. This file belongs to the source tree and describes the state of that tree.

## 1. What this is, and what it is not

Reaper Client's game layer (`com.reaper.client.mc`, `com.reaper.client.mixin` and `ReaperClient`) is the only code
that talks to Minecraft, Fabric API, Fabric Loader, Mixin, LWJGL or JOML. It was written in an environment that could not
download or start Minecraft, Fabric Loom or any Fabric artifact. **It has therefore never been compiled against the real
game, and it has never run inside the game.** Everything else (`com.reaper.client.core`, about 80% of the main code:
9,259 of 11,431 lines) does not touch the game and is tested by `./gradlew coreTests` (3,947 checks at the time of writing, all passing).

What was done instead, in order of strength:

1. Every game member the layer uses was looked up in the sources of other mods that build against Minecraft 26.x
   (section 3). This document lists the result for each of them (section 7).
2. The whole layer was type-checked with `javac` against small hand-written stand-ins for those members
   (`tools/api-stubs`, run by `tools/check-adapters.sh`: 107 source files, no errors, no warnings). This catches typos,
   wrong argument counts, wrong generics and unhandled exceptions. It cannot tell whether the real game has a member,
   because a stub is only as good as the evidence behind it.
3. Members with no 26.1 evidence are reached by reflection and fail soft (section 4); every mixin is optional (section 5).

None of this replaces `./gradlew build` followed by a play test. BUILD.md has the checklist.

## 2. How to read the evidence

Each game member has a **Result**:

| Result | Meaning |
|---|---|
| seen | A line in a project built for Minecraft 26.1.x imports the class and uses a member with that name and that number of arguments. |
| seen* | Same, but the call runs over several lines, so the number of arguments could not be read. |
| name only | Such a line exists, but its file does not import the class (the receiver is a field or a local of that type). The name and argument count match; a coincidence is possible. |
| defined in ref | The class is part of a reference project (Fabric API) and the member is declared there. |
| newer game only | The only line found is in a project built for Minecraft 26.3. |
| seen (checked by hand) | The automatic search picked a coincidental line, so one real use was looked up by hand. |

**What "seen" does not prove:** parameter and return *types*, and run-time behaviour. A name and an argument count can
match while a type does not. That is exactly what the compiler will check on your machine.

## 3. Reference projects

All were cloned on 2026-11-21. "Built for" is the `minecraft_version` in the project's own build files.

| Short name | Project, branch @ commit (date) | Built for |
|---|---|---|
| wurst | Wurst-Imperium/Wurst7, `26.1.2` @ eacf17e (2026-11-03) | 26.1.2 |
| malilib | sakura-ryoko/malilib, `LTS/26.1` @ 23066a8 (2026-09-26) | 26.1.2 |
| modmenu | TerraformersMC/ModMenu, `26.1` @ 1f0477e (2026-09-24) | 26.1 |
| sodium | CaffeineMC/sodium, `26.1.2/stable` @ 93c7711 (2026-09-20) | 26.1.2 |
| fabric-api | FabricMC/fabric, `26.1.2` @ 1abe282 (2026-09-07), plus tags `0.145.4+26.1.2` and `0.155.3+26.1.2` | 26.1.2 |
| baritone | cabaletta/baritone, `26.1` @ 016cc21 (2026-08-31) | 26.1.2 |
| zoomify | isXander/Zoomify, `main` @ 4abaf61 (2026-10-08) | a 26.x release (not stated in the files read) |
| meteor | MeteorDevelopment/meteor-client, `master` @ 40db8a1 (2026-11-11) | **26.3**: used only when no 26.1 project has the member |
| mixin | FabricMC/Mixin, `main` @ b5acee9 (2026-11-01) | the Mixin library itself, for failure behaviour |

Brigadier (the command library) and SLF4J and Gson are real libraries, not stubs, and come with the game.

## 4. What is not confirmed on 26.1.x, and what the code does about it

Totals for section 7: **191 game members in 115 classes. 189 have a line from a 26.1.x project, 2 only from the 26.3 project.**
The items below are the honest list of everything beyond that. None of them stops the game from starting; the first group
could stop the *build* (a compile error), the others only switch one feature off or make it look slightly off.

### 4.1 Could break the build if the member does not exist

| Member | Evidence | Where it is used | If the compiler rejects it |
|---|---|---|---|
| `Options.getCameraType()` and `CameraType.isFirstPerson()` | Only the 26.3 project (Meteor: `Nametags.java:333`, `Freecam.java:238`). Fabric API's 26.1.2 game test calls the matching setter and the enum constants: `client.options.setCameraType(CameraType.FIRST_PERSON)` (`ClientGameTestTest.java:101-150`). Both are plain vanilla members that have existed since 1.15. | `Game.drawOwnCrosshair`, one condition | In `Game.drawOwnCrosshair`, delete `!m.options.getCameraType().isFirstPerson() ||` from the `if`: the custom crosshair is then also drawn in third person. Nothing else depends on it. |

Every other direct call has a line in a 26.1.x project (section 7). A signature *type* mismatch can still exist: see
section 2.

### 4.2 Found by reflection, with a safe fallback

| Member | Evidence | Fallback when it is not found |
|---|---|---|
| `KeyboardHandler.getClipboard()` | Only the 26.3 project (`Meteor: NbtUtils.java:51`). No 26.1 project reads the clipboard through the game. | Paste inside Reaper's own text fields uses Reaper's own copy buffer. Copying still goes to the system clipboard through `KeyboardHandler.setClipboard` (Wurst 26.1.2: `ViewCompCmd.java:72`). One warning in the log. |
| `PlayerInfo.getLatency()` | Only the 26.3 project (`Meteor: PlayerUtils.java:371`). | The Ping element does not appear. One warning in the log. |
| The "reduced debug info" flag the server can send (`Minecraft.showOnlyReducedInfo()`, then `isReducedDebugInfo()` / `hasReducedDebugInfo()` on the player) | **No reference reads it**; the names are a best guess. | The flag counts as "reduced" on multiplayer servers: the Coordinates, World information and Waypoints elements and the waypoint markers stay hidden there. Singleplayer is not affected. This is the cautious default. One warning in the log. |
| `TextureManager.release(Identifier)` | malilib `LTS/26.1`: `GuiColorEditorHSV.java:729`. | Screenshot thumbnails stay registered until the game closes (a few small textures). |

The reflection code is `mc/Reflect.java`. It looks members up by name (Minecraft 26.1 is not obfuscated, so the names in
the running game are the names in the source) and catches every failure.

### 4.3 Behaviour that could not be observed

| Point | What the code assumes | What you would see if it is wrong |
|---|---|---|
| Scissor under a scaled transform | `GuiGraphicsExtractor.enableScissor` takes GUI coordinates and respects the current pose scale. | Lists inside windows clip at the wrong rectangle when the GUI scale setting is not 1.0. Set Client, Scale to 1.0 to confirm. |
| Draw order | Fills, text and items drawn later appear above earlier ones. | An item icon or a piece of text on the wrong side of a popup. |
| Custom crosshair position | The centre of the game's 15 x 15 crosshair is `(guiWidth - 15) / 2 + 7` (same for the height). | The crosshair is one pixel off. Switching the custom crosshair off hands drawing back to the game. |
| Inventory clicks | The sorter sends ordinary `PICKUP` clicks through `MultiPlayerGameMode.handleContainerInput(containerId, slot, 0, ContainerInput.PICKUP, player)` (the same call Wurst 26.1.2 makes in `AutoLibrarianHack.java:246`) and checks every slot index against the open container before each click. The sorting plan itself is tested in the core against a simulated container, not against the real menu. | Items end up in an unexpected order. The run stops on the first inconsistency. It is switched off on STRICT servers. |
| Zoom and the hand | Only the field of view of the world is changed. | The held item keeps its normal size while zoomed (Wurst also adjusts `calculateHudFov`; Reaper does not). |
| Singleplayer world names | `server.getWorldData().getLevelName()` names the world a waypoint list belongs to (malilib `LTS/26.1`: `StringUtils.java:596`). | A renamed singleplayer world starts a new, empty waypoint list. |
| Mojo Launcher | Nothing in the mod depends on the launcher. | Not tested; any launcher that starts a Fabric profile with Fabric Loader 0.18.4 or newer should load the jar. |

### 4.4 Build tool chain

`gradle.properties` pins Minecraft 26.1.2, Fabric Loader 0.18.4, Fabric API 0.145.4+26.1.2, Loom 1.15.5 and Gradle 9.4.0.
Fabric API's own 26.1.2 branch builds with Loom 1.15.5 (`build.gradle:5`), Gradle 9.4.0 (`gradle-wrapper.properties:3`)
and Loader 0.18.4 (`gradle.properties:7`); Mod Menu's 26.1 branch uses Loom 1.15-SNAPSHOT, Gradle 9.2.1 and Loader 0.18.4.
`fabric.mod.json` asks for exactly the same minimums (`fabricloader >=0.18.4`, `fabric-api >=0.145.4`, `minecraft ~26.1`,
`java >=25`). **The build was never run here** (no access to the Fabric and Mojang servers). The parts that do not need
them were run under Gradle 8.14.3: resource expansion, jar naming, the licence file, the sources jar and the `coreTests` task.

## 5. Mixins

All five mixin classes are listed in `reaper.mixins.json` with `"required": false` and `injectors.defaultRequire: 0`.
In Mixin's own source, a mixin that fails to apply in a non-required config is downgraded to a warning:
`MixinProcessor.java:651`: `ErrorAction action = config.isRequired() ? ErrorAction.ERROR : ErrorAction.WARN;`
The game starts, the log names the mixin, and only the feature behind it stops working. (Wurst, Mod Menu and malilib use the strict
setting, `"required": true` and `"defaultRequire": 1`; Reaper deliberately does not.) The MixinExtras setting
`"mixinextras": {"minVersion": "0.5.0"}` is the same as in Wurst's `wurst.mixins.json:6-7`.
`/reaper status` reports whether each hook has been seen working during play.

| Mixin | Target | Evidence | If it does not apply |
|---|---|---|---|
| `CameraMixin` | `Camera.calculateFov(F)F`, `@ModifyReturnValue` at `RETURN` | Identical in Wurst 26.1.2: `mixin/zoom/CameraMixin.java:24`. Also Zoomify and Meteor (`calculateFov`). | Zoom does nothing. |
| `MouseHandlerMixin.reaper$sensitivity` | `MouseHandler.turnPlayer(D)V`, `@ModifyExpressionValue` on `Double.doubleValue()D` | Identical in Wurst 26.1.2: `mixin/zoom/MouseHandlerMixin.java:24-25`. Zoomify hooks the same method through `OptionInstance.get()`. | Sensitivity is not lowered while zoomed. |
| `MouseHandlerMixin.reaper$button` | `MouseHandler.onButton(JLnet/minecraft/client/input/MouseButtonInfo;I)V`, `HEAD` | Same descriptor in Wurst 26.1.2: `mixin/MouseHandlerMixin.java:36`. | CPS falls back to the button state sampled once per frame; a click shorter than a frame can be missed. |
| `MouseHandlerMixin.reaper$scrollStart/End` | `MouseHandler.onScroll(JDD)V`, `HEAD` and `RETURN` | The 26.3 project has `onScroll(long, double, double)` (`Meteor: mixin/MouseHandlerMixin.java:47`); Fabric API and malilib hook `onScroll` by name. | The mouse wheel cannot change the zoom factor (the setting still can). |
| `MouseHandlerMixin.reaper$hotbar` | `@WrapWithCondition` on the `Inventory.setSelectedSlot(I)V` call inside `onScroll` | The method exists in 26.1 (Baritone: `InventoryBehavior.java:203`). **No reference hooks this call**; that `onScroll` makes it is taken from the vanilla code. | The hotbar also scrolls while zoomed. |
| `ChatComponentMixin` | `ChatComponent.addMessage(Component, MessageSignature, GuiMessageSource, GuiMessageTag)V`, `HEAD`, with `@Local(argsOnly = true) LocalRef<Component>` | Identical in Wurst 26.1.2: `mixin/ChatComponentMixin.java:41-50`. | No time stamps in chat. |
| `OptionInstanceMixin` | Shadows `OptionInstance.value` and `OptionInstance.onValueUpdate` (a `Consumer<T>`) | Identical in Wurst 26.1.2: `mixin/OptionInstanceMixin.java`. **The 26.3 project has a different type for `onValueUpdate`** (`OptionInstance.ValueUpdateListener`), so this mixin is right for 26.1.x only and is dropped on a newer game. | Fullbright cannot go past the slider's own maximum (brightness 1.0). It still works inside that range. |
| `AbstractContainerScreenAccessor` | Reads the fields `leftPos`, `topPos`, `imageWidth` | Wurst 26.1.2: `mixin/autosteal/AbstractContainerScreenMixin.java:31-35`; malilib `LTS/26.1`: `IMixinAbstractContainerScreen.java:14`. | The Sort buttons do not appear (the failure is caught and logged once). |

## 6. Fabric API

Modules used, and the classes imported from them. Each class below was compared file by file between the tags
`0.145.4+26.1.2` (the compile version) and `0.155.3+26.1.2` (the newest build for 26.1.2): **all 13 are byte-identical**.
Between those two tags Fabric changed other classes (atlas and block-colour registries, `ScreenKeyboardEvents`) and
some internals; Reaper uses none of them. Reaper does not use `ScreenKeyboardEvents`.

| Module | Classes |
|---|---|
| fabric-key-mapping-api-v1 | `KeyMappingHelper` |
| fabric-screen-api-v1 | `Screens`, `ScreenEvents` |
| fabric-rendering-v1 | `HudElementRegistry`, `VanillaHudElements`, `HudElement` |
| fabric-networking-api-v1 | `ClientPlayConnectionEvents` |
| fabric-message-api-v1 | `ClientReceiveMessageEvents` |
| fabric-lifecycle-events-v1 | `ClientTickEvents`, `ClientLifecycleEvents` |
| fabric-command-api-v2 | `ClientCommands`, `ClientCommandRegistrationCallback`, `FabricClientCommandSource` |

`fabric-screen-api-v1` rewrote the internals of its button list between the two versions. Reaper only appends buttons
(`Screens.getWidgets(screen).add(button)`), which behaves the same in both.

## 7. Every game member the layer uses

Generated by comparing each member of each stub in `tools/api-stubs/src` with the reference projects (section 3).
"Used by" names the Reaper files that import the class. The "reference line" is one real line from a reference project.
Members that Reaper does not call are not in the stubs and therefore not here.


#### `com.llamalad7.mixinextras.injector.ModifyExpressionValue`

Used by: `mixin/MouseHandlerMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/zoom/MouseHandlerMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `method()` | seen | `@ModifyExpressionValue(method = "turnPlayer(D)V",` (wurst: src/main/java/net/wurstclient/mixin/zoom/MouseHandlerMixin.java:24) |
| `at()` | seen | `at = @At(value = "INVOKE", target = "Ljava/lang/Double;doubleValue()D"))` (wurst: src/main/java/net/wurstclient/mixin/zoom/MouseHandlerMixin.java:25) |

#### `com.llamalad7.mixinextras.injector.ModifyReturnValue`

Used by: `mixin/CameraMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/safewalk/PlayerMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `method()` | seen | `@ModifyReturnValue(method = "isStayingOnGroundSurface()Z",` (wurst: src/main/java/net/wurstclient/mixin/safewalk/PlayerMixin.java:28) |
| `at()` | seen | `at = @At("RETURN"))` (wurst: src/main/java/net/wurstclient/mixin/safewalk/PlayerMixin.java:29) |

#### `com.llamalad7.mixinextras.injector.v2.WrapWithCondition`

Used by: `mixin/MouseHandlerMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/MouseHandlerMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `method()` | seen | `method = "onButton(JLnet/minecraft/client/input/MouseButtonInfo;I)V",` (wurst: src/main/java/net/wurstclient/mixin/MouseHandlerMixin.java:36) |
| `at()` | seen | `at = @At("HEAD"))` (wurst: src/main/java/net/wurstclient/mixin/MouseHandlerMixin.java:37) |

#### `com.llamalad7.mixinextras.sugar.Local`

Used by: `mixin/ChatComponentMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/MinecraftMixin.java


#### `com.llamalad7.mixinextras.sugar.ref.LocalRef`

Used by: `mixin/ChatComponentMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/ChatScreenMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `get()` | seen | `if(message.get().isEmpty())` (wurst: src/main/java/net/wurstclient/mixin/ChatScreenMixin.java:41) |
| `set(T value)` | seen | `message.set(event.getMessage());` (wurst: src/main/java/net/wurstclient/mixin/ChatScreenMixin.java:58) |

#### `com.mojang.authlib.GameProfile`

Used by: `mc/Game.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/AltRenderer.java


#### `com.mojang.blaze3d.pipeline.RenderPipeline`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/WurstShaderPipelines.java


#### `com.mojang.blaze3d.platform.InputConstants`

Used by: `mc/ClientKeys.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/BindsCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getValue()` | seen (checked by hand) | `InputConstants.UNKNOWN.getValue(),` (modmenu: src/main/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java:37) |
| `getDisplayName()` | seen | `return InputConstants.getKey(key).getDisplayName().getString();` (wurst: src/main/java/net/wurstclient/keybinds/Keybind.java:72) |
| `KEYSYM` | seen | `case KEYSYM:` (wurst: src/main/java/net/wurstclient/mixin/KeyMappingMixin.java:64) |

#### `com.mojang.blaze3d.platform.NativeImage`

Used by: `mc/ThumbnailCache.java`  
Class seen in: wurst: src/gametest/java/net/wurstclient/gametest/WurstClientTestHelper.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `NativeImage(int width, int height, boolean zero)` | seen | `try (NativeImage image = new NativeImage(sizeW, sizeH, false))` (malilib: src/main/java/fi/dy/masa/malilib/gui/GuiColorEditorHSV.java:687) |
| `read(java.io.InputStream in)` | seen | `return NativeImage.read(inputStream);` (wurst: …metest/java/net/wurstclient/gametest/WurstClientTestHelper.java:206) |
| `getWidth()` | seen | `int width = template.getWidth();` (wurst: …metest/java/net/wurstclient/gametest/WurstClientTestHelper.java:144) |
| `getHeight()` | seen | `int height = template.getHeight();` (wurst: …metest/java/net/wurstclient/gametest/WurstClientTestHelper.java:145) |
| `getPixel(int x, int y)` | seen | `if(getColorDifference(reference.getPixel(x, y),` (wurst: …ava/net/wurstclient/gametest/tests/NoShieldOverlayHackTest.java:169) |
| `setPixel(int x, int y, int abgr)` | seen | `image.setPixel(x, ((sizeH - 1) - y), Color.HSBtoRGB(this.relH, saturation, brightness));` (malilib: src/main/java/fi/dy/masa/malilib/gui/GuiColorEditorHSV.java:705) |
| `close()` | seen | `this.vertexBuffer.close();` (malilib: src/main/java/fi/dy/masa/malilib/render/RenderContext.java:267) |

#### `com.mojang.blaze3d.platform.Window`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/KeyMappingMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `handle()` | seen | `return GLFW.glfwGetMouseButton(window.handle(), code) == 1;` (wurst: src/main/java/net/wurstclient/mixin/KeyMappingMixin.java:40) |
| `getGuiScaledWidth()` | seen | `return (int) (mc.mouseHandler.xpos() * (double) window.getGuiScaledWidth() / (double) window.getScreenWidth());` (malilib: src/main/java/fi/dy/masa/malilib/util/InputUtils.java:16) |
| `getGuiScaledHeight()` | seen | `return (int) (mc.mouseHandler.ypos() * (double) window.getGuiScaledHeight() / (double) window.getScreenHeight());` (malilib: src/main/java/fi/dy/masa/malilib/util/InputUtils.java:23) |

#### `net.fabricmc.api.ClientModInitializer`

Used by: `ReaperClient.java`  
Class seen in: modmenu: src/main/java/com/terraformersmc/modmenu/ModMenu.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `onInitializeClient()` | seen | `public void onInitializeClient() {` (modmenu: src/main/java/com/terraformersmc/modmenu/ModMenu.java:93) |

#### `net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback`

Used by: `mc/Game.java`  
Class seen in: fabric-api: fabric-sound-api-v1/src/testmodClient/java/net/fabricmc/fabric/test/sound/client/ClientSoundTest.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `register(CommandDispatcher<FabricClientCommandSource> dispatcher, Com…` | seen* | `ClientCommandRegistrationCallback.EVENT.register((dispatcher, buildContext) -> {` (fabric-api: …java/net/fabricmc/fabric/test/sound/client/ClientSoundTest.java:33) |

#### `net.fabricmc.fabric.api.client.command.v2.ClientCommands`

Used by: `mc/ReaperCommands.java`  
Class seen in: fabric-api: fabric-sound-api-v1/src/testmodClient/java/net/fabricmc/fabric/test/sound/client/ClientSoundTest.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `literal(String name)` | seen | `dispatcher.register(ClientCommands.literal("sine").executes(o -> {` (fabric-api: …java/net/fabricmc/fabric/test/sound/client/ClientSoundTest.java:34) |
| `argument(String name, ArgumentType<T> type)` | seen | `help.then(argument("command", StringArgumentType.greedyString()).executes(ClientCommandInternals::executeArgumentHelp…` (fabric-api: …fabricmc/fabric/impl/command/client/ClientCommandInternals.java:142) |

#### `net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource`

Used by: `mc/ReaperCommands.java`  
Class seen in: fabric-api: fabric-command-api-v2/src/client/java/net/fabricmc/fabric/impl/command/client/ClientCommandInternals.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `sendFeedback(Component message)` | seen | `context.getSource().sendFeedback(Component.literal("/" + command));` (fabric-api: …fabricmc/fabric/impl/command/client/ClientCommandInternals.java:173) |
| `sendError(Component message)` | seen | `source.sendError(getErrorMessage(e));` (fabric-api: …fabricmc/fabric/impl/command/client/ClientCommandInternals.java:97) |

#### `net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents`

Used by: `mc/Game.java`  
Class seen in: fabric-api: fabric-rendering-v1/src/client/java/net/fabricmc/fabric/impl/client/rendering/hud/HudStatusBarHeightRegistryImpl.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `onClientStopping(Minecraft client)` | seen | `ClientLifecycleEvents.CLIENT_STOPPING.invoker().onClientStopping((Minecraft) (Object) this);` (fabric-api: …abricmc/fabric/mixin/event/lifecycle/client/MinecraftMixin.java:46) |
| `CLIENT_STOPPING` | seen | `ClientLifecycleEvents.CLIENT_STOPPING.invoker().onClientStopping((Minecraft) (Object) this);` (fabric-api: …abricmc/fabric/mixin/event/lifecycle/client/MinecraftMixin.java:46) |

#### `net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents`

Used by: `mc/Game.java`  
Class seen in: modmenu: src/main/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `onEndTick(Minecraft client)` | seen | `private void onEndTick(CallbackInfo info) {` (fabric-api: …abricmc/fabric/mixin/event/lifecycle/client/MinecraftMixin.java:40) |
| `END_CLIENT_TICK` | seen | `ClientTickEvents.END_CLIENT_TICK.register(ModMenuEventHandler::onClientEndTick);` (modmenu: …/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java:43) |

#### `net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper`

Used by: `mc/ClientKeys.java`, `mc/GameData.java`  
Class seen in: modmenu: src/main/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `registerKeyMapping(KeyMapping keyMapping)` | seen* | `MENU_KEY_MAPPING = KeyMappingHelper.registerKeyMapping(new KeyMapping(` (modmenu: …/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java:37) |
| `getBoundKeyOf(KeyMapping keyMapping)` | defined in ref | `public static InputConstants.Key getBoundKeyOf(KeyMapping keyMapping) {` (definition: …/fabricmc/fabric/api/client/keymapping/v1/KeyMappingHelper.java:61) |

#### `net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents`

Used by: `mc/Game.java`  
Class seen in: fabric-api: fabric-message-api-v1/src/client/java/net/fabricmc/fabric/mixin/client/message/ChatListenerMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `onReceiveChatMessage(Component message, PlayerChatMessage signedMessa…` | seen | `ClientReceiveMessageEvents.CHAT.invoker().onReceiveChatMessage(message, signedMessage, sender, boundChatType, recepti…` (fabric-api: …net/fabricmc/fabric/mixin/client/message/ChatListenerMixin.java:63) |
| `onReceiveGameMessage(Component message, boolean overlay)` | seen | `ClientReceiveMessageEvents.GAME.invoker().onReceiveGameMessage(message.get(), false);` (fabric-api: …net/fabricmc/fabric/mixin/client/message/ChatListenerMixin.java:74) |
| `CHAT` | seen | `ClientReceiveMessageEvents.CHAT.invoker().onReceiveChatMessage(message, signedMessage, sender, boundChatType, recepti…` (fabric-api: …net/fabricmc/fabric/mixin/client/message/ChatListenerMixin.java:63) |
| `GAME` | seen | `ClientReceiveMessageEvents.GAME.invoker().onReceiveGameMessage(message.get(), false);` (fabric-api: …net/fabricmc/fabric/mixin/client/message/ChatListenerMixin.java:74) |

#### `net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents`

Used by: `mc/Game.java`  
Class seen in: fabric-api: fabric-networking-api-v1/src/client/java/net/fabricmc/fabric/impl/networking/client/ClientNetworkingImpl.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `onPlayReady(ClientPacketListener handler, PacketSender sender, Minecr…` | seen | `ClientPlayConnectionEvents.JOIN.invoker().onPlayReady(this.listener, this, this.client);` (fabric-api: …ricmc/fabric/impl/networking/client/ClientPlayNetworkAddon.java:60) |
| `onPlayDisconnect(ClientPacketListener handler, Minecraft client)` | seen | `ClientPlayConnectionEvents.DISCONNECT.invoker().onPlayDisconnect(this.listener, this.client);` (fabric-api: …ricmc/fabric/impl/networking/client/ClientPlayNetworkAddon.java:98) |
| `JOIN` | seen | `ClientPlayConnectionEvents.JOIN.invoker().onPlayReady(this.listener, this, this.client);` (fabric-api: …ricmc/fabric/impl/networking/client/ClientPlayNetworkAddon.java:60) |
| `DISCONNECT` | seen | `ClientPlayConnectionEvents.DISCONNECT.register((listener, client) -> {` (fabric-api: …abricmc/fabric/impl/networking/client/ClientNetworkingImpl.java:138) |

#### `net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement`

Used by: `mc/Game.java`  
Class seen in: fabric-api: fabric-rendering-v1/src/client/java/net/fabricmc/fabric/impl/client/rendering/hud/HudStatusBarHeightRegistryImpl.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `extractRenderState(GuiGraphicsExtractor graphics, DeltaTracker deltaT…` | seen | `layer.extractRenderState(graphics, deltaTracker);` (fabric-api: …c/impl/client/rendering/hud/HudStatusBarHeightRegistryImpl.java:379) |

#### `net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry`

Used by: `mc/Game.java`  
Class seen in: fabric-api: fabric-transfer-api-v1/src/testmodClient/java/net/fabricmc/fabric/test/transfer/ingame/client/FluidVariantRenderTest.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `attachElementBefore(Identifier beforeThis, Identifier identifier, Hud…` | seen | `HudElementRegistry.attachElementBefore(testIdentifier("layer1"), testIdentifier("before1"), testElement("before1"));` (fabric-api: …mc/fabric/impl/client/rendering/hud/HudElementRegistryTest.java:70) |
| `replaceElement(Identifier identifier, Function<HudElement, HudElement…` | seen* | `HudElementRegistry.replaceElement(id, (HudElement layer) -> {` (fabric-api: …c/impl/client/rendering/hud/HudStatusBarHeightRegistryImpl.java:369) |

#### `net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements`

Used by: `mc/Game.java`  
Class seen in: fabric-api: fabric-rendering-v1/src/client/java/net/fabricmc/fabric/impl/client/rendering/hud/HudStatusBarHeightRegistryImpl.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `CHAT` | seen | `VanillaHudElements.CHAT,` (fabric-api: …mc/fabric/impl/client/rendering/hud/HudElementRegistryImpl.java:60) |
| `CROSSHAIR` | seen | `VanillaHudElements.CROSSHAIR,` (fabric-api: …mc/fabric/impl/client/rendering/hud/HudElementRegistryImpl.java:41) |

#### `net.fabricmc.fabric.api.client.screen.v1.ScreenEvents`

Used by: `mc/InventoryTools.java`  
Class seen in: modmenu: src/main/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `afterTick(Screen screen)` | seen | `callback.afterTick(screen);` (fabric-api: …/net/fabricmc/fabric/impl/client/screen/ScreenEventFactory.java:72) |
| `afterInit(Minecraft client, Screen screen, int scaledWidth, int scale…` | seen | `ScreenEvents.AFTER_INIT.invoker().afterInit(Minecraft.getInstance(), (Screen) (Object) this, width, height);` (fabric-api: …c/client/java/net/fabricmc/fabric/mixin/screen/ScreenMixin.java:184) |
| `AFTER_INIT` | seen | `ScreenEvents.AFTER_INIT.register(ModMenuEventHandler::afterScreenInit);` (modmenu: …/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java:44) |

#### `net.fabricmc.fabric.api.client.screen.v1.Screens`

Used by: `mc/InventoryTools.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getWidgets(Screen screen)` | seen | `for(AbstractWidget button : Screens.getWidgets(this))` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:502) |

#### `net.fabricmc.fabric.api.event.Event`

Used by: -  
Class seen in: fabric-api: fabric-item-api-v1/src/client/java/net/fabricmc/fabric/api/client/item/v1/ItemTooltipCallback.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `register(T listener)` | seen* | `DefaultItemComponentEvents.MODIFY.register(context -> {` (fabric-api: …ava/net/fabricmc/fabric/test/item/DefaultItemComponentTest.java:43) |

#### `net.fabricmc.fabric.api.networking.v1.PacketSender`

Used by: -  
Class seen in: fabric-api: fabric-permission-api-v1/src/testmod/java/net/fabricmc/fabric/test/permission/PermissionTestMod.java


#### `net.fabricmc.loader.api.FabricLoader`

Used by: `mc/Game.java`  
Class seen in: wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getInstance()` | seen | `return FabricLoader.getInstance().getModContainer(modId)` (wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java:89) |
| `getConfigDir()` | seen | `path = FabricLoader.getInstance().getConfigDir().resolve(ModMenu.MOD_ID + ".json");` (modmenu: …ava/com/terraformersmc/modmenu/config/ModMenuConfigManager.java:29) |
| `getGameDir()` | seen | `Path modsDirectory = FabricLoader.getInstance().getGameDir().resolve("mods");` (modmenu: src/main/java/com/terraformersmc/modmenu/gui/ModsScreen.java:569) |
| `getModContainer(String id)` | seen | `return FabricLoader.getInstance().getModContainer(modId)` (wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java:89) |

#### `net.fabricmc.loader.api.ModContainer`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getMetadata()` | seen | `ModMetadata metadata = entrypoint.getProvider().getMetadata();` (modmenu: src/main/java/com/terraformersmc/modmenu/ModMenu.java:103) |

#### `net.fabricmc.loader.api.Version`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getFriendlyString()` | seen | `return new FabricLoaderUpdateInfo(match.getFriendlyString(), stableVersion);` (modmenu: …ormersmc/modmenu/util/mod/fabric/FabricLoaderUpdateChecker.java:114) |

#### `net.fabricmc.loader.api.metadata.ModMetadata`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getVersion()` | seen | `map.put(meta.getId(), meta.getVersion().getFriendlyString());` (malilib: src/main/java/fi/dy/masa/malilib/MaLiLibFabricData.java:26) |

#### `net.minecraft.ChatFormatting`

Used by: `mc/Game.java`, `mc/ReaperCommands.java`  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/HealthTagsHack.java


#### `net.minecraft.Util`

Used by: `mc/Game.java`  
Class seen in: **no reference imports it**

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getPlatform()` | name only | `Util.getPlatform().openFile(skinFolder.toFile());` (wurst: …in/java/net/wurstclient/altmanager/screens/AltEditorScreen.java:107) |
| `openFile(java.io.File file)` | name only | `Util.getPlatform().openFile(skinFolder.toFile());` (wurst: …in/java/net/wurstclient/altmanager/screens/AltEditorScreen.java:107) |

#### `net.minecraft.client.Camera`

Used by: `mixin/CameraMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/util/RenderUtils.java


#### `net.minecraft.client.CameraType`

Used by: -  
Class seen in: fabric-api: fabric-client-gametest-api-v1/src/testmodClient/java/net/fabricmc/fabric/test/client/gametest/ClientGameTestTest.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `isFirstPerson()` | newer game only | `if (!perspective.isFirstPerson()) mc.options.setCameraType(CameraType.FIRST_PERSON);` (meteor: …eordevelopment/meteorclient/systems/modules/render/Freecam.java:238) |

#### `net.minecraft.client.DeltaTracker`

Used by: `mc/Game.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/GuiMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getGameTimeDeltaPartialTick(boolean ignoreFreeze)` | seen | `float tickDelta = tickCounter.getGameTimeDeltaPartialTick(true);` (wurst: src/main/java/net/wurstclient/mixin/GuiMixin.java:38) |

#### `net.minecraft.client.KeyMapping`

Used by: `mc/ClientKeys.java`, `mc/Game.java`, `mc/GameData.java`  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/MileyCyrusHack.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `KeyMapping(String name, InputConstants.Type type, int keyCode, Catego…` | seen* | `MENU_KEY_MAPPING = KeyMappingHelper.registerKeyMapping(new KeyMapping(` (modmenu: …/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java:37) |
| `consumeClick()` | seen | `while (MENU_KEY_MAPPING.consumeClick()) {` (modmenu: …/java/com/terraformersmc/modmenu/event/ModMenuEventHandler.java:138) |
| `isDown()` | seen | `sneakKey.setDown(!sneakKey.isDown());` (wurst: src/main/java/net/wurstclient/hacks/MileyCyrusHack.java:57) |
| `register(net.minecraft.resources.Identifier id)` | seen (checked by hand) | `KeyMapping.Category category2 = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("fabric-key-mapping-api-v1-testmod", "test_category_2"));` (fabric-api: fabric-key-mapping-api-v1/src/testmodClient/java/net/fabricmc/fabric/test/client/keymapping/KeyMappingsTest.java:35) |

#### `net.minecraft.client.KeyboardHandler`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/KeyboardHandlerMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `setClipboard(String text)` | name only | `MC.keyboardHandler.setClipboard(compString);` (wurst: src/main/java/net/wurstclient/commands/ViewCompCmd.java:72) |

#### `net.minecraft.client.Minecraft`

Used by: `mc/BrightnessControl.java`, `mc/Game.java`, `mc/GameData.java`, `mc/InventoryTools.java`, `mc/McCanvas.java`, `mc/ThumbnailCache.java`, `mixin/OptionInstanceMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getInstance()` | seen | `return FabricLoader.getInstance().getModContainer(modId)` (wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java:89) |
| `getWindow()` | seen | `windows.add(WurstClient.INSTANCE.getHax().radarHack.getWindow());` (wurst: src/main/java/net/wurstclient/clickgui/ClickGui.java:99) |
| `hasSingleplayerServer()` | seen | `default boolean hasSingleplayerServer() {return Minecraft.getInstance().hasSingleplayerServer();}` (malilib: src/main/java/fi/dy/masa/malilib/interfaces/IDataSyncer.java:160) |
| `getSingleplayerServer()` | seen | `if (this.hasSingleplayerServer() && Minecraft.getInstance().getSingleplayerServer() != null)` (malilib: src/main/java/fi/dy/masa/malilib/interfaces/IDataSyncer.java:169) |
| `getCurrentServer()` | seen | `ServerData server = client.getCurrentServer();` (wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java:119) |
| `getConnection()` | seen | `ClientPacketListener netHandler = MC.getConnection();` (wurst: …/main/java/net/wurstclient/other_features/NoChatReportsOtf.java:62) |
| `getDeltaTracker()` | seen | `float delta = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);` (malilib: …/java/fi/dy/masa/malilib/test/render/TestTextPlateRenderer.java:85) |
| `getTextureManager()` | seen | `AbstractTexture tex = this.mc().getTextureManager().getTexture(id);` (malilib: src/main/java/fi/dy/masa/malilib/render/GuiContext.java:112) |
| `setScreen(Screen screen)` | seen | `minecraft.setScreen(screen);` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:109) |
| `isRunning()` | seen | `if(!Minecraft.getInstance().isRunning())` (wurst: src/main/java/net/wurstclient/mixin/OptionInstanceMixin.java:34) |

#### `net.minecraft.client.MouseHandler`

Used by: `mixin/MouseHandlerMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/events/MouseUpdateListener.java


#### `net.minecraft.client.OptionInstance`

Used by: `mc/BrightnessControl.java`, `mixin/OptionInstanceMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixinterface/IOptionInstance.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `get()` | seen | `double gamma = MC.options.gamma().get();` (wurst: src/main/java/net/wurstclient/hacks/FullbrightHack.java:71) |
| `set(T value)` | seen | `options.cloudStatus().set(CloudStatus.OFF);` (fabric-api: …ric/impl/client/gametest/context/ClientGameTestContextImpl.java:95) |

#### `net.minecraft.client.Options`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/TunnellerHack.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `gamma()` | name only | `IOptionInstance.get(MC.options.gamma())` (wurst: src/main/java/net/wurstclient/hacks/XRayHack.java:151) |
| `getCameraType()` | newer game only | `boolean notThirdPerson = mc.options.getCameraType().isFirstPerson();` (meteor: …ordevelopment/meteorclient/systems/modules/render/Nametags.java:333) |

#### `net.minecraft.client.gui.Font`

Used by: `mc/McCanvas.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `width(String text)` | seen | `if(itemX >= 31 + font.width(hoveredEntry.getBottomText()))` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:474) |

#### `net.minecraft.client.gui.Gui`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/GuiMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getChat()` | name only | `MC.gui.getChat().clearMessages(true);` (wurst: src/main/java/net/wurstclient/commands/ClearCmd.java:27) |

#### `net.minecraft.client.gui.GuiGraphicsExtractor`

Used by: `mc/Game.java`, `mc/McCanvas.java`, `mc/ReaperScreen.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/TacoCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `guiWidth()` | seen | `int x = extractor.guiWidth() / 2 - 32 + 76;` (wurst: src/main/java/net/wurstclient/commands/TacoCmd.java:88) |
| `guiHeight()` | seen | `int y = extractor.guiHeight() - 32 - 19;` (wurst: src/main/java/net/wurstclient/commands/TacoCmd.java:89) |
| `fill(int x0, int y0, int x1, int y1, int color)` | seen | `extractor.fill(0, 0, width, height, color);` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:442) |
| `fillGradient(int x0, int y0, int x1, int y1, int colorFrom, int color…` | seen | `extractor.fillGradient(x1, y1, x2, y2, shadowColor1, shadowColor2);` (wurst: src/main/java/net/wurstclient/navigator/NavigatorScreen.java:246) |
| `text(Font font, String text, int x, int y, int color, boolean shadow)` | seen* | `extractor.text(tr, "Name: " + alt.getDisplayName(), x + 31, y + 3,` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:606) |
| `enableScissor(int x0, int y0, int x1, int y1)` | seen | `extractor.enableScissor(x1, y3, x2, y2);` (wurst: src/main/java/net/wurstclient/clickgui/ClickGui.java:709) |
| `disableScissor()` | seen | `extractor.disableScissor();` (wurst: src/main/java/net/wurstclient/clickgui/ClickGui.java:747) |
| `pose()` | seen | `Matrix3x2fStack matrixStack = extractor.pose();` (wurst: …main/java/net/wurstclient/clickgui/screens/EditBlockScreen.java:101) |
| `item(ItemStack stack, int x, int y)` | seen | `extractor.item(renderStack, 0, 0);` (wurst: src/main/java/net/wurstclient/util/RenderUtils.java:734) |
| `itemDecorations(Font font, ItemStack stack, int x, int y)` | seen | `this.itemDecorations(font, stack, x, y);` (malilib: src/main/java/fi/dy/masa/malilib/render/GuiContext.java:325) |
| `blit(RenderPipeline pipeline, Identifier texture, int x, int y, float…` | seen* | `extractor.blit(RenderPipelines.GUI_TEXTURED, tacos[ticks / 8], x, y, 0,` (wurst: src/main/java/net/wurstclient/commands/TacoCmd.java:92) |
| `blit(RenderPipeline pipeline, Identifier texture, int x, int y, float…` | seen* | `extractor.blit(RenderPipelines.GUI_TEXTURED, tacos[ticks / 8], x, y, 0,` (wurst: src/main/java/net/wurstclient/commands/TacoCmd.java:92) |

#### `net.minecraft.client.gui.components.AbstractWidget`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `setX(int x)` | seen | `window.setX(bgx1);` (wurst: …main/java/net/wurstclient/navigator/NavigatorFeatureScreen.java:325) |
| `setY(int y)` | seen | `window.setY(windowY1 - 13);` (wurst: …main/java/net/wurstclient/navigator/NavigatorFeatureScreen.java:346) |

#### `net.minecraft.client.gui.components.Button`

Used by: `mc/InventoryTools.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `builder(Component message, OnPress onPress)` | seen | `Button.builder(Component.literal("Login"), b -> pressLogin())` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:124) |
| `onPress(Button button)` | seen | `useButton.onPress(context);` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:189) |
| `bounds(int x, int y, int width, int height)` | seen | `.bounds(width / 2 - 154, height - 52, 100, 20).build());` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:125) |
| `build()` | seen | `.bounds(width / 2 - 154, height - 52, 100, 20).build());` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:125) |

#### `net.minecraft.client.gui.components.ChatComponent`

Used by: `mixin/ChatComponentMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/AntiSpamHack.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `clearMessages(boolean history)` | name only | `MC.gui.getChat().clearMessages(true);` (wurst: src/main/java/net/wurstclient/commands/ClearCmd.java:27) |

#### `net.minecraft.client.gui.screens.DeathScreen`

Used by: `mc/Game.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/autorespawn/DeathScreenMixin.java


#### `net.minecraft.client.gui.screens.PauseScreen`

Used by: `mc/InventoryTools.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/PauseScreenMixin.java


#### `net.minecraft.client.gui.screens.Screen`

Used by: `mc/Game.java`, `mc/InventoryTools.java`, `mc/ReaperScreen.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mo…` | seen* | `public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX,` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:411) |
| `extractBackground(GuiGraphicsExtractor extractor, int mouseX, int mou…` | seen* | `public void extractBackground(GuiGraphicsExtractor extractor, int mouseX,` (wurst: …/main/java/net/wurstclient/clickgui/screens/ClickGuiScreen.java:68) |
| `isPauseScreen()` | seen | `public boolean isPauseScreen()` (wurst: …main/java/net/wurstclient/clickgui/screens/EditBlockScreen.java:149) |
| `shouldCloseOnEsc()` | seen | `public boolean shouldCloseOnEsc()` (wurst: …main/java/net/wurstclient/clickgui/screens/EditBlockScreen.java:155) |
| `removed()` | seen | `public void removed()` (malilib: src/main/java/fi/dy/masa/malilib/gui/GuiColorListEdit.java:113) |
| `keyPressed(KeyEvent event)` | seen | `public boolean keyPressed(KeyEvent context)` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:186) |
| `charTyped(CharacterEvent event)` | seen | `return this.textField1.charTyped(input);` (malilib: …va/fi/dy/masa/malilib/gui/GuiTextInputStackedMultiLineBase.java:191) |
| `mouseClicked(MouseButtonEvent event, boolean doubleClick)` | seen | `public boolean mouseClicked(MouseButtonEvent context, boolean doubleClick)` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:195) |
| `mouseReleased(MouseButtonEvent event)` | seen | `public boolean mouseReleased(MouseButtonEvent context)` (wurst: …/main/java/net/wurstclient/clickgui/screens/ClickGuiScreen.java:41) |
| `mouseDragged(MouseButtonEvent event, double dragX, double dragY)` | seen* | `public final boolean mouseDragged(MouseButtonEvent context, double double_3,` (wurst: src/main/java/net/wurstclient/navigator/NavigatorScreen.java:68) |
| `mouseScrolled(double mouseX, double mouseY, double horizontalAmount, …` | seen* | `public boolean mouseScrolled(double mouseX, double mouseY,` (wurst: …/main/java/net/wurstclient/clickgui/screens/ClickGuiScreen.java:48) |

#### `net.minecraft.client.gui.screens.inventory.AbstractContainerScreen`

Used by: `mc/InventoryTools.java`, `mixin/AbstractContainerScreenAccessor.java`  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/TriggerBotHack.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getMenu()` | seen | `.mapToObj(i -> screen.getMenu().slots.get(i)).toList();` (wurst: src/main/java/net/wurstclient/hacks/AutoStealHack.java:74) |

#### `net.minecraft.client.gui.screens.inventory.ContainerScreen`

Used by: `mc/InventoryTools.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/autosteal/AbstractContainerScreenMixin.java


#### `net.minecraft.client.gui.screens.inventory.InventoryScreen`

Used by: `mc/InventoryTools.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/InvseeCmd.java


#### `net.minecraft.client.gui.screens.inventory.ShulkerBoxScreen`

Used by: `mc/InventoryTools.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/autosteal/AbstractContainerScreenMixin.java


#### `net.minecraft.client.input.CharacterEvent`

Used by: `mc/ReaperScreen.java`  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/gui/GuiTextInputStackedMultiLineBase.java


#### `net.minecraft.client.input.KeyEvent`

Used by: `mc/ReaperScreen.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `hasShiftDown()` | seen | `boolean hasShiftDown = context.hasShiftDown();` (wurst: src/main/java/net/wurstclient/navigator/NavigatorMainScreen.java:78) |
| `hasControlDown()` | seen | `if (Minecraft.getInstance().hasControlDown()) {` (sodium: …/net/caffeinemc/mods/sodium/client/gui/VideoSettingsScreen.java:454) |

#### `net.minecraft.client.input.MouseButtonEvent`

Used by: `mc/ReaperScreen.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `button()` | seen | `if(context.button() == GLFW.GLFW_MOUSE_BUTTON_4)` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:197) |

#### `net.minecraft.client.input.MouseButtonInfo`

Used by: `mixin/MouseHandlerMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/navigator/NavigatorFeatureScreen.java


#### `net.minecraft.client.multiplayer.ClientLevel`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `dimension()` | seen | `return player != null && server != null ? server.getLevel(player.level().dimension()) : null;` (malilib: src/main/java/fi/dy/masa/malilib/util/game/wrap/GameWrap.java:51) |
| `getBiome(BlockPos pos)` | seen | `movingBlockRenderState.biome = entity.level().getBiome(entity.blockPosition());` (fabric-api: …bricmc/fabric/test/rendering/client/mixin/PigRendererMixin.java:57) |
| `getBrightness(LightLayer layer, BlockPos pos)` | seen | `public int getBrightness(LightLayer type, BlockPos pos) {` (sodium: …in/java/net/caffeinemc/mods/sodium/client/world/LevelSlice.java:283) |
| `getOverworldClockTime()` | name only | `context.waitFor(mc -> mc.level.getOverworldClockTime() == time);` (wurst: …test/java/net/wurstclient/gametest/tests/NoWeatherHackTest.java:84) |

#### `net.minecraft.client.multiplayer.ClientPacketListener`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/commands/TpCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getPlayerInfo(java.util.UUID id)` | name only | `.getPlayerInfo(getGameProfile().id());` (wurst: src/main/java/net/wurstclient/util/FakePlayerEntity.java:46) |

#### `net.minecraft.client.multiplayer.MultiPlayerGameMode`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/events/PlayerAttacksEntityListener.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `handleContainerInput(int syncId, int slotId, int button, ContainerInp…` | seen* | `MC.gameMode.handleContainerInput(tradeScreen.getMenu().containerId,` (wurst: src/main/java/net/wurstclient/hacks/AutoLibrarianHack.java:246) |

#### `net.minecraft.client.multiplayer.PlayerInfo`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/commands/AddAltCmd.java


#### `net.minecraft.client.multiplayer.ServerData`

Used by: `mc/Game.java`  
Class seen in: wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `isRealm()` | seen | `if(server.isRealm())` (wurst: src/main/java/net/wurstclient/analytics/PlausibleAnalytics.java:124) |

#### `net.minecraft.client.multiplayer.chat.GuiMessageSource`

Used by: `mixin/ChatComponentMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/ChatComponentMixin.java


#### `net.minecraft.client.multiplayer.chat.GuiMessageTag`

Used by: `mixin/ChatComponentMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/other_features/NoChatReportsOtf.java


#### `net.minecraft.client.player.LocalPlayer`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/commands/ViewCompCmd.java


#### `net.minecraft.client.renderer.RenderPipelines`

Used by: `mc/McCanvas.java`  
Class seen in: wurst: src/main/java/net/wurstclient/WurstShaderPipelines.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `GUI_TEXTURED` | seen | `extractor.blit(RenderPipelines.GUI_TEXTURED, tacos[ticks / 8], x, y, 0,` (wurst: src/main/java/net/wurstclient/commands/TacoCmd.java:92) |

#### `net.minecraft.client.renderer.texture.AbstractTexture`

Used by: -  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/render/GuiContext.java


#### `net.minecraft.client.renderer.texture.DynamicTexture`

Used by: `mc/ThumbnailCache.java`  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/gui/GuiColorEditorHSV.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `DynamicTexture(java.util.function.Supplier<String> label, com.mojang.…` | seen | `new DynamicTexture(id::toString, image)` (malilib: src/main/java/fi/dy/masa/malilib/gui/GuiColorEditorHSV.java:692) |

#### `net.minecraft.client.renderer.texture.TextureManager`

Used by: -  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/render/RenderUtils.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `register(net.minecraft.resources.Identifier id, AbstractTexture textu…` | seen (checked by hand) | `Minecraft.getInstance().getTextureManager().register(this.textureId, this.texture);` (sodium: common/src/main/java/net/caffeinemc/mods/sodium/client/gl/arena/BufferArena.java:436; also modmenu: ModListEntry.java:211, malilib: GuiColorEditorHSV.java:694) |

#### `net.minecraft.client.server.IntegratedServer`

Used by: -  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/interfaces/IServerListener.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getWorldData()` | seen | `String name = server.getWorldData().getLevelName();` (malilib: src/main/java/fi/dy/masa/malilib/util/StringUtils.java:596) |

#### `net.minecraft.commands.CommandBuildContext`

Used by: -  
Class seen in: fabric-api: fabric-permission-api-v1/src/testmod/java/net/fabricmc/fabric/test/permission/PermissionTestMod.java


#### `net.minecraft.core.BlockPos`

Used by: `mc/GameData.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/GoToCmd.java


#### `net.minecraft.core.Holder`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/commands/EnchantCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `unwrapKey()` | seen | `if(entry.unwrapKey().orElse(null) == Enchantments.SILK_TOUCH)` (wurst: src/main/java/net/wurstclient/commands/EnchantCmd.java:71) |

#### `net.minecraft.core.Registry`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/commands/EnchantCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getKey(T value)` | seen | `Identifier id = registry.getKey(enchantment);` (wurst: src/main/java/net/wurstclient/hacks/autolibrarian/BookOffer.java:33) |

#### `net.minecraft.core.registries.BuiltInRegistries`

Used by: `mc/InventoryTools.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/PotionCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `ITEM` | seen | `String itemName = BuiltInRegistries.ITEM.getKey(item).toString();` (wurst: src/main/java/net/wurstclient/commands/ItemListCmd.java:84) |

#### `net.minecraft.network.chat.ChatType`

Used by: -  
Class seen in: fabric-api: fabric-message-api-v1/src/client/java/net/fabricmc/fabric/api/client/message/v1/ClientReceiveMessageEvents.java


#### `net.minecraft.network.chat.Component`

Used by: `mc/Game.java`, `mc/Hooks.java`, `mc/InventoryTools.java`, `mc/ReaperCommands.java`, `mc/ReaperScreen.java`, `mixin/ChatComponentMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/RenameCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `literal(String text)` | seen | `stack.set(DataComponents.CUSTOM_NAME, Component.literal(message));` (wurst: src/main/java/net/wurstclient/commands/RenameCmd.java:47) |
| `getString()` | seen | `String text = disconnectReason.getString();` (wurst: …in/java/net/wurstclient/nochatreports/NcrModRequiredScreen.java:156) |

#### `net.minecraft.network.chat.MessageSignature`

Used by: `mixin/ChatComponentMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/other_features/NoChatReportsOtf.java


#### `net.minecraft.network.chat.MutableComponent`

Used by: `mc/Hooks.java`, `mc/ReaperCommands.java`  
Class seen in: wurst: src/main/java/net/wurstclient/other_features/WurstOptionsOtf.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `withStyle(net.minecraft.ChatFormatting formatting)` | seen | `.withStyle(s -> s.withUnderlined(true).withClickEvent(event));` (wurst: …/net/wurstclient/hacks/templatetool/states/SavingFileState.java:61) |
| `setStyle(Style style)` | seen | `protected void setStyle(Style style)` (malilib: …n/java/fi/dy/masa/malilib/gui/widgets/WidgetHoverComponent.java:26) |
| `append(Component other)` | seen | `message.append(link);` (wurst: …/net/wurstclient/hacks/templatetool/states/SavingFileState.java:62) |

#### `net.minecraft.network.chat.PlayerChatMessage`

Used by: -  
Class seen in: fabric-api: fabric-message-api-v1/src/client/java/net/fabricmc/fabric/api/client/message/v1/ClientReceiveMessageEvents.java


#### `net.minecraft.network.chat.Style`

Used by: `mc/Hooks.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `withColor(int rgb)` | seen | `.withStyle(Style.EMPTY.withColor(ChatFormatting.GRAY)));` (sodium: …net/caffeinemc/mods/sodium/client/gui/widgets/SearchWidget.java:81) |
| `EMPTY` | seen | `font.getSplitter().splitLines(translated, 200, Style.EMPTY).stream()` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:532) |

#### `net.minecraft.resources.Identifier`

Used by: `mc/ClientKeys.java`, `mc/Game.java`, `mc/McCanvas.java`, `mc/Reflect.java`, `mc/ThumbnailCache.java`  
Class seen in: wurst: src/main/java/net/wurstclient/WurstShaderPipelines.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `fromNamespaceAndPath(String namespace, String path)` | seen | `{Identifier.fromNamespaceAndPath("wurst", "dancingtaco1.png"),` (wurst: src/main/java/net/wurstclient/commands/TacoCmd.java:25) |

#### `net.minecraft.resources.ResourceKey`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/AttributeSwapHack.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `identifier()` | seen | `return key.identifier().toString();` (malilib: src/main/java/fi/dy/masa/malilib/util/game/RecipeBookUtils.java:79) |

#### `net.minecraft.util.ARGB`

Used by: `mc/McCanvas.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/xray/ModelBlockRendererMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `white(float alpha)` | seen | `ARGB.white(1.0F)` (modmenu: …com/terraformersmc/modmenu/gui/widget/entries/ModListEntry.java:83) |

#### `net.minecraft.util.Mth`

Used by: `mc/GameData.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `lerp(float delta, float a, float b)` | seen | `return Mth.lerp(partialTicks, prevCamPos, camPos);` (wurst: src/main/java/net/wurstclient/hacks/FreecamHack.java:279) |

#### `net.minecraft.world.entity.Entity`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/commands/ProtectCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getX()` | seen | `int x1 = getX();` (wurst: …in/java/net/wurstclient/clickgui/components/RadarComponent.java:46) |
| `getY()` | seen | `int y1 = getY();` (wurst: …in/java/net/wurstclient/clickgui/components/RadarComponent.java:48) |
| `getZ()` | seen | `entity.getZ()) <= MC.player.distanceToSqr(MC.player.getX(),` (wurst: src/main/java/net/wurstclient/hacks/FollowHack.java:198) |
| `getViewYRot(float partial)` | seen | `camYaw = cameraEntity.getViewYRot(1);` (wurst: src/main/java/net/wurstclient/hacks/FreecamHack.java:143) |
| `getViewXRot(float partial)` | seen | `camPitch = cameraEntity.getViewXRot(1);` (wurst: src/main/java/net/wurstclient/hacks/FreecamHack.java:144) |
| `getEyeHeight(Pose pose)` | seen | `float eyeHeight = e.getEyeHeight(e.getPose());` (wurst: src/main/java/net/wurstclient/settings/AimAtSetting.java:79) |
| `getPose()` | seen | `float eyeHeight = e.getEyeHeight(e.getPose());` (wurst: src/main/java/net/wurstclient/settings/AimAtSetting.java:79) |
| `isSprinting()` | seen | `boolean isSprinting = TickUtils.isSprinting();` (malilib: …main/java/fi/dy/masa/malilib/test/render/TestRenderHandler.java:139) |
| `isShiftKeyDown()` | seen | `return MC.player.isShiftKeyDown()` (wurst: src/main/java/net/wurstclient/hacks/AnchorAuraHack.java:392) |
| `isSwimming()` | name only | `if(!player.isSwimming() && !player.isUnderWater())` (wurst: src/main/java/net/wurstclient/hacks/AutoSwimHack.java:48) |
| `isSpectator()` | seen | `e -> !e.isSpectator() && e.isPickable();` (wurst: src/main/java/net/wurstclient/hacks/TrajectoriesHack.java:161) |
| `blockPosition()` | seen | `BlockPos center = target.blockPosition();` (wurst: src/main/java/net/wurstclient/hacks/CrystalAuraHack.java:260) |
| `getUUID()` | seen | `\|\| MC.level.getEntity(entity.getUUID()) == null)` (wurst: src/main/java/net/wurstclient/hacks/FollowHack.java:132) |
| `sendSystemMessage(net.minecraft.network.chat.Component message)` | seen | `player.sendSystemMessage(Component.nullToEmpty(command));` (malilib: src/main/java/fi/dy/masa/malilib/util/game/wrap/GameWrap.java:163) |

#### `net.minecraft.world.entity.EquipmentSlot`

Used by: `mc/GameData.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/CopyItemCmd.java


#### `net.minecraft.world.entity.LivingEntity`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/commands/GoToCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `isFallFlying()` | seen | `@ModifyReturnValue(method = "isFallFlying()Z", at = @At("RETURN"))` (wurst: …c/main/java/net/wurstclient/mixin/flight/LivingEntityMixin.java:24) |
| `getItemBySlot(EquipmentSlot slot)` | seen | `.canGlideUsing(player.getItemBySlot(slot), slot));` (wurst: src/main/java/net/wurstclient/hacks/NoClipHack.java:143) |
| `getMainHandItem()` | seen | `ItemStack current = MC.player.getMainHandItem();` (wurst: src/main/java/net/wurstclient/hacks/AttributeSwapHack.java:181) |
| `getOffhandItem()` | seen | `return livingEntity instanceof Player && livingEntity.getOffhandItem().is(Items.POTATO);` (fabric-api: …fabric/test/entity/event/gametest/ServerMobEffectsGameTest.java:170) |

#### `net.minecraft.world.entity.Pose`

Used by: `mc/GameData.java`  
Class seen in: wurst: src/main/java/net/wurstclient/settings/filters/FilterSleepingSetting.java


#### `net.minecraft.world.entity.player.Abilities`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/CreativeFlightHack.java


#### `net.minecraft.world.entity.player.Inventory`

Used by: `mixin/MouseHandlerMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/ModifyCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `setSelectedSlot(int slot)` | seen | `inventory.setSelectedSlot(oldSlot);` (wurst: src/main/java/net/wurstclient/hacks/InstaBuildHack.java:189) |

#### `net.minecraft.world.entity.player.Player`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/settings/filters/FilterCreativeSetting.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getAbilities()` | seen | `@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getAbilities()Lnet/minecraft/wo…` (fabric-api: …ic/mixin/event/interaction/client/MultiPlayerGameModeMixin.java:66) |
| `getGameProfile()` | seen | `LOGGER.info("Copied data for {} from {} to {}", oldPlayer.getGameProfile().name(), oldPlayer, newPlayer);` (fabric-api: …ava/net/fabricmc/fabric/test/entity/event/EntityEventTests.java:100) |

#### `net.minecraft.world.inventory.AbstractContainerMenu`

Used by: -  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/mixin/block/MixinBaseContainerBlockEntity.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getCarried()` | seen | `return menu.getCarried();` (fabric-api: …a/net/fabricmc/fabric/impl/transfer/item/CursorSlotWrapper.java:47) |

#### `net.minecraft.world.inventory.ChestMenu`

Used by: -  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/mixin/block/MixinChestBlock_createMenu.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getRowCount()` | name only | `rows = chest.getMenu().getRowCount();` (wurst: …t/wurstclient/mixin/autosteal/AbstractContainerScreenMixin.java:49) |

#### `net.minecraft.world.inventory.ContainerInput`

Used by: `mc/InventoryTools.java`  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/AutoLibrarianHack.java


#### `net.minecraft.world.inventory.InventoryMenu`

Used by: -  
Class seen in: baritone: src/main/java/baritone/process/GetToBlockProcess.java


#### `net.minecraft.world.inventory.ShulkerBoxMenu`

Used by: -  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/mixin/menu/IMixinShulkerBoxMenu.java


#### `net.minecraft.world.inventory.Slot`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/AutoStealHack.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getItem()` | seen | `if(slot.getItem().isEmpty())` (wurst: src/main/java/net/wurstclient/hacks/AutoStealHack.java:82) |

#### `net.minecraft.world.item.Item`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/commands/GiveCmd.java


#### `net.minecraft.world.item.ItemStack`

Used by: `mc/GameData.java`, `mc/InventoryTools.java`, `mc/McCanvas.java`  
Class seen in: wurst: src/main/java/net/wurstclient/commands/CopyItemCmd.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `isEmpty()` | seen | `if(stack.isEmpty())` (wurst: src/main/java/net/wurstclient/commands/ViewCompCmd.java:44) |
| `getHoverName()` | seen | `: stack.getHoverName().getString();` (wurst: …/java/net/wurstclient/clickgui/screens/EditBlockListScreen.java:247) |
| `isDamageableItem()` | seen | `if(!stack.isDamageableItem())` (wurst: src/main/java/net/wurstclient/commands/RepairCmd.java:53) |
| `getMaxDamage()` | seen | `return stack.getMaxDamage() - stack.getDamageValue() <= repairMode;` (wurst: src/main/java/net/wurstclient/hacks/AutoToolHack.java:221) |
| `getDamageValue()` | seen | `return stack.getMaxDamage() - stack.getDamageValue() <= repairMode;` (wurst: src/main/java/net/wurstclient/hacks/AutoToolHack.java:221) |
| `getCount()` | seen | `int oldCount = stack.getCount();` (wurst: src/main/java/net/wurstclient/util/InteractionSimulator.java:121) |
| `getMaxStackSize()` | seen | `.min(restockAmount.getValueI(), hotbarStack.getMaxStackSize()))` (wurst: src/main/java/net/wurstclient/hacks/RestockHack.java:104) |
| `getItem()` | seen | `if(!(stack.getItem() instanceof PotionItem))` (wurst: src/main/java/net/wurstclient/commands/PotionCmd.java:51) |
| `isSameItemSameComponents(ItemStack a, ItemStack b)` | seen | `return ItemStack.isSameItemSameComponents(stack1, stack2);` (malilib: src/main/java/fi/dy/masa/malilib/util/InventoryUtils.java:91) |

#### `net.minecraft.world.level.Level`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/noweather/LevelMixin.java


#### `net.minecraft.world.level.LightLayer`

Used by: `mc/GameData.java`  
Class seen in: wurst: src/main/java/net/wurstclient/hacks/MobSpawnEspHack.java


#### `net.minecraft.world.level.biome.Biome`

Used by: -  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/util/WorldUtils.java


#### `net.minecraft.world.level.storage.WorldData`

Used by: -  
Class seen in: fabric-api: fabric-game-rule-api-v1/src/test/java/net/fabricmc/fabric/test/gamerule/MinecraftGameRuleServiceImplTest.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `getLevelName()` | name only | `String name = server.getWorldData().getLevelName();` (malilib: src/main/java/fi/dy/masa/malilib/util/StringUtils.java:596) |

#### `org.joml.Matrix3x2f`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/util/CustomQuadRenderState.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `translate(float x, float y)` | seen | `matrixStack.translate(x, y);` (wurst: src/main/java/net/wurstclient/util/RenderUtils.java:725) |
| `scale(float xy)` | seen | `return getCameraRotation().toLookVec().scale(10);` (wurst: src/main/java/net/wurstclient/util/RenderUtils.java:137) |
| `scale(float x, float y)` | seen | `matrixStack.scale(1.5F, 1.5F);` (wurst: src/main/java/net/wurstclient/util/RenderUtils.java:727) |

#### `org.joml.Matrix3x2fStack`

Used by: -  
Class seen in: wurst: src/main/java/net/wurstclient/clickgui/screens/EditBlockScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `pushMatrix()` | seen | `matrixStack.pushMatrix();` (wurst: …main/java/net/wurstclient/clickgui/screens/EditBlockScreen.java:114) |
| `popMatrix()` | seen | `matrixStack.popMatrix();` (wurst: …main/java/net/wurstclient/clickgui/screens/EditBlockScreen.java:136) |

#### `org.lwjgl.glfw.GLFW`

Used by: `mc/ClientKeys.java`, `mc/Game.java`, `mc/GameData.java`  
Class seen in: wurst: src/main/java/net/wurstclient/altmanager/screens/AltManagerScreen.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `glfwGetKey(long window, int key)` | seen | `return GLFW.glfwGetKey(window, keyCode) == GLFW.GLFW_PRESS;` (malilib: src/main/java/fi/dy/masa/malilib/hotkeys/KeybindMulti.java:495) |
| `glfwGetMouseButton(long window, int button)` | seen | `return GLFW.glfwGetMouseButton(window.handle(), code) == 1;` (wurst: src/main/java/net/wurstclient/mixin/KeyMappingMixin.java:40) |
| `GLFW_KEY_UNKNOWN` | seen | `new KeyEvent(GLFW.GLFW_KEY_UNKNOWN, key.getValue(), 0));` (wurst: src/main/java/net/wurstclient/mixin/KeyMappingMixin.java:71) |
| `GLFW_KEY_Z` | seen | `public static final int KEY_Z               = GLFW.GLFW_KEY_Z;` (malilib: src/main/java/fi/dy/masa/malilib/util/KeyCodes.java:65) |
| `GLFW_KEY_RIGHT_SHIFT` | seen | `\|\| InputConstants.isKeyDown(Minecraft.getInstance().getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT);` (malilib: src/main/java/fi/dy/masa/malilib/gui/GuiBase.java:910) |
| `GLFW_PRESS` | seen | `if(event.getAction() != GLFW.GLFW_PRESS)` (wurst: src/main/java/net/wurstclient/keybinds/KeybindProcessor.java:43) |
| `GLFW_MOUSE_BUTTON_LEFT` | seen | `if(context.button() != GLFW.GLFW_MOUSE_BUTTON_LEFT)` (wurst: …n/java/net/wurstclient/altmanager/screens/AltManagerScreen.java:569) |

#### `org.spongepowered.asm.mixin.Final`

Used by: `mixin/OptionInstanceMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/DownloadQueueMixin.java


#### `org.spongepowered.asm.mixin.Mixin`

Used by: `mixin/AbstractContainerScreenAccessor.java`, `mixin/CameraMixin.java`, `mixin/ChatComponentMixin.java`, `mixin/MouseHandlerMixin.java`, `mixin/OptionInstanceMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/DownloadQueueMixin.java


#### `org.spongepowered.asm.mixin.Shadow`

Used by: `mixin/OptionInstanceMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/DownloadQueueMixin.java


#### `org.spongepowered.asm.mixin.gen.Accessor`

Used by: `mixin/AbstractContainerScreenAccessor.java`  
Class seen in: malilib: src/main/java/fi/dy/masa/malilib/mixin/nbt/IMixinNbtReadView.java


#### `org.spongepowered.asm.mixin.injection.At`

Used by: `mixin/CameraMixin.java`, `mixin/ChatComponentMixin.java`, `mixin/MouseHandlerMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/DownloadQueueMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `value()` | seen | `at = @At(value = "INVOKE",` (wurst: src/main/java/net/wurstclient/mixin/DownloadQueueMixin.java:44) |

#### `org.spongepowered.asm.mixin.injection.Inject`

Used by: `mixin/ChatComponentMixin.java`, `mixin/MouseHandlerMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/autosteal/AbstractContainerScreenMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `method()` | seen | `@Inject(method = "init()V", at = @At("TAIL"))` (wurst: …t/wurstclient/mixin/autosteal/AbstractContainerScreenMixin.java:42) |

#### `org.spongepowered.asm.mixin.injection.callback.CallbackInfo`

Used by: `mixin/ChatComponentMixin.java`, `mixin/MouseHandlerMixin.java`  
Class seen in: wurst: src/main/java/net/wurstclient/mixin/autosteal/AbstractContainerScreenMixin.java

| Member (as the stub declares it) | Result | Reference line (project: file:line) |
|---|---|---|
| `cancel()` | seen | `ci.cancel();` (wurst: src/main/java/net/wurstclient/mixin/MinecraftMixin.java:123) |

