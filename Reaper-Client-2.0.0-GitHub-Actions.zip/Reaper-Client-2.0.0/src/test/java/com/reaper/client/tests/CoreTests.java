package com.reaper.client.tests;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.reaper.client.core.config.ClientConfig;
import com.reaper.client.core.config.JsonIO;
import com.reaper.client.core.config.ProfileStore;
import com.reaper.client.core.config.SaveScheduler;
import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.KeyTracker;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.policy.ServerMode;
import com.reaper.client.core.policy.ServerPolicy;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.util.Anim;
import com.reaper.client.core.util.Colors;
import com.reaper.client.core.util.Text;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/** Settings, modules, key binds, policy, colours, profile and config storage. */
public final class CoreTests {
    private CoreTests() {}

    enum Mode { ALPHA, BETA, GAMMA }

    static ModuleRegistry sampleRegistry(List<String> log) {
        ModuleRegistry r = new ModuleRegistry();
        Module fps = new Module("fps", "FPS", "Frame rate counter", Category.HUD, true, true, "performance");
        fps.add(new Settings.Num("size", "Size", "Text scale", 1.0, 0.5, 3.0, 0.1, "x"));
        fps.add(new Settings.Color("color", "Colour", "Text colour", 0xFFFFFFFF, false));
        fps.add(new Settings.Choice<>("mode", "Mode", "Mode", Mode.ALPHA));
        fps.add(new Settings.Str("label", "Label", "Prefix", "FPS", 8));
        fps.onToggle(on -> log.add("fps:" + on));
        r.register(fps);
        Module zoom = new Module("zoom", "Zoom", "Hold to zoom", Category.VISUAL).feature(Feature.ZOOM);
        zoom.add(new Settings.Num("factor", "Factor", "Zoom factor", 4, 1.5, 10, 0.5, "x"));
        zoom.add(new Settings.Bool("smooth", "Smooth", "Smooth zoom", true));
        r.register(zoom);
        Module ui = new Module("interface", "Interface", "GUI options", Category.CLIENT, false, false, "");
        ui.add(new Settings.Bool("anim", "Animations", "Animate", true));
        r.register(ui);
        return r;
    }

    public static void run() throws IOException {
        colours();
        text();
        settings();
        modules();
        keys();
        policy();
        storage();
        profiles();
    }

    // ------------------------------------------------------------------
    static void colours() {
        T.section("Colors");
        T.eq(0xFF112233, Colors.rgb(0x11, 0x22, 0x33), "rgb");
        T.eq(0x80112233, Colors.withAlpha(0xFF112233, 0x80), "withAlpha");
        T.eq(0xFF808080, Colors.lerp(0xFF000000, 0xFFFFFFFF, 0.5f), "lerp mid (rounded)");
        T.eq(0xFFFF0000, Colors.hsb(0f, 1f, 1f), "hsb red");
        T.eq(0xFF00FF00, Colors.hsb(1f / 3f, 1f, 1f), "hsb green");
        float[] h = Colors.toHsb(0xFF3366CC, new float[3]);
        T.eq(0xFF3366CC, Colors.hsb(h[0], h[1], h[2]), "hsb round trip");
        T.eq(0xFFAABBCC, Colors.parseHex("#AABBCC", 0), "parse #RRGGBB");
        T.eq(0xFFAABBCC, Colors.parseHex("#ABC", 0), "parse #RGB");
        T.eq(0x80112233, Colors.parseHex("#80112233", 0), "parse #AARRGGBB");
        T.eq(7, Colors.parseHex("nonsense", 7), "parse invalid -> fallback");
        T.check(Colors.isHex("#12345678") && Colors.isHex("abc") && Colors.isHex(" #ABCDEF "), "isHex accepts 3/6/8 digits");
        T.check(!Colors.isHex("#12") && !Colors.isHex("+ABCDE") && !Colors.isHex("-12345") && !Colors.isHex("#GGGGGG") && !Colors.isHex(null), "isHex rejects junk and signs");
        T.eq(0x12345678, Colors.parseHex("#12345678", 7), "the old sentinel value is an ordinary colour now");
        T.eq("#FF8800", Colors.toHex(0xFFFF8800, false), "toHex");
        T.eq(0xFF111111, Colors.onColor(0xFFFFFFFF), "dark text on white");
        T.eq(0xFFFFFFFF, Colors.onColor(0xFF000000), "white text on black");
        T.eq(0x40FFFFFF, Colors.mulAlpha(0x80FFFFFF, 0.5f), "mulAlpha");
        Anim a = new Anim(0f).set(1f);
        float v1 = a.update(0.016f, 12f);
        T.check(v1 > 0f && v1 < 0.3f, "anim moves a little in one frame: " + v1);
        for (int i = 0; i < 200; i++) a.update(0.016f, 12f);
        T.check(a.value == 1f && a.settled(), "anim settles exactly");
        Anim slow = new Anim(0f).set(1f), fast = new Anim(0f).set(1f);
        for (int i = 0; i < 10; i++) slow.update(0.1f, 12f);
        for (int i = 0; i < 100; i++) fast.update(0.01f, 12f);
        T.near(slow.value, fast.value, 0.001, "anim is frame-rate independent");
        T.eq(0f, Anim.outCubic(0f), "outCubic 0");
        T.eq(1f, Anim.outCubic(1f), "outCubic 1");
    }

    static void text() {
        T.section("Text");
        T.eq("Dark Oak Forest", Text.prettyId("minecraft:dark_oak_forest"), "prettyId namespaced");
        T.eq("Plains", Text.prettyId("plains"), "prettyId plain");
        T.eq("3.14", Text.num(3.14159, 2), "num 2 decimals");
        T.eq("-0.50", Text.num(-0.5, 2), "num negative");
        T.eq("0.0", Text.num(-0.0001, 1), "no negative zero");
        T.eq("12", Text.num(11.6, 0), "num 0 decimals");
        T.eq("1.5 MB", Text.bytes(1_572_864), "bytes MB");
        T.check(Text.matchesAll("fullbright brightness gamma", "bright gam"), "multi word match");
        T.check(!Text.matchesAll("fullbright", "zoom"), "no match");
        T.check(Text.matchesAll("anything", "  "), "blank query matches all");
    }

    static void settings() {
        T.section("Settings");
        Settings.Num n = new Settings.Num("n", "N", "", 5, 1, 10, 0.5, "x");
        T.check(n.set(7.26), "set changes");
        T.eq(7.5, n.get(), "snapped to step grid");
        n.set(99.0); T.eq(10.0, n.get(), "clamped to max");
        n.set(Double.NaN); T.eq(5.0, n.get(), "NaN -> default");
        T.eq("5.0x", n.valueText(), "valueText");
        T.eq(1, n.decimals, "decimals from step");
        Settings.Num whole = new Settings.Num("w", "W", "", 3, 0, 10, 1, "");
        T.eq(0, whole.decimals, "integer step");
        whole.set(2.4); T.eq(2.0, whole.get(), "integer rounding");
        T.throwsEx(() -> new Settings.Num("bad", "Bad", "", 1, 5, 5, 1, ""), "max must exceed min");
        n.set(2.0);
        n.fromJson(JsonParser.parseString("\"oops\"")); T.eq(2.0, n.get(), "wrong JSON type ignored");
        n.fromJson(JsonParser.parseString("1000")); T.eq(10.0, n.get(), "JSON number clamped");
        n.setFraction(0.5); T.near(5.5, n.get(), 0.01, "fraction");

        Settings.Bool b = new Settings.Bool("b", "B", "", false);
        b.toggle(); T.check(b.on(), "toggle");
        b.fromJson(JsonParser.parseString("\"yes\"")); T.check(b.on(), "string ignored for bool");
        b.fromJson(JsonParser.parseString("false")); T.check(!b.on(), "bool from json");

        Settings.Choice<Mode> c = new Settings.Choice<>("c", "C", "", Mode.BETA);
        c.next(); T.eq(Mode.GAMMA, c.v(), "next");
        c.next(); T.eq(Mode.ALPHA, c.v(), "wraps forward");
        c.prev(); T.eq(Mode.GAMMA, c.v(), "wraps backward");
        c.fromJson(JsonParser.parseString("\"alpha\"")); T.eq(Mode.ALPHA, c.v(), "case-insensitive load");
        c.fromJson(JsonParser.parseString("\"nope\"")); T.eq(Mode.ALPHA, c.v(), "unknown constant ignored");
        T.eq("Alpha", c.valueText(), "label from constant name");

        Settings.Color col = new Settings.Color("col", "Col", "", 0x80FF0000, false);
        T.eq(0xFFFF0000, col.get(), "opaque colour forces alpha");
        col.fromJson(JsonParser.parseString("\"#00FF00\"")); T.eq(0xFF00FF00, col.get(), "hex load");
        Settings.Color cola = new Settings.Color("cola", "Col", "", 0x80FF0000, true);
        T.eq(0x80FF0000, cola.get(), "alpha colour keeps alpha");
        T.eq("\"#80FF0000\"", cola.toJson().toString(), "alpha colour saved as #AARRGGBB");
        col.fromJson(JsonParser.parseString("\"garbage\"")); T.eq(0xFF00FF00, col.get(), "bad hex ignored");

        Settings.Str s = new Settings.Str("s", "S", "", "abc", 5);
        s.set("abcdefghij"); T.eq("abcde", s.get(), "text truncated");
        s.set("a\nb\u0007c"); T.eq("abc", s.get(), "control chars stripped");
        s.set(null); T.eq("abc", s.get(), "null -> default");

        Settings.Key k = new Settings.Key("k", "K", "", -1);
        k.set(70); T.eq("F", k.valueText(), "key label");
        k.set(9999); T.check(!k.bound(), "out-of-range key -> unbound");
        k.set(293); T.eq("F4", k.valueText(), "function key label (GLFW F1 = 290)");
        k.set(290); T.eq("F1", k.valueText(), "F1");
        k.set(301); T.eq("F12", k.valueText(), "F12");
        T.eq("R Shift", KeyNames.of(KeyNames.RSHIFT), "named key");

        List<Double> changes = new ArrayList<>();
        Settings.Num l = new Settings.Num("l", "L", "", 1, 0, 10, 1, "");
        l.onChange(changes::add);
        l.set(3.0); l.set(3.0); l.set(4.0);
        T.eq("[3.0, 4.0]", changes.toString(), "listener fires only when the value really changes");

        int[] clicks = {0};
        Settings.Action act = new Settings.Action("a", "Go", "", false, () -> clicks[0]++);
        act.run();
        T.eq(1, clicks[0], "action runs");
        T.check(!act.persistent(), "action is not persisted");
    }

    // ------------------------------------------------------------------
    static void modules() {
        T.section("Modules");
        List<String> log = new ArrayList<>();
        ModuleRegistry r = sampleRegistry(log);
        Module fps = r.get("fps"), zoom = r.get("zoom"), ui = r.get("interface");
        T.check(fps.isEnabled(), "defaultEnabled honoured");
        T.check(!zoom.isEnabled(), "off by default");
        T.check(!ui.setEnabled(true), "non-toggleable modules cannot be enabled");
        T.throwsEx(() -> r.register(new Module("fps", "Dup", "", Category.HUD)), "duplicate module id rejected");
        T.throwsEx(() -> fps.add(new Settings.Bool("size", "x", "", false)), "duplicate setting id rejected");
        T.throwsEx(() -> fps.add(new Settings.Bool("bind", "x", "", false)), "reserved setting id rejected");

        fps.toggle(); fps.toggle();
        T.eq("[fps:false, fps:true]", log.toString(), "toggle listeners fire in order");
        fps.setEnabled(true); T.eq(2, log.size(), "no event when state unchanged");

        zoom.setEnabled(true);
        T.check(zoom.isActive(), "active when policy allows");
        r.setPolicyGate(f -> f != Feature.ZOOM);
        T.check(zoom.isEnabled() && !zoom.isActive() && zoom.isBlockedByPolicy(), "policy blocks without changing the user's choice");
        T.check(fps.isActive(), "modules without a feature are never blocked");
        r.setPolicyGate(null);
        T.check(zoom.isActive(), "unblocked again");

        T.check(zoom.matches("zoom"), "search by name");
        T.check(fps.matches("performance"), "search by tag");
        T.check(zoom.matches("visual"), "search by category");
        T.check(!zoom.matches("hud"), "search miss");

        // key rows
        T.eq(1, ui.allSettings().size(), "non-toggleable modules have no key rows");
        T.eq(6, fps.allSettings().size(), "toggleable modules: own settings + 2 key rows");
        T.eq("bindMode", fps.allSettings().get(5).id, "key rows come last");
        T.check(!fps.bindMode.isVisible(), "key mode hidden until a key is bound");
        fps.bind.set(70);
        T.check(fps.bindMode.isVisible(), "key mode visible once bound");

        // persistence
        ((Settings.Num) fps.find("size")).set(2.0);
        ((Settings.Choice<?>) fps.find("mode")).fromJson(JsonParser.parseString("\"GAMMA\""));
        JsonObject saved = r.toJson();
        T.eq(2.0, saved.getAsJsonObject("fps").getAsJsonObject("settings").get("size").getAsDouble(), "toJson size");
        T.check(!saved.getAsJsonObject("interface").has("enabled"), "non-toggleable has no enabled flag");

        ModuleRegistry r2 = sampleRegistry(new ArrayList<>());
        r2.fromJson(saved);
        T.eq(2.0, ((Settings.Num) r2.get("fps").find("size")).get(), "round trip number");
        T.eq(Mode.GAMMA, ((Settings.Choice<?>) r2.get("fps").find("mode")).get(), "round trip enum");
        T.eq(70, r2.get("fps").bind.code(), "round trip key");
        T.check(r2.get("fps").isEnabled(), "round trip enabled");

        // missing / garbage data must reset, not crash
        JsonObject partial = new JsonObject();
        partial.add("zoom", JsonParser.parseString("{\"enabled\":true,\"settings\":{\"factor\":3.5,\"smooth\":\"maybe\",\"ghost\":1}}"));
        partial.add("fps", JsonParser.parseString("[1,2,3]"));
        r2.fromJson(partial);
        T.check(r2.get("zoom").isEnabled(), "partial: enabled loaded");
        T.eq(3.5, ((Settings.Num) r2.get("zoom").find("factor")).get(), "partial: known setting loaded");
        T.check(((Settings.Bool) r2.get("zoom").find("smooth")).on(), "partial: bad bool keeps default");
        T.eq(1.0, ((Settings.Num) r2.get("fps").find("size")).get(), "module with garbage data is reset to defaults");
        T.check(r2.get("fps").isEnabled(), "reset restores defaultEnabled");
        T.eq(-1, r2.get("fps").bind.code(), "reset clears key");

        r2.get("zoom").setEnabled(true);
        T.eq(2, r2.disableAll(), "disableAll counts enabled modules (fps + zoom)");
        T.check(r2.all().stream().noneMatch(Module::isEnabled), "everything off");
    }

    static void keys() {
        T.section("KeyTracker");
        ModuleRegistry r = sampleRegistry(new ArrayList<>());
        Module zoom = r.get("zoom"), fps = r.get("fps");
        zoom.bind.set(66);
        fps.bind.set(67);
        fps.bindMode.set(Module.KeyMode.HOLD);
        fps.setEnabled(false);
        KeyTracker kt = new KeyTracker(r);
        boolean[] down = new boolean[512];
        kt.update(k -> down[k]);
        T.check(!zoom.isEnabled(), "nothing pressed");
        down[66] = true;
        kt.update(k -> down[k]);
        T.check(zoom.isEnabled(), "press toggles on");
        kt.update(k -> down[k]);
        kt.update(k -> down[k]);
        T.check(zoom.isEnabled(), "holding a toggle key does not re-toggle");
        down[66] = false; kt.update(k -> down[k]);
        down[66] = true; kt.update(k -> down[k]);
        T.check(!zoom.isEnabled(), "second press toggles off");
        down[67] = true; kt.update(k -> down[k]);
        T.check(fps.isEnabled(), "hold mode on while down");
        down[67] = false; kt.update(k -> down[k]);
        T.check(!fps.isEnabled(), "hold mode off when released");
        down[66] = false; kt.update(k -> down[k]);
        down[66] = true;
        kt.reset();
        kt.update(k -> down[k]);
        T.check(zoom.isEnabled(), "after reset() a key that is still held counts as a fresh press (screen closed)");
        T.eq(zoom, KeyTracker.owner(r, 66, fps), "owner finds the module that already uses a key");
        T.eq(null, KeyTracker.owner(r, 66, zoom), "owner ignores the module itself");
        T.eq(null, KeyTracker.owner(r, -1, fps), "unbound key has no owner");
    }

    static void policy() {
        T.section("ServerPolicy");
        T.eq("play.example.com", ServerPolicy.normalizeHost("Play.Example.com:25565"), "strip port + case");
        T.eq("::1", ServerPolicy.normalizeHost("[::1]:25565"), "bracketed ipv6");
        T.eq("2001:db8::1", ServerPolicy.normalizeHost("2001:db8::1"), "bare ipv6 untouched");
        T.eq("example.com", ServerPolicy.normalizeHost("example.com."), "trailing dot");
        T.eq("", ServerPolicy.normalizeHost("bad host!"), "illegal characters -> empty");
        T.eq("", ServerPolicy.normalizeHost("  "), "blank");
        T.eq("*.example.com", ServerPolicy.normalizeHost("*.Example.com"), "wildcard kept");

        ServerPolicy p = new ServerPolicy();
        p.setContext(new ServerPolicy.Context(false, "mc.example.com"));
        T.eq(ServerMode.STANDARD, p.mode(), "unknown servers are STANDARD");
        T.check(p.allows(Feature.FULLBRIGHT) && p.allows(Feature.ZOOM), "standard allows visual QoL");
        T.check(!p.allows(Feature.AUTOMATION), "standard blocks automation");
        p.setMode("MC.example.com:25565", ServerMode.STRICT);
        T.eq(ServerMode.STRICT, p.mode(), "mode set by host");
        for (Feature f : Feature.values()) T.check(!p.allows(f), "strict blocks " + f);
        p.setMode("mc.example.com", ServerMode.OPEN);
        T.check(p.allows(Feature.AUTOMATION), "open allows automation");
        p.setMode("mc.example.com", ServerMode.STANDARD);
        T.eq(0, p.hosts().size(), "STANDARD removes the rule");
        p.setMode("*.strict.net", ServerMode.STRICT);
        T.eq(ServerMode.STRICT, p.modeFor("a.b.strict.net"), "wildcard match");
        T.eq(ServerMode.STRICT, p.modeFor("strict.net"), "wildcard matches bare domain");
        T.eq(ServerMode.STANDARD, p.modeFor("notstrict.net"), "wildcard does not match look-alikes");
        p.setContext(new ServerPolicy.Context(true, ""));
        T.eq(ServerMode.OPEN, p.mode(), "singleplayer is always OPEN");
        T.check(p.reason(Feature.ZOOM).contains("Zoom"), "reason names the feature");

        JsonObject j = p.toJson();
        ServerPolicy q = new ServerPolicy();
        q.fromJson(j);
        T.eq(ServerMode.STRICT, q.modeFor("x.strict.net"), "policy JSON round trip");
        q.fromJson(JsonParser.parseString("{\"a.com\":\"nonsense\",\"b.com\":\"open\",\"c d\":\"strict\"}").getAsJsonObject());
        T.eq(ServerMode.OPEN, q.modeFor("b.com"), "lenient mode names");
        T.eq(1, q.hosts().size(), "invalid entries dropped");
    }

    // ------------------------------------------------------------------
    static Path tmp() throws IOException { return Files.createTempDirectory("reaper-test"); }

    static void storage() throws IOException {
        T.section("JsonIO / ClientConfig / SaveScheduler");
        Path dir = tmp();
        Path f = dir.resolve("sub/x.json");
        JsonObject o = JsonParser.parseString("{\"a\":1}").getAsJsonObject();
        T.check(JsonIO.writeAtomic(f, o), "write creates parent directories");
        T.eq(1, JsonIO.readObject(f).get("a").getAsInt(), "read back");
        o.addProperty("a", 2);
        JsonIO.writeAtomic(f, o);
        T.eq(2, JsonIO.readObject(f).get("a").getAsInt(), "overwrite");
        T.check(Files.exists(JsonIO.backupOf(f)), "backup kept");
        T.check(!Files.exists(f.resolveSibling("x.json.tmp")), "no temp file left behind");
        Files.writeString(f, "{ this is not json", StandardCharsets.UTF_8);
        T.eq(1, JsonIO.readObject(f).get("a").getAsInt(), "corrupt main file falls back to the backup");
        Files.delete(f); Files.delete(JsonIO.backupOf(f));
        T.eq(null, JsonIO.readObject(f), "missing file -> null");
        Files.writeString(f, "[1,2]");
        T.eq(null, JsonIO.readObject(f), "non-object JSON -> null");
        T.eq(null, JsonIO.parseObject("x".repeat(2_000_000)), "oversized text refused");

        ClientConfig cc = new ClientConfig(dir);
        cc.activeProfile = "Pro"; cc.restoreGamma = 0.5; cc.welcomed = true;
        cc.windows.addProperty("k", 1);
        T.check(cc.save(), "client config saves");
        ClientConfig cc2 = new ClientConfig(dir);
        cc2.load();
        T.eq("Pro", cc2.activeProfile, "client config: active profile");
        T.eq(0.5, cc2.restoreGamma, "client config: gamma");
        T.check(cc2.welcomed, "client config: welcomed");
        T.eq(1, cc2.windows.get("k").getAsInt(), "client config: windows blob");
        ClientConfig cc3 = new ClientConfig(tmp());
        cc3.load();
        T.eq("Default", cc3.activeProfile, "no file -> defaults");
        T.check(Double.isNaN(cc3.restoreGamma), "no gamma by default");

        int[] saves = {0};
        SaveScheduler s = new SaveScheduler(() -> saves[0]++, 500, 3000);
        s.tick(0); T.eq(0, saves[0], "nothing to save");
        s.markDirty(1000); s.tick(1200); T.eq(0, saves[0], "waits until quiet");
        s.markDirty(1300); s.tick(1700); T.eq(0, saves[0], "each change restarts the quiet period");
        s.tick(1800); T.eq(1, saves[0], "saves once quiet");
        s.tick(5000); T.eq(1, saves[0], "no repeat saves");
        for (long t = 10_000; t < 14_000; t += 100) { s.markDirty(t); s.tick(t); }
        T.eq(2, saves[0], "constant changes still save after maxMs");
        s.markDirty(20_000); s.flush(); T.eq(3, saves[0], "flush saves immediately");
        s.flush(); T.eq(3, saves[0], "flush when clean does nothing");
    }

    static void profiles() throws IOException {
        T.section("ProfileStore");
        Path root = tmp();
        ModuleRegistry r = sampleRegistry(new ArrayList<>());
        ProfileStore ps = new ProfileStore(root, r);

        T.check(ProfileStore.validName("Default"), "valid");
        T.check(ProfileStore.validName("My profile-2.0"), "valid with punctuation");
        T.check(!ProfileStore.validName(""), "empty");
        T.check(!ProfileStore.validName("a/b"), "slash");
        T.check(!ProfileStore.validName("..\\x"), "backslash/dots");
        T.check(!ProfileStore.validName(" lead"), "leading space");
        T.check(!ProfileStore.validName("trail "), "trailing space");
        T.check(!ProfileStore.validName("x".repeat(33)), "too long");
        T.check(!ProfileStore.validName("CON"), "reserved device name");
        T.check(!ProfileStore.validName("nul.txt"), "reserved device name with extension");
        T.check(!ProfileStore.validName("éclair"), "non-ascii start rejected (portable file names)");

        T.eq(List.of("Default"), ps.list(), "a fresh store always lists the active profile");
        ps.load("Default");
        ((Settings.Num) r.get("fps").find("size")).set(2.5);
        r.get("zoom").setEnabled(true);
        T.check(ps.saveActive(), "save active");
        T.check(ps.create("Minimal"), "create");
        T.check(!ps.create("minimal"), "names are case-insensitively unique");
        T.check(!ps.create("bad/name"), "invalid name refused");
        T.eq(List.of("Default", "Minimal"), ps.list(), "list sorted");

        T.check(ps.switchTo("minimal"), "switch (case-insensitive)");
        T.eq("Minimal", ps.active(), "active name has the stored casing");
        T.eq(1.0, ((Settings.Num) r.get("fps").find("size")).get(), "new profile = defaults");
        T.check(!r.get("zoom").isEnabled(), "new profile: zoom off");
        ((Settings.Bool) r.get("zoom").find("smooth")).set(false);
        r.get("fps").bind.set(71);
        T.check(ps.switchTo("Default"), "switch back saves Minimal first");
        T.eq(2.5, ((Settings.Num) r.get("fps").find("size")).get(), "Default restored");
        T.check(r.get("zoom").isEnabled(), "Default: zoom on again");
        ps.switchTo("Minimal");
        T.check(!((Settings.Bool) r.get("zoom").find("smooth")).on(), "Minimal kept its change");
        T.eq(71, r.get("fps").bind.code(), "Minimal kept its key");
        T.check(!ps.switchTo("DoesNotExist"), "switching to a missing profile fails");
        T.eq("Minimal", ps.active(), "and leaves the active profile alone");

        T.check(ps.duplicate("Minimal", "Copy"), "duplicate");
        T.check(ps.switchTo("Copy"), "switch to the copy");
        T.eq(71, r.get("fps").bind.code(), "copy has the same data");
        T.check(ps.rename("Copy", "Renamed"), "rename the active profile");
        T.eq("Renamed", ps.active(), "active name follows the rename");
        T.check(!ps.rename("Renamed", "Default"), "rename onto an existing name refused");
        T.check(!ps.delete("Renamed"), "cannot delete the active profile");
        T.check(ps.delete("Minimal"), "delete another profile");
        T.check(!Files.exists(root.resolve("profiles/Minimal.json")), "file removed");
        T.eq(List.of("Default", "Renamed"), ps.list(), "list after changes");

        String exported = ps.export("Renamed");
        T.check(exported != null && exported.startsWith("REAPER1:"), "export prefix");
        T.check(!exported.contains("="), "URL-safe base64 without padding");
        String imported = ps.importText(exported, null);
        T.eq("Renamed 2", imported, "import never overwrites: gets a unique name");
        T.eq("Mine", ps.importText("  " + exported + "\n", "Mine"), "import with chosen name, whitespace tolerated");
        T.eq(null, ps.importText("hello", null), "import: not our format");
        T.eq(null, ps.importText("REAPER1:!!!not-base64!!!", null), "import: bad base64");
        T.eq(null, ps.importText("REAPER1:" + Base64.getUrlEncoder().encodeToString("{\"x\":1}".getBytes(StandardCharsets.UTF_8)), null), "import: JSON without modules");
        T.eq(null, ps.importText("REAPER1:" + Base64.getUrlEncoder().encodeToString("[1]".getBytes(StandardCharsets.UTF_8)), null), "import: JSON that is not an object");
        T.eq(null, ps.importText("REAPER1:" + "A".repeat(600_000), null), "import: oversized refused");
        ps.switchTo("Mine");
        T.eq(71, r.get("fps").bind.code(), "imported profile applies");

        // hostile import: values are sanitised by the settings, unknown modules ignored
        String evil = "{\"modules\":{\"fps\":{\"enabled\":true,\"settings\":{\"size\":1e99,\"color\":\"zzz\",\"label\":\"" + "x".repeat(500) + "\"}},\"nope\":{}}}";
        String ev = ps.importText("REAPER1:" + Base64.getUrlEncoder().withoutPadding().encodeToString(evil.getBytes(StandardCharsets.UTF_8)), "Evil");
        T.eq("Evil", ev, "hostile import accepted as data");
        ps.switchTo("Evil");
        T.eq(3.0, ((Settings.Num) r.get("fps").find("size")).get(), "huge number clamped to the setting's max");
        T.eq(8, ((Settings.Str) r.get("fps").find("label")).get().length(), "long text truncated");

        // corrupt profile file falls back to defaults, never throws
        Files.writeString(root.resolve("profiles/Default.json"), "garbage");
        Files.deleteIfExists(root.resolve("profiles/Default.json.bak"));
        ps.switchTo("Default");
        T.eq(1.0, ((Settings.Num) r.get("fps").find("size")).get(), "corrupt profile -> defaults");
        // a stray non-profile file in the folder is ignored
        Files.writeString(root.resolve("profiles/notes.txt"), "hi");
        Files.writeString(root.resolve("profiles/bad..name.json"), "{}");
        T.check(!ps.list().contains("notes"), "stray files ignored");
        T.check(ps.uniqueName("a/b:c").startsWith("abc"), "uniqueName sanitises");
        T.eq("Profile", ps.uniqueName("///"), "uniqueName falls back");
    }
}
