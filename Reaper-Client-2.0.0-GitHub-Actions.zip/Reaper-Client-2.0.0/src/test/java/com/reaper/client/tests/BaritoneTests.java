package com.reaper.client.tests;

import baritone.api.BaritoneAPI;
import com.reaper.client.core.feature.AutomationModule;
import com.reaper.client.core.feature.BaritoneBridge;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.policy.ServerMode;
import com.reaper.client.core.policy.ServerPolicy;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * The reflection link to Baritone, run against a stand-in that has Baritone's package, class and method names (see
 * src/test/java/baritone). This shows the bridge finds and calls those methods and degrades safely; it cannot show
 * that the real Baritone jar behaves the same, which only a run in the game can.
 */
public final class BaritoneTests {
    private BaritoneTests() {}

    public static void run() throws Exception {
        missing();
        present();
        failures();
        inModule();
    }

    private static void missing() throws Exception {
        T.section("Baritone: not installed");
        try (URLClassLoader blind = new URLClassLoader(new URL[0], null)) {   // sees no Baritone classes at all
            BaritoneBridge b = new BaritoneBridge(blind);
            T.check(!b.installed(), "a loader without Baritone reports it as not installed");
            T.eq("Baritone is not installed.", b.run("goto 1 2 3"), "running a command says Baritone is missing");
            T.check(!b.installed(), "and it stays that way");

            AutomationModule m = new AutomationModule();
            m.setBridge(b);
            m.setEnabled(true);
            T.check(m.unavailable().contains("not installed"), "the module explains it: " + m.unavailable());
            T.check(m.goTo(1, 64, 1).contains("not installed"), "goto is refused");
            T.check(m.stopAll().contains("not installed"), "stop reports that nothing can be stopped");
        }
    }

    private static void present() {
        T.section("Baritone: installed");
        BaritoneAPI.Control.reset();
        BaritoneBridge b = new BaritoneBridge();
        T.check(b.installed(), "the bridge finds BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager()");
        T.check(b.run("goto 10 64 -20") == null, "a known command succeeds");
        T.eq(1, BaritoneAPI.Control.SENT.size(), "exactly one command was sent");
        T.eq("goto 10 64 -20", BaritoneAPI.Control.SENT.get(0), "and it is the text that was given, without any prefix");
        T.check(b.run("mine diamond_ore") == null, "mine is accepted");
        T.eq("mine diamond_ore", BaritoneAPI.Control.SENT.get(1), "the command arrives unchanged");
    }

    private static void failures() {
        T.section("Baritone: problems come back as text");
        BaritoneAPI.Control.reset();
        BaritoneBridge b = new BaritoneBridge();

        T.eq("Nothing to do.", b.run("   "), "a blank command is refused");
        T.eq("Nothing to do.", b.run(null), "a missing command is refused");
        T.eq(0, BaritoneAPI.Control.SENT.size(), "and nothing was sent for either");

        String why = b.run("fly 1 2 3");
        T.check(why != null && why.contains("did not recognise"), "an unknown command is reported: " + why);

        BaritoneAPI.Control.throwInExecute = true;
        String boom = null;
        try {
            boom = b.run("goto 1 2 3");
        } catch (Throwable t) {
            T.check(false, "an exception inside Baritone must not escape: " + t);
        }
        T.check(boom != null && boom.contains("IllegalStateException") && boom.contains("player is null"), "the error is named in the text: " + boom);
        BaritoneAPI.Control.throwInExecute = false;
        T.check(b.run("stop") == null, "the bridge keeps working after an error");

        BaritoneAPI.Control.noPrimary = true;
        T.eq("Baritone is not ready yet.", b.run("stop"), "no primary Baritone yet is reported, not thrown");
        BaritoneAPI.Control.noPrimary = false;
        T.check(b.run("stop") == null, "and works once there is one");
    }

    private static void inModule() {
        T.section("Baritone: through the module and the server rules");
        BaritoneAPI.Control.reset();
        ServerPolicy policy = new ServerPolicy();
        ModuleRegistry registry = new ModuleRegistry();
        AutomationModule m = new AutomationModule();
        registry.register(m);
        registry.setPolicyGate(policy::allows);
        m.setBridge(new BaritoneBridge());
        m.setEnabled(true);

        policy.setContext(ServerPolicy.Context.NONE);
        T.check(m.goTo(5, 70, 5) != null, "outside any world the module is off");

        policy.setContext(new ServerPolicy.Context(true, ""));
        m.tick();
        T.check(m.unavailable() == null, "in singleplayer, enabled, with Baritone present, it is available: " + m.unavailable());
        T.check(m.goTo(10, 64, -20) == null, "goto goes through");
        T.check(m.mine("Diamond_Ore") == null, "mine goes through, lower-cased");
        T.check(m.mine("diamond_ore; stop") != null, "text that is not a block name is refused");
        T.eq("goto 10 64 -20", BaritoneAPI.Control.SENT.get(0), "the goto command as sent");
        T.eq("mine diamond_ore", BaritoneAPI.Control.SENT.get(1), "the mine command as sent");
        T.eq(2, BaritoneAPI.Control.SENT.size(), "nothing else was sent");

        policy.setContext(new ServerPolicy.Context(false, "play.example.net"));
        T.eq(ServerMode.STANDARD, policy.mode(), "an unknown server is Standard");
        T.check(m.goTo(1, 2, 3) != null, "goto is refused on a Standard server");
        T.check(m.tick(), "the module cancels what Baritone was doing the moment the rules stop allowing it");
        T.eq("stop", BaritoneAPI.Control.SENT.get(BaritoneAPI.Control.SENT.size() - 1), "by sending Baritone's stop command");

        int before = BaritoneAPI.Control.SENT.size();
        T.check(m.stopAll() == null, "Stop always works, even here");
        T.eq(before + 1, BaritoneAPI.Control.SENT.size(), "and it did send the stop command");
    }
}
