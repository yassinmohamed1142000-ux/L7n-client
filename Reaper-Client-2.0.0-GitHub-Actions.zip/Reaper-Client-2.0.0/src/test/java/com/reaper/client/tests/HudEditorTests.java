package com.reaper.client.tests;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudEditor;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.hud.HudLayout;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.ui.Input;

import java.util.ArrayList;
import java.util.List;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;

/** Drives the HUD editor headlessly, like GuiHarness does for the ClickGUI. */
final class HudEditorTests {
    private HudEditorTests() {}

    private static final class Rig implements HudEditor.Host {
        final HudRig hud;
        final HudEditor ed;
        int saves, closes;
        final List<String> toasts = new ArrayList<>();

        Rig(int w, int h) { this(w, h, "fps"); }

        Rig(int w, int h, String... only) {
            hud = new HudRig(w, h);
            hud.only(only);
            hud.editing = true;
            ed = new HudEditor(hud.hud, this);
            ed.open();
            frames(30);
        }

        @Override public void requestSave() { saves++; }
        @Override public void close() { closes++; }
        @Override public void toast(Level level, String message) { toasts.add(level + ": " + message); }

        void frame() {
            HudRig r = hud;
            r.now += 16;
            r.d.nowMs = r.now;
            r.hud.update(r.d);
            r.cv.begin(0xFF000000);
            r.cv.gradientV(0, 0, r.W, r.H * 2 / 3, 0xFF6FA8DC, 0xFFBFD9EE);
            r.cv.gradientV(0, r.H * 2 / 3, r.W, r.H - r.H * 2 / 3, 0xFF4F7A3A, 0xFF2F4A24);
            ed.render(r.cv, r.d, r.theme, (int) Math.round(ed.in.mx), (int) Math.round(ed.in.my), 1f / 60f);
        }

        void frames(int n) { for (int i = 0; i < n; i++) frame(); }
        void move(double x, double y) { ed.in.mouseMove(x, y); frame(); }
        void down(int b) { ed.in.mouseDown(b, ed.in.mx, ed.in.my); frame(); }
        void up(int b) { ed.in.mouseUp(b, ed.in.mx, ed.in.my); frame(); }
        void click(int b, double x, double y) { move(x, y); down(b); up(b); }
        void key(int k, int mods) { ed.in.key(k, mods); frame(); }

        void drag(double x0, double y0, double x1, double y1) {
            move(x0, y0);
            down(Input.LEFT);
            for (int i = 1; i <= 8; i++) move(x0 + (x1 - x0) * i / 8, y0 + (y1 - y0) * i / 8);
            up(Input.LEFT);
            frames(2);
        }

        HudElement el(String id) { return hud.get(id); }
        double cx(HudElement e) { return e.rx + e.rw / 2.0; }
        double cy(HudElement e) { return e.ry + e.rh / 2.0; }
    }

    static void run() {
        T.section("HUD editor");
        Rig r = new Rig(427, 240);
        HudElement fps = r.el("fps");

        // the screen and its palette
        check(r.hud.has("Drag: move  |  Scroll: resize  |  Arrows: nudge") && r.hud.has("Right-click: reset  |  Delete: hide  |  Esc: done"), "the hint is shown");
        check(r.hud.has("Done") && r.hud.has("Reset layout") && r.hud.has("Elements"), "the toolbar buttons are drawn");
        for (HudElement e : r.hud.el.values()) check(r.hud.has(e.name), "the palette lists " + e.name);
        for (RasterCanvas.Drawn d : r.hud.cv.texts) check(d.x() >= 0 && d.x() + d.w() <= r.hud.W, "text \"" + d.text() + "\" fits on the screen width");
        check(r.hud.has("FPS: 144"), "elements are drawn with sample data");

        // plain drag, no snapping (Alt held)
        r.ed.in.mods = Input.MOD_ALT;
        int sx = fps.rx + 5, sy = fps.ry + 5;
        r.drag(sx, sy, sx + 60, sy + 40);
        r.ed.in.mods = 0;
        eq(Anchor.TOP_LEFT, fps.anchor.v(), "still anchored top-left");
        eq(64, fps.offsetX.i(), "dragged 60 right");
        eq(44, fps.offsetY.i(), "dragged 40 down");
        eq(1, r.saves, "one save for one drag");
        check(r.ed.selected() == fps, "the dragged element is selected");
        eq(null, r.ed.dragging(), "the drag ended");

        // snapping to the margin
        r.saves = 0;
        sx = fps.rx + 5; sy = fps.ry + 5;
        r.drag(sx, sy, sx - 56, sy - 38);     // would land at x=8, y=6: within reach of the margin (4)
        eq(4, fps.offsetX.i(), "snaps to the left margin");
        eq(4, fps.offsetY.i(), "snaps to the top margin");
        r.hud.cv.begin(0);
        // snapping to the centre produces guide lines while dragging
        sx = fps.rx + 5; sy = fps.ry + 5;
        r.move(sx, sy);
        r.down(Input.LEFT);
        double targetX = 213.5 - fps.rw / 2.0 + 3 + 5;   // so the element's centre is a few pixels from the screen centre
        for (int i = 1; i <= 6; i++) r.move(sx + (targetX - sx) * i / 6, sy + 100.0 * i / 6);
        check(r.ed.guideCount() > 0, "a guide line appears near the screen centre");
        r.up(Input.LEFT);
        r.frames(2);
        eq(0, r.ed.guideCount(), "guides disappear when the drag ends");
        eq(Anchor.CENTER == fps.anchor.v() || Anchor.MIDDLE_LEFT == fps.anchor.v() || Anchor.TOP_CENTER == fps.anchor.v(), true, "re-anchored to a sensible region (" + fps.anchor.v() + ")");

        // dragging into the bottom-right corner re-anchors and keeps the element on screen
        sx = fps.rx + 5; sy = fps.ry + 5;
        r.drag(sx, sy, 500, 400);
        eq(Anchor.BOTTOM_RIGHT, fps.anchor.v(), "bottom-right anchor");
        check(fps.rx >= 0 && fps.ry >= 0 && fps.rx + fps.rw <= 427 && fps.ry + fps.rh <= 240, "stays inside the screen (" + fps.rx + "," + fps.ry + ")");
        check(fps.offsetX.i() >= 0 && fps.offsetY.i() >= 0, "offsets are measured inwards");
        eq(427, HudLayout.x(fps.anchor.v(), fps.offsetX.i(), fps.rw, 427) + fps.rw, "flush with the right edge");

        // a click without moving saves nothing
        r.saves = 0;
        r.click(Input.LEFT, r.cx(fps), r.cy(fps));
        eq(0, r.saves, "selecting without moving does not save");
        // clicking empty space deselects
        r.click(Input.LEFT, 5, 120);
        eq(null, r.ed.selected(), "clicking empty space deselects");

        // wheel resizing (in the top-left corner, clear of the toolbar)
        fps.resetPosition();
        r.frames(2);
        r.move(r.cx(fps), r.cy(fps));
        double before = fps.scale.v();
        r.ed.in.scroll(1); r.frame();
        eq(before + 0.05, fps.scale.v(), "scroll up grows by a small step");
        r.ed.in.scroll(-1); r.frame();
        eq(before, fps.scale.v(), "scroll down shrinks it again");
        r.ed.in.mods = Input.MOD_SHIFT;
        r.ed.in.scroll(1); r.frame();
        eq(before + 0.25, fps.scale.v(), "shift makes the step bigger");
        r.ed.in.mods = 0;
        fps.scale.set(2.9); r.frames(2);
        for (int i = 0; i < 6; i++) { r.move(r.cx(fps), r.cy(fps)); r.ed.in.scroll(1); r.frame(); }
        eq(3.0, fps.scale.v(), "scale stops at the maximum");
        fps.scale.set(0.6); r.frames(2);
        for (int i = 0; i < 6; i++) { r.move(r.cx(fps), r.cy(fps)); r.ed.in.scroll(-1); r.frame(); }
        eq(0.5, fps.scale.v(), "scale stops at the minimum");
        fps.scale.set(1.0); r.frames(2);

        // right click resets
        r.saves = 0; r.toasts.clear();
        r.click(Input.RIGHT, r.cx(fps), r.cy(fps));
        eq(fps.defaultAnchor, fps.anchor.v(), "right-click restores the anchor");
        eq(fps.defaultOffsetX, fps.offsetX.i(), "right-click restores the offset");
        check(r.saves == 1 && r.toasts.size() == 1, "and tells the player");

        // keyboard
        r.click(Input.LEFT, r.cx(fps), r.cy(fps));
        int ox = fps.offsetX.i(), oy = fps.offsetY.i();
        r.key(KeyNames.RIGHT, 0);
        eq(ox + 1, fps.offsetX.i(), "right arrow nudges one pixel");
        r.key(KeyNames.DOWN, Input.MOD_SHIFT);
        eq(oy + 10, fps.offsetY.i(), "shift + down arrow nudges ten pixels");
        r.key(KeyNames.LEFT, 0); r.key(KeyNames.UP, Input.MOD_SHIFT);
        eq(ox, fps.offsetX.i(), "left arrow");
        eq(oy, fps.offsetY.i(), "up arrow");
        r.key(82, 0);
        eq(fps.defaultOffsetX, fps.offsetX.i(), "R resets the selected element");
        r.key(KeyNames.DELETE, 0);
        check(!fps.isEnabled(), "Delete hides the selected element");
        check(r.toasts.get(r.toasts.size() - 1).contains("hidden"), "and says how to get it back");
        r.frames(2);
        check(!r.hud.has("FPS: 144"), "it is gone from the screen");

        // palette
        r.click(Input.LEFT, r.hud.text("FPS Counter").x() + 5, r.hud.text("FPS Counter").y() + 3);
        check(fps.isEnabled(), "clicking its chip brings it back");
        r.frames(2);
        check(r.hud.has("FPS: 144"), "and it is drawn again");
        HudElement co = r.el("coordinates");
        boolean was = co.isEnabled();
        r.click(Input.LEFT, r.hud.text("Coordinates").x() + 5, r.hud.text("Coordinates").y() + 3);
        eq(!was, co.isEnabled(), "chips toggle elements");
        r.click(Input.LEFT, r.hud.text("Elements").x() + 5, r.hud.text("Elements").y() + 3);
        check(!r.ed.paletteOpen(), "the palette can be collapsed");
        check(!r.hud.has("Sprint Indicator"), "the chips are hidden then");
        r.click(Input.LEFT, r.hud.text("Elements").x() + 5, r.hud.text("Elements").y() + 3);
        check(r.ed.paletteOpen(), "and opened again");

        // the toolbar is not click-through
        RasterCanvas.Drawn chip = r.hud.text("Armor Status");
        r.saves = 0;
        HudElement armor = r.el("armor");
        int aox = armor.offsetX.i();
        r.drag(chip.x() + 3, chip.y() + 3, chip.x() + 40, chip.y() + 3);
        eq(aox, armor.offsetX.i(), "pressing on the toolbar never drags an element behind it");

        // reset layout needs a second click
        r.saves = 0;
        fps.offsetX.set(90.0);
        RasterCanvas.Drawn rl = r.hud.text("Reset layout");
        r.click(Input.LEFT, rl.x() + 5, rl.y() + 3);
        eq(90, fps.offsetX.i(), "the first click only arms the reset");
        check(r.hud.has("Click to confirm"), "the button asks for confirmation");
        RasterCanvas.Drawn cf = r.hud.text("Click to confirm");
        r.click(Input.LEFT, cf.x() + 5, cf.y() + 3);
        eq(fps.defaultOffsetX, fps.offsetX.i(), "the second click resets every element");
        check(r.saves >= 1, "and saves");
        fps.offsetX.set(90.0);
        r.click(Input.LEFT, r.hud.text("Reset layout").x() + 5, r.hud.text("Reset layout").y() + 3);
        r.frames(60 * 4);
        check(r.hud.has("Reset layout") && !r.hud.has("Click to confirm"), "the confirmation times out");

        // done / escape
        r.closes = 0;
        RasterCanvas.Drawn done = r.hud.text("Done");
        r.click(Input.LEFT, done.x() + 3, done.y() + 3);
        eq(1, r.closes, "Done closes the editor");
        r.key(KeyNames.ESCAPE, 0);
        eq(2, r.closes, "Escape closes the editor");

        // closing in the middle of a drag still saves it
        r.saves = 0;
        r.ed.open();
        r.frames(5);
        fps.setEnabled(true); r.frames(2);
        r.ed.in.mods = Input.MOD_ALT;
        r.move(fps.rx + 3, fps.ry + 3);
        r.down(Input.LEFT);
        r.move(fps.rx + 40, fps.ry + 30);
        r.ed.close();
        check(r.saves >= 1, "a drag in progress is saved when the editor closes");
        r.ed.in.mods = 0;

        // several elements can be arranged, hit testing follows the drawn order, and snapping aligns neighbours
        Rig s = new Rig(427, 240, "fps", "cps");
        s.hud.only("fps", "cps");
        s.hud.el.get("cps").anchor.set(Anchor.TOP_LEFT);
        s.hud.el.get("cps").offsetX.set(150.0);
        s.hud.el.get("cps").offsetY.set(100.0);
        s.frames(5);
        HudElement cps = s.el("cps"), f = s.el("fps");
        int targetStart = cps.rx;
        // drag fps so its left edge is two pixels from the cps left edge: it should snap to align exactly
        s.drag(f.rx + 3, f.ry + 3, targetStart + 3 + 2, 60);
        eq(cps.rx, f.rx, "dragging near another element aligns the edges");

        // leaks: the editor's widget state stays bounded however long it is open (no painting needed for this)
        HudRig lk = new HudRig(427, 240);
        lk.only("fps");
        lk.editing = true;
        HudEditor leakEd = new HudEditor(lk.hud, new HudEditor.Host() {
            @Override public void requestSave() { }
            @Override public void close() { }
            @Override public void toast(Level level, String message) { }
        });
        leakEd.open();
        NullCanvas nc = new NullCanvas(427, 240);
        for (int i = 0; i < 30; i++) leakEd.render(nc, lk.d, lk.theme, 100, 100, 1f / 60f);
        int base = leakEd.uiStateCount();
        for (int i = 0; i < 4000; i++) { leakEd.in.mouseMove(50 + i % 300, 80 + i % 100); leakEd.render(nc, lk.d, lk.theme, 50 + i % 300, 80 + i % 100, 1f / 60f); }
        check(leakEd.uiStateCount() <= base + 2, "no widget state accumulates (" + base + " -> " + leakEd.uiStateCount() + ")");

        // preview
        Rig pv = new Rig(427, 240, "fps");
        pv.hud.enableAll();
        pv.hud.d.singleplayer = false;
        pv.frames(10);
        pv.move(pv.cx(pv.el("coordinates")), pv.cy(pv.el("coordinates")));
        pv.ed.in.mouseDown(Input.LEFT, pv.ed.in.mx, pv.ed.in.my);
        pv.frames(3);
        pv.hud.preview("hud-editor");
    }
}
