package com.reaper.client.tests;

import com.reaper.client.core.ui.Canvas;
import com.reaper.client.core.util.Colors;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Test-only software implementation of {@link Canvas} on top of java.awt (headless). It follows Minecraft's font
 * metrics (6 px advance for most letters, line height 9) so layouts measured here match the game closely, records
 * every piece of text it draws so tests can find and click widgets by label, and can save PNG previews.
 */
public final class RasterCanvas implements Canvas {
    /** One drawn piece of text, in GUI coordinates after all transforms. */
    public record Drawn(String text, int x, int y, int w, int h) {}

    public final BufferedImage img;
    public final List<Drawn> texts = new ArrayList<>();
    public int fills;

    private final Graphics2D g;
    private final int px, guiW, guiH;
    private final Font base;

    private float ox, oy, sc = 1f;
    private final float[] tStack = new float[3 * 32];
    private int tn;

    private Rectangle clip;
    private final Rectangle[] clipStack = new Rectangle[64];
    private int cn;

    private float alpha = 1f;
    private final float[] aStack = new float[16];
    private int an;

    /** @param guiW,guiH size in GUI pixels; @param pixelScale device pixels per GUI pixel (2 looks like Minecraft's GUI scale 2). */
    public RasterCanvas(int guiW, int guiH, int pixelScale) {
        this.guiW = guiW;
        this.guiH = guiH;
        this.px = pixelScale;
        img = new BufferedImage(guiW * pixelScale, guiH * pixelScale, BufferedImage.TYPE_INT_ARGB);
        g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        base = new Font("DejaVu Sans", Font.BOLD, 8);
    }

    /** Clears the picture and the recorded text; call at the start of every frame. */
    public void begin(int backgroundArgb) {
        g.setClip(null);
        g.setComposite(AlphaComposite.Src);
        g.setColor(new Color(backgroundArgb, true));
        g.fillRect(0, 0, img.getWidth(), img.getHeight());
        g.setComposite(AlphaComposite.SrcOver);
        texts.clear();
        fills = 0;
        ox = oy = 0;
        sc = 1f;
        tn = 0;
        clip = null;
        cn = 0;
        alpha = 1f;
        an = 0;
    }

    public void save(File f) throws IOException {
        File dir = f.getParentFile();
        if (dir != null) dir.mkdirs();
        javax.imageio.ImageIO.write(img, "png", f);
    }

    // ------------------------------------------------------------------ metrics (Minecraft default font)
    /** Advance width of one character in GUI pixels, as in Minecraft's default font. */
    public static int advance(char ch) {
        switch (ch) {
            case ' ': return 4;
            case 'i': case '!': case '.': case ',': case ':': case ';': case '|': case '\'': return 2;
            case 'l': case '`': return 3;
            case 'I': case 't': case '[': case ']': case '(': case ')': case '{': case '}': case '"': case '*': return 4;
            case 'f': case 'k': case '<': case '>': return 5;
            case '@': case '~': return 7;
            default: return 6;
        }
    }

    @Override public int width() { return guiW; }
    @Override public int height() { return guiH; }
    @Override public int lineHeight() { return 9; }

    @Override public int textWidth(String s) {
        int w = 0;
        for (int i = 0; i < s.length(); i++) w += advance(s.charAt(i));
        return Math.max(0, w - (s.isEmpty() ? 0 : 1));
    }

    // ------------------------------------------------------------------ geometry helpers
    private int dx(float x) { return Math.round((x * sc + ox) * px); }
    private int dy(float y) { return Math.round((y * sc + oy) * px); }

    private Color color(int argb) {
        int a = Math.round((argb >>> 24) * alpha);
        return new Color((argb & 0xFFFFFF) | (Math.max(0, Math.min(255, a)) << 24), true);
    }

    // ------------------------------------------------------------------ primitives
    @Override public void fill(int x, int y, int w, int h, int argb) {
        if (w <= 0 || h <= 0 || (argb >>> 24) == 0) return;
        fills++;
        g.setColor(color(argb));
        int x0 = dx(x), y0 = dy(y), x1 = dx(x + w), y1 = dy(y + h);
        g.fillRect(x0, y0, Math.max(0, x1 - x0), Math.max(0, y1 - y0));
    }

    @Override public void gradientV(int x, int y, int w, int h, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        int x0 = dx(x), x1 = dx(x + w), y0 = dy(y), y1 = dy(y + h);
        int rows = Math.max(1, y1 - y0);
        for (int r = 0; r < rows; r++) {
            g.setColor(color(Colors.lerp(top, bottom, (r + 0.5f) / rows)));
            g.fillRect(x0, y0 + r, Math.max(0, x1 - x0), 1);
        }
    }

    @Override public void text(String s, int x, int y, int argb, boolean shadow) {
        if (s == null || s.isEmpty()) return;
        int w = textWidth(s);
        texts.add(new Drawn(s, Math.round(x * sc + ox), Math.round(y * sc + oy), Math.round(w * sc), Math.round(8 * sc)));
        if (shadow) drawString(s, x + 1, y + 1, (argb & 0xFF000000) | ((argb & 0xFCFCFC) >> 2));
        drawString(s, x, y, argb);
    }

    private void drawString(String s, int x, int y, int argb) {
        g.setColor(color(argb));
        g.setFont(base.deriveFont(8f * sc * px));
        int cx = x;
        java.awt.FontMetrics fm = g.getFontMetrics();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            int adv = advance(ch);
            if (ch != ' ') {
                String one = String.valueOf(ch);
                float gw = fm.stringWidth(one);
                float cellW = (adv - 1) * sc * px;
                float gx = (cx * sc + ox) * px + Math.max(0f, (cellW - gw) / 2f);
                float gy = (y * sc + oy + 7f * sc) * px;
                g.drawString(one, gx, gy);
            }
            cx += adv;
        }
    }

    @Override public void clip(int x, int y, int w, int h) {
        if (cn < clipStack.length) clipStack[cn++] = clip;
        Rectangle r = new Rectangle(dx(x), dy(y), Math.max(0, dx(x + w) - dx(x)), Math.max(0, dy(y + h) - dy(y)));
        clip = clip == null ? r : clip.intersection(r);
        g.setClip(clip);
    }

    @Override public void unclip() {
        if (cn > 0) clip = clipStack[--cn];
        g.setClip(clip);
    }

    @Override public void push() {
        if (tn < 32) { tStack[tn * 3] = ox; tStack[tn * 3 + 1] = oy; tStack[tn * 3 + 2] = sc; tn++; }
    }

    @Override public void pop() {
        if (tn > 0) { tn--; ox = tStack[tn * 3]; oy = tStack[tn * 3 + 1]; sc = tStack[tn * 3 + 2]; }
    }

    @Override public void translate(float x, float y) { ox += x * sc; oy += y * sc; }

    @Override public void scale(float s) { sc *= s; }

    @Override public void pushAlpha(float a) {
        if (an < aStack.length) aStack[an++] = alpha;
        alpha *= Math.max(0f, Math.min(1f, a));
    }

    @Override public void popAlpha() { if (an > 0) alpha = aStack[--an]; }

    @Override public void item(Object stack, int x, int y, boolean decorations) {
        if (stack == null) return;
        int h = stack.toString().hashCode();
        int col = Colors.hsb(((h >>> 3) & 0x3FF) / 1024f, 0.5f, 0.85f);
        roundRect(x + 1, y + 1, 14, 14, 3, col);
        roundRect(x + 3, y + 3, 10, 10, 2, Colors.darken(col, 0.25f));
    }

    @Override public void image(Object texture, int texW, int texH, int x, int y, int w, int h) {
        if (!(texture instanceof BufferedImage bi)) return;
        int x0 = dx(x), y0 = dy(y), x1 = dx(x + w), y1 = dy(y + h);
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.max(0f, Math.min(1f, alpha))));
        g.drawImage(bi, x0, y0, x1 - x0, y1 - y0, null);
        g.setComposite(AlphaComposite.SrcOver);
    }

    // ------------------------------------------------------------------ pixel access for assertions
    public int pixel(int guiX, int guiY) {
        int x = Math.max(0, Math.min(img.getWidth() - 1, guiX * px + px / 2));
        int y = Math.max(0, Math.min(img.getHeight() - 1, guiY * px + px / 2));
        return img.getRGB(x, y);
    }

    /** First recorded text equal to {@code s}, or null. */
    public Drawn find(String s) {
        for (Drawn d : texts) if (d.text().equals(s)) return d;
        return null;
    }

    /** First recorded text starting with the prefix, or null. */
    public Drawn findPrefix(String prefix) {
        for (Drawn d : texts) if (d.text().startsWith(prefix)) return d;
        return null;
    }
}
