package com.reaper.client.tests;

import com.reaper.client.core.ReaperCore;
import com.reaper.client.core.feature.AutomationModule;
import com.reaper.client.core.feature.Waypoint;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.policy.ServerMode;
import com.reaper.client.core.policy.ServerPolicy;
import com.reaper.client.core.setting.Setting;
import com.reaper.client.core.ui.InterfaceModule;
import com.reaper.client.core.ui.UiWindow;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;

/** The real module set wired together: registration, rules, saving and loading, crash recovery, and the real GUI and HUD. */
final class WiringTests {
    private WiringTests() {}

    private static final ServerPolicy.Context SINGLEPLAYER = new ServerPolicy.Context(true, "");
    private static final ServerPolicy.Context SERVER = new ServerPolicy.Context(false, "play.example.com");

    /** A core on a fresh temporary folder with a clock the test controls. */
    private static final class Env {
        final Path dir, shots;
        final long[] t = {5_000_000L};
        ReaperCore core;

        Env() throws IOException {
            dir = Files.createTempDirectory("reaper-wiring");
            shots = dir.resolve("screenshots");
            core = open();
        }

        ReaperCore open() { return new ReaperCore(dir, shots, () -> t[0]); }
    }

    static void run() throws IOException {
        T.section("Wiring: registration");
        registration();
        T.section("Wiring: server rules");
        rules();
        T.section("Wiring: saving and loading");
        persistence();
        T.section("Wiring: save timing");
        timing();
        T.section("Wiring: brightness safety");
        brightness();
        T.section("Wiring: automation safety");
        automation();
        T.section("Wiring: damaged files");
        damaged();
        T.section("Wiring: real GUI and HUD");
        realGui();
    }

    // ------------------------------------------------------------------ registration
    private static void registration() throws IOException {
        Env e = new Env();
        ReaperCore c = e.core;
        List<String> ids = new ArrayList<>();
        for (Module m : c.modules.all()) ids.add(m.id);
        eq((long) ids.size(), ids.stream().distinct().count(), "every module id is unique");
        for (String id : new String[]{"fps", "coordinates", "cps", "ping", "sprint", "worldinfo", "direction", "armor", "durability", "keystrokes", "modulelist", "notifications", "waypointsHud",
                "crosshair", "zoom", "fullbright", "waypoints", "sorter", "chat", "automation", "interface"})
            check(c.modules.get(id) != null, "module registered: " + id + (c.modules.get(id) == null ? "  (have: " + ids + ")" : ""));
        eq(13, c.modules.in(Category.HUD).size(), "13 HUD elements");
        eq(List.of("crosshair", "zoom", "fullbright"), c.modules.in(Category.VISUAL).stream().map(m -> m.id).toList(), "visual modules");
        eq(List.of("waypoints", "sorter", "chat"), c.modules.in(Category.UTILITY).stream().map(m -> m.id).toList(), "utility modules");
        eq(List.of("automation"), c.modules.in(Category.AUTOMATION).stream().map(m -> m.id).toList(), "automation modules");
        eq(List.of("interface"), c.modules.in(Category.CLIENT).stream().map(m -> m.id).toList(), "client modules");
        for (Module m : c.modules.all()) {
            check(!m.name.isBlank() && !m.description.isBlank(), m.id + " has a name and a description");
            for (Setting<?> s : m.allSettings()) check(!s.name.isBlank() && !s.description.isBlank() || s instanceof com.reaper.client.core.setting.Settings.Action, m.id + "." + s.id + " has a name and a description");
        }
        // every HUD element starts where its constructor says, also after a profile was loaded (regression: loading reset every offset to 4,4)
        int[][] want = {{4, 4}, {4, 22}, {4, 4}, {4, 22}, {4, 82}, {4, 100}, {0, 4}, {4, 4}, {4, 84}, {4, 4}, {4, 40}, {0, 44}, {4, 64}};
        String[] order = {"fps", "coordinates", "cps", "ping", "sprint", "worldinfo", "direction", "armor", "durability", "keystrokes", "modulelist", "notifications", "waypointsHud"};
        for (int i = 0; i < order.length; i++) {
            HudElement he = (HudElement) c.modules.get(order[i]);
            check(he.offsetX.i() == want[i][0] && he.offsetY.i() == want[i][1], order[i] + " starts at " + want[i][0] + "," + want[i][1] + " (is " + he.offsetX.i() + "," + he.offsetY.i() + ")");
            check(he.offsetX.isDefault() && he.offsetY.isDefault() && he.anchor.isDefault(), order[i] + " position counts as the default");
        }
        // no two elements that are on by default start on top of each other
        List<HudElement> on = c.hud.elements().stream().filter(Module::isEnabled).toList();
        for (int i = 0; i < on.size(); i++) for (int j = i + 1; j < on.size(); j++) {
            HudElement p = on.get(i), q = on.get(j);
            check(!(p.anchor.v() == q.anchor.v() && p.offsetX.i() == q.offsetX.i() && p.offsetY.i() == q.offsetY.i()), p.id + " and " + q.id + " do not start at the same spot");
        }
        // what a first-time player gets
        check(!c.automation.isEnabled(), "automation is off by default");
        check(!c.fullbright.isEnabled(), "fullbright is off by default");
        check(c.zoom.isEnabled() && c.chat.isEnabled() && c.waypoints.isEnabled() && c.sorter.isEnabled(), "the harmless quality-of-life modules are on");
        check(c.gui.windows().stream().anyMatch(w -> w.id.equals("waypoints")), "the waypoint window is part of the GUI");
        check(c.modules.get("notifications").isEnabled(), "notifications are on");
        eq("Default", c.profiles.active(), "the default profile is active");
        // the one place where "undetectable" style claims could hide: names and descriptions
        for (Module m : c.modules.all()) {
            String all = (m.name + " " + m.description + " " + m.searchText()).toLowerCase();
            check(!all.contains("undetect") && !all.contains("bypass") && !all.contains("stealth") && !all.contains("hidden from"), m.id + " makes no concealment claims");
        }
    }

    // ------------------------------------------------------------------ rules
    private static void rules() throws IOException {
        Env e = new Env();
        ReaperCore c = e.core;
        c.automation.setEnabled(true);
        c.fullbright.setEnabled(true);
        c.enterWorld(SINGLEPLAYER, "sp:Test");
        check(c.automation.isActive() && c.fullbright.isActive() && c.zoom.isActive() && c.waypoints.isActive() && c.sorter.isActive(), "singleplayer: everything is available");

        c.enterWorld(SERVER, "mp:play.example.com");
        eq(ServerMode.STANDARD, c.policy.mode(), "a server nobody described is Standard");
        check(!c.automation.isActive() && c.automation.isBlockedByPolicy(), "Standard: automation is off");
        check(c.fullbright.isActive() && c.zoom.isActive() && c.waypoints.isActive() && c.sorter.isActive(), "Standard: the visual and comfort features work");

        c.policy.setMode("play.example.com", ServerMode.STRICT);
        check(!c.fullbright.isActive() && !c.zoom.isActive() && !c.waypoints.isActive() && !c.sorter.isActive() && !c.automation.isActive(), "Strict: all optional features are off");
        check(c.hud.elements().size() == 13 && c.modules.get("fps").isActive() && c.chat.isActive(), "Strict: HUD and chat tools stay");
        check(!c.zoom.wantsZoom(), "Strict: zoom does nothing even when the key is held");
        c.zoom.setHeld(true);
        check(!c.zoom.wantsZoom(), "still nothing");
        c.zoom.setHeld(false);

        c.policy.setMode("play.example.com", ServerMode.OPEN);
        check(c.automation.isActive(), "Open: automation is allowed (and it was switched on by the player)");
        c.policy.setMode("play.example.com", ServerMode.STANDARD);
        c.enterWorld(new ServerPolicy.Context(false, "*.example.com".replace("*.", "mc.")), "mp:mc.example.com");
        check(!c.automation.isActive(), "another host is Standard");
        c.policy.setMode("*.example.com", ServerMode.OPEN);
        check(c.automation.isActive(), "a wildcard rule covers its subdomains");
        c.leaveWorld();
        eq(ServerPolicy.Context.NONE, c.policy.context(), "leaving a world clears the context");
        for (Feature f : Feature.values()) check(f.label != null && !f.label.isBlank(), "feature label " + f);
    }

    // ------------------------------------------------------------------ persistence
    private static void persistence() throws IOException {
        Env e = new Env();
        ReaperCore a = e.core;
        a.iface.theme.set(InterfaceModule.ThemeName.OCEAN);
        a.iface.scale.set(1.25);
        a.crosshair.setEnabled(true);
        a.crosshair.size.set(11.0);
        a.fullbright.level.set(9.0);
        a.chat.words.set("diamonds, base");
        a.chat.clock.set(com.reaper.client.core.feature.ChatToolsModule.Clock.H12);
        a.automation.target.set("iron_ore");
        HudElement fps = (HudElement) a.modules.get("fps");
        fps.setEnabled(true);
        fps.offsetX.set(77.0);
        fps.scale.set(1.5);
        a.modules.get("zoom").bind.set(70);
        a.policy.setMode("play.example.com", ServerMode.STRICT);
        a.policy.setMode("*.example.org", ServerMode.OPEN);
        a.enterWorld(SINGLEPLAYER, "sp:My World");
        a.data.inWorld = true;
        a.data.x = 10.5;
        a.data.y = 64;
        a.data.z = -20.5;
        a.data.dimensionId = "minecraft:the_nether";
        Waypoint home = a.waypoints.addHere("Home");
        check(home != null, "a waypoint can be added: " + a.waypoints.problem());
        a.enterWorld(SERVER, "mp:play.example.com");
        a.data.inWorld = true;
        a.data.dimensionId = "minecraft:overworld";
        check(!a.waypoints.isActive(), "under the strict rule for this server the markers are off");
        check(a.waypoints.addHere("Spawn") != null, "but a place can still be written down: " + a.waypoints.problem());
        a.gui.windows().get(0).x = 321;
        a.gui.windows().get(0).visible = true;
        a.profiles.create("Raid");
        check(a.profiles.switchTo("Raid"), "switching profiles works");
        a.crosshair.size.set(4.0);
        a.flush();

        ReaperCore b = e.open();
        eq("Raid", b.profiles.active(), "the active profile is remembered");
        eq(4.0, b.crosshair.size.v(), "the active profile's values load");
        b.profiles.switchTo("Default");
        eq(InterfaceModule.ThemeName.OCEAN, b.iface.theme.v(), "theme restored");
        near(1.25, b.iface.scale.v(), "scale restored");
        eq(11.0, b.crosshair.size.v(), "crosshair size restored");
        check(b.crosshair.isEnabled(), "crosshair switch restored");
        eq(9.0, b.fullbright.level.v(), "fullbright level restored");
        eq("diamonds, base", b.chat.words.get(), "chat words restored");
        eq(com.reaper.client.core.feature.ChatToolsModule.Clock.H12, b.chat.clock.v(), "clock restored");
        eq("iron_ore", b.automation.target.get(), "mine target restored");
        HudElement fps2 = (HudElement) b.modules.get("fps");
        check(fps2.isEnabled(), "HUD element switch restored");
        eq(77, fps2.offsetX.i(), "HUD position restored");
        near(1.5, fps2.scale.v(), "HUD size restored");
        eq(70, b.modules.get("zoom").bind.code(), "key bind restored");
        eq(ServerMode.STRICT, b.policy.modeFor("play.example.com"), "server rule restored");
        eq(ServerMode.OPEN, b.policy.modeFor("shop.example.org"), "wildcard server rule restored");
        eq(321, b.gui.windows().get(0).x, "window position restored");
        b.enterWorld(SINGLEPLAYER, "sp:My World");
        eq(1, b.waypointStore.count(), "the waypoint of that world is back");
        eq("Home", b.waypointStore.list().get(0).name, "its name");
        eq("minecraft:the_nether", b.waypointStore.list().get(0).dimension, "its dimension");
        b.enterWorld(SERVER, "mp:play.example.com");
        eq(1, b.waypointStore.count(), "and the one of the server");
        b.enterWorld(SINGLEPLAYER, "sp:Other World");
        eq(0, b.waypointStore.count(), "another world has none");
        check(!b.automation.isEnabled(), "automation stayed off: it was never switched on");
    }

    private static void near(double want, double got, String msg) { T.near(want, got, 1e-6, msg); }

    // ------------------------------------------------------------------ timing
    private static void timing() throws IOException {
        Env e = new Env();
        ReaperCore a = e.core;
        a.flush();
        a.crosshair.size.set(11.0);
        a.requestSave();
        e.t[0] += 1000;
        a.tick();
        eq(6.0, e.open().crosshair.size.v(), "nothing is written while changes are still coming in (1 s)");
        e.t[0] += 600;
        a.tick();
        eq(11.0, e.open().crosshair.size.v(), "written once it was quiet for 1.5 s");
        a.crosshair.size.set(12.0);
        a.tick();
        eq(11.0, e.open().crosshair.size.v(), "a change nobody asked to save waits for the next request or shutdown");
        a.flush();
        eq(12.0, e.open().crosshair.size.v(), "shutdown writes it");

        // a steady stream of changes (dragging a slider for a long time) is still written within 10 s
        for (int i = 1; i <= 9; i++) {
            e.t[0] += 1000;
            a.crosshair.size.set(12.0 + i);
            a.requestSave();
            a.tick();
        }
        eq(12.0, e.open().crosshair.size.v(), "8 s of constant changes: not yet");
        e.t[0] += 1000;
        a.crosshair.size.set(22.0);
        a.requestSave();
        a.tick();
        eq(12.0, e.open().crosshair.size.v(), "9 s: not yet");
        e.t[0] += 1000;
        a.crosshair.size.set(23.0);
        a.requestSave();
        a.tick();
        eq(23.0, e.open().crosshair.size.v(), "10 s after the first unsaved change it is written anyway");

        // waypoints save by themselves
        a.enterWorld(SINGLEPLAYER, "sp:W");
        a.data.inWorld = true;
        check(a.waypoints.addHere("A") != null, "waypoint added");
        e.t[0] += 100;
        a.tick();
        e.t[0] += 1600;
        a.tick();
        ReaperCore b = e.open();
        b.enterWorld(SINGLEPLAYER, "sp:W");
        eq(1, b.waypointStore.count(), "a new waypoint is saved without anybody asking");
    }

    // ------------------------------------------------------------------ brightness
    private static void brightness() throws IOException {
        Env e = new Env();
        ReaperCore a = e.core;
        a.enterWorld(SINGLEPLAYER, "sp:G");
        eq(Double.NaN, a.fullbrightTick(0.5), "fullbright off: no change");
        a.fullbright.setEnabled(true);
        eq(12.0, a.fullbrightTick(0.5), "fullbright on: the game is told to use the high brightness");
        eq(Double.NaN, a.fullbrightTick(12.0), "and left alone afterwards");

        ReaperCore after = e.open();     // the game crashed here: nobody restored the brightness
        eq(0.5, after.takeCrashedGamma(), "the next start finds the player's own brightness");
        check(Double.isNaN(after.takeCrashedGamma()), "and only once");
        check(Double.isNaN(e.open().takeCrashedGamma()), "it is gone from the disk too");

        a.fullbright.setEnabled(false);
        eq(0.5, a.fullbrightTick(12.0), "switching it off puts the player's brightness back");
        check(Double.isNaN(e.open().takeCrashedGamma()), "nothing left to recover");

        a.fullbright.setEnabled(true);
        a.fullbrightTick(0.3);
        eq(0.3, a.fullbrightRestore(), "leaving the game puts it back");
        check(Double.isNaN(a.fullbrightRestore()), "only once");
        check(Double.isNaN(e.open().takeCrashedGamma()), "and clears the record");

        // moving to a server that does not allow it
        a.fullbright.setEnabled(true);
        a.enterWorld(SINGLEPLAYER, "sp:G");
        a.fullbrightTick(0.7);
        a.enterWorld(SERVER, "mp:x");
        a.policy.setMode("play.example.com", ServerMode.STRICT);
        eq(0.7, a.fullbrightTick(12.0), "a strict server switches it off at once and restores the brightness");
        a.policy.setMode("play.example.com", ServerMode.STANDARD);
        eq(12.0, a.fullbrightTick(0.7), "and it comes back when the rules allow it");
        eq(12.0, a.fullbright.level.v(), "level unchanged");
        // the player moves the slider while fullbright is on
        eq(Double.NaN, a.fullbrightTick(12.0), "steady");
        a.fullbrightTick(0.9);
        a.fullbright.setEnabled(false);
        eq(0.9, a.fullbrightTick(12.0), "a brightness the player chose meanwhile is the one restored");
    }

    // ------------------------------------------------------------------ automation
    private static final class FakeBridge implements AutomationModule.Bridge {
        boolean installed = true;
        String problem;
        final List<String> ran = new ArrayList<>();
        @Override public boolean installed() { return installed; }
        @Override public String run(String command) { ran.add(command); return problem; }
    }

    private static void automation() throws IOException {
        Env e = new Env();
        ReaperCore c = e.core;
        FakeBridge b = new FakeBridge();
        c.automation.setBridge(b);
        List<String> said = new ArrayList<>();
        c.automation.setFeedback((l, s) -> said.add(l + ": " + s));
        c.enterWorld(SINGLEPLAYER, "sp:A");
        check(c.automation.request("goto 1 2 3") != null && b.ran.isEmpty(), "off by default: nothing is sent");
        c.automation.setEnabled(true);
        eq(null, c.automation.goTo(100, 64, -200), "singleplayer, switched on: allowed");
        eq("goto 100 64 -200", b.ran.get(0), "the plain Baritone command is sent");
        eq(null, c.automation.mine("Diamond_Ore  minecraft:ancient_debris"), "mine");
        eq("mine diamond_ore minecraft:ancient_debris", b.ran.get(1), "block names are cleaned");
        check(c.automation.mine("../../etc; stop") != null, "text that is not a block name is refused as a whole");
        check(c.automation.mine("stone; stop") != null, "a semicolon refuses the whole text");
        check(c.automation.mine("a:b:c") != null, "two namespaces are refused");
        check(c.automation.mine("") != null && c.automation.mine(null) != null, "no block, no command");
        eq(2, b.ran.size(), "refused requests send nothing");
        check(c.automation.goTo(Integer.MAX_VALUE, 0, 0) != null && c.automation.goTo(0, 100000, 0) != null, "absurd coordinates are refused");

        c.automation.mine.run();
        eq("mine diamond_ore", b.ran.get(2), "the Mine button uses the setting");
        c.automation.stop.run();
        eq("stop", b.ran.get(3), "the Stop button");

        b.problem = "no path";
        eq("no path", c.automation.goTo(1, 2, 3), "Baritone's answer is passed on");
        c.automation.mine.run();
        eq(1, said.size(), "and shown to the player when a button failed");
        b.problem = null;
        said.clear();

        // rules change while it works: it is cancelled at once, by the client
        c.hud.notifications.clear();
        c.tick();
        int before = b.ran.size();
        c.enterWorld(SERVER, "mp:play.example.com");
        c.tick();
        eq("stop", b.ran.get(b.ran.size() - 1), "moving to a Standard server cancels what Baritone was doing");
        eq(before + 1, b.ran.size(), "exactly once");
        c.tick();
        eq(before + 1, b.ran.size(), "and not again");
        check(c.automation.goTo(1, 2, 3) != null && c.automation.unavailable().contains("server"), "the player is told why: " + c.automation.unavailable());
        eq(before + 1, b.ran.size(), "nothing sent under Standard rules");
        eq(null, c.automation.stopAll(), "stop still works under the rules that forbid starting");
        eq("stop", b.ran.get(b.ran.size() - 1), "...and was sent");
        c.automation.setEnabled(false);
        eq(null, c.automation.stopAll(), "also when the module is off");

        b.installed = false;
        check(c.automation.stopAll() != null, "without Baritone there is nothing to stop");
        c.automation.setEnabled(true);
        c.policy.setMode("play.example.com", ServerMode.OPEN);
        check(c.automation.request("goto 1 2 3").contains("not installed"), "without Baritone the player is told so: " + c.automation.request("goto 1 2 3"));
        check(!c.automation.tick(), "no cancel is attempted without Baritone");
        eq(null, AutomationModule.cleanBlocks("   "), "blank block text");
        eq("a b c d e f", AutomationModule.cleanBlocks("a b c d e f g h"), "at most six blocks");
        eq("stone", AutomationModule.cleanBlocks("STONE, stone"), "duplicates are dropped");
        eq(null, AutomationModule.cleanBlocks("stone;"), "a bad character refuses the whole text");
        eq(null, AutomationModule.cleanBlocks(":stone"), "an empty namespace");
        eq(null, AutomationModule.cleanBlocks("a:b:c"), "two namespaces");
    }

    // ------------------------------------------------------------------ damaged files
    private static void damaged() throws IOException {
        Env e = new Env();
        e.core.crosshair.size.set(13.0);
        e.core.flush();
        byte[] junk = "{ not json \u0000\u0001 [[[".getBytes(StandardCharsets.UTF_8);
        for (String f : new String[]{"client.json", "profiles/Default.json", "waypoints.json"}) {
            Path p = e.dir.resolve(f);
            if (Files.exists(p)) Files.write(p, junk);
        }
        ReaperCore b = e.open();
        eq("Default", b.profiles.active(), "garbage in client.json: default profile");
        check(b.crosshair.size.v() == 13.0 || b.crosshair.size.v() == 6.0, "garbage in the profile: defaults or the backup copy (" + b.crosshair.size.v() + ")");
        b.enterWorld(SINGLEPLAYER, "sp:x");
        check(b.waypointStore.count() == 0, "garbage in the waypoint file: none");
        b.data.inWorld = true;
        check(b.waypoints.addHere("Fresh") != null, "and new ones can be added");
        b.flush();
        // truncated and empty files
        for (String f : new String[]{"client.json", "profiles/Default.json", "waypoints.json"}) Files.write(e.dir.resolve(f), new byte[0]);
        ReaperCore c = e.open();
        check(c.modules.all().size() > 20, "empty files: still starts");
        // wrong shapes
        Files.writeString(e.dir.resolve("client.json"), "{\"activeProfile\": 5, \"windows\": [1,2], \"serverRules\": \"x\", \"restoreGamma\": \"hello\", \"welcomed\": 3}");
        Files.writeString(e.dir.resolve("profiles/Default.json"), "{\"modules\": [], \"schema\": \"one\"}");
        Files.writeString(e.dir.resolve("waypoints.json"), "{\"worlds\": 5}");
        ReaperCore d = e.open();
        eq("Default", d.profiles.active(), "wrong types in client.json");
        check(Double.isNaN(d.takeCrashedGamma()), "a non-number brightness record is ignored");
        // a profile name from a hand-edited file that is not a valid name
        Files.writeString(e.dir.resolve("client.json"), "{\"activeProfile\": \"../../evil\"}");
        eq("Default", e.open().profiles.active(), "a path-like profile name is not used");
        // a read-only settings folder must not crash the game
        Path ro = Files.createTempDirectory("reaper-ro");
        Path inside = ro.resolve("not-a-folder");
        Files.writeString(inside, "I am a file");
        ReaperCore f = new ReaperCore(inside, ro.resolve("shots"), () -> 1L);
        f.crosshair.size.set(3.0);
        f.flush();
        check(f.modules.all().size() > 20, "settings folder that cannot be created: starts and keeps running");
    }

    // ------------------------------------------------------------------ GUI and HUD with the real modules
    private static void realGui() throws IOException {
        Env e = new Env();
        ReaperCore c = e.core;
        int W = 960, H = 540;
        c.data.fillSample(e.t[0]);
        c.data.screenW = W;
        c.data.screenH = H;
        RasterCanvas cv = new RasterCanvas(W, H, 2);
        c.gui.onOpen();
        cv.begin(0xFF2A3B4F);
        c.gui.render(cv, 480, 270, 1f / 60f);          // the first frame lays the windows out
        eq(4L, c.gui.windows().stream().filter(w -> w.visible).count(), "first start: four windows are open, the rest wait behind their chips");
        for (UiWindow w : c.gui.windows()) w.visible = true;
        for (Module m : c.modules.all()) c.gui.ui.st(m).open = true;
        for (int i = 0; i < 60; i++) {
            cv.begin(0xFF2A3B4F);
            c.gui.render(cv, 480, 270, 1f / 60f);
        }
        for (Category cat : Category.values()) check(cv.texts.stream().anyMatch(d -> d.text().equalsIgnoreCase(cat.label)), "window for " + cat.label + " is drawn");
        for (String name : new String[]{"FPS Counter", "Custom Crosshair", "Zoom", "Fullbright", "Inventory Sorter", "Chat Tools", "Baritone Bridge", "Waypoints", "Notifications"})
            check(cv.texts.stream().anyMatch(d -> d.text().startsWith(name)), "the GUI shows " + name);
        for (String name : new String[]{"Zoom factor", "Brightness", "Time stamps", "Block to mine", "Order", "Clicks per tick", "Theme"})
            check(cv.texts.stream().anyMatch(d -> d.text().startsWith(name)), "setting row drawn: " + name);
        check(cv.fills > 500, "the GUI really painted (" + cv.fills + " fills)");
        c.gui.windows().forEach(w -> { w.x = Math.max(0, Math.min(W - 40, w.x)); });
        cv.save(new java.io.File(System.getProperty("reaper.preview.dir", "build/previews"), "wiring-clickgui-all-open.png"));

        // search finds real modules and settings
        for (String q : new String[]{"zoom", "baritone", "stamp", "crosshair", "waypoint", "sort", "xyz", "nonsense-query-xyz"}) {
            c.gui.in.mouseMove(480, 270);
            c.gui.ui.unfocus();
            c.gui.onOpen();
            for (int i = 0; i < 3; i++) { cv.begin(0xFF2A3B4F); c.gui.render(cv, 480, 270, 1f / 60f); }
        }

        // the HUD with every element on
        for (Module m : c.modules.in(Category.HUD)) m.setEnabled(true);
        c.hud.update(c.data);
        for (int i = 0; i < 30; i++) {
            c.data.nowMs += 16;
            c.hud.update(c.data);
            cv.begin(0xFF4F7A3A);
            c.hud.render(cv, c.data, c.theme(), 1f / 60f, false);
        }
        check(cv.texts.size() > 10, "the HUD drew its elements (" + cv.texts.size() + " texts)");
        cv.save(new java.io.File(System.getProperty("reaper.preview.dir", "build/previews"), "wiring-hud-all-on.png"));

        // the HUD editor
        c.hudEditor.open();
        for (int i = 0; i < 20; i++) {
            cv.begin(0xFF4F7A3A);
            c.hudEditor.render(cv, c.data, c.theme(), 100, 100, 1f / 60f);
        }
        check(cv.texts.stream().anyMatch(d -> d.text().contains("Drag")), "the HUD editor shows its hints");
        c.hudEditor.close();

        // a toast
        c.hud.notifications.clear();
        c.toast(Level.SUCCESS, "Profile loaded");
        check(c.hud.notifications.count() == 1, "toast shown");
        c.modules.get("notifications").setEnabled(false);
        c.toast(Level.SUCCESS, "Hidden");
        eq(1, c.hud.notifications.count(), "toasts follow the Notifications switch");

        // every module survives a reset and a save/load
        c.modules.resetAll();
        c.flush();
        check(e.open().modules.all().size() == c.modules.all().size(), "reset and reload");

        // all platform hooks are safe before the game layer sets them
        c.openHudEditor();
        c.openScreenshots();
        c.closeGui();
        c.close();
        c.chat.clearChat.run();
        check(c.logo() == null && c.logoW() == 0, "no logo by default");
        final int[] calls = new int[5];
        c.setPlatform(new ReaperCore.Platform() {
            @Override public void openHudEditor() { calls[0]++; }
            @Override public void closeHudEditor() { calls[1]++; }
            @Override public void openScreenshots() { calls[2]++; }
            @Override public void closeGui() { calls[3]++; }
            @Override public void clearChat() { calls[4]++; }
        });
        c.openHudEditor();
        c.close();
        c.openScreenshots();
        c.closeGui();
        c.chat.clearChat.run();
        eq(List.of(1, 1, 1, 1, 1), java.util.Arrays.stream(calls).boxed().toList(), "the buttons reach the game layer");
    }
}
