package com.reaper.client.tests;

import com.google.gson.JsonObject;
import com.reaper.client.core.feature.ChatToolsModule;
import com.reaper.client.core.feature.ChatToolsModule.Clock;

import java.time.ZoneId;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;

/** Chat tools: time stamps and mention alerts (pure logic). */
final class ChatTests {
    private ChatTests() {}

    static void run() {
        T.section("Chat: time stamps");
        stamps();
        T.section("Chat: mention alerts");
        mentions();
        T.section("Chat: settings");
        settings();
    }

    private static void stamps() {
        ChatToolsModule m = new ChatToolsModule();
        eq("00:05", m.format(0, 5, 9), "24-hour: midnight");
        eq("09:05", m.format(9, 5, 59), "24-hour: leading zeros");
        eq("23:59", m.format(23, 59, 59), "24-hour: last minute");
        m.seconds.set(true);
        eq("00:05:09", m.format(0, 5, 9), "24-hour with seconds");
        eq("23:59:59", m.format(23, 59, 59), "24-hour with seconds, last second");
        m.clock.set(Clock.H12);
        eq("12:05:09 AM", m.format(0, 5, 9), "12-hour: midnight is 12 AM");
        eq("12:00:00 PM", m.format(12, 0, 0), "12-hour: noon is 12 PM");
        eq("1:07:09 PM", m.format(13, 7, 9), "12-hour: afternoon");
        eq("11:59:59 AM", m.format(11, 59, 59), "12-hour: last minute of the morning");
        eq("11:59:59 PM", m.format(23, 59, 59), "12-hour: last minute of the day");
        m.seconds.set(false);
        eq("1:07 PM", m.format(13, 7, 9), "12-hour without seconds");
        for (int h = 0; h < 24; h++) for (int mi = 0; mi < 60; mi += 7) {
            m.clock.set(Clock.H24);
            String a = m.format(h, mi, 0);
            check(a.matches("\\d\\d:\\d\\d"), "24-hour shape for " + h + ":" + mi + " -> " + a);
            m.clock.set(Clock.H12);
            String b = m.format(h, mi, 0);
            check(b.matches("(1[0-2]|[1-9]):\\d\\d (AM|PM)"), "12-hour shape for " + h + ":" + mi + " -> " + b);
            check(b.endsWith(h < 12 ? "AM" : "PM"), "AM/PM for hour " + h);
        }

        m.clock.set(Clock.H24);
        long t = 1_700_000_000_000L;      // 2023-11-14 22:13:20 UTC
        eq("[22:13] ", m.prefix(t, ZoneId.of("UTC")), "prefix in UTC");
        eq("[23:13] ", m.prefix(t, ZoneId.of("Europe/Amsterdam")), "prefix follows the zone (winter time)");
        eq("[17:13] ", m.prefix(t, ZoneId.of("America/New_York")), "prefix west of Greenwich");
        eq("[22:13] ", m.prefix(t, ZoneId.of("Africa/Abidjan")), "prefix in another UTC zone");
        eq("[07:13] ", m.prefix(t, ZoneId.of("Asia/Tokyo")), "prefix in Tokyo");
        eq("[00:13] ", m.prefix(t + 2 * 3600_000L, ZoneId.of("UTC")), "after midnight");
        m.seconds.set(true);
        eq("[22:13:20] ", m.prefix(t, ZoneId.of("UTC")), "prefix with seconds");
        m.clock.set(Clock.H12);
        eq("[10:13:20 PM] ", m.prefix(t, ZoneId.of("UTC")), "prefix in 12-hour time");
        eq("[1:13:20 AM] ", m.prefix(t + 3 * 3600_000L, ZoneId.of("UTC")), "prefix just after midnight");

        check(m.stampsOn(), "on by default");
        m.timestamps.set(false);
        check(!m.stampsOn(), "off when the setting is off");
        m.timestamps.set(true);
        m.setEnabled(false);
        check(!m.stampsOn(), "off when the module is off");
        m.setEnabled(true);
        check(m.stampsOn(), "on again");
        eq(0x8C95A8, m.stampRgb(), "default colour without alpha");
        m.stampColor.set(0x80FF0000);
        eq(0xFF0000, m.stampRgb(), "alpha is dropped");
    }

    private static final long T0 = 1_000_000L;

    private static ChatToolsModule fresh() {
        ChatToolsModule m = new ChatToolsModule();
        m.gap.set(0.0);
        return m;
    }

    private static void mentions() {
        ChatToolsModule m = fresh();
        String me = "Steve";
        check(m.check("hey Steve, come here", me, false, T0) != null, "name as a whole word");
        check(m.check("HEY STEVE", me, false, T0) != null, "case does not matter");
        check(m.check("<Alex> steve?", me, false, T0) != null, "punctuation after the name");
        check(m.check("(steve)", me, false, T0) != null, "brackets around the name");
        check(m.check("look at this steve!!", me, false, T0) != null, "at the end");
        eq(null, m.check("stevenson is here", me, false, T0), "part of a longer word does not count");
        eq(null, m.check("mysteve", me, false, T0), "nor at the end of a longer word");
        eq(null, m.check("Steve_2 says hi", me, false, T0), "an underscore continues the word");
        eq(null, m.check("Steve1 hi", me, false, T0), "so does a digit");
        eq(null, m.check("hello everybody", me, false, T0), "no name, no alert");
        eq(null, m.check("", me, false, T0), "empty text");
        eq(null, m.check(null, me, false, T0), "no text");
        eq(null, m.check("steve", null, false, T0), "no own name known");
        eq(null, m.check("steve", "", false, T0), "empty own name");
        eq(null, m.check("steve was here", me, true, T0), "messages the player sent never alert");

        // the speaker is not a mention
        eq(null, m.check("<Steve> hello", me, false, T0), "<Steve> hello is the player talking");
        eq(null, m.check("<steve> hello steve", me, false, T0), "even when the name is repeated");
        eq(null, m.check("[VIP] Steve: hi", me, false, T0), "a rank tag before the name");
        eq(null, m.check("[12:30] [VIP] Steve \u00bb hi", me, false, T0), "a time stamp and a rank tag");
        eq(null, m.check("Steve joined the game", me, false, T0), "the player's own join message");
        eq(null, m.check("Steve was slain by Zombie", me, false, T0), "the player's own death message");
        check(m.check("<Alex> Steve come here", me, false, T0) != null, "somebody else speaking to the player");
        check(m.check("[VIP] Alex: steve look", me, false, T0) != null, "with a rank tag");
        check(m.check("Alex was slain by Steve", me, false, T0) != null, "the name later in a system message");
        eq(null, m.check("<Alex> nice day", me, false, T0), "somebody else, no mention");
        check(m.check("[a really long tag that is not closed properly Steve", me, false, T0) != null, "a runaway bracket does not hide a mention");

        // alert text
        eq("Chat: hey Steve", m.check("  hey Steve  ", me, false, T0), "the alert text is the stripped message");
        String longText = "<Alex> Steve " + "x".repeat(300);
        String a = m.check(longText, me, false, T0);
        eq("Chat: ".length() + ChatToolsModule.ALERT_LENGTH, a.codePointCount(0, a.length()), "long messages are shortened");
        check(a.endsWith("\u2026"), "with an ellipsis");
        String emoji = "<Alex> Steve " + "\uD83D\uDE00".repeat(120);
        String e = m.check(emoji, me, false, T0);
        check(e != null && e.endsWith("\u2026"), "emoji text is shortened too");
        check(!Character.isHighSurrogate(e.charAt(e.length() - 2)), "without cutting a character in half");
        eq(null, m.check("Steve", "Alex", false, T0), "somebody else's name alone is no mention");

        // unicode names
        eq(null, m.check("hello", "\u00dcnal", false, T0), "unicode name, no mention");
        check(m.check("hello \u00dcNAL!", "\u00dcnal", false, T0) != null, "unicode name matches in upper case");
        check(m.check("<Alex> \u00fcnal, hi", "\u00dcnal", false, T0) != null, "unicode name matches in lower case");
        eq(null, m.check("\u00fcnalx", "\u00dcnal", false, T0), "and still only as a whole word");

        // extra words
        m.words.set("diamonds, Base ,, DIAMONDS, x");
        eq(3, m.extraWords().length, "the extra words are split, trimmed, lower-cased and de-duplicated");
        eq("diamonds", m.extraWords()[0], "first word");
        eq("base", m.extraWords()[1], "second word");
        eq("x", m.extraWords()[2], "third word");
        check(m.check("found DIAMONDS!", "Alex", false, T0) != null, "an extra word");
        check(m.check("my base is near", "Alex", false, T0) != null, "another extra word");
        eq(null, m.check("diamond", "Alex", false, T0), "a different word");
        eq(null, m.check("foundation", "Alex", false, T0), "a word inside another word");
        check(m.check("x marks the spot", "Alex", false, T0) != null, "a one-letter word");
        eq(null, m.check("<Alex> hello", "Alex", false, T0), "own messages do not alert for own name");
        check(m.check("<Alex> my base", "Alex", false, T0) != null, "but extra words still do (somebody wrote the word)");
        m.words.set(" , ,, ");
        eq(0, m.extraWords().length, "only separators: no words");
        StringBuilder many = new StringBuilder();
        for (int i = 0; i < 30; i++) many.append("w").append(i).append(',');
        m.words.set(many.toString().substring(0, Math.min(many.length(), 120)));
        check(m.extraWords().length <= ChatToolsModule.MAX_WORDS, "at most " + ChatToolsModule.MAX_WORDS + " words (" + m.extraWords().length + ")");
        m.words.set("a".repeat(100));
        eq(ChatToolsModule.MAX_WORD_LENGTH, m.extraWords()[0].length(), "a very long word is cut");
        m.words.set("");
        eq(0, m.extraWords().length, "no extra words");
        check(m.extraWords() == m.extraWords(), "the list is only rebuilt when the text changes");

        // switches
        ChatToolsModule s = fresh();
        check(s.check("<Alex> steve", "Steve", false, T0) != null, "on");
        s.mentions.set(false);
        eq(null, s.check("<Alex> steve", "Steve", false, T0 + 1), "mention alerts off");
        s.mentions.set(true);
        s.setEnabled(false);
        eq(null, s.check("<Alex> steve", "Steve", false, T0 + 2), "module off");
        s.setEnabled(true);
        check(s.check("<Alex> steve", "Steve", false, T0 + 3) != null, "and on again");

        // spacing between alerts
        ChatToolsModule g = new ChatToolsModule();
        g.gap.set(5.0);
        check(g.check("<Alex> steve", "Steve", false, 10_000) != null, "first alert");
        eq(null, g.check("<Alex> steve", "Steve", false, 10_001), "too soon");
        eq(null, g.check("<Alex> steve", "Steve", false, 14_999), "still too soon");
        check(g.check("<Alex> steve", "Steve", false, 15_000) != null, "after the gap");
        eq(null, g.check("<Alex> steve", "Steve", false, 18_000), "the gap counts from the last alert, not from the suppressed one");
        check(g.check("<Alex> steve", "Steve", false, 20_000) != null, "again");
        check(g.check("<Alex> steve", "Steve", false, 1_000) != null, "a clock that jumped back does not silence alerts for good");
        g.gap.set(0.0);
        check(g.check("<Alex> steve", "Steve", false, 1_000) != null && g.check("<Alex> steve", "Steve", false, 1_000) != null, "gap 0: every message");
        g.gap.set(60.0);
        eq(null, g.check("<Alex> steve", "Steve", false, 2_000), "a longer gap counts from the last alert (at 1000)");
        check(g.check("<Alex> steve", "Steve", false, 61_000) != null, "and ends 60 s after it");
    }

    private static void settings() {
        ChatToolsModule m = new ChatToolsModule();
        check(m.clock.isVisible() && m.seconds.isVisible() && m.stampColor.isVisible(), "time settings are shown while time stamps are on");
        m.timestamps.set(false);
        check(!m.clock.isVisible() && !m.seconds.isVisible() && !m.stampColor.isVisible(), "and hidden while they are off");
        check(m.words.isVisible() && m.gap.isVisible(), "mention settings are shown");
        m.mentions.set(false);
        check(!m.words.isVisible() && !m.gap.isVisible(), "and hidden when alerts are off");

        int[] ran = {0};
        m.clearChat.run();
        eq(0, ran[0], "the button without an action does nothing and does not fail");
        m.setClearAction(() -> ran[0]++);
        m.clearChat.run();
        eq(1, ran[0], "the button runs the action the game layer gave it");
        check(m.clearChat.danger && !m.clearChat.persistent(), "it is marked as dangerous and is not saved");

        m.words.set("a\tb\u0007c\u007Fd" + "z".repeat(200));
        check(m.words.get().length() <= 120, "the word list is capped at 120 characters");
        check(m.words.get().startsWith("abcd"), "control characters are removed: " + m.words.get().substring(0, 8));

        // saved and loaded again
        ChatToolsModule a = new ChatToolsModule();
        a.timestamps.set(false);
        a.clock.set(Clock.H12);
        a.seconds.set(true);
        a.stampColor.set(0xFF112233);
        a.mentions.set(false);
        a.words.set("one, two");
        a.gap.set(12.0);
        a.setEnabled(false);
        JsonObject json = a.toJson();
        ChatToolsModule b = new ChatToolsModule();
        b.fromJson(json);
        check(!b.timestamps.on() && b.clock.v() == Clock.H12 && b.seconds.on() && b.stampColor.argb() == 0xFF112233 && !b.mentions.on() && b.words.get().equals("one, two") && b.gap.i() == 12 && !b.isEnabled(), "settings survive saving and loading");
        check(!json.toString().contains("clearChat"), "the button is not in the file");
        ChatToolsModule c = new ChatToolsModule();
        JsonObject junk = new JsonObject();
        junk.addProperty("timestamps", "yes");
        junk.addProperty("gap", "many");
        junk.addProperty("words", 5);
        c.fromJson(junk);
        check(c.timestamps.on() && c.gap.i() == 5 && c.words.get().isEmpty(), "wrong types in the file are ignored");
    }
}
