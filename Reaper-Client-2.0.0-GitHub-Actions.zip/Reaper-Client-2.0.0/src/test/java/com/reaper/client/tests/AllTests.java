package com.reaper.client.tests;

/**
 * Runs every core test (or only the suites named on the command line, e.g. {@code Screenshots Sorter}).
 * Exit code 0 = all passed. Usage: java -cp <classes> com.reaper.client.tests.AllTests [suite...]
 */
public final class AllTests {
    private AllTests() {}

    private interface Suite { void run() throws Exception; }

    private static String[] only = new String[0];

    private static void suite(String name, Suite s) throws Exception {
        boolean selected = only.length == 0;
        for (String o : only) if (o.equalsIgnoreCase(name)) selected = true;
        if (selected) s.run();
    }

    public static void main(String[] args) throws Exception {
        only = args;
        com.reaper.client.core.util.Log.setSinks(s -> { }, s -> { }); // keep expected-failure warnings out of the output
        suite("Core", CoreTests::run);
        suite("Gui", GuiTests::run);
        suite("Hud", HudTests::run);
        suite("HudEditor", HudEditorTests::run);
        suite("Features", FeatureTests::run);
        suite("Waypoints", WaypointTests::run);
        suite("Panels", PanelTests::run);
        suite("Sorter", SorterTests::run);
        suite("Screenshots", ScreenshotTests::run);
        suite("Chat", ChatTests::run);
        suite("Adapter", AdapterLogicTests::run);
        suite("Baritone", BaritoneTests::run);
        suite("Commands", CommandTests::run);
        suite("Wiring", WiringTests::run);
        System.exit(T.summary());
    }
}
