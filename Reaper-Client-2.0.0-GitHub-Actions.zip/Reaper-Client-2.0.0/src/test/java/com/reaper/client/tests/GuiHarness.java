package com.reaper.client.tests;

import com.reaper.client.core.config.ProfileStore;
import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.policy.ServerPolicy;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.ClickGui;
import com.reaper.client.core.ui.GuiHost;
import com.reaper.client.core.ui.Input;
import com.reaper.client.core.ui.InterfaceModule;
import com.reaper.client.core.ui.UiWindow;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Drives a {@link ClickGui} headlessly: renders into a {@link RasterCanvas} and simulates mouse and keyboard. */
final class GuiHarness implements GuiHost {
    final Path dir;
    final ModuleRegistry reg = new ModuleRegistry();
    final InterfaceModule iface = new InterfaceModule();
    final ServerPolicy policy = new ServerPolicy();
    final ProfileStore profiles;
    final ClickGui gui;
    final RasterCanvas cv;
    final int W, H;

    final List<String> toasts = new ArrayList<>();
    int saves, hudEditorOpens, screenshotOpens, closes;
    BufferedImage logo;
    String clipboard = "";

    Module fps, coords, keystrokes, fullbright, zoom, crosshair, waypoints, sorter, chat, bridge;
    Settings.Bool fpsShadow, fpsBg;
    Settings.Num fpsScale, zoomFactor;
    Settings.Color fpsColor;
    Settings.Str mentions;
    Settings.Action sampleAction;
    int actionRuns;

    GuiHarness(int w, int h) throws IOException { this(w, h, true); }

    GuiHarness(int w, int h, boolean open) throws IOException {
        W = w;
        H = h;
        dir = Files.createTempDirectory("reaper-gui-test");
        buildModules();
        profiles = new ProfileStore(dir, reg);
        profiles.load(ProfileStore.DEFAULT_NAME);
        policy.setContext(new ServerPolicy.Context(true, ""));
        reg.setPolicyGate(policy::allows);
        try (var in = GuiHarness.class.getResourceAsStream("/assets/reaper/textures/gui/logo.png")) {
            if (in != null) logo = javax.imageio.ImageIO.read(in);
        } catch (IOException ignored) { /* logo is optional in tests */ }
        if (logo == null) {
            File f = new File("src/main/resources/assets/reaper/textures/gui/logo.png");
            if (f.exists()) logo = javax.imageio.ImageIO.read(f);
        }
        gui = new ClickGui(reg, iface, profiles, policy, this);
        gui.clipboardImpl = new com.reaper.client.core.ui.TextField.Clipboard() {
            @Override public String get() { return clipboard; }
            @Override public void set(String s) { clipboard = s; }
        };
        cv = new RasterCanvas(w, h, 2);
        nullCanvas = new NullCanvas(w, h);
        if (open) gui.onOpen();
    }

    private void buildModules() {
        fps = reg.register(new Module("fps", "FPS Counter", "Shows your frame rate.", Category.HUD));
        fpsColor = fps.add(new Settings.Color("color", "Text colour", "Colour of the text.", 0xFFFFFFFF, false));
        fpsShadow = fps.add(new Settings.Bool("shadow", "Text shadow", "Draw a drop shadow behind the text.", true));
        fpsBg = fps.add(new Settings.Bool("bg", "Background", "Dim panel behind the element.", false));
        fpsScale = fps.add(new Settings.Num("scale", "Size", "Size of the element.", 1.0, 0.5, 3.0, 0.1, "x"));
        coords = reg.register(new Module("coords", "Coordinates", "Your position in the world.", Category.HUD, true, true, "xyz position"));
        coords.add(new Settings.Bool("nether", "Nether conversion", "Also show the matching Overworld/Nether position.", true));
        coords.add(new Settings.Num("decimals", "Decimals", "Digits after the point.", 0, 0, 3, 1, ""));
        keystrokes = reg.register(new Module("keystrokes", "Keystrokes", "WASD, space and mouse buttons.", Category.HUD));
        keystrokes.add(new Settings.Color("pressed", "Pressed colour", "Colour of pressed keys.", 0xCC7C5CFF, true));
        reg.register(new Module("armor", "Armor Status", "Armour pieces with durability.", Category.HUD));
        reg.register(new Module("ping", "Ping", "Latency to the server.", Category.HUD));

        fullbright = reg.register(new Module("fullbright", "Fullbright", "Brightens dark areas.", Category.VISUAL).feature(Feature.FULLBRIGHT));
        fullbright.add(new Settings.Num("level", "Brightness", "How bright.", 10.0, 1.0, 15.0, 1.0, ""));
        zoom = reg.register(new Module("zoom", "Zoom", "Hold a key to zoom in.", Category.VISUAL).feature(Feature.ZOOM));
        zoomFactor = zoom.add(new Settings.Num("factor", "Zoom factor", "How far to zoom.", 4.0, 1.5, 12.0, 0.5, "x"));
        zoom.add(new Settings.Bool("smooth", "Smooth camera", "Cinematic camera while zoomed.", true));
        crosshair = reg.register(new Module("crosshair", "Custom Crosshair", "Replaces the crosshair.", Category.VISUAL));
        crosshair.add(new Settings.Color("color", "Colour", "Crosshair colour.", 0xFFFFFFFF, true));
        crosshair.add(new Settings.Num("size", "Size", "Arm length.", 5.0, 1.0, 20.0, 1.0, "px"));

        waypoints = reg.register(new Module("waypoints", "Waypoints", "Named places with distance markers.", Category.UTILITY).feature(Feature.WAYPOINT_MARKERS));
        sorter = reg.register(new Module("sorter", "Inventory Sorter", "Sort chests and your inventory.", Category.UTILITY).feature(Feature.INVENTORY_SORT));
        chat = reg.register(new Module("chat", "Chat Tools", "Timestamps and mention alerts.", Category.UTILITY));
        chat.add(new Settings.Bool("timestamps", "Timestamps", "Prefix messages with the time.", false));
        mentions = chat.add(new Settings.Str("mentions", "Mention words", "Words that trigger an alert.", "", 64));
        sampleAction = chat.add(new Settings.Action("clear", "Clear history", "Remove the sent-message history.", true, () -> actionRuns++));

        bridge = reg.register(new Module("bridge", "Baritone Bridge", "Optional pathfinding helper.", Category.AUTOMATION).feature(Feature.AUTOMATION));
        reg.register(iface);
    }

    // ------------------------------------------------------------------ GuiHost
    @Override public void toast(Level level, String message) { toasts.add(level + ": " + message); }
    private boolean dirty;
    @Override public void requestSave() { saves++; dirty = true; }
    @Override public void openHudEditor() { hudEditorOpens++; }
    @Override public void openScreenshots() { screenshotOpens++; }
    @Override public void closeGui() { closes++; }
    @Override public Object logo() { return logo; }
    @Override public int logoW() { return logo == null ? 0 : logo.getWidth(); }
    @Override public int logoH() { return logo == null ? 0 : logo.getHeight(); }

    // ------------------------------------------------------------------ frames
    void frame() { frame(1f / 60f); }

    /** When true, frames run the GUI logic but paint nothing: for long loops that only look at state. */
    boolean fast;
    private final NullCanvas nullCanvas;

    void frame(float dt) {
        if (fast) { gui.render(nullCanvas, (int) Math.round(gui.in.mx), (int) Math.round(gui.in.my), dt); if (dirty) { dirty = false; profiles.saveActive(); } return; }
        cv.begin(0xFF000000);
        // a stand-in "game view" so translucent panels are judged against something realistic
        cv.gradientV(0, 0, W, H * 2 / 3, 0xFF6FA8DC, 0xFFBFD9EE);
        cv.gradientV(0, H * 2 / 3, W, H - H * 2 / 3, 0xFF4F7A3A, 0xFF2F4A24);
        gui.render(cv, (int) Math.round(gui.in.mx), (int) Math.round(gui.in.my), dt);
        if (dirty) { dirty = false; profiles.saveActive(); }   // what the debounced SaveScheduler does in the game
    }

    /** Lets time pass (long enough to end any double-click window). */
    void wait(int frames) { frames(frames); }
    void settle() { frames(30); }

    void frames(int n) { for (int i = 0; i < n; i++) frame(); }

    // ------------------------------------------------------------------ input
    void move(double x, double y) { gui.in.mouseMove(x, y); }

    void down(int button) { gui.in.mouseDown(button, gui.in.mx, gui.in.my); }

    void up(int button) { gui.in.mouseUp(button, gui.in.mx, gui.in.my); }

    void click(double x, double y) { click(Input.LEFT, x, y); }

    void rightClick(double x, double y) { click(Input.RIGHT, x, y); }

    void click(int button, double x, double y) {
        move(x, y);
        frame();
        gui.in.mouseDown(button, x, y);
        frame();
        gui.in.mouseUp(button, x, y);
        frame();
    }

    void drag(double x0, double y0, double x1, double y1) {
        move(x0, y0);
        frame();
        gui.in.mouseDown(Input.LEFT, x0, y0);
        frame();
        int steps = 8;
        for (int i = 1; i <= steps; i++) {
            double x = x0 + (x1 - x0) * i / steps, y = y0 + (y1 - y0) * i / steps;
            gui.in.mouseMove(x, y);
            frame();
        }
        gui.in.mouseUp(Input.LEFT, x1, y1);
        frame();
    }

    void type(String s) {
        s.codePoints().forEach(gui.in::character);
        frame();
    }

    void key(int key) { key(key, 0); }

    void key(int key, int mods) {
        gui.in.key(key, mods);
        frame();
    }

    // ------------------------------------------------------------------ lookups
    RasterCanvas.Drawn text(String s) {
        RasterCanvas.Drawn d = cv.find(s);
        if (d == null) throw new AssertionError("text not drawn: \"" + s + "\"");
        return d;
    }

    boolean has(String s) { return cv.find(s) != null; }

    /** The occurrence of a text that is lowest on screen (e.g. the list row rather than a heading with the same text). */
    RasterCanvas.Drawn textLast(String s) {
        RasterCanvas.Drawn best = null;
        for (var d : cv.texts) if (d.text().equals(s) && (best == null || d.y() >= best.y())) best = d;
        if (best == null) throw new AssertionError("text not drawn: \"" + s + "\"");
        return best;
    }

    /** The occurrence drawn last (the top bar is drawn after the windows, so this is how to reach a chip rather than a window title). */
    RasterCanvas.Drawn textDrawnLast(String s) {
        RasterCanvas.Drawn best = null;
        for (var d : cv.texts) if (d.text().equals(s)) best = d;
        if (best == null) throw new AssertionError("text not drawn: \"" + s + "\"");
        return best;
    }

    void clickChip(String s) { RasterCanvas.Drawn d = textDrawnLast(s); click(d.x() + d.w() / 2.0, d.y() + d.h() / 2.0); }

    void clickLast(String s) { RasterCanvas.Drawn d = textLast(s); click(d.x() + d.w() / 2.0, d.y() + d.h() / 2.0); }

    /** Shows only one window, at the top-left, so tests do not depend on where free space was found. */
    void solo(String id) {
        for (UiWindow w : gui.windows()) w.visible = w.id.equals(id);
        UiWindow w = window(id);
        w.x = 12;
        w.y = 64;
        frames(40);
    }

    /** Clicks the middle of a drawn text. */
    void clickText(String s) { RasterCanvas.Drawn d = text(s); click(d.x() + d.w() / 2.0, d.y() + d.h() / 2.0); }

    void rightClickText(String s) { RasterCanvas.Drawn d = text(s); rightClick(d.x() + d.w() / 2.0, d.y() + d.h() / 2.0); }

    UiWindow window(String id) {
        for (UiWindow w : gui.windows()) if (w.id.equals(id)) return w;
        throw new AssertionError("no window " + id);
    }

    void preview(String name) {
        String d = System.getProperty("reaper.preview.dir");
        if (d == null || d.isEmpty()) return;
        try { cv.save(new File(d, name + ".png")); }
        catch (IOException ex) { System.out.println("  (could not save preview " + name + ": " + ex.getMessage() + ")"); }
    }
}
