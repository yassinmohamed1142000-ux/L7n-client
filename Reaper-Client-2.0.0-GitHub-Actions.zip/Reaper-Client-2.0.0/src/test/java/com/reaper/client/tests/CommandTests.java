package com.reaper.client.tests;

import com.reaper.client.core.ReaperCore;
import com.reaper.client.core.command.CommandCenter;
import com.reaper.client.core.feature.AutomationModule;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.policy.ServerMode;
import com.reaper.client.core.policy.ServerPolicy;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;

/** The {@code /reaper} commands: parsing, replies, what they change, tab completion, and that they never throw. */
final class CommandTests {
    private CommandTests() {}

    private static final ServerPolicy.Context SINGLEPLAYER = new ServerPolicy.Context(true, "");
    private static final ServerPolicy.Context SERVER = new ServerPolicy.Context(false, "play.example.com");

    /** A core on a temporary folder, a command centre over it, and counters for what the game layer was asked to do. */
    private static final class Rig {
        final Path dir;
        final long[] t = {5_000_000L};
        final int[] opened = new int[3];   // gui, hud, screenshots
        final List<String> bridge = new ArrayList<>();
        boolean bridgeInstalled = true;
        boolean failOpen;
        ReaperCore core;
        CommandCenter cmd;

        Rig() throws IOException {
            dir = Files.createTempDirectory("reaper-cmd");
            core = open();
            cmd = center(core);
            core.automation.setBridge(new AutomationModule.Bridge() {
                @Override public boolean installed() { return bridgeInstalled; }
                @Override public String run(String command) { bridge.add(command); return null; }
            });
        }

        ReaperCore open() { return new ReaperCore(dir, dir.resolve("screenshots"), () -> t[0]); }

        CommandCenter center(ReaperCore c) {
            return new CommandCenter(c, new CommandCenter.Actions() {
                @Override public void openGui() { if (failOpen) throw new IllegalStateException("no screen"); opened[0]++; }
                @Override public void openHudEditor() { opened[1]++; }
                @Override public void openScreenshots() { opened[2]++; }
                @Override public List<String> statusLines() { return List.of("Reaper Client test build"); }
            });
        }

        List<CommandCenter.Reply> run(String line) { return cmd.run(line); }

        /** All replies of a command as "LEVEL text" lines joined by newlines. */
        String say(String line) {
            StringBuilder sb = new StringBuilder();
            for (CommandCenter.Reply r : cmd.run(line)) sb.append(r.level()).append(' ').append(r.text()).append('\n');
            return sb.toString();
        }
    }

    static void run() throws IOException {
        T.section("Commands: opening screens, help, errors");
        basics();
        T.section("Commands: modules and toggle");
        toggles();
        T.section("Commands: profiles");
        profiles();
        T.section("Commands: server rules");
        server();
        T.section("Commands: waypoints");
        waypoints();
        T.section("Commands: Baritone");
        baritone();
        T.section("Commands: status and tab completion");
        statusAndCompletion();
        T.section("Commands: a failure never escapes");
        failures();
    }

    // ------------------------------------------------------------------ basics
    private static void basics() throws IOException {
        Rig r = new Rig();
        eq(0, r.run("").size(), "an empty line has no reply");
        eq(1, r.opened[0], "and opens the menu");
        r.run(null);
        eq(2, r.opened[0], "null counts as empty");
        r.run("gui");
        r.run("menu");
        r.run("GUI");
        eq(5, r.opened[0], "gui, menu and GUI (any case) open the menu");
        r.run("hud");
        eq(1, r.opened[1], "hud opens the HUD editor");
        r.run("screenshots");
        r.run("shots");
        eq(2, r.opened[2], "screenshots and shots open the screenshot manager");

        List<CommandCenter.Reply> help = r.run("help");
        check(help.size() >= 6, "help has several lines: " + help.size());
        boolean allSlash = true;
        for (CommandCenter.Reply h : help) allSlash &= h.text().startsWith("/reaper");
        check(allSlash, "every help line starts with /reaper");
        eq(help.size(), r.run("?").size(), "? is the same as help");

        List<CommandCenter.Reply> unknown = r.run("fly 12");
        eq(1, unknown.size(), "an unknown command gets one reply");
        eq(Level.WARN, unknown.get(0).level(), "a warning");
        check(unknown.get(0).text().contains("\"fly\""), "naming the word: " + unknown.get(0).text());
        eq(5, r.opened[0], "and opens nothing");

        List<CommandCenter.Reply> longLine = r.run("toggle " + "x".repeat(CommandCenter.MAX_LINE));
        eq(1, longLine.size(), "a very long line gets one reply");
        check(longLine.get(0).text().contains("too long"), "saying it is too long: " + longLine.get(0).text());
    }

    // ------------------------------------------------------------------ modules and toggle
    private static void toggles() throws IOException {
        Rig r = new Rig();
        ReaperCore c = r.core;
        c.enterWorld(SINGLEPLAYER, "sp:T");

        final boolean fpsAtStart = c.modules.get("fps").isEnabled(), crosshairAtStart = c.modules.get("crosshair").isEnabled();
        int total = 0, on = 0;
        for (Module m : c.modules.all()) if (m.toggleable) { total++; if (m.isEnabled()) on++; }
        String list = r.say("modules");
        check(list.startsWith("INFO " + on + " of " + total + " modules are on"), "modules counts them: " + list);

        Module fps = c.modules.get("fps");
        boolean was = fps.isEnabled();
        String s = r.say("toggle fps");
        check(s.startsWith("SUCCESS ") && s.contains(fps.name + " is now " + (was ? "off" : "on")), "toggle reports the new state: " + s);
        eq(!was, fps.isEnabled(), "and flips it");
        r.run("toggle fps");
        eq(was, fps.isEnabled(), "a second toggle flips it back");
        r.run("toggle FPS on");
        r.run("toggle fps on");
        check(fps.isEnabled(), "on stays on, whatever the case");
        r.run("toggle fps off");
        check(!fps.isEnabled(), "off turns it off");

        fps.setEnabled(true);
        s = r.say("toggle fps maybe");
        check(s.startsWith("WARN "), "a third word other than on/off is refused: " + s);
        check(fps.isEnabled(), "and changes nothing");
        check(r.say("toggle").startsWith("WARN Usage"), "no module name shows the usage");
        check(r.say("toggle nosuch").contains("no module called \"nosuch\""), "an unknown module is named in the reply");

        Module panel = c.modules.get("interface");
        check(panel != null && !panel.toggleable, "precondition: the interface panel has no switch");
        check(r.say("toggle interface").contains("settings panel"), "a settings panel cannot be toggled");

        Module byName = null;
        for (Module m : c.modules.all()) {
            String plain = m.name.toLowerCase().replace(" ", "");
            if (m.toggleable && !plain.equals(m.id.toLowerCase())) { byName = m; break; }
        }
        check(byName != null, "precondition: some module's name differs from its id");
        if (byName != null) {
            boolean before = byName.isEnabled();
            r.run("toggle " + byName.name.toLowerCase().replace(" ", ""));
            eq(!before, byName.isEnabled(), "a module is found by its name too (" + byName.name + ")");
        }

        // rules: switched on but not running on a server that does not allow it
        c.enterWorld(SERVER, "mp:play.example.com");
        s = r.say("toggle automation on");
        check(s.contains("SUCCESS ") && s.contains("is now on"), "the switch still turns on: " + s);
        check(s.contains("WARN ") && s.contains("off on this server"), "and the reply says the server rules keep it off: " + s);
        check(c.automation.isEnabled() && !c.automation.isActive(), "enabled, but not active");
        s = r.say("toggle fullbright on");
        check(!s.contains("WARN"), "Fullbright is fine on a Standard server: " + s);
        r.run("server strict");
        s = r.say("toggle fullbright on");
        check(s.contains("is now on"), "already on stays on");
        check(c.fullbright.isBlockedByPolicy(), "but a Strict server blocks it");
        r.run("toggle fullbright off");
        s = r.say("toggle fullbright on");
        check(s.contains("WARN ") && s.contains("Fullbright is off on this server"), "turning it on under Strict says why it does nothing: " + s);

        // saved
        c.enterWorld(SINGLEPLAYER, "sp:T");
        r.run("toggle fps " + (fpsAtStart ? "off" : "on"));
        r.run("toggle crosshair " + (crosshairAtStart ? "off" : "on"));
        c.flush();
        ReaperCore again = r.open();
        eq(!fpsAtStart, again.modules.get("fps").isEnabled(), "a module switched away from its default keeps that after a restart (FPS)");
        eq(!crosshairAtStart, again.modules.get("crosshair").isEnabled(), "and so does a second one (crosshair)");
    }

    // ------------------------------------------------------------------ profiles
    private static void profiles() throws IOException {
        Rig r = new Rig();
        ReaperCore c = r.core;
        c.enterWorld(SINGLEPLAYER, "sp:P");

        String s = r.say("profile");
        check(s.startsWith("INFO Active profile: Default. All: Default"), "profile alone lists them: " + s);
        eq(s, r.say("profile list"), "list is the same");

        s = r.say("profile new Raid");
        check(s.startsWith("SUCCESS ") && s.contains("\"Raid\""), "a new profile is created: " + s);
        eq("Raid", c.profiles.active(), "and becomes the active one");
        check(r.say("profile list").contains("Default") && r.say("profile list").contains("Raid"), "both are listed");
        check(r.say("profile new raid").contains("already exists"), "a duplicate name (any case) is refused");
        check(r.say("profile new bad/name").contains("letters, digits"), "a name with other characters is refused");
        check(r.say("profile new").contains("Usage"), "a missing name shows the usage");

        r.run("toggle fullbright on");
        check(c.fullbright.isEnabled(), "precondition: fullbright on in Raid");
        s = r.say("profile load default");
        check(s.startsWith("SUCCESS ") && s.contains("\"Default\""), "loading works whatever the case: " + s);
        eq("Default", c.profiles.active(), "Default is active again");
        check(!c.fullbright.isEnabled(), "Default has its own settings: fullbright is off");
        r.run("profile load RAID");
        check(c.fullbright.isEnabled(), "going back to Raid brings back what was saved there");

        check(r.say("profile load nope").contains("no profile called \"nope\""), "an unknown profile is named");
        check(r.say("profile load").contains("Usage"), "no name shows the usage");
        check(r.say("profile save").startsWith("SUCCESS "), "save works");
        check(r.say("profile delete Raid").contains("Could not delete"), "the active profile cannot be deleted");
        r.run("profile load Default");
        check(r.say("profile delete Raid").startsWith("SUCCESS "), "an inactive profile can");
        check(!r.say("profile list").contains("Raid"), "and it is gone from the list");
        check(r.say("profile delete Default").contains("Could not delete"), "the last one cannot");
        check(r.say("profile bogus").contains("Usage"), "an unknown subcommand shows the usage");
        check(r.say("profile delete").contains("Usage"), "delete without a name shows the usage");
    }

    // ------------------------------------------------------------------ server rules
    private static void server() throws IOException {
        Rig r = new Rig();
        ReaperCore c = r.core;

        check(r.say("server").startsWith("WARN Join a world"), "outside a world there is nothing to show");

        c.enterWorld(SINGLEPLAYER, "sp:S");
        String s = r.say("server");
        check(s.startsWith("INFO Singleplayer: Open mode."), "singleplayer is Open: " + s);
        check(r.say("server strict").contains("always Open"), "singleplayer cannot be changed");
        eq(ServerMode.OPEN, c.policy.mode(), "and stays Open");

        c.enterWorld(SERVER, "mp:play.example.com");
        s = r.say("server");
        check(s.contains("play.example.com: Standard mode."), "a server starts as Standard: " + s);
        check(s.contains("Automation (Baritone) off") && s.contains("Fullbright on"), "with the list of what is on and off: " + s);

        s = r.say("server strict");
        check(s.startsWith("SUCCESS ") && s.contains("play.example.com is now treated as Strict"), "strict is set: " + s);
        eq(ServerMode.STRICT, c.policy.mode(), "and in force at once");
        check(r.say("server").contains("Fullbright off"), "the list follows");

        s = r.say("server open");
        check(s.contains("INFO ") && s.contains("server's own rules allow it"), "Open comes with a reminder: " + s);
        check(s.contains("SUCCESS "), "and is set");
        eq(ServerMode.OPEN, c.policy.mode(), "Open is in force");
        check(c.policy.allows(com.reaper.client.core.policy.Feature.AUTOMATION), "automation is allowed under Open");

        c.flush();
        ReaperCore again = r.open();
        eq(ServerMode.OPEN, again.policy.modeFor("play.example.com"), "the choice for that server is kept after a restart");
        eq(ServerMode.STANDARD, again.policy.modeFor("other.example.com"), "other servers are unaffected");

        r.run("SERVER Standard");
        eq(ServerMode.STANDARD, c.policy.mode(), "standard (any case) goes back");
        check(r.say("server bogus").startsWith("WARN Write standard, strict or open"), "an unknown mode is refused");
        eq(ServerMode.STANDARD, c.policy.mode(), "and changes nothing");
    }

    // ------------------------------------------------------------------ waypoints
    private static void waypoints() throws IOException {
        Rig r = new Rig();
        ReaperCore c = r.core;

        check(r.say("waypoint add Home").startsWith("WARN Join a world first"), "no world, no waypoint");
        check(r.say("waypoint list").startsWith("WARN Join a world first"), "and nothing to list");

        c.enterWorld(SINGLEPLAYER, "sp:W");
        c.data.inWorld = true;
        c.data.x = 10.5;
        c.data.y = 64;
        c.data.z = -20.2;
        c.data.dimensionId = "minecraft:overworld";

        check(r.say("waypoint list").startsWith("INFO This world has no waypoints"), "an empty world says so");
        String s = r.say("waypoint add Home");
        check(s.startsWith("SUCCESS ") && s.contains("\"Home\" at 10 64 -21"), "a waypoint is saved at the floored position: " + s);
        s = r.say("waypoint list");
        eq("INFO 1 waypoint: Home (10 64 -21)\n", s, "and listed");
        s = r.say("waypoint add");
        check(s.startsWith("SUCCESS ") && s.contains("\"Waypoint 1\""), "without a name it gets a numbered one: " + s);
        eq("INFO 2 waypoints: Home (10 64 -21); Waypoint 1 (10 64 -21)\n", r.say("waypoints"), "waypoints (plural) is an alias, and alone it lists");
        check(r.say("wp list").startsWith("INFO 2 waypoints"), "wp too");

        s = r.say("waypoint remove HOME");
        check(s.startsWith("SUCCESS ") && s.contains("\"Home\""), "removal ignores case: " + s);
        eq(1, c.waypointStore.count(), "one is left");
        check(r.say("waypoint remove nope").startsWith("WARN There is no waypoint called \"nope\""), "an unknown name is reported");
        check(r.say("waypoint remove").contains("Usage"), "no name shows the usage");
        check(r.say("waypoint bogus").contains("Usage"), "an unknown subcommand shows the usage");

        for (int i = 0; i < 14; i++) r.run("waypoint add Spot" + i);
        s = r.say("waypoint list");
        check(s.contains("15 waypoints") && s.contains(" ..."), "a long list is cut short but shows the count: " + s);

        c.data.reducedDebug = true;
        s = r.say("waypoint add Hidden");
        check(s.startsWith("WARN ") && s.contains("hides coordinates"), "on a server that hides coordinates no waypoint is made: " + s);
    }

    // ------------------------------------------------------------------ Baritone
    private static void baritone() throws IOException {
        Rig r = new Rig();
        ReaperCore c = r.core;
        c.enterWorld(SINGLEPLAYER, "sp:B");

        check(r.say("baritone goto 1 64 2").startsWith("WARN "), "with the module off nothing is sent: " + r.say("baritone goto 1 64 2"));
        eq(0, r.bridge.size(), "the bridge heard nothing");

        r.run("toggle automation on");
        c.tick();
        String s = r.say("baritone goto 10 64 -20");
        eq("SUCCESS Sent to Baritone: goto 10 64 -20\n", s, "goto is sent once the module is on (singleplayer is Open)");
        eq("goto 10 64 -20", r.bridge.get(0), "exactly as Baritone expects it");
        s = r.say("baritone mine Diamond_Ore");
        eq("SUCCESS Sent to Baritone: mine diamond_ore\n", s, "mine lower-cases the block");
        eq("mine diamond_ore", r.bridge.get(1), "and arrives that way");
        eq(2, r.bridge.size(), "nothing else was sent");

        check(r.say("baritone goto 1 2").contains("Usage"), "two coordinates are not enough");
        check(r.say("baritone goto 1 2 3 4").contains("Usage"), "nor are four");
        check(r.say("baritone goto a b c").contains("whole numbers"), "letters are refused");
        check(r.say("baritone goto 1.5 2 3").contains("whole numbers"), "so are fractions");
        check(r.say("baritone mine diamond_ore; stop").startsWith("WARN "), "text that is not a block name is refused");
        check(r.say("baritone").contains("Usage") && r.say("baritone fly").contains("Usage"), "no or unknown subcommand shows the usage");
        eq(2, r.bridge.size(), "all of that sent nothing");

        s = r.say("baritone stop");
        eq("SUCCESS Sent to Baritone: stop\n", s, "stop is sent");
        eq("stop", r.bridge.get(2), "as the stop command");

        // on a Standard server the rules refuse movement commands, and stop still works
        c.enterWorld(SERVER, "mp:play.example.com");
        r.bridge.clear();
        s = r.say("baritone goto 1 64 2");
        check(s.startsWith("WARN ") && s.contains("off under this server's rules"), "a Standard server refuses goto, with the reason: " + s);
        s = r.say("baritone mine stone");
        check(s.startsWith("WARN "), "and mine");
        eq(0, r.bridge.size(), "nothing was sent");
        check(r.say("baritone stop").startsWith("SUCCESS "), "stop always works");
        eq(List.of("stop"), r.bridge, "and it is the only thing sent");

        // no Baritone installed
        c.enterWorld(SINGLEPLAYER, "sp:B");
        r.bridgeInstalled = false;
        r.bridge.clear();
        s = r.say("baritone goto 1 2 3");
        check(s.startsWith("WARN ") && s.contains("not installed"), "without Baritone the reply says so: " + s);
        eq(0, r.bridge.size(), "and nothing is sent");
    }

    // ------------------------------------------------------------------ status and completion
    private static void statusAndCompletion() throws IOException {
        Rig r = new Rig();
        ReaperCore c = r.core;

        String s = r.say("status");
        check(s.startsWith("INFO Reaper Client test build\n"), "status starts with the game layer's lines: " + s);
        check(Pattern.compile("INFO Profile: Default\\. Modules on: \\d+ of \\d+\\.").matcher(s).find(), "then the profile and module count: " + s);
        check(s.contains("INFO Not in a world."), "outside a world it says so: " + s);
        c.enterWorld(SERVER, "mp:play.example.com");
        check(r.say("status").contains("INFO play.example.com: Standard mode."), "on a server it shows the rules");
        c.enterWorld(SINGLEPLAYER, "sp:S");
        check(r.say("status").contains("INFO Singleplayer: Open mode."), "in singleplayer too");

        List<String> all = r.cmd.complete("");
        check(all.contains("gui") && all.contains("toggle") && all.contains("baritone") && all.contains("status"), "every command is offered: " + all);
        check(all.size() <= CommandCenter.MAX_SUGGESTIONS, "the list is capped: " + all.size());
        eq(List.of("toggle", "toggle " + firstToggleable(c)), firstTwo(r.cmd.complete("togg")), "a prefix offers the command and then its completions");
        check(r.cmd.complete("toggle fu").contains("toggle fullbright"), "toggle completes module ids");
        eq(r.cmd.complete("toggle fu"), r.cmd.complete("TOGGLE FU"), "completion ignores case");
        eq(List.of(), r.cmd.complete("gui"), "a finished word has nothing left to offer");
        eq(3, r.cmd.complete("server ").size(), "server offers three modes");
        check(r.cmd.complete("profile load ").contains("profile load Default"), "profile names are offered");
        check(r.cmd.complete("profile ").contains("profile new "), "profile subcommands are offered");
        eq(List.of(), r.cmd.complete("zzz"), "nothing matches nonsense");
        check(r.cmd.complete(null).size() > 5, "null is the same as empty");
        check(r.cmd.complete("   toggle fu").contains("toggle fullbright"), "leading blanks are ignored");

        c.data.inWorld = true;
        c.data.dimensionId = "minecraft:overworld";
        r.run("waypoint add Base camp");
        check(r.cmd.complete("waypoint remove ").contains("waypoint remove Base camp"), "waypoint names (with spaces) are offered whole");
        r.run("waypoint remove base camp");
        check(!r.cmd.complete("waypoint remove ").contains("waypoint remove Base camp"), "and not after removal");
    }

    private static String firstToggleable(ReaperCore c) {
        for (Module m : c.modules.all()) if (m.toggleable) return m.id;
        return "";
    }

    private static List<String> firstTwo(List<String> l) { return l.size() <= 2 ? l : l.subList(0, 2); }

    // ------------------------------------------------------------------ failures
    private static void failures() throws IOException {
        Rig r = new Rig();
        r.failOpen = true;
        List<CommandCenter.Reply> out = null;
        try {
            out = r.run("gui");
        } catch (Throwable t) {
            check(false, "an exception from the game layer must not escape a command: " + t);
        }
        check(out != null && out.size() == 1 && out.get(0).level() == Level.ERROR, "it becomes one error reply: " + out);
        check(out != null && out.get(0).text().contains("IllegalStateException"), "naming the problem");
        r.failOpen = false;
        eq(0, r.run("").size(), "and the next command works");
        eq(1, r.opened[0], "it opened the menu");
    }
}
