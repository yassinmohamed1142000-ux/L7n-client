package com.reaper.client.tests;

import com.reaper.client.core.feature.ScreenshotLibrary;
import com.reaper.client.core.feature.ScreenshotLibrary.Entry;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.theme.Themes;
import com.reaper.client.core.ui.Input;
import com.reaper.client.core.ui.ScreenshotBrowser;
import com.reaper.client.core.ui.Thumbnails;
import com.reaper.client.core.ui.TextField;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;

/** The screenshot library (real files in a temporary folder) and the browser screen. */
final class ScreenshotTests {
    private ScreenshotTests() {}

    static void run() throws IOException {
        T.section("Screenshots: file names");
        names();
        T.section("Screenshots: library");
        library();
        T.section("Screenshots: browser");
        browser();
    }

    private static void names() {
        eq("shot", ScreenshotLibrary.cleanBaseName("  shot "), "trimmed");
        eq("shot", ScreenshotLibrary.cleanBaseName("shot.png"), "a typed .png is dropped");
        eq("shot", ScreenshotLibrary.cleanBaseName("shot.PNG"), "in any case");
        eq("my.shot v2", ScreenshotLibrary.cleanBaseName("my.shot v2"), "dots and spaces inside are fine");
        eq("2026-11-14_09.05.33", ScreenshotLibrary.cleanBaseName("2026-11-14_09.05.33"), "the game's own style");
        eq("Zuhause \u00fc", ScreenshotLibrary.cleanBaseName("Zuhause \u00fc"), "accents");
        for (String bad : new String[]{null, "", "   ", ".png", ".hidden", " .x", "a/b", "a\\b", "a:b", "a*b", "a?b", "a\"b", "a<b", "a>b", "a|b", "name.", "..", ".", "con", "CON", "Con.txt", "prn", "aux", "NUL", "com1", "COM9", "lpt3", "tab\tname", "bell\u0007", "x".repeat(101)})
            eq(null, ScreenshotLibrary.cleanBaseName(bad), "refused: " + (bad == null ? "null" : bad.replace("\t", "\\t").replace("\u0007", "\\a").replaceAll("^(.{12}).+$", "$1...")));
        eq("a.png.x", ScreenshotLibrary.cleanBaseName("a.png.x"), "a dot inside is fine");
        check(ScreenshotLibrary.cleanBaseName("x".repeat(100)) != null, "100 characters are fine");
        check(ScreenshotLibrary.cleanBaseName("com") != null && ScreenshotLibrary.cleanBaseName("com10") != null && ScreenshotLibrary.cleanBaseName("console") != null, "names that only start like reserved ones are fine");
        eq("0 B", ScreenshotLibrary.sizeText(0), "size 0");
        eq("1023 B", ScreenshotLibrary.sizeText(1023), "size just under 1 KB");
        eq("1 KB", ScreenshotLibrary.sizeText(1024), "1 KB");
        eq("2 KB", ScreenshotLibrary.sizeText(1536), "rounded");
        eq("1.0 MB", ScreenshotLibrary.sizeText(1024 * 1024), "1 MB");
        eq("2.5 MB", ScreenshotLibrary.sizeText((long) (2.5 * 1024 * 1024)), "2.5 MB");
        check(ScreenshotLibrary.dateText(1_700_000_000_000L).matches("\\d{4}-\\d\\d-\\d\\d \\d\\d:\\d\\d"), "date format: " + ScreenshotLibrary.dateText(1_700_000_000_000L));
    }

    private static Path touch(Path dir, String name, long modified, int bytes) throws IOException {
        Path p = dir.resolve(name);
        Files.write(p, new byte[bytes]);
        Files.setLastModifiedTime(p, FileTime.fromMillis(modified));
        return p;
    }

    private static void library() throws IOException {
        Path dir = Files.createTempDirectory("reaper-shots");
        long base = 1_700_000_000_000L;
        touch(dir, "old.png", base, 500);
        touch(dir, "middle.png", base + 60_000, 2048);
        touch(dir, "NEW.PNG", base + 120_000, 3 * 1024 * 1024);
        touch(dir, "notes.txt", base + 200_000, 10);
        touch(dir, "backup.png.bak", base + 200_000, 10);
        touch(dir, ".png", base + 200_000, 10);
        Files.createDirectory(dir.resolve("folder.png"));
        try { Files.createSymbolicLink(dir.resolve("link.png"), dir.resolve("old.png")); } catch (IOException | UnsupportedOperationException ex) { /* no links on this file system */ }
        ScreenshotLibrary lib = new ScreenshotLibrary(dir);
        eq(0, lib.entries().size(), "empty before the first read");
        check(lib.refresh(), "the folder can be read");
        List<Entry> l = lib.entries();
        eq(3, l.size(), "only plain png files are listed (not txt, bak, folders, links)");
        eq("NEW", l.get(0).name, "newest first");
        eq("middle", l.get(1).name, "then the next");
        eq("old", l.get(2).name, "oldest last");
        eq("NEW.png", l.get(0).fileName(), "the file name");
        eq(3 * 1024 * 1024L, l.get(0).size, "the size");
        eq("3.0 MB", l.get(0).sizeText, "the size text");
        eq("2 KB", l.get(1).sizeText, "a small size text");
        check(l.get(0).dateText.matches("\\d{4}-\\d\\d-\\d\\d \\d\\d:\\d\\d"), "the date text: " + l.get(0).dateText);
        try { l.add(null); check(false, "read-only"); } catch (UnsupportedOperationException ex) { check(true, "the list is read-only"); }

        // same time stamp: ordered by name
        touch(dir, "b.png", base + 500_000, 1);
        touch(dir, "a.png", base + 500_000, 1);
        lib.refresh();
        eq("a", lib.entries().get(0).name, "equal times are ordered by name (a)");
        eq("b", lib.entries().get(1).name, "equal times are ordered by name (b)");

        // renaming
        Entry mid = lib.entries().stream().filter(e -> e.name.equals("middle")).findFirst().orElseThrow();
        eq(null, lib.rename(mid, "holiday"), "rename works");
        check(Files.exists(dir.resolve("holiday.png")) && !Files.exists(dir.resolve("middle.png")), "the file was moved");
        eq("holiday", mid.name, "the entry follows");
        eq(dir.resolve("holiday.png"), mid.path, "and its path");
        eq(null, lib.rename(mid, "holiday.png"), "the same name is a no-op");
        check(lib.rename(mid, "a/b") != null && lib.rename(mid, "") != null && lib.rename(mid, "con") != null, "bad names are explained");
        eq("holiday", mid.name, "and change nothing");
        check(lib.rename(mid, "OLD") != null, "a name that exists is refused: " + lib.rename(mid, "OLD"));
        check(lib.rename(mid, "old").contains("already"), "case does not matter for that check");
        check(Files.exists(dir.resolve("holiday.png")), "and the file is still there");
        Files.write(dir.resolve("stranger.png"), new byte[1]);   // appeared after the last read
        check(lib.rename(mid, "stranger") != null, "a file the list does not know about is not overwritten");
        eq(1L, (long) Files.readAllBytes(dir.resolve("stranger.png")).length, "and kept");
        eq(null, lib.rename(mid, "Holiday"), "a change of letter case is allowed");
        check(Files.exists(dir.resolve("Holiday.png")), "and done");
        Entry ghost = new Entry();
        ghost.name = "ghost";
        ghost.path = dir.resolve("ghost.png");
        check(lib.rename(ghost, "x") != null, "an entry that is not in the list cannot be renamed");

        // deleting
        Entry old = lib.entries().stream().filter(e -> e.name.equals("old")).findFirst().orElseThrow();
        int before = lib.entries().size();
        check(lib.delete(old), "deleted");
        check(!Files.exists(dir.resolve("old.png")), "the file is gone");
        eq(before - 1, lib.entries().size(), "and the list is shorter");
        check(!lib.delete(old), "deleting again does nothing");
        check(!lib.delete(ghost), "nor does deleting an unknown entry");
        Entry vanished = lib.entries().get(0);
        Files.delete(vanished.path);
        check(lib.delete(vanished), "a file that is already gone is removed from the list");

        // a missing folder
        ScreenshotLibrary none = new ScreenshotLibrary(dir.resolve("nope"));
        check(!none.refresh() && none.entries().isEmpty(), "a missing folder gives an empty list");
        check(!new ScreenshotLibrary(null).refresh(), "no folder at all");
        check(!new ScreenshotLibrary(dir.resolve("notes.txt")).refresh(), "a file where the folder should be");

        // many files: the newest 3000 are kept
        Path big = Files.createTempDirectory("reaper-shots-big");
        for (int i = 0; i < 3200; i++) touch(big, "s" + i + ".png", base + i * 1000L, 1);
        ScreenshotLibrary bl = new ScreenshotLibrary(big);
        check(bl.refresh(), "a big folder");
        eq(ScreenshotLibrary.MAX_ENTRIES, bl.entries().size(), "the list is capped");
        eq("s3199", bl.entries().get(0).name, "keeping the newest");
        eq("s200", bl.entries().get(2999).name, "and dropping the oldest");
    }

    // ------------------------------------------------------------------ browser
    private static final class FakeThumbs implements Thumbnails {
        final Map<Entry, Thumb> loaded = new HashMap<>();
        final List<Entry> pending = new ArrayList<>();
        final Set<Entry> requested = new HashSet<>();
        int released;

        @Override public Thumb get(Entry e) {
            requested.add(e);
            Thumb t = loaded.get(e);
            if (t == null && !pending.contains(e)) pending.add(e);
            return t;
        }

        @Override public void release() { released++; loaded.clear(); pending.clear(); }

        /** Finishes one pending picture, like a background loader would between frames. */
        void tick() {
            if (pending.isEmpty()) return;
            Entry e = pending.remove(0);
            BufferedImage img = new BufferedImage(160, 90, BufferedImage.TYPE_INT_ARGB);
            int h = Math.abs(e.name.hashCode());
            for (int y = 0; y < 90; y++) for (int x = 0; x < 160; x++) {
                int r = (h >> 3 & 0x7F) + x / 3, g = (h >> 10 & 0x7F) + y, b = (h >> 17 & 0x7F) + (x + y) / 4;
                img.setRGB(x, y, 0xFF000000 | Math.min(255, r) << 16 | Math.min(255, g) << 8 | Math.min(255, b));
            }
            loaded.put(e, new Thumb(img, 160, 90));
        }
    }

    private static final class FakeHost implements ScreenshotBrowser.Host {
        final List<String> toasts = new ArrayList<>();
        Path opened;
        int closed;
        @Override public void openFolder(Path dir) { opened = dir; }
        @Override public void toast(Level level, String message) { toasts.add(level + ": " + message); }
        @Override public void close() { closed++; }
    }

    private static final class Env {
        final Path dir;
        final ScreenshotLibrary lib;
        final FakeThumbs thumbs = new FakeThumbs();
        final FakeHost host = new FakeHost();
        final ScreenshotBrowser b;
        final RasterCanvas cv;
        String clipboard = "";

        Env(int files, int w, int h) throws IOException {
            dir = Files.createTempDirectory("reaper-shots-ui");
            for (int i = 0; i < files; i++) touch(dir, String.format("shot-%02d.png", i), 1_700_000_000_000L + i * 60_000L, 1000 + i);
            lib = new ScreenshotLibrary(dir);
            b = new ScreenshotBrowser(lib, thumbs, host);
            b.ui.clipboard = new TextField.Clipboard() {
                @Override public String get() { return clipboard; }
                @Override public void set(String s) { clipboard = s; }
            };
            cv = new RasterCanvas(w, h, 1);
            b.open();
        }

        void frame() { thumbs.tick(); cv.begin(0xFF0E1418); b.render(cv, Themes.MIDNIGHT, 1f / 60f); }
        void frames(int n) { for (int i = 0; i < n; i++) frame(); }

        void click(double x, double y) {
            b.in.mouseMove(x, y); frame();
            b.in.mouseDown(Input.LEFT, x, y); frame();
            b.in.mouseUp(Input.LEFT, x, y); frame();
        }

        RasterCanvas.Drawn text(String s) {
            RasterCanvas.Drawn d = cv.find(s);
            if (d == null) throw new AssertionError("text not drawn: \"" + s + "\" (drawn: " + cv.texts + ")");
            return d;
        }

        boolean has(String s) { return cv.find(s) != null; }
        void clickText(String s) { RasterCanvas.Drawn d = text(s); click(d.x() + d.w() / 2.0, d.y() + d.h() / 2.0); }
        /** Clicks the picture area of the card with this name. */
        /** Clicks into the name box (it sits 25 px above the Rename button; its text changes, so it cannot be found by label). */
        void clickNameBox() { RasterCanvas.Drawn r = text("Rename"); click(r.x() + 60, r.y() - 25 + r.h() / 2.0); }
        void clickCard(String name) { RasterCanvas.Drawn d = text(name); click(d.x() + 12, d.y() - 25); }
        void key(int k) { b.in.key(k, 0); frames(2); }
        void type(String s) { s.codePoints().forEach(b.in::character); frame(); }
        void selectAll() { b.in.key(KeyNames.A, Input.MOD_CTRL); frames(2); b.in.mods = 0; }
        void settle() { frames(40); }

        void preview(String name) {
            String out = System.getProperty("reaper.preview.dir");
            if (out == null || out.isEmpty()) return;
            try { RasterCanvas big = new RasterCanvas(cv.width(), cv.height(), 2); big.begin(0xFF0E1418); b.render(big, Themes.MIDNIGHT, 1f / 60f); big.save(new java.io.File(out, name + ".png")); }
            catch (IOException ex) { System.out.println("  (could not save preview " + name + ")"); }
        }
    }

    private static void browser() throws IOException {
        Env e = new Env(40, 640, 360);
        e.settle();
        check(e.has("SCREENSHOTS") && e.has("40 pictures"), "the header says how many");
        check(e.has("Done") && e.has("Refresh") && e.has("Open folder"), "the header buttons");
        check(e.has("shot-39") && e.has("shot-38"), "the newest pictures come first");
        check(!e.has("shot-00"), "the oldest is below the visible part");
        check(e.thumbs.requested.size() > 3 && e.thumbs.requested.size() < 25, "only the visible cards ask for pictures (" + e.thumbs.requested.size() + " of 40)");
        check(e.has("Select a screenshot."), "nothing selected yet");
        e.preview("screenshots-browser-empty-selection");

        // selecting
        e.clickCard("shot-38");
        eq("shot-38", e.b.selected().name, "clicking a card selects it");
        check(e.has("shot-38.png"), "the details show the file name");
        check(e.cv.findPrefix("2023-") != null, "and the date");
        e.preview("screenshots-browser");

        // keyboard
        e.key(KeyNames.RIGHT);
        eq("shot-37", e.b.selected().name, "Right moves to the next");
        e.key(KeyNames.LEFT);
        eq("shot-38", e.b.selected().name, "Left moves back");
        e.key(KeyNames.DOWN);
        eq("shot-35", e.b.selected().name, "Down moves one row (three columns)");
        e.key(KeyNames.UP);
        eq("shot-38", e.b.selected().name, "Up moves back");
        e.key(KeyNames.END);
        eq("shot-00", e.b.selected().name, "End goes to the last");
        e.settle();
        check(e.has("shot-00"), "and scrolls it into view");
        e.key(KeyNames.HOME);
        eq("shot-39", e.b.selected().name, "Home goes to the first");
        e.settle();
        check(e.has("shot-39"), "and scrolls back up");
        e.key(KeyNames.LEFT);
        eq("shot-39", e.b.selected().name, "Left at the start stays put");

        // wheel
        e.b.in.mouseMove(200, 200);
        for (int i = 0; i < 6; i++) { e.b.in.scroll(-1); e.frame(); }
        e.settle();
        check(!e.has("shot-39") && !e.has("shot-38"), "the wheel scrolls the grid down");
        for (int i = 0; i < 20; i++) { e.b.in.scroll(1); e.frame(); }
        e.settle();
        check(e.has("shot-39"), "and back up");
        for (int i = 0; i < 40; i++) { e.b.in.scroll(1); e.frame(); }
        e.settle();
        check(e.has("shot-39"), "never above the top");

        // rename
        e.clickCard("shot-38");
        e.clickNameBox();
        e.type("holiday");
        e.clickText("Rename");
        e.frames(2);
        check(Files.exists(e.dir.resolve("holiday.png")) && !Files.exists(e.dir.resolve("shot-38.png")), "renamed on disk");
        check(e.has("holiday") && e.has("holiday.png"), "and in the list and the details");
        check(e.cv.findPrefix("Renamed to holiday.png") != null, "the player is told");
        e.clickNameBox();
        e.type("a/b");
        e.clickText("Rename");
        e.frames(2);
        check(e.cv.findPrefix("That is not a usable file name.") != null, "an unusable name is explained");
        check(Files.exists(e.dir.resolve("holiday.png")), "and nothing changed");
        check(e.has("a/b"), "the text stays in the box so it can be corrected");
        // correct it: click into the box, select everything, type a name that is taken, press Enter
        e.clickNameBox();
        e.selectAll();
        e.type("shot-39");
        e.key(KeyNames.ENTER);
        check(e.cv.findPrefix("A screenshot with that name") != null, "Enter renames too, and a taken name is explained: " + e.cv.texts);
        check(Files.exists(e.dir.resolve("holiday.png")) && Files.exists(e.dir.resolve("shot-39.png")), "both files are untouched");
        e.clickNameBox();
        e.selectAll();
        e.type("Holiday 2");
        e.key(KeyNames.ENTER);
        check(Files.exists(e.dir.resolve("Holiday 2.png")) && !Files.exists(e.dir.resolve("holiday.png")), "a corrected name works");
        e.clickNameBox();
        e.type("holiday");
        e.key(KeyNames.ESCAPE);
        check(e.has("holiday") && Files.exists(e.dir.resolve("Holiday 2.png")), "Escape leaves the box without renaming");
        e.selectAll();   // not in the box any more: must not do anything
        eq("Holiday 2", e.b.selected().name, "and the selection is the same");
        e.clickNameBox();
        e.selectAll();
        e.type("holiday");
        e.key(KeyNames.ENTER);
        check(Files.exists(e.dir.resolve("holiday.png")), "back to the old name");

        // copy path
        e.clickText("Copy path");
        eq(e.dir.resolve("holiday.png").toString(), e.clipboard, "the full path is on the clipboard");
        check(e.host.toasts.stream().anyMatch(s -> s.contains("Copied the path of holiday.png")), "a notification confirms it");

        // delete needs two clicks
        e.clickText("Delete");
        check(e.has("Sure? Click again to delete"), "the first click asks");
        check(Files.exists(e.dir.resolve("holiday.png")), "nothing deleted yet");
        e.frames(200);
        check(e.has("Delete") && !e.has("Sure? Click again to delete"), "the question times out");
        e.clickText("Delete");
        e.clickText("Sure? Click again to delete");
        check(!Files.exists(e.dir.resolve("holiday.png")), "two clicks delete the file");
        check(e.has("39 pictures"), "the count goes down");
        check(e.b.selected() != null && e.b.selected().name.equals("shot-37"), "the next picture is selected");
        check(e.host.toasts.stream().anyMatch(s -> s.contains("Deleted holiday.png")), "a notification says what was deleted");
        e.clickCard("shot-37");
        e.clickText("Delete");
        e.clickCard("shot-36");
        check(e.has("Delete") && !e.has("Sure? Click again to delete"), "changing the selection cancels a pending delete");
        check(Files.exists(e.dir.resolve("shot-37.png")), "and deletes nothing");

        // header buttons
        e.clickText("Open folder");
        eq(e.dir, e.host.opened, "Open folder asks the game to open the folder");
        Files.write(e.dir.resolve("fresh.png"), new byte[10]);
        e.clickText("Refresh");
        e.frames(3);
        check(e.has("40 pictures"), "Refresh finds a new file");
        e.clickText("Done");
        eq(1, e.host.closed, "Done closes the screen");
        e.b.close();
        eq(1, e.thumbs.released, "closing frees the pictures");

        // empty and missing folders
        Env empty = new Env(0, 640, 360);
        empty.frames(3);
        check(empty.has("No screenshots yet.") && empty.has("0 pictures"), "an empty folder says so");
        Env gone = new Env(0, 640, 360);
        Files.delete(gone.dir);
        gone.b.open();
        gone.frames(3);
        check(gone.has("The screenshots folder does not exist yet."), "a missing folder says so");
        Env one = new Env(1, 640, 360);
        one.frames(3);
        check(one.has("1 picture"), "singular");

        // a narrow screen has no details panel but still works
        Env narrow = new Env(12, 400, 300);
        narrow.settle();
        check(narrow.has("shot-11") && !narrow.has("Select a screenshot."), "narrow: the grid only");
        narrow.clickCard("shot-11");
        eq("shot-11", narrow.b.selected().name, "and selecting still works");

        // scrolling through every picture: the per-card state is dropped again afterwards
        Env many = new Env(300, 640, 360);
        many.settle();
        many.b.in.mouseMove(200, 200);
        int worst = 0;
        for (int i = 0; i < 700; i++) {
            many.b.in.scroll(i < 330 ? -1 : (i < 560 ? 1 : 0));
            many.frame();
            worst = Math.max(worst, many.b.ui.stateCount());
        }
        many.frames(1300);
        int idle = many.b.ui.stateCount();
        System.out.println("  widget states while scrolling through 300 pictures: peak " + worst + ", after waiting " + idle);
        check(worst >= 250, "the scroll really went past (nearly) every card (" + worst + ")");
        check(idle < 60, "and the state of cards that are gone is dropped again (" + idle + " left)");
    }
}
