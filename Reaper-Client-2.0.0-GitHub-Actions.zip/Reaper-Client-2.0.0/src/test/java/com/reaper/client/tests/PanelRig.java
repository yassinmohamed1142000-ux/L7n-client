package com.reaper.client.tests;

import com.reaper.client.core.notify.Level;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.theme.Themes;
import com.reaper.client.core.ui.GuiHost;
import com.reaper.client.core.ui.Input;
import com.reaper.client.core.ui.TextField;
import com.reaper.client.core.ui.Ui;
import com.reaper.client.core.ui.UiWindow;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Draws one window body (a {@link UiWindow.Content}) on its own, with a software canvas and simulated mouse and keyboard. */
final class PanelRig implements GuiHost {
    static final int X = 6, Y = 30, CW = 202, VIEW = 380;

    final Input in = new Input();
    final Ui ui = new Ui(in);
    final RasterCanvas cv;
    final UiWindow win = new UiWindow("test", "Test", (u, w, x, y, cw, vh) -> 0);
    final List<String> toasts = new ArrayList<>();
    int saves;
    String clipboard = "";
    UiWindow.Content body;
    Theme theme = Themes.MIDNIGHT;
    int contentH;

    PanelRig(int w, int h) {
        cv = new RasterCanvas(w, h, 2);
        ui.clipboard = new TextField.Clipboard() {
            @Override public String get() { return clipboard; }
            @Override public void set(String s) { clipboard = s; }
        };
    }

    // ------------------------------------------------------------------ GuiHost
    @Override public void toast(Level level, String message) { toasts.add(level + ": " + message); }
    @Override public void requestSave() { saves++; }
    @Override public void openHudEditor() { }
    @Override public void openScreenshots() { }
    @Override public void closeGui() { }

    // ------------------------------------------------------------------ frames
    void frame() { frame(1f / 60f); }

    void frame(float dt) {
        cv.begin(0xFF101820);
        ui.begin(cv, theme, dt, (int) Math.round(in.mx), (int) Math.round(in.my));
        contentH = body.draw(ui, win, X, Y, CW, VIEW);
        ui.end();
    }

    void frames(int n) { for (int i = 0; i < n; i++) frame(); }

    // ------------------------------------------------------------------ input
    void move(double x, double y) { in.mouseMove(x, y); }

    void click(double x, double y) {
        move(x, y);
        frame();
        in.mouseDown(Input.LEFT, x, y);
        frame();
        in.mouseUp(Input.LEFT, x, y);
        frame();
    }

    /** Clicks the middle of the first drawn text equal to {@code s}. */
    void clickText(String s) {
        RasterCanvas.Drawn d = text(s);
        click(d.x() + d.w() / 2.0, d.y() + d.h() / 2.0);
    }

    void type(String s) {
        s.codePoints().forEach(in::character);
        frame();
    }

    void key(int k) {
        in.key(k, 0);
        frame();
    }

    // ------------------------------------------------------------------ lookups
    RasterCanvas.Drawn text(String s) {
        RasterCanvas.Drawn d = cv.find(s);
        if (d == null) throw new AssertionError("text not drawn: \"" + s + "\" (drawn: " + cv.texts + ")");
        return d;
    }

    boolean has(String s) { return cv.find(s) != null; }

    int count(String prefix) {
        int n = 0;
        for (RasterCanvas.Drawn d : cv.texts) if (d.text().startsWith(prefix)) n++;
        return n;
    }

    void preview(String name) {
        String dir = System.getProperty("reaper.preview.dir");
        if (dir == null || dir.isEmpty()) return;
        try { cv.save(new File(dir, name + ".png")); }
        catch (IOException ex) { System.out.println("  (could not save preview " + name + ": " + ex.getMessage() + ")"); }
    }
}
