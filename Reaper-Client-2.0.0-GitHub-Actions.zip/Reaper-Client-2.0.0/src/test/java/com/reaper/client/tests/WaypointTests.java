package com.reaper.client.tests;

import com.reaper.client.core.feature.Glyphs;
import com.reaper.client.core.feature.Projector;
import com.reaper.client.core.feature.Waypoint;
import com.reaper.client.core.feature.WaypointStore;
import com.reaper.client.core.feature.WaypointsModule;
import com.reaper.client.core.hud.Hud;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.elements.WaypointsElement;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.theme.Themes;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;
import static com.reaper.client.tests.T.near;

/** Waypoints: names, the per-world store and its file, the projection maths, markers, the HUD list and the actions. */
final class WaypointTests {
    private WaypointTests() {}

    private static final String OW = "minecraft:overworld", NETHER = "minecraft:the_nether";

    static void run() throws IOException {
        T.section("Waypoints: names");
        names();
        T.section("Waypoints: store");
        store();
        T.section("Waypoints: nearest");
        nearest();
        T.section("Waypoints: file");
        file();
        T.section("Waypoints: projector");
        projector();
        T.section("Waypoints: glyphs");
        glyphs();
        T.section("Waypoints: actions");
        actions();
        T.section("Waypoints: markers");
        markers();
        T.section("Waypoints: HUD list");
        hudList();
        T.section("Waypoints: allocation");
        allocation();
    }

    // ------------------------------------------------------------------ rig
    private static final class Rig {
        final Path dir, file;
        final ModuleRegistry reg = new ModuleRegistry();
        final HudData d = new HudData();
        final WaypointStore store;
        final WaypointsModule mod;
        final WaypointsElement el;
        final Hud hud;
        final RasterCanvas cv;
        final int W = 320, H = 180;
        boolean blocked;
        long now = 1_000_000;

        Rig() throws IOException {
            dir = Files.createTempDirectory("reaper-wp-test");
            file = dir.resolve("waypoints.json");
            store = new WaypointStore(file);
            d.fillSample(now);
            d.singleplayer = false;
            d.screenW = W;
            d.screenH = H;
            d.wallClockMs = 1_700_000_000_000L;
            d.x = 0.5; d.y = 64.0; d.z = 0.5;
            d.camX = 0.5; d.camY = 64.5; d.camZ = 0.5;   // the middle of block (0, 64, 0): distances come out whole
            d.yaw = 0f; d.pitch = 0f; d.fov = 70f;       // facing +Z
            mod = reg.register(new WaypointsModule(store, d));
            el = reg.register(new WaypointsElement(mod));
            hud = new Hud(reg);
            hud.add(el);
            reg.setPolicyGate(f -> !(blocked && f == Feature.WAYPOINT_MARKERS));
            cv = new RasterCanvas(W, H, 2);
            store.setContext("test-world");
        }

        void marks() { cv.begin(0xFF203040); mod.drawMarkers(cv, Themes.MIDNIGHT); }

        void hudFrame(boolean editing) {
            now += 16;
            d.nowMs = now;
            cv.begin(0xFF203040);
            hud.render(cv, d, Themes.MIDNIGHT, 0.016f, editing);
        }

        Waypoint add(String name, int x, int y, int z) { return store.add(name, x, y, z, OW, 0xFF4ADE80); }

        void preview(String name) {
            String out = System.getProperty("reaper.preview.dir");
            if (out == null || out.isEmpty()) return;
            try { cv.save(new java.io.File(out, name + ".png")); }
            catch (IOException ex) { System.out.println("  (could not save preview " + name + ": " + ex.getMessage() + ")"); }
        }
    }

    // ------------------------------------------------------------------ names
    private static void names() {
        eq("Home", Waypoint.cleanName("  Home "), "names are trimmed");
        eq(null, Waypoint.cleanName(null), "null is not a name");
        eq(null, Waypoint.cleanName(""), "empty is not a name");
        eq(null, Waypoint.cleanName("    "), "blanks are not a name");
        eq("a".repeat(32), Waypoint.cleanName("a".repeat(32)), "32 characters are fine");
        eq(null, Waypoint.cleanName("a".repeat(33)), "33 are too many");
        eq(null, Waypoint.cleanName("bad\tname"), "control characters are refused");
        eq(null, Waypoint.cleanName("bell\u0007"), "so is a bell");
        eq("Zuhause \u00f1 \u00fc", Waypoint.cleanName("Zuhause \u00f1 \u00fc"), "accents are fine");
        eq("\uD83C\uDFE0 base", Waypoint.cleanName("\uD83C\uDFE0 base"), "so are characters outside the basic plane");
        eq("x".repeat(31) + "\uD83C\uDFE0", Waypoint.cleanName("x".repeat(31) + "\uD83C\uDFE0"), "length counts characters, not UTF-16 units");
        Waypoint w = new Waypoint("A", 10, 64, -20, OW, 0x112233);
        eq(0xFF112233, w.color, "colours are always opaque");
        eq("10 64 -20", w.coordinates(), "coordinates in the form /tp takes");
        near(Math.sqrt(10.5 * 10.5 + 64.5 * 64.5 + 19.5 * 19.5), w.distance(0, 0, 0), 1e-9, "distance to the middle of the block");
        near(Math.sqrt(10.5 * 10.5 + 19.5 * 19.5), w.horizontal(0, 0), 1e-9, "horizontal distance ignores height");
    }

    // ------------------------------------------------------------------ store
    private static void store() throws IOException {
        Rig r = new Rig();
        WaypointStore s = r.store;
        eq(null, new WaypointStore(r.dir.resolve("x.json")).add("A", 1, 2, 3, OW, 0), "no world, no waypoints");
        eq(0, s.count(), "starts empty");
        Waypoint home = s.add("Home", 10, 64, -20, OW, 0x4ADE80);
        check(home != null && s.count() == 1 && s.list().get(0) == home, "added");
        check(home.created > 0, "stamped with a creation time");
        check(s.isDirty(), "adding marks the store as changed");
        eq(null, s.add("", 1, 2, 3, OW, 0), "empty name refused");
        eq(null, s.add("x".repeat(40), 1, 2, 3, OW, 0), "long name refused");
        eq(null, s.add("A", 30_000_001, 2, 3, OW, 0), "x beyond the world border refused");
        eq(null, s.add("A", 1, 2, -30_000_001, OW, 0), "z beyond the world border refused");
        eq(null, s.add("A", 1, 200_000, 3, OW, 0), "absurd height refused");
        eq(null, s.add("A", 1, 2, 3, "", 0), "no dimension refused");
        eq(null, s.add("A", 1, 2, 3, null, 0), "null dimension refused");
        eq(1, s.count(), "nothing refused was added");
        check(s.add("Edge", 30_000_000, -64, -30_000_000, OW, 0) != null, "the world border itself is fine");

        eq("Waypoint 1", s.uniqueName("Waypoint"), "first free name");
        s.add("Waypoint 1", 0, 0, 0, OW, 0);
        eq("Waypoint 2", s.uniqueName("Waypoint"), "next free name");
        s.add("waypoint 2", 0, 0, 0, OW, 0);
        eq("Waypoint 3", s.uniqueName("Waypoint"), "names are compared ignoring case");
        eq("Mine 1", s.uniqueName("Mine"), "other bases work");
        eq("Waypoint 3", s.uniqueName(" "), "a blank base falls back");

        // other worlds are separate
        s.setContext("other.server.net");
        eq(0, s.count(), "a different world has its own list");
        Waypoint o = s.add("Elsewhere", 5, 5, 5, OW, 0);
        check(o != null, "can add there");
        s.setContext("test-world");
        eq(4, s.count(), "the first world is untouched");
        s.setContext(null);
        eq(0, s.count(), "no context, no list");
        eq(null, s.add("A", 1, 2, 3, OW, 0), "and nothing can be added");
        s.setContext("   ");
        eq(null, s.context(), "a blank context counts as none");
        s.setContext("test-world");

        // editing
        check(s.rename(home, "House"), "rename");
        eq("House", home.name, "renamed");
        check(!s.rename(home, ""), "empty rename refused");
        check(!s.rename(home, "y".repeat(33)), "long rename refused");
        eq("House", home.name, "name unchanged after a refused rename");
        check(!s.rename(o, "Nope"), "a waypoint of another world cannot be renamed here");
        s.setColor(home, 0x123456);
        eq(0xFF123456, home.color, "set colour is opaque");
        s.setVisible(home, false);
        check(!home.visible, "hidden");
        check(s.remove(home), "removed");
        check(!s.remove(home), "removing twice does nothing");
        eq(3, s.count(), "three left");
        s.removeAllHere();
        eq(0, s.count(), "all removed");
        s.removeAllHere();
        eq(0, s.count(), "removing nothing is fine");

        // limit
        for (int i = 0; i < WaypointStore.MAX_PER_WORLD; i++) check(s.add("p" + i, i, 0, 0, OW, 0) != null, "add " + i);
        eq(null, s.add("one too many", 0, 0, 0, OW, 0), "the 201st is refused");
        eq(WaypointStore.MAX_PER_WORLD, s.count(), "exactly the limit");

        // deaths
        s.removeAllHere();
        s.add("Base", 0, 0, 0, OW, 0);
        for (int i = 1; i <= 5; i++) {
            Waypoint dth = s.addDeath("Death " + i, i, 60, i, OW, 0xFFFF0000, 3);
            check(dth != null && dth.death, "death " + i + " added");
        }
        int deaths = 0;
        StringBuilder kept = new StringBuilder();
        for (Waypoint w : s.list()) if (w.death) { deaths++; kept.append(w.name).append(';'); }
        eq(3, deaths, "only the three newest deaths are kept");
        eq("Death 3;Death 4;Death 5;", kept.toString(), "the oldest went first");
        check(s.list().stream().anyMatch(w -> w.name.equals("Base")), "ordinary waypoints are not touched");
        s.addDeath("Death 6", 6, 60, 6, OW, 0xFFFF0000, 0);
        deaths = 0;
        for (Waypoint w : s.list()) if (w.death) deaths++;
        eq(1, deaths, "keeping zero still keeps the newest");
        try { s.list().add(home); check(false, "the list is read-only"); } catch (UnsupportedOperationException ex) { check(true, "the list is read-only"); }
    }

    // ------------------------------------------------------------------ nearest
    private static void nearest() throws IOException {
        Rig r = new Rig();
        WaypointStore s = r.store;
        Waypoint far = s.add("far", 300, 64, 0, OW, 0);
        Waypoint mid = s.add("mid", 0, 64, 100, OW, 0);
        Waypoint near = s.add("near", -10, 64, 0, OW, 0);
        Waypoint hidden = s.add("hidden", 1, 64, 1, OW, 0);
        s.setVisible(hidden, false);
        Waypoint other = s.add("nether", 2, 64, 2, NETHER, 0);
        Waypoint[] out = new Waypoint[5];
        int n = s.nearest(OW, 0.5, 0.5, out);
        eq(3, n, "hidden and other-dimension waypoints are left out");
        check(out[0] == near && out[1] == mid && out[2] == far, "nearest first");
        n = s.nearest(OW, 0.5, 0.5, out, 2);
        eq(2, n, "the max limits the count");
        check(out[0] == near && out[1] == mid, "and keeps the nearest");
        n = s.nearest(NETHER, 0.5, 0.5, out);
        eq(1, n, "per dimension");
        check(out[0] == other, "the nether one");
        eq(0, s.nearest("minecraft:the_end", 0, 0, out), "none in the end");
        eq(0, s.nearest(OW, 0, 0, new Waypoint[0]), "an empty output holds nothing");
        eq(0, s.nearest(OW, 0, 0, out, 0), "a zero limit holds nothing");
        Waypoint[] big = new Waypoint[40];
        for (int i = 0; i < 40; i++) s.add("w" + i, 1000 + i, 0, 0, OW, 0);
        eq(16, s.nearest(OW, 0.5, 0.5, big), "at most 16");
        // against a brute-force sort, with random positions
        Random rnd = new Random(7);
        s.removeAllHere();
        for (int i = 0; i < 120; i++) s.add("r" + i, rnd.nextInt(2001) - 1000, 64, rnd.nextInt(2001) - 1000, i % 7 == 0 ? NETHER : OW, 0);
        for (int trial = 0; trial < 40; trial++) {
            double px = rnd.nextInt(2001) - 1000, pz = rnd.nextInt(2001) - 1000;
            Waypoint[] got = new Waypoint[8];
            int g = s.nearest(OW, px, pz, got);
            java.util.List<Waypoint> expect = new java.util.ArrayList<>();
            for (Waypoint w : s.list()) if (w.dimension.equals(OW)) expect.add(w);
            expect.sort(java.util.Comparator.comparingDouble(w -> Math.pow(w.x + 0.5 - px, 2) + Math.pow(w.z + 0.5 - pz, 2)));
            boolean same = g == 8;
            for (int i = 0; i < g && same; i++) {
                double a = Math.pow(got[i].x + 0.5 - px, 2) + Math.pow(got[i].z + 0.5 - pz, 2);
                double b = Math.pow(expect.get(i).x + 0.5 - px, 2) + Math.pow(expect.get(i).z + 0.5 - pz, 2);
                same = a == b;
            }
            check(same, "nearest matches a full sort (trial " + trial + ")");
        }
    }

    // ------------------------------------------------------------------ file
    private static void file() throws IOException {
        Rig r = new Rig();
        WaypointStore a = r.store;
        Waypoint w1 = a.add("Zuhause \u00f1 \u00fc", 10, 64, -20, OW, 0x4ADE80);
        Waypoint w2 = a.add("Gone", -5, 11, 99, NETHER, 0xFF8800);
        a.setVisible(w2, false);
        a.addDeath("Death 12:00", 7, 8, 9, OW, 0xFFFF5D5D, 3);
        a.setContext("second.server.net");
        a.add("Elsewhere", 1, 2, 3, "minecraft:the_end", 0x112233);
        a.setContext("test-world");
        check(a.save() && !a.isDirty(), "saved");
        check(Files.isRegularFile(r.file), "the file exists");
        String text = Files.readString(r.file);
        check(!text.contains("\u0000"), "plain text");

        WaypointStore b = new WaypointStore(r.file);
        b.load();
        b.setContext("test-world");
        eq(3, b.count(), "three waypoints came back");
        Waypoint x = b.list().get(0), y = b.list().get(1), z = b.list().get(2);
        eq(w1.name, x.name, "name");
        eq(10, x.x, "x"); eq(64, x.y, "y"); eq(-20, x.z, "z");
        eq(OW, x.dimension, "dimension");
        eq(w1.color, x.color, "colour");
        check(x.visible && !x.death, "flags");
        check(!y.visible && y.dimension.equals(NETHER) && y.color == w2.color, "hidden waypoint in the nether");
        check(z.death && z.name.equals("Death 12:00"), "the death marker");
        eq(w1.created, x.created, "creation time");
        b.setContext("second.server.net");
        eq(1, b.count(), "the other world is stored separately");
        eq("Elsewhere", b.list().get(0).name, "its waypoint");
        b.setContext("unknown");
        eq(0, b.count(), "an unknown world is empty");
        check(!b.isDirty(), "loading does not mark the store as changed");

        // a clean store writes nothing
        Files.delete(r.file);
        check(b.save(), "saving a clean store succeeds");
        check(!Files.exists(r.file), "and writes nothing");

        // removing the last waypoint of a world drops the world from the file
        Rig r2 = new Rig();
        r2.add("Only", 1, 2, 3);
        r2.store.save();
        r2.store.removeAllHere();
        r2.store.save();
        WaypointStore c = new WaypointStore(r2.file);
        c.load();
        c.setContext("test-world");
        eq(0, c.count(), "an emptied world stays empty");

        // damaged file: nothing is thrown, the backup is used when there is one
        Rig r3 = new Rig();
        r3.add("First", 1, 2, 3);
        r3.store.save();
        r3.add("Second", 4, 5, 6);
        r3.store.save();
        Files.writeString(r3.file, "{{{ this is not json");
        WaypointStore d = new WaypointStore(r3.file);
        d.load();
        d.setContext("test-world");
        eq(1, d.count(), "the backup (the previous save) is used");
        eq("First", d.list().get(0).name, "with its content");
        Files.writeString(JsonBak(r3.file), "also broken");
        WaypointStore e = new WaypointStore(r3.file);
        e.load();
        e.setContext("test-world");
        eq(0, e.count(), "both damaged: an empty list, no exception");
        Files.writeString(r3.file, "[1,2,3]");
        e.load();
        eq(0, e.count(), "valid JSON of the wrong shape");
        Files.writeString(r3.file, "");
        e.load();
        eq(0, e.count(), "an empty file");
        Files.delete(r3.file);
        e.load();
        eq(0, e.count(), "a missing file");
        check(new WaypointStore(r3.dir.resolve("never.json")).save(), "saving a never-used store is fine");

        // hostile content
        Path hostile = r3.dir.resolve("hostile.json");
        Files.writeString(hostile, """
                {"schema":1,"worlds":{
                 "ok":[{"name":"Fine","x":1,"y":2,"z":3,"dim":"minecraft:overworld","color":16711680},
                       {"name":"","x":1,"y":2,"z":3},
                       {"name":"BadX","x":"1","y":2,"z":3},
                       {"name":"Huge","x":99999999999,"y":2,"z":3},
                       {"name":"Out","x":30000001,"y":2,"z":3},
                       {"name":"Ctl\\u0007","x":1,"y":2,"z":3},
                       {"name":"NoDim","x":4,"y":5,"z":6},
                       "notAnObject", 7, null, [],
                       {"name":"TooLongTooLongTooLongTooLongTooLongTooLong","x":1,"y":2,"z":3},
                       {"name":"Flags","x":1.9,"y":2,"z":3,"dim":"minecraft:the_nether","visible":false,"death":true,"color":-1},
                       {"name":"LongDim","x":1,"y":2,"z":3,"dim":"%s"},
                       {"name":"Weird","x":1,"y":2,"z":3,"visible":"no","death":5,"created":"yesterday","color":"red"}],
                 "notAList":{"a":1},
                 "":[{"name":"EmptyKey","x":1,"y":1,"z":1}]
                }}""".formatted("d".repeat(200)));
        WaypointStore h = new WaypointStore(hostile);
        h.load();
        h.setContext("ok");
        StringBuilder names = new StringBuilder();
        for (Waypoint w : h.list()) names.append(w.name).append(',');
        eq("Fine,NoDim,Flags,Weird,", names.toString(), "only the valid entries are kept");
        eq(0xFFFF0000, h.list().get(0).color, "numeric colour");
        eq(OW, h.list().get(1).dimension, "a missing dimension means the overworld");
        Waypoint flags = h.list().get(2);
        eq(1, flags.x, "a fractional coordinate is cut");
        check(!flags.visible && flags.death && flags.dimension.equals(NETHER), "flags and dimension");
        eq(0xFFFFFFFF, flags.color, "colour -1 is opaque white");
        Waypoint weird = h.list().get(3);
        check(weird.visible && !weird.death && weird.created == 0, "wrong-typed flags fall back to the defaults");
        h.setContext("");
        eq(null, h.context(), "an empty world name is no world");
        h.setContext("notAList");
        eq(0, h.count(), "a world that is not a list is ignored");

        StringBuilder many = new StringBuilder("{\"worlds\":{\"big\":[");
        for (int i = 0; i < 260; i++) many.append(i == 0 ? "" : ",").append("{\"name\":\"n").append(i).append("\",\"x\":").append(i).append(",\"y\":0,\"z\":0}");
        many.append("]}}");
        Files.writeString(hostile, many.toString());
        h.load();
        h.setContext("big");
        eq(WaypointStore.MAX_PER_WORLD, h.count(), "an oversized world is cut to the limit");
        StringBuilder worlds = new StringBuilder("{\"worlds\":{");
        for (int i = 0; i < 350; i++) worlds.append(i == 0 ? "" : ",").append("\"w").append(i).append("\":[{\"name\":\"a\",\"x\":0,\"y\":0,\"z\":0}]");
        worlds.append("}}");
        Files.writeString(hostile, worlds.toString());
        h.load();
        int loaded = 0;
        for (int i = 0; i < 350; i++) { h.setContext("w" + i); if (h.count() > 0) loaded++; }
        eq(WaypointStore.MAX_WORLDS, loaded, "the number of worlds is limited");
        // and a very long context key is shortened, not rejected
        h.setContext("k".repeat(500));
        eq(WaypointStore.MAX_KEY, h.context().length(), "a very long world key is cut");
    }

    private static Path JsonBak(Path f) { return f.resolveSibling(f.getFileName() + ".bak"); }

    // ------------------------------------------------------------------ projector
    private static void projector() {
        Projector p = new Projector();
        p.camera(0, 0, 0, 0, 0, 90, 200, 100);
        check(p.project(0, 0, 10), "ahead is in front");
        near(100, p.sx, 1e-3, "straight ahead is the middle (x)");
        near(50, p.sy, 1e-3, "straight ahead is the middle (y)");
        near(10, p.depth, 1e-9, "depth is the distance along the view");
        check(p.project(-5, 0, 10), "to the right (facing south, right is -X)");
        near(125, p.sx, 1e-3, "a quarter of the way to the right edge");
        check(p.project(5, 0, 10), "to the left");
        near(75, p.sx, 1e-3, "and to the left");
        check(p.project(0, 5, 10), "above");
        near(25, p.sy, 1e-3, "above the middle is a smaller y");
        check(p.project(0, 10, 10), "the top edge");
        near(0, p.sy, 1e-3, "half the vertical field of view is the top edge");
        check(p.project(-20, 0, 10), "exactly at the edge of the view");
        near(200, p.sx, 1e-3, "is the right edge");
        check(p.project(-30, 0, 10), "far to the side");
        near(250, p.sx, 1e-3, "beyond the right edge");
        check(!p.onScreen(0), "which is off the screen");
        p.project(-5, 0, 10);
        check(p.onScreen(0), "on the screen");
        check(!p.onScreen(80), "but not inside a big margin");
        check(!p.project(0, 0, -10), "behind is rejected");
        check(!p.project(0, 0, 0.01), "too close is rejected");
        check(!p.project(10, 0, 0), "exactly beside is rejected");

        for (float[] c : new float[][]{{0, 0, 0, 10}, {90, -10, 0, 0}, {180, 0, 0, -10}, {-90, 10, 0, 0}, {270, 10, 0, 0}}) {
            p.camera(0, 0, 0, c[0], 0, 70, 200, 100);
            check(p.project(c[1], c[2], c[3]), "facing yaw " + c[0]);
            near(100, p.sx, 1e-3, "yaw " + c[0] + ": straight ahead (x)");
            near(50, p.sy, 1e-3, "yaw " + c[0] + ": straight ahead (y)");
        }
        p.camera(0, 0, 0, 0, 45, 70, 200, 100);
        check(p.project(0, -10, 10), "looking 45 degrees down: the point below ahead");
        near(100, p.sx, 1e-3, "is in the middle (x)");
        near(50, p.sy, 1e-3, "is in the middle (y)");
        p.camera(0, 0, 0, 0, -45, 70, 200, 100);
        check(p.project(0, 10, 10), "looking 45 degrees up");
        near(50, p.sy, 1e-3, "the point above ahead is in the middle");
        p.camera(0, 0, 0, 0, 0, 90, 200, 100);
        p.project(-5, 0, 10);
        float wide = p.sx;
        p.camera(0, 0, 0, 0, 0, 45, 200, 100);
        p.project(-5, 0, 10);
        check(p.sx > wide, "a narrower field of view magnifies");
        near(0.5 * 200 * (1 + 5 / (10 * Math.tan(Math.toRadians(22.5)) * 2)), p.sx, 1e-2, "by the right amount");
        p.camera(0, 0, 0, 0, 0, 70, 0, 0);
        check(p.project(0, 0, 5), "a zero-size screen does not divide by zero");
        p.camera(3, 4, 5, 0, 0, 400, 100, 100);
        check(p.project(3, 4, 15), "an absurd field of view is limited");

        // independent derivation with cross products, random cameras and points
        Random rnd = new Random(99);
        int bad = 0;
        for (int i = 0; i < 2000; i++) {
            float yaw = (float) (rnd.nextDouble() * 360 - 180), pitch = (float) (rnd.nextDouble() * 160 - 80), fov = (float) (30 + rnd.nextDouble() * 90);
            int w = 200 + rnd.nextInt(800), h = 150 + rnd.nextInt(600);
            double cx = rnd.nextDouble() * 200 - 100, cy = rnd.nextDouble() * 200 - 100, cz = rnd.nextDouble() * 200 - 100;
            double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
            double[] f = {-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr)};
            double[] up = {0, 1, 0};
            double[] rt = cross(f, up);
            double len = Math.sqrt(rt[0] * rt[0] + rt[1] * rt[1] + rt[2] * rt[2]);
            for (int k = 0; k < 3; k++) rt[k] /= len;
            double[] u = cross(rt, f);
            double t = 1 + rnd.nextDouble() * 50, a = (rnd.nextDouble() - 0.5) * t, b = (rnd.nextDouble() - 0.5) * t * 0.6;
            double px = cx + f[0] * t + rt[0] * a + u[0] * b, py = cy + f[1] * t + rt[1] * a + u[1] * b, pz = cz + f[2] * t + rt[2] * a + u[2] * b;
            p.camera(cx, cy, cz, yaw, pitch, fov, w, h);
            if (!p.project(px, py, pz)) { bad++; continue; }
            double tan = Math.tan(Math.toRadians(fov) / 2), aspect = (double) w / h;
            double ex = (a / (t * tan * aspect) * 0.5 + 0.5) * w, ey = (0.5 - b / (t * tan) * 0.5) * h;
            if (Math.abs(ex - p.sx) > 0.01 || Math.abs(ey - p.sy) > 0.01 || Math.abs(p.depth - t) > 1e-6) bad++;
        }
        eq(0, bad, "2000 random cameras agree with an independent derivation");
    }

    private static double[] cross(double[] a, double[] b) {
        return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    // ------------------------------------------------------------------ glyphs
    private static void glyphs() {
        int bg = 0xFF000000, fg = 0xFFFFFFFF;
        RasterCanvas c = new RasterCanvas(21, 21, 1);
        c.begin(bg);
        Glyphs.diamond(c, 10, 10, 2, fg);
        for (int[] p : new int[][]{{10, 8}, {10, 12}, {8, 10}, {12, 10}, {9, 9}, {11, 11}, {10, 10}, {9, 11}, {11, 9}}) eq(fg, c.pixel(p[0], p[1]), "diamond pixel " + p[0] + "," + p[1]);
        for (int[] p : new int[][]{{8, 8}, {12, 12}, {10, 7}, {10, 13}, {7, 10}, {13, 10}, {8, 9}}) eq(bg, c.pixel(p[0], p[1]), "outside the diamond " + p[0] + "," + p[1]);

        c.begin(bg);
        Glyphs.pointer(c, 10, 10, 5, 0f, fg);
        eq(fg, c.pixel(10, 6), "pointing up: near the tip");
        eq(fg, c.pixel(10, 10), "the middle is filled");
        eq(bg, c.pixel(10, 15), "nothing far behind");
        eq(bg, c.pixel(5, 5), "nothing at the corner");
        boolean mirror = true;
        for (int y = 0; y < 21; y++) for (int x = 0; x <= 10; x++) if (c.pixel(10 - x, y) != c.pixel(10 + x, y)) mirror = false;
        check(mirror, "an arrow pointing up is left-right symmetric");
        c.begin(bg);
        Glyphs.pointer(c, 10, 10, 5, 180f, fg);
        eq(fg, c.pixel(10, 14), "pointing down: near the tip");
        eq(bg, c.pixel(10, 5), "nothing behind it");
        c.begin(bg);
        Glyphs.pointer(c, 10, 10, 5, 90f, fg);
        eq(fg, c.pixel(14, 10), "pointing right: near the tip");
        eq(bg, c.pixel(5, 10), "nothing behind it");
        boolean flip = true;
        for (int x = 0; x < 21; x++) for (int y = 0; y <= 10; y++) if (c.pixel(x, 10 - y) != c.pixel(x, 10 + y)) flip = false;
        check(flip, "an arrow pointing right is top-bottom symmetric");
        c.begin(bg);
        Glyphs.pointer(c, 10, 10, 5, 270f, fg);
        eq(fg, c.pixel(6, 10), "pointing left: near the tip");
        c.begin(bg);
        Glyphs.pointer(c, 10, 10, 5, 45f, fg);
        eq(fg, c.pixel(13, 7), "pointing up-right: along the diagonal");
        eq(bg, c.pixel(7, 13), "nothing down-left");
        // always some pixels, whatever the angle
        for (int a = -360; a <= 360; a += 7) {
            c.begin(bg);
            Glyphs.pointer(c, 10, 10, 4, a, fg);
            int filled = 0;
            for (int y = 0; y < 21; y++) for (int x = 0; x < 21; x++) if (c.pixel(x, y) == fg) filled++;
            check(filled >= 8 && filled <= 40, "angle " + a + " gives a sensible shape (" + filled + " pixels)");
        }
    }

    // ------------------------------------------------------------------ actions
    private static void actions() throws IOException {
        Rig r = new Rig();
        WaypointsModule m = r.mod;
        r.d.inWorld = false;
        eq(null, m.addHere("x"), "not in a world");
        check(m.problem().toLowerCase().contains("join"), "the player is told why: " + m.problem());
        r.d.inWorld = true;
        r.d.reducedDebug = true;
        eq(null, m.addHere("x"), "the server hides coordinates");
        check(m.problem().toLowerCase().contains("hides coordinates"), "and is told: " + m.problem());
        eq(0, r.store.count(), "nothing was saved");
        r.d.reducedDebug = false;
        r.store.setContext(null);
        eq(null, m.addHere("x"), "no world selected");
        r.store.setContext("test-world");
        r.d.x = -0.5; r.d.y = 70.9; r.d.z = 12.25;
        r.d.dimensionId = NETHER;
        Waypoint w = m.addHere("");
        check(w != null, "added with an empty name");
        eq("Waypoint 1", w.name, "named automatically");
        eq(-1, w.x, "negative coordinates round down");
        eq(70, w.y, "height rounds down");
        eq(12, w.z, "z");
        eq(NETHER, w.dimension, "in the dimension the player is in");
        eq(WaypointsModule.PALETTE[0], w.color, "first palette colour");
        eq("", m.problem(), "no problem reported");
        Waypoint w2 = m.addHere("  Mine  ");
        eq("Mine", w2.name, "names are trimmed");
        eq(WaypointsModule.PALETTE[1], w2.color, "second palette colour");
        eq("Waypoint 2", m.addHere(null).name, "null name: automatic again");
        eq(null, m.addHere("n".repeat(40)), "name too long");
        check(m.problem().contains("32"), "says the limit: " + m.problem());
        for (int i = r.store.count(); i < WaypointStore.MAX_PER_WORLD; i++) r.store.add("f" + i, i, 0, 0, OW, 0);
        eq(null, m.addHere("one more"), "world full");
        check(m.problem().contains("200"), "says the limit: " + m.problem());

        // colours cycle through the palette and wrap
        int c = WaypointsModule.PALETTE[0];
        for (int i = 1; i < WaypointsModule.PALETTE.length; i++) { c = WaypointsModule.nextColor(c); eq(WaypointsModule.PALETTE[i], c, "palette step " + i); }
        eq(WaypointsModule.PALETTE[0], WaypointsModule.nextColor(c), "wraps around");
        eq(WaypointsModule.PALETTE[0], WaypointsModule.nextColor(0xFF010203), "an unknown colour starts the cycle");
        eq(WaypointsModule.PALETTE[1], WaypointsModule.nextColor(WaypointsModule.PALETTE[0] & 0xFFFFFF), "alpha is ignored when matching");

        // deaths
        r.store.removeAllHere();
        r.d.x = 100.7; r.d.y = 12; r.d.z = -3.2;
        r.d.dimensionId = OW;
        Waypoint dth = m.onDeath();
        check(dth != null && dth.death, "a death waypoint");
        check(dth.name.matches("Death \\d\\d:\\d\\d"), "named with the time: " + dth.name);
        eq(100, dth.x, "at the death position (x)");
        eq(-4, dth.z, "at the death position (z)");
        eq(WaypointsModule.DEATH_COLOR, dth.color, "in the death colour");
        m.deathPoint.set(false);
        eq(null, m.onDeath(), "switched off");
        m.deathPoint.set(true);
        r.d.reducedDebug = true;
        eq(null, m.onDeath(), "nothing is saved while the server hides coordinates");
        r.d.reducedDebug = false;
        r.d.inWorld = false;
        eq(null, m.onDeath(), "nor outside a world");
        r.d.inWorld = true;
        m.deaths.set(2.0);
        for (int i = 0; i < 5; i++) m.onDeath();
        int n = 0;
        for (Waypoint x : r.store.list()) if (x.death) n++;
        eq(2, n, "only as many death waypoints as the setting says");

        eq("0 m", WaypointsModule.formatDistance(0.2), "distance 0");
        eq("850 m", WaypointsModule.formatDistance(850), "distance in metres");
        eq("999 m", WaypointsModule.formatDistance(999.4), "just under a kilometre");
        eq("1.0 km", WaypointsModule.formatDistance(1000), "a kilometre");
        eq("12.3 km", WaypointsModule.formatDistance(12_345), "distance in kilometres");
    }

    // ------------------------------------------------------------------ markers
    private static void markers() throws IOException {
        Rig r = new Rig();
        int green = 0xFF4ADE80;
        Waypoint ahead = r.add("Base", 0, 64, 20);
        r.marks();
        RasterCanvas.Drawn name = r.cv.find("Base"), dist = r.cv.find("20 m");
        check(name != null, "the name is drawn");
        check(dist != null, "the distance is drawn: " + r.cv.texts);
        Projector p = new Projector();
        p.camera(r.d.camX, r.d.camY, r.d.camZ, r.d.yaw, r.d.pitch, r.d.fov, r.W, r.H);
        check(p.project(ahead.x + 0.5, ahead.y + 1.0, ahead.z + 0.5), "projects");
        int px = Math.round(p.sx), py = Math.round(p.sy);
        eq(160, px, "straight ahead is the middle");
        eq(green, r.cv.pixel(px, py), "the diamond is in the waypoint colour");
        if (name != null && dist != null) {
            near(px, name.x() + name.w() / 2.0, 1.5, "the name is centred under the marker");
            near(px, dist.x() + dist.w() / 2.0, 1.5, "so is the distance");
            check(name.y() > py && dist.y() > name.y(), "name, then distance, below the diamond");
        }
        r.preview("waypoint-markers-ahead");

        // sides
        Waypoint right = r.add("Right", -10, 64, 20);
        Waypoint left = r.add("Left", 10, 64, 20);
        r.marks();
        check(r.cv.find("Right").x() > r.cv.find("Base").x() && r.cv.find("Left").x() < r.cv.find("Base").x(), "right is right, left is left");
        r.store.remove(right);
        r.store.remove(left);

        // behind, other dimension
        Waypoint behind = r.add("Behind", 0, 64, -20);
        r.marks();
        check(r.cv.find("Behind") == null, "nothing is drawn for a waypoint behind you");
        r.d.yaw = 180f;
        r.marks();
        check(r.cv.find("Behind") != null && r.cv.find("Base") == null, "turn around and it swaps");
        r.d.yaw = 0f;
        r.store.remove(behind);
        Waypoint nether = r.store.add("Portal", 0, 64, 10, NETHER, green);
        r.marks();
        check(r.cv.find("Portal") == null, "waypoints of another dimension are not shown");
        r.d.dimensionId = NETHER;
        r.marks();
        check(r.cv.find("Portal") != null && r.cv.find("Base") == null, "in that dimension they are");
        r.d.dimensionId = OW;
        r.store.remove(nether);

        // options
        r.mod.labels.set(false);
        r.marks();
        check(r.cv.find("Base") == null && r.cv.find("20 m") != null, "names off, distance stays");
        r.mod.labels.set(true);
        r.mod.distance.set(false);
        r.marks();
        check(r.cv.find("Base") != null && r.cv.find("20 m") == null, "distance off, name stays");
        r.mod.distance.set(true);
        r.mod.markers.set(false);
        r.marks();
        check(r.cv.texts.isEmpty(), "markers off: nothing");
        r.mod.markers.set(true);
        Waypoint far100 = r.add("Far", 0, 64, 100);
        Waypoint edge50 = r.add("Edge", 0, 64, 50);
        r.mod.maxDistance.set(50.0);
        r.marks();
        check(r.cv.find("Base") != null && r.cv.find("Far") == null, "beyond the hide distance: nothing");
        check(r.cv.find("Edge") != null, "exactly at the limit is still shown");
        r.mod.maxDistance.set(0.0);
        r.marks();
        check(r.cv.find("Far") != null, "no limit when set to zero");
        r.mod.maxDistance.set(10.0);
        eq(0.0, r.mod.maxDistance.v(), "the setting snaps to its 50 block steps");
        r.store.remove(far100);
        r.store.remove(edge50);
        Waypoint nearer = r.add("Nearer", 0, 64, 8);
        r.mod.maxMarkers.set(1.0);
        r.marks();
        check(r.cv.find("Nearer") != null && r.cv.find("Base") == null, "only the nearest when limited to one");
        r.mod.maxMarkers.set(10.0);
        r.marks();
        check(r.cv.find("Nearer") != null && r.cv.find("Base") != null, "both when allowed");
        r.store.setVisible(nearer, false);
        r.marks();
        check(r.cv.find("Nearer") == null, "hidden waypoints have no marker");
        r.store.remove(nearer);
        r.mod.size.set(6.0);
        r.marks();
        eq(green, r.cv.pixel(px, py), "a bigger marker is still centred");
        eq(green, r.cv.pixel(px + 5, py), "and wider");
        r.mod.size.set(3.0);

        // the server rules
        r.blocked = true;
        r.marks();
        check(r.cv.texts.isEmpty(), "markers are off where the server rules say so");
        check(r.mod.isBlockedByPolicy(), "and the module says why");
        r.blocked = false;
        r.d.reducedDebug = true;
        r.marks();
        check(r.cv.texts.isEmpty(), "markers are off while the server hides coordinates");
        r.d.reducedDebug = false;
        r.d.inWorld = false;
        r.marks();
        check(r.cv.texts.isEmpty(), "and outside a world");
        r.d.inWorld = true;
        r.mod.setEnabled(false);
        r.marks();
        check(r.cv.texts.isEmpty(), "and while the module is off");
        r.mod.setEnabled(true);

        // the label stays on the screen
        r.d.yaw = 50f;   // the waypoint is now far to the left of the view, close to the edge
        r.marks();
        RasterCanvas.Drawn edge = r.cv.find("Base");
        if (edge != null) check(edge.x() >= 2 && edge.x() + edge.w() <= r.W - 2, "a label near the edge is moved inside the screen");
        r.d.yaw = 0f;

        // many markers: the nearest ones, none overlapping the HUD crash
        r.store.removeAllHere();
        Random rnd = new Random(5);
        for (int i = 0; i < 150; i++) r.add("m" + i, rnd.nextInt(101) - 50, 64, rnd.nextInt(100) + 5);
        r.mod.maxMarkers.set(30.0);
        r.marks();
        check(r.cv.texts.size() <= 60, "at most thirty markers with two lines each (" + r.cv.texts.size() + ")");
        r.preview("waypoint-markers-many");
    }

    // ------------------------------------------------------------------ HUD list
    private static void hudList() throws IOException {
        Rig r = new Rig();
        check(!r.el.isEnabled(), "the list is off by default");
        r.el.setEnabled(true);
        r.hudFrame(false);
        check(r.cv.texts.isEmpty(), "no waypoints, nothing drawn");
        r.add("Far", 0, 64, 300);
        r.add("Mid", 0, 64, 100);
        r.add("Near", 0, 64, 20);
        r.add("East", 50, 64, 0);
        r.el.find("count").fromJson(new com.google.gson.JsonPrimitive(3));
        r.hudFrame(false);
        RasterCanvas.Drawn near = r.cv.find("Near"), mid = r.cv.find("Mid");
        check(near != null && mid != null, "the nearest are listed: " + r.cv.texts);
        check(r.cv.find("East") != null, "a waypoint 50 blocks to the side is nearer than Mid");
        check(r.cv.find("Far") == null, "and Far is left out");
        if (r.cv.find("East") != null && near != null) check(near.y() < r.cv.find("East").y() && r.cv.find("East").y() < r.cv.find("Mid").y(), "ordered by distance (Near, East, Mid)");
        check(r.cv.find("20 m") != null && r.cv.find("100 m") != null, "with distances");
        check(r.cv.find("50 m") != null, "East is 50 m away");
        // arrows: Near is straight ahead, East is on the left (facing south)
        int rowH = 10, arrowX = r.el.rx + r.el.rw - 8, row0 = r.el.ry + 3 + 4;
        eq(0xFF4ADE80, r.cv.pixel(arrowX, row0 - 3), "the arrow of the first row points up (straight ahead)");
        int row1 = row0 + rowH;
        eq(0xFF4ADE80, r.cv.pixel(arrowX - 3, row1), "East: the arrow points left (the tip side)");
        check(r.cv.pixel(arrowX + 3, row1) != 0xFF4ADE80, "and not right");
        r.preview("waypoint-list");
        r.el.find("arrows").fromJson(new com.google.gson.JsonPrimitive(false));
        r.hudFrame(false);
        int wNoArrow = r.el.rw;
        r.el.find("arrows").fromJson(new com.google.gson.JsonPrimitive(true));
        r.hudFrame(false);
        check(r.el.rw > wNoArrow, "without arrows the list is narrower");

        // turning around changes the arrows, not the order
        r.d.yaw = 90f;   // facing west: East is behind
        r.hudFrame(false);
        arrowX = r.el.rx + r.el.rw - 8;
        // the nearest is still Near; facing west, south is on your left
        row0 = r.el.ry + 3 + 4;
        eq(0xFF4ADE80, r.cv.pixel(arrowX - 3, row0), "facing west the arrow of Near (south of you) points left");
        check(r.cv.pixel(arrowX + 3, row0) != 0xFF4ADE80, "and not right");
        r.d.yaw = 0f;

        // names are shortened, not cut off
        r.store.removeAllHere();
        r.add("A very long waypoint name indeed", 0, 64, 5);
        r.hudFrame(false);
        boolean shortened = false;
        for (RasterCanvas.Drawn t : r.cv.texts) if (t.text().endsWith("...") && t.text().startsWith("A very")) shortened = true;
        check(shortened, "a long name is shortened with ...");
        r.store.removeAllHere();

        // editing shows samples
        r.hudFrame(true);
        check(r.cv.find("Home") != null && r.cv.find("Mine") != null && r.cv.find("Village") != null, "the editor shows sample rows");
        r.hudFrame(false);
        check(r.cv.texts.isEmpty(), "and the game does not");

        // rules
        r.add("Near", 0, 64, 20);
        r.hudFrame(false);
        check(r.cv.find("Near") != null, "back to normal");
        r.blocked = true;
        r.hudFrame(false);
        check(r.cv.texts.isEmpty(), "hidden where the server rules say so");
        r.blocked = false;
        r.mod.setEnabled(false);
        r.hudFrame(false);
        check(r.cv.texts.isEmpty(), "hidden while the Waypoints module is off");
        r.mod.setEnabled(true);
        r.d.reducedDebug = true;
        r.hudFrame(false);
        check(r.cv.find("Waypoints hidden by server") != null && r.cv.find("Near") == null && r.cv.find("20 m") == null, "a note instead of numbers while the server hides coordinates");
        r.d.reducedDebug = false;
        r.d.inWorld = false;
        r.hudFrame(false);
        check(r.cv.texts.isEmpty(), "nothing outside a world");
        r.d.inWorld = true;
        check(r.el.hasCommonSettings(), "has the shared position and colour settings");
    }

    // ------------------------------------------------------------------ allocation
    private static void allocation() throws IOException {
        Rig r = new Rig();
        for (int i = 0; i < 20; i++) r.add("wp" + i, i * 3 - 30, 64, 10 + i * 4);
        r.el.setEnabled(true);
        NullCanvas nc = new NullCanvas(r.W, r.H);
        for (int i = 0; i < 3000; i++) { r.mod.drawMarkers(nc, Themes.MIDNIGHT); r.hud.render(nc, r.d, Themes.MIDNIGHT, 0.016f, false); }
        com.sun.management.ThreadMXBean mx = ManagementFactory.getThreadMXBean() instanceof com.sun.management.ThreadMXBean m ? m : null;
        if (mx == null || !mx.isThreadAllocatedMemorySupported()) { System.out.println("  (allocation measurement not supported on this JVM; skipped)"); return; }
        long id = Thread.currentThread().threadId();
        int n = 6000;
        long start = mx.getThreadAllocatedBytes(id);
        for (int i = 0; i < n; i++) { r.mod.drawMarkers(nc, Themes.MIDNIGHT); r.hud.render(nc, r.d, Themes.MIDNIGHT, 0.016f, false); }
        double perFrame = (mx.getThreadAllocatedBytes(id) - start) / (double) n;
        System.out.println("  steady-state markers + list allocation: " + String.format(java.util.Locale.ROOT, "%.1f", perFrame) + " bytes per frame");
        check(perFrame < 64, "standing still allocates almost nothing (" + perFrame + " bytes/frame)");
        start = mx.getThreadAllocatedBytes(id);
        for (int i = 0; i < n; i++) {
            r.d.camX += 0.05; r.d.camZ += 0.04; r.d.yaw += 0.3f;
            r.mod.drawMarkers(nc, Themes.MIDNIGHT);
            r.hud.render(nc, r.d, Themes.MIDNIGHT, 0.016f, false);
        }
        perFrame = (mx.getThreadAllocatedBytes(id) - start) / (double) n;
        System.out.println("  while moving: " + String.format(java.util.Locale.ROOT, "%.1f", perFrame) + " bytes per frame");
        check(perFrame < 2048, "moving costs only a few small strings (" + perFrame + " bytes/frame)");
    }
}
