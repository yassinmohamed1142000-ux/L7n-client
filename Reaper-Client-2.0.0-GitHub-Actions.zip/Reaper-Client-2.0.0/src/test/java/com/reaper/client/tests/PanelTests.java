package com.reaper.client.tests;

import com.reaper.client.core.feature.Waypoint;
import com.reaper.client.core.feature.WaypointStore;
import com.reaper.client.core.feature.WaypointsModule;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.ui.UiWindow;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;

/** The extra ClickGUI windows (Waypoints, Screenshots), driven with simulated clicks and typing. */
final class PanelTests {
    private PanelTests() {}

    static void run() throws IOException {
        T.section("Panels: Waypoints window");
        waypointsPanel();
        T.section("Panels: Waypoints window inside the ClickGUI");
        waypointsInGui();
    }

    private static final String OW = "minecraft:overworld", NETHER = "minecraft:the_nether";

    private static final class WpEnv {
        final Path dir;
        final HudData d = new HudData();
        final WaypointStore store;
        final ModuleRegistry reg = new ModuleRegistry();
        final WaypointsModule mod;
        boolean blocked;

        WpEnv() throws IOException {
            dir = Files.createTempDirectory("reaper-panel-test");
            d.fillSample(1000);
            d.singleplayer = false;
            d.x = 0.5; d.y = 64; d.z = 0.5;
            d.camX = 0.5; d.camY = 64.5; d.camZ = 0.5;
            d.wallClockMs = 1_700_000_000_000L;
            store = new WaypointStore(dir.resolve("waypoints.json"));
            mod = reg.register(new WaypointsModule(store, d));
            reg.setPolicyGate(f -> !(blocked && f == Feature.WAYPOINT_MARKERS));
        }
    }

    private static void waypointsPanel() throws IOException {
        WpEnv env = new WpEnv();
        WaypointStore store = env.store;
        PanelRig rig = new PanelRig(214, 440);
        com.reaper.client.core.ui.WaypointsPanel panel = new com.reaper.client.core.ui.WaypointsPanel(env.mod, rig);
        rig.body = panel::draw;
        UiWindow win = panel.window();
        eq("Waypoints", win.title, "the window title");
        eq("waypoints", win.id, "the window id");

        rig.frames(3);
        check(rig.has("Join a world to use waypoints."), "no world yet");
        check(!rig.has("Add here"), "and no buttons");

        store.setContext("play.example.net");
        rig.frames(3);
        check(rig.has("play.example.net"), "the world is named");
        check(rig.has("No waypoints yet."), "an empty list says so");
        check(rig.has("Add here") && rig.has("Rename") && rig.has("Colour") && rig.has("Copy XYZ") && rig.has("Delete") && rig.has("Delete all"), "all the buttons are there");
        rig.preview("waypoints-panel-empty");

        // add with a blank name
        rig.clickText("Add here");
        eq(1, store.count(), "one waypoint was added");
        Waypoint first = store.list().get(0);
        eq("Waypoint 1", first.name, "named automatically");
        eq("0 64 0", first.coordinates(), "at the player's block");
        check(rig.saves >= 1, "a save was requested");
        check(rig.cv.findPrefix("Added Waypoint 1") != null, "the player is told");
        check(rig.has("Waypoint 1"), "the row is shown");
        eq(first, panel.selected(), "and selected");
        check(rig.has("0 64 0   Overworld"), "with its coordinates and dimension: " + rig.cv.texts);
        check(rig.has("0 m"), "and its distance");

        // type a name, Enter adds it
        rig.clickText("Name for Add / Rename");
        rig.type("Mine");
        check(rig.has("Mine"), "the typed name is shown in the box");
        rig.key(KeyNames.ENTER);
        rig.frames(1);   // the box is cleared after it was drawn: one more frame shows it
        eq(2, store.count(), "Enter adds the waypoint");
        eq("Mine", store.list().get(1).name, "with the typed name");
        check(rig.has("Name for Add / Rename"), "the box is empty again, showing its hint");

        // select the first one and rename it
        rig.clickText("Waypoint 1");
        eq(first, panel.selected(), "clicking a row selects it");
        rig.clickText("Name for Add / Rename");
        rig.type("House");
        rig.clickText("Rename");
        eq("House", first.name, "renamed");
        check(rig.has("House") && !rig.has("Waypoint 1"), "the list shows the new name");
        check(rig.cv.findPrefix("Renamed to House") != null, "and says so");
        rig.clickText("Rename");   // empty box
        check(rig.cv.findPrefix("Names are 1 to 32") != null, "an empty name is explained");
        eq("House", first.name, "and nothing changed");

        // colour
        int before = first.color;
        rig.clickText("Colour");
        eq(WaypointsModule.nextColor(before), first.color, "the colour moves to the next one in the palette");

        // copy
        rig.clickText("Copy XYZ");
        eq("0 64 0", rig.clipboard, "coordinates are on the clipboard");
        check(rig.toasts.stream().anyMatch(s -> s.contains("Copied 0 64 0")), "a notification confirms it");

        // visibility box
        RasterCanvas.Drawn row = rig.text("House");
        int rowTop = row.y() - 6;
        check(first.visible, "visible to begin with");
        rig.click(PanelRig.X + PanelRig.CW - 11, rowTop + 10);
        check(!first.visible, "the box hides it");
        rig.click(PanelRig.X + PanelRig.CW - 11, rowTop + 10);
        check(first.visible, "and shows it again");
        eq(first, panel.selected(), "toggling does not change the selection");

        // delete needs two clicks within three seconds
        rig.clickText("Delete");
        check(rig.has("Sure?"), "the first click asks");
        eq(2, store.count(), "nothing deleted yet");
        rig.frames(200);
        check(!rig.has("Sure?") && rig.has("Delete"), "the question times out");
        rig.clickText("Delete");
        check(rig.has("Sure?"), "asks again");
        rig.clickText("Mine");   // a different row
        check(!rig.has("Sure?"), "changing the selection cancels a pending delete");
        eq(2, store.count(), "and nothing was deleted");
        rig.clickText("Delete");
        rig.clickText("Sure?");
        eq(1, store.count(), "two clicks delete");
        check(rig.cv.findPrefix("Deleted Mine") != null, "and say what was deleted");
        eq(null, panel.selected(), "nothing is selected afterwards");
        rig.clickText("Delete");
        check(rig.cv.findPrefix("Select a waypoint in the list first.") != null, "Delete with nothing selected explains itself");
        check(!rig.has("Sure?"), "and does not ask");
        rig.clickText("Colour");
        check(rig.cv.findPrefix("Select a waypoint in the list first.") != null, "so do the other buttons");

        // other dimensions and distances
        store.add("Portal", 5, 64, 5, NETHER, 0xFFC084FC);
        store.add("Far", 0, 64, 100, OW, 0xFF60A5FA);
        rig.frames(2);
        check(rig.has("100 m"), "distance to a far waypoint");
        int meters = 0;
        for (RasterCanvas.Drawn dd : rig.cv.texts) if (dd.text().endsWith(" m")) meters++;
        eq(2, meters, "a waypoint of another dimension has no distance (House and Far have one)");
        rig.preview("waypoints-panel-list");

        // the server hides coordinates
        env.d.reducedDebug = true;
        rig.frames(2);
        check(rig.has("This server hides coordinates."), "a note about the server");
        meters = 0;
        for (RasterCanvas.Drawn dd : rig.cv.texts) if (dd.text().endsWith(" m")) meters++;
        eq(0, meters, "no distances are shown");
        rig.clickText("Add here");
        eq(3, store.count(), "nothing was added");
        check(rig.count("This server hides coordinates") >= 2, "the player is told why: " + rig.cv.texts);
        env.d.reducedDebug = false;

        env.blocked = true;
        rig.frames(2);
        check(rig.has("Markers are off by the server rules."), "a note about the rules");
        env.blocked = false;
        env.mod.setEnabled(false);
        rig.frames(2);
        check(rig.has("The Waypoints module is switched off."), "a note when the module is off");
        env.mod.setEnabled(true);
        rig.frames(2);   // the note line is gone and the buttons moved up

        // delete all
        rig.clickText("Delete all");
        check(rig.has("Sure?"), "delete all asks first");
        eq(3, store.count(), "and does nothing yet");
        rig.clickText("Sure?");
        eq(0, store.count(), "deleted");
        check(rig.cv.findPrefix("Deleted 3 waypoints") != null, "and says how many");
        check(rig.has("No waypoints yet."), "the list is empty again");

        // names longer than the box
        rig.clickText("Name for Add / Rename");
        rig.type("n".repeat(50));
        rig.key(KeyNames.ENTER);
        eq(1, store.count(), "the box limits the name to 32 characters");
        eq(32, store.list().get(0).name.length(), "exactly 32");

        // many waypoints: only the visible rows are drawn, the content still has its full height
        store.removeAllHere();
        for (int i = 0; i < 150; i++) store.add("Place " + i, i, 64, 0, OW, 0xFF4ADE80);
        rig.frames(2);
        int drawnNames = 0;
        for (RasterCanvas.Drawn dd : rig.cv.texts) if (dd.text().startsWith("Place ")) drawnNames++;
        check(drawnNames > 5 && drawnNames <= 20, "only the rows in view are drawn (" + drawnNames + ")");
        check(rig.contentH > 150 * 22, "but the window can scroll through all of them (" + rig.contentH + ")");
        rig.preview("waypoints-panel-many");
        store.removeAllHere();
    }

    private static void waypointsInGui() throws IOException {
        WpEnv env = new WpEnv();
        env.store.setContext("world");
        GuiHarness h = new GuiHarness(900, 600, false);
        UiWindow w = new com.reaper.client.core.ui.WaypointsPanel(env.mod, h).window();
        h.gui.addWindow(w);
        h.gui.onOpen();
        h.frames(3);
        check(h.gui.windows().contains(w), "the window is part of the ClickGUI");
        w.visible = true;
        w.vis.snap(1f);
        w.x = 300;
        w.y = 90;
        h.frames(10);
        check(h.has("THIS WORLD"), "it draws inside the GUI");
        h.clickText("Add here");
        eq(1, env.store.count(), "clicking works through the real GUI");
        check(h.saves > 0, "and asks for a save");
        h.preview("gui-with-waypoints");
        h.gui.requestClose();
        h.frames(30);
    }
}
