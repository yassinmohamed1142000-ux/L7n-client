package com.reaper.client.tests;

import com.reaper.client.core.feature.InventorySorter;
import com.reaper.client.core.feature.InventorySorter.Order;
import com.reaper.client.core.feature.SorterModule;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.policy.Feature;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;

/** Inventory sorting: plans are replayed on a separate model of the game's click rules and the end state is checked. */
final class SorterTests {
    private SorterTests() {}

    /** The game's PICKUP click, written out separately from the planner's own copy. */
    private static final class Ref {
        final String[] key;
        final int[] count, max;
        String curKey;
        int curCount, curMax;

        Ref(String[] k, int[] c, int[] m) { key = k.clone(); count = c.clone(); max = m.clone(); }

        void click(int i) {
            if (curKey == null) {
                if (key[i] == null) return;
                curKey = key[i]; curCount = count[i]; curMax = max[i];
                key[i] = null; count[i] = 0; max[i] = 0;
                return;
            }
            if (key[i] == null) {
                key[i] = curKey; count[i] = curCount; max[i] = curMax;
                curKey = null; curCount = 0; curMax = 0;
                return;
            }
            if (key[i].equals(curKey)) {
                int moved = Math.min(curCount, max[i] - count[i]);
                count[i] += moved;
                curCount -= moved;
                if (curCount == 0) { curKey = null; curMax = 0; }
                return;
            }
            String k = key[i]; int c = count[i], m = max[i];
            key[i] = curKey; count[i] = curCount; max[i] = curMax;
            curKey = k; curCount = c; curMax = m;
        }

        void run(int[] plan) { for (int s : plan) click(s); }

        Map<String, Integer> totals() {
            Map<String, Integer> t = new HashMap<>();
            for (int i = 0; i < key.length; i++) if (key[i] != null) t.merge(key[i], count[i], Integer::sum);
            if (curKey != null) t.merge(curKey, curCount, Integer::sum);
            return t;
        }
    }

    static void run() {
        T.section("Sorter: planner");
        cases();
        T.section("Sorter: random inventories");
        random();
        T.section("Sorter: module");
        module();
    }

    private static String[] keys(String... k) { return k; }
    private static int[] ints(int... v) { return v; }

    private static Ref play(String[] k, int[] c, int[] m, Order o) {
        Ref r = new Ref(k, c, m);
        r.run(InventorySorter.plan(k, c, m, o));
        return r;
    }

    private static String describe(Ref r) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < r.key.length; i++) sb.append(r.key[i] == null ? "_" : InventorySorter.id(r.key[i]).replace("minecraft:", "") + "x" + r.count[i]).append(' ');
        return sb.toString().trim();
    }

    private static void cases() {
        eq(0, InventorySorter.plan(new String[0], new int[0], new int[0], Order.NAME).length, "no slots, no clicks");
        eq(0, InventorySorter.plan(keys("a"), ints(1, 2), ints(64), Order.NAME).length, "mismatched arrays are refused");
        eq(0, InventorySorter.plan(keys(null, null, null), ints(0, 0, 0), ints(0, 0, 0), Order.NAME).length, "nothing to sort in empty slots");
        eq(0, InventorySorter.plan(keys("minecraft:dirt", "minecraft:stone"), ints(1, 1), ints(64, 64), Order.NAME).length, "already in order: no clicks");
        eq(0, InventorySorter.plan(keys("minecraft:dirt", "minecraft:stone", null), ints(64, 5, 0), ints(64, 64, 0), Order.NAME).length, "a tidy inventory with a gap at the end: no clicks");
        eq(0, InventorySorter.plan(keys("minecraft:dirt"), ints(3), ints(64), Order.NAME).length, "one slot");
        eq(0, InventorySorter.plan(keys("minecraft:dirt", "minecraft:dirt"), ints(64, 5), ints(64, 64), null).length, "a null order means the default and stays tidy");

        String stone = "minecraft:stone", dirt = "minecraft:dirt";
        Ref r = play(keys(stone, dirt), ints(1, 1), ints(64, 64), Order.NAME);
        eq("dirtx1 stonex1", describe(r), "two items swapped into place");
        eq(3, InventorySorter.plan(keys(stone, dirt), ints(1, 1), ints(64, 64), Order.NAME).length, "in three clicks");

        r = play(keys(stone, stone, null), ints(10, 20, 0), ints(64, 64, 0), Order.NAME);
        eq("stonex30 _ _", describe(r), "two partial stacks merge and move to the front");
        r = play(keys(stone, stone), ints(50, 40), ints(64, 64), Order.NAME);
        eq("stonex64 stonex26", describe(r), "an overflow leaves the rest in a second stack");
        r = play(keys(stone, null, stone, stone), ints(30, 0, 30, 30), ints(64, 0, 64, 64), Order.NAME);
        eq("stonex64 stonex26 _ _", describe(r), "three partial stacks make one full one and a remainder");
        r = play(keys(null, null, stone, null, stone), ints(0, 0, 64, 0, 64), ints(0, 0, 64, 0, 64), Order.NAME);
        eq("stonex64 stonex64 _ _ _", describe(r), "full stacks only move");

        // components: the same item with different data never merges
        r = play(keys("minecraft:iron_sword#a", "minecraft:iron_sword#b"), ints(1, 1), ints(1, 1), Order.NAME);
        eq("iron_swordx1 iron_swordx1", describe(r), "non-stackable items stay as they are");
        check(!r.key[0].equals(r.key[1]) && r.key[0].compareTo(r.key[1]) < 0, "ordered by their data as a last resort");
        r = play(keys("minecraft:iron_sword#b", "minecraft:iron_sword#a"), ints(1, 1), ints(1, 1), Order.NAME);
        eq("#a", r.key[0].substring(r.key[0].indexOf('#')), "the same two in the other order are swapped");
        r = play(keys("minecraft:stick#x", "minecraft:stick#y"), ints(10, 10), ints(64, 64), Order.NAME);
        eq("stickx10 stickx10", describe(r), "different data: no merge");

        // orders
        String[] k = keys("minecraft:dirt", "minecraft:iron_boots", "minecraft:apple", "minecraft:diamond_sword", "minecraft:cobblestone", "minecraft:bow");
        int[] c = ints(5, 1, 40, 1, 64, 1), m = ints(64, 1, 64, 1, 64, 1);
        eq("bowx1 diamond_swordx1 iron_bootsx1 applex40 cobblestonex64 dirtx5", describe(play(k, c, m, Order.TYPE)), "by type: tools and weapons, armour, then the rest by name");
        eq("applex40 bowx1 cobblestonex64 diamond_swordx1 dirtx5 iron_bootsx1", describe(play(k, c, m, Order.NAME)), "by name only");
        eq("cobblestonex64 applex40 dirtx5 bowx1 diamond_swordx1 iron_bootsx1", describe(play(k, c, m, Order.COUNT)), "biggest stacks first, ties by name");
        eq(0, InventorySorter.group("minecraft:netherite_pickaxe"), "pickaxe is a tool");
        eq(0, InventorySorter.group("minecraft:crossbow"), "so is a crossbow");
        eq(1, InventorySorter.group("minecraft:elytra"), "elytra count as armour");
        eq(1, InventorySorter.group("minecraft:shield"), "and a shield");
        eq(2, InventorySorter.group("minecraft:bread"), "bread is everything else");
        eq(2, InventorySorter.group("bow_and_arrow_mod"), "ids without a namespace work");
        eq("minecraft:stick", InventorySorter.id("minecraft:stick#1f2e"), "the id is the part before #");
        eq("minecraft:stick", InventorySorter.id("minecraft:stick"), "or the whole key");

        // empty-string keys and zero counts count as empty slots
        r = play(keys("", dirt, null), ints(5, 1, 3), ints(64, 64, 64), Order.NAME);
        eq("dirtx1 _ _", describe(r), "empty keys and zero counts are empty slots");
    }

    private static final String[] POOL = {"minecraft:stone", "minecraft:dirt", "minecraft:cobblestone", "minecraft:apple", "minecraft:oak_log",
            "minecraft:iron_sword#a", "minecraft:iron_sword#b", "minecraft:diamond_pickaxe#x", "minecraft:iron_helmet#h", "minecraft:ender_pearl",
            "minecraft:egg", "minecraft:potion#p1", "minecraft:potion#p2", "minecraft:arrow"};

    private static int maxOf(String key) {
        String id = InventorySorter.id(key);
        if (InventorySorter.group(id) < 2 || id.endsWith("potion")) return 1;
        return id.endsWith("ender_pearl") || id.endsWith("egg") ? 16 : 64;
    }

    private static void random() {
        Random rnd = new Random(20261114);
        int[] sizes = {1, 2, 5, 9, 18, 27, 36, 54};
        int bad = 0, total = 0, longest = 0, maxRatio100 = 0;
        for (int trial = 0; trial < 3000; trial++) {
            int n = sizes[rnd.nextInt(sizes.length)];
            int pool = 1 + rnd.nextInt(POOL.length);
            double fill = rnd.nextDouble();
            String[] k = new String[n];
            int[] c = new int[n], m = new int[n];
            for (int i = 0; i < n; i++) {
                if (rnd.nextDouble() > fill) continue;
                String key = POOL[rnd.nextInt(pool)];
                k[i] = key;
                m[i] = maxOf(key);
                c[i] = 1 + rnd.nextInt(m[i]);
                if (rnd.nextInt(4) == 0) c[i] = m[i];   // plenty of full stacks
            }
            Order order = Order.values()[rnd.nextInt(3)];
            Ref start = new Ref(k, c, m);
            int[] plan = InventorySorter.plan(k, c, m, order);
            Ref r = new Ref(k, c, m);
            boolean inRange = true;
            for (int s : plan) if (s < 0 || s >= n) inRange = false;
            if (!inRange) { bad++; System.out.println("  out-of-range click in trial " + trial); continue; }
            r.run(plan);
            String problem = verify(start, r, order, plan.length, n);
            // sorting again changes nothing
            int[] again = InventorySorter.plan(r.key, r.count, r.max, order);
            if (problem == null && again.length != 0) problem = "a second plan was not empty (" + again.length + " clicks)";
            if (problem != null) { if (bad++ < 5) System.out.println("  trial " + trial + " (" + order + ", " + n + " slots): " + problem + "\n    before: " + describe(start) + "\n    after:  " + describe(r)); }
            total += plan.length;
            longest = Math.max(longest, plan.length);
            if (n > 0) maxRatio100 = Math.max(maxRatio100, plan.length * 100 / n);
        }
        eq(0, bad, "3000 random inventories end up tidy, in order, with every item still there");
        System.out.println("  clicks: " + total + " in total, longest plan " + longest + ", at most " + (maxRatio100 / 100.0) + " clicks per slot");
        check(longest <= 200, "even a full double chest of scattered stacks needs at most 200 clicks (longest seen: " + longest + ")");
    }

    /** Null when the end state is right, otherwise a description of what is wrong. */
    private static String verify(Ref before, Ref after, Order order, int clicks, int n) {
        if (after.curKey != null) return "the cursor still holds " + after.curKey;
        if (!before.totals().equals(after.totals())) return "item totals changed: " + before.totals() + " -> " + after.totals();
        boolean gap = false;
        for (int i = 0; i < n; i++) {
            if (after.key[i] == null) gap = true;
            else if (gap) return "an item after a gap at slot " + i;
        }
        Map<String, Integer> partials = new HashMap<>();
        for (int i = 0; i < n; i++) if (after.key[i] != null && after.count[i] < after.max[i]) partials.merge(after.key[i], 1, Integer::sum);
        for (Map.Entry<String, Integer> e : partials.entrySet()) if (e.getValue() > 1) return "item " + e.getKey() + " still has " + e.getValue() + " partial stacks";
        for (int i = 0; i + 1 < n; i++) {
            if (after.key[i] == null || after.key[i + 1] == null) continue;
            if (compare(order, after.key[i], after.count[i], after.key[i + 1], after.count[i + 1]) > 0) return "slots " + i + " and " + (i + 1) + " are out of order";
        }
        if (clicks > 6 * n + 6) return "too many clicks: " + clicks;
        return null;
    }

    private static int compare(Order o, String ka, int ca, String kb, int cb) {
        String ia = InventorySorter.id(ka), ib = InventorySorter.id(kb);
        if (o == Order.COUNT) {
            if (ca != cb) return Integer.compare(cb, ca);
            int r = ia.compareTo(ib);
            return r != 0 ? r : ka.compareTo(kb);
        }
        if (o == Order.TYPE) {
            int r = Integer.compare(InventorySorter.group(ia), InventorySorter.group(ib));
            if (r != 0) return r;
        }
        int r = ia.compareTo(ib);
        if (r != 0) return r;
        r = ka.compareTo(kb);
        return r != 0 ? r : Integer.compare(cb, ca);
    }

    private static void module() {
        ModuleRegistry reg = new ModuleRegistry();
        SorterModule s = reg.register(new SorterModule());
        boolean[] allowed = {true};
        reg.setPolicyGate(f -> f != Feature.INVENTORY_SORT || allowed[0]);
        eq(Feature.INVENTORY_SORT, s.feature(), "sorting follows the server rules");
        check(s.isEnabled() && s.showButtons(), "on by default, with buttons");
        String[] k = {"minecraft:stone", "minecraft:dirt", null, "minecraft:stone"};
        int[] c = {10, 5, 0, 10}, m = {64, 64, 0, 64};
        int planned = s.begin(k, c, m);
        check(planned > 0, "a plan was made (" + planned + " clicks)");
        eq(planned, s.total(), "total matches");
        check(s.running(), "running");
        // the replay through the module hands out one click per tick by default
        Ref r = new Ref(k, c, m);
        int[] buf = new int[4];
        int ticks = 0;
        while (s.running() && ticks < 100) {
            int n = s.next(buf);
            eq(1, n, "one click per tick by default");
            for (int i = 0; i < n; i++) r.click(buf[i]);
            ticks++;
        }
        eq(planned, ticks, "one tick per click");
        check(!s.running(), "finished");
        eq("dirtx5 stonex20 _ _", describe(r), "and the result is tidy");
        eq(0, s.next(buf), "nothing more to hand out");

        s.speed.set(3.0);
        s.begin(k, c, m);
        eq(Math.min(3, planned), s.next(buf), "three clicks per tick when asked");
        eq(planned - Math.min(3, planned), s.remaining(), "the rest is still waiting");
        s.cancel();
        check(!s.running() && s.remaining() == 0, "cancelled");
        s.speed.set(4.0);
        s.begin(k, c, m);
        eq(Math.min(2, planned), s.next(new int[2]), "never more than the buffer holds");
        s.cancel();

        eq(0, s.begin(new String[]{"minecraft:dirt", "minecraft:stone"}, new int[]{1, 1}, new int[]{64, 64}), "already tidy: zero clicks");
        check(!s.running(), "so nothing runs");

        s.order.set(Order.COUNT);
        s.begin(new String[]{"minecraft:dirt", "minecraft:stone"}, new int[]{1, 9}, new int[]{64, 64});
        check(s.running(), "the order setting is used (biggest first needs a swap)");
        s.cancel();

        // the server rules and the module switch stop a running sort at once
        s.begin(k, c, m);
        allowed[0] = false;
        check(!s.showButtons(), "buttons disappear when the rules forbid sorting");
        eq(0, s.next(buf), "a running sort stops when the rules forbid it");
        check(!s.running(), "and is dropped");
        eq(-1, s.begin(k, c, m), "no new sort can start");
        allowed[0] = true;
        s.setEnabled(false);
        eq(-1, s.begin(k, c, m), "nor while the module is off");
        s.setEnabled(true);
        s.buttons.set(false);
        check(!s.showButtons() && s.begin(k, c, m) > 0, "the buttons can be hidden without disabling sorting");
    }
}
