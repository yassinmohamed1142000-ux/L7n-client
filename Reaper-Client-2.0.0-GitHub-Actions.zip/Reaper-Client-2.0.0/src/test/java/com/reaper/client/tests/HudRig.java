package com.reaper.client.tests;

import com.reaper.client.core.hud.Hud;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.hud.elements.HudElements;
import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.theme.Themes;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/** A HUD with every element, a registry with a few ordinary modules, fake game data and a software canvas. */
final class HudRig {
    final ModuleRegistry reg = new ModuleRegistry();
    final Hud hud = new Hud(reg);
    final HudData d = new HudData();
    final Map<String, HudElement> el = new LinkedHashMap<>();
    final RasterCanvas cv;
    final int W, H;
    long now = 1_000_000;
    Theme theme = Themes.MIDNIGHT;
    boolean editing;
    /** Feature the fake server policy currently blocks, or null. */
    Feature blocked;

    Module fullbright, zoom, waypoints, chat;

    HudRig(int w, int h) { this(w, h, 2); }

    HudRig(int w, int h, int pixelScale) {
        W = w;
        H = h;
        cv = new RasterCanvas(w, h, pixelScale);
        for (HudElement e : HudElements.create()) {
            reg.register(e);
            hud.add(e);
            el.put(e.id, e);
        }
        fullbright = reg.register(new Module("fullbright", "Fullbright", "Brightens dark areas.", Category.VISUAL).feature(Feature.FULLBRIGHT));
        zoom = reg.register(new Module("zoom", "Zoom", "Hold a key to zoom.", Category.VISUAL).feature(Feature.ZOOM));
        waypoints = reg.register(new Module("waypoints", "Waypoints", "Named places.", Category.UTILITY).feature(Feature.WAYPOINT_MARKERS));
        chat = reg.register(new Module("chat", "Chat Tools", "Timestamps and mentions.", Category.UTILITY));
        reg.setPolicyGate(f -> f != blocked);
        hud.notifications.setGate(el.get("notifications")::isEnabled);
        d.fillSample(now);
        d.screenW = w;
        d.screenH = h;
        d.wallClockMs = 1_700_000_000_000L;
    }

    @SuppressWarnings("unchecked")
    <T extends HudElement> T get(String id) { return (T) el.get(id); }

    void enableAll() { for (HudElement e : el.values()) e.setEnabled(true); }

    void only(String... ids) {
        for (HudElement e : el.values()) e.setEnabled(false);
        for (String id : ids) el.get(id).setEnabled(true);
    }

    void frame() { frame(1f / 60f); }

    void frame(float dt) {
        now += Math.max(1, Math.round(dt * 1000f));
        d.nowMs = now;
        hud.update(d);
        cv.begin(0xFF000000);
        cv.gradientV(0, 0, W, H * 2 / 3, 0xFF6FA8DC, 0xFFBFD9EE);
        cv.gradientV(0, H * 2 / 3, W, H - H * 2 / 3, 0xFF4F7A3A, 0xFF2F4A24);
        hud.render(cv, d, theme, dt, editing);
    }

    void frames(int n) { for (int i = 0; i < n; i++) frame(); }

    boolean has(String s) { return cv.find(s) != null; }

    RasterCanvas.Drawn text(String s) {
        RasterCanvas.Drawn t = cv.find(s);
        if (t == null) throw new AssertionError("text not drawn: \"" + s + "\"");
        return t;
    }

    /** Any drawn text starting with the prefix, or null. */
    RasterCanvas.Drawn prefix(String p) { return cv.findPrefix(p); }

    void preview(String name) {
        String dir = System.getProperty("reaper.preview.dir");
        if (dir == null || dir.isEmpty()) return;
        try { cv.save(new File(dir, name + ".png")); }
        catch (IOException ex) { System.out.println("  (could not save preview " + name + ": " + ex.getMessage() + ")"); }
    }
}
