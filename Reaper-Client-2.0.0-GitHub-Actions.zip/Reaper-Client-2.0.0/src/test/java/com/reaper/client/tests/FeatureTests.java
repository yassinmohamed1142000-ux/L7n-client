package com.reaper.client.tests;

import com.reaper.client.core.feature.CrosshairModule;
import com.reaper.client.core.feature.FullbrightModule;
import com.reaper.client.core.feature.GammaController;
import com.reaper.client.core.feature.ZoomModule;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.policy.Feature;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;
import static com.reaper.client.tests.T.near;

/** Crosshair drawing, zoom behaviour and the brightness controller. */
final class FeatureTests {
    private FeatureTests() {}

    private static final int BG = 0xFF336699, WHITE = 0xFFFFFFFF, BLACK = 0xFF000000;

    static void run() {
        T.section("Crosshair");
        crosshair();
        T.section("Zoom");
        zoom();
        T.section("Fullbright");
        fullbright();
    }

    private static RasterCanvas draw(CrosshairModule m, double speed) {
        RasterCanvas cv = new RasterCanvas(41, 41, 1);
        cv.begin(BG);
        m.draw(cv, 20, 20, speed);
        return cv;
    }

    private static void crosshair() {
        CrosshairModule m = new CrosshairModule();
        RasterCanvas cv = draw(m, 0);
        eq(BG, cv.pixel(20, 20), "the centre stays empty");
        for (int y = 11; y < 17; y++) eq(WHITE, cv.pixel(20, y), "upper arm pixel y=" + y);
        eq(BLACK, cv.pixel(20, 17), "the outline hugs the inner end of the upper arm");
        eq(BLACK, cv.pixel(20, 23), "the outline hugs the inner end of the lower arm");
        for (int y = 18; y < 20; y++) eq(BG, cv.pixel(20, y), "gap above the centre y=" + y);
        for (int y = 21; y < 23; y++) eq(BG, cv.pixel(20, y), "gap below the centre y=" + y);
        for (int y = 24; y < 30; y++) eq(WHITE, cv.pixel(20, y), "lower arm pixel y=" + y);
        for (int x = 11; x < 17; x++) eq(WHITE, cv.pixel(x, 20), "left arm pixel x=" + x);
        for (int x = 24; x < 30; x++) eq(WHITE, cv.pixel(x, 20), "right arm pixel x=" + x);
        eq(BLACK, cv.pixel(20, 10), "outline beyond the tip");
        eq(BLACK, cv.pixel(19, 13), "outline beside the arm");
        eq(BLACK, cv.pixel(21, 13), "outline on the other side");
        eq(BG, cv.pixel(20, 9), "nothing beyond the outline");
        // mirror symmetry about the centre pixel for every style (odd sizes; an even-sized dot always extends right/down)
        m.dot.set(3.0);
        for (CrosshairModule.Style st : CrosshairModule.Style.values()) {
            m.style.set(st);
            m.thickness.set(3.0);
            cv = draw(m, 0);
            boolean sym = true;
            for (int dy = 0; dy <= 14 && sym; dy++) for (int dx = 0; dx <= 14; dx++) {
                int p = cv.pixel(20 + dx, 20 + dy);
                if (p != cv.pixel(20 - dx, 20 + dy) || p != cv.pixel(20 + dx, 20 - dy)) { sym = false; break; }
            }
            check(sym, "the " + st + " crosshair is symmetric (thickness 3)");
        }
        m.style.set(CrosshairModule.Style.CROSS);
        m.thickness.set(3.0);
        cv = draw(m, 0);
        for (int x = 19; x <= 21; x++) eq(WHITE, cv.pixel(x, 13), "thick arm is centred at x=" + x);
        eq(BLACK, cv.pixel(18, 13), "outline of the thick arm");
        m.thickness.set(1.0);
        m.outline.set(false);
        cv = draw(m, 0);
        boolean anyBlack = false;
        for (int y = 0; y < 41; y++) for (int x = 0; x < 41; x++) if (cv.pixel(x, y) == BLACK) anyBlack = true;
        check(!anyBlack, "no outline when switched off");
        m.outline.set(true);
        m.color.set(0xFFFF0000);
        cv = draw(m, 0);
        eq(0xFFFF0000, cv.pixel(20, 13), "colour setting is used");
        m.color.set(0xFFFFFFFF);
        // dynamic gap
        m.dynamic.set(true);
        cv = draw(m, 10);
        eq(BG, cv.pixel(20, 15), "the gap is wider while moving");
        eq(WHITE, cv.pixel(20, 11), "the arm moved outwards");
        cv = draw(m, 0);
        eq(WHITE, cv.pixel(20, 15), "back to the normal gap when still");
        m.dynamic.set(false);

        m.style.set(CrosshairModule.Style.DOT);
        m.dot.set(2.0);
        cv = draw(m, 0);
        for (int[] p : new int[][]{{20, 20}, {21, 20}, {20, 21}, {21, 21}}) eq(WHITE, cv.pixel(p[0], p[1]), "dot pixel " + p[0] + "," + p[1]);
        eq(BG, cv.pixel(20, 15), "a dot has no arms");
        m.dot.set(5.0);
        cv = draw(m, 0);
        for (int y = 18; y <= 22; y++) for (int x = 18; x <= 22; x++) eq(WHITE, cv.pixel(x, y), "5px dot is centred");
        m.style.set(CrosshairModule.Style.CROSS_DOT);
        m.dot.set(2.0);
        cv = draw(m, 0);
        eq(WHITE, cv.pixel(20, 20), "cross with dot has a centre");
        eq(WHITE, cv.pixel(20, 13), "and arms");

        m.style.set(CrosshairModule.Style.CIRCLE);
        m.size.set(6.0);
        m.thickness.set(1.0);
        cv = draw(m, 0);
        eq(BG, cv.pixel(20, 20), "the ring is hollow");
        eq(WHITE, cv.pixel(26, 20), "ring at radius 6 (right)");
        eq(WHITE, cv.pixel(14, 20), "ring at radius 6 (left)");
        eq(WHITE, cv.pixel(20, 26), "ring at radius 6 (bottom)");
        eq(WHITE, cv.pixel(24, 25), "ring on a diagonal");
        eq(BG, cv.pixel(23, 20), "inside the ring");
        eq(BLACK, cv.pixel(27, 20), "outer outline");
        eq(BLACK, cv.pixel(25, 20), "inner outline");
        m.size.set(30.0);
        m.thickness.set(6.0);
        cv = draw(m, 0);   // bigger than the canvas: must not crash and must stay in order
        check(true, "a ring larger than the canvas draws without trouble");

        // visibility of settings follows the style
        m.style.set(CrosshairModule.Style.DOT);
        check(!m.size.isVisible() && !m.thickness.isVisible() && !m.gap.isVisible() && m.dot.isVisible(), "a dot hides the arm settings");
        m.style.set(CrosshairModule.Style.CROSS);
        check(m.size.isVisible() && m.gap.isVisible() && !m.dot.isVisible(), "a cross shows them");
        m.outline.set(false);
        check(!m.outlineColor.isVisible(), "no outline colour without an outline");
    }

    private static void zoom() {
        ModuleRegistry reg = new ModuleRegistry();
        ZoomModule z = reg.register(new ZoomModule());
        boolean[] allowed = {true};
        reg.setPolicyGate(f -> f != Feature.ZOOM || allowed[0]);
        check(z.isEnabled(), "zoom is on by default");
        eq(Feature.ZOOM, z.feature(), "zoom is a server-rule controlled feature");
        z.update(1f / 60f);
        eq(1f, z.zoom(), "no zoom without the key");
        near(70, z.fov(70), 1e-9, "no zoom: the field of view is unchanged");
        z.setHeld(true);
        z.update(1f / 60f);
        check(z.zoom() > 1f && z.zoom() < 4f, "the first frame moves partway (" + z.zoom() + ")");
        check(z.zooming(), "zooming");
        float prev = z.zoom();
        for (int i = 0; i < 20; i++) { z.update(1f / 60f); check(z.zoom() >= prev, "zoom never goes backwards while held"); prev = z.zoom(); }
        for (int i = 0; i < 120; i++) z.update(1f / 60f);
        eq(4f, z.zoom(), "ends exactly at the factor");
        near(Math.toDegrees(2 * Math.atan(Math.tan(Math.toRadians(35)) / 4)), z.fov(70), 1e-4, "field of view for 4x (true magnification)");
        check(z.fov(70) < 70 && z.fov(70) > 70.0 / 4 - 0.5 || z.fov(70) > 70.0 / 4 - 5, "a sensible narrower angle");
        check(z.cinematicWanted(), "steadier camera while zoomed");
        z.cinematic.set(false);
        check(!z.cinematicWanted(), "unless turned off");
        z.cinematic.set(true);
        z.setHeld(false);
        for (int i = 0; i < 200; i++) z.update(1f / 60f);
        eq(1f, z.zoom(), "back to normal after release");
        check(!z.cinematicWanted(), "no steady camera when not zoomed");

        z.smooth.set(false);
        z.setHeld(true);
        z.update(1f / 60f);
        eq(4f, z.zoom(), "no smoothing: instant");
        z.setHeld(false);
        z.update(1f / 60f);
        eq(1f, z.zoom(), "no smoothing: instant release");
        z.smooth.set(true);

        // scroll
        z.setHeld(true);
        for (int i = 0; i < 200; i++) z.update(1f / 60f);
        check(z.onScroll(1), "the wheel is used while zooming");
        eq(4.5, z.factor.v(), "one notch adds 0.5 at 4x");
        z.factor.set(20.0);
        z.onScroll(1);
        eq(22.0, z.factor.v(), "bigger steps at high zoom");
        for (int i = 0; i < 20; i++) z.onScroll(1);
        eq(30.0, z.factor.v(), "stops at the maximum");
        for (int i = 0; i < 80; i++) z.onScroll(-1);
        eq(1.5, z.factor.v(), "stops at the minimum");
        z.scroll.set(false);
        check(!z.onScroll(1), "the wheel is left alone when scrolling is off");
        z.scroll.set(true);
        z.setHeld(false);
        check(!z.onScroll(1), "the wheel is left alone when not zooming");
        check(!z.onScroll(0), "zero movement is ignored");

        // server rules
        z.factor.set(4.0);
        z.setHeld(true);
        allowed[0] = false;
        check(z.isBlockedByPolicy(), "blocked by the rules");
        check(!z.wantsZoom(), "no zoom when the rules forbid it");
        for (int i = 0; i < 200; i++) z.update(1f / 60f);
        eq(1f, z.zoom(), "zoom fades out when the rules forbid it");
        check(!z.onScroll(1), "no scrolling then");
        allowed[0] = true;
        z.update(1f / 60f);
        check(z.zoom() > 1f, "zoom works again when allowed");
        z.reset();
        eq(1f, z.zoom(), "reset clears the zoom");
        check(!z.held(), "and the key");
        // a huge frame time cannot overshoot
        z.setHeld(true);
        z.update(100f);
        check(z.zoom() <= 4f + 1e-3f && z.zoom() > 1f, "a very long frame does not overshoot (" + z.zoom() + ")");
        z.setEnabled(false);
        check(!z.wantsZoom(), "a disabled module does not zoom");
    }

    private static void fullbright() {
        GammaController g = new GammaController();
        eq(Double.NaN, g.tick(false, 0.5, 12), "nothing to do while off");
        eq(12.0, g.tick(true, 0.5, 12), "turning on writes the level");
        check(g.applied(), "applied");
        eq(0.5, g.saved(), "the player's own value is remembered");
        eq(Double.NaN, g.tick(true, 12, 12), "steady while on");
        eq(0.5, g.tick(false, 12, 12), "turning off restores the player's value");
        check(!g.applied(), "no longer applied");
        eq(Double.NaN, g.tick(false, 0.5, 12), "and then nothing more");

        // the player moves the slider while it is on: that value comes back later
        eq(12.0, g.tick(true, 0.5, 12), "on again");
        eq(12.0, g.tick(true, 0.8, 12), "the override is re-applied over a slider change");
        eq(0.8, g.saved(), "but the new slider value is what we go back to");
        eq(0.8, g.tick(false, 12, 12), "restored to the newest value");

        // changing the level while on
        g.tick(true, 1.0, 12);
        eq(15.0, g.tick(true, 12, 15), "a new level is written");
        eq(1.0, g.saved(), "without touching the saved value");
        eq(1.0, g.restore(), "shutdown restores the player's value");
        check(!g.applied(), "and clears the state");
        check(Double.isNaN(g.restore()), "a second restore does nothing");
        check(Double.isNaN(g.restore()), "restore without an override does nothing");

        // module and server rules
        ModuleRegistry reg = new ModuleRegistry();
        FullbrightModule f = reg.register(new FullbrightModule());
        boolean[] allowed = {true};
        reg.setPolicyGate(feat -> feat != Feature.FULLBRIGHT || allowed[0]);
        eq(Double.NaN, f.tick(0.5), "off by default: nothing happens");
        f.setEnabled(true);
        eq(12.0, f.tick(0.5), "enabled: writes the level");
        allowed[0] = false;
        eq(0.5, f.tick(12.0), "the server rules switch it off and the value comes back");
        allowed[0] = true;
        eq(12.0, f.tick(0.5), "and on again when allowed");
        f.setEnabled(false);
        eq(0.5, f.tick(12.0), "disabling restores");
        eq(Feature.FULLBRIGHT, f.feature(), "fullbright is a server-rule controlled feature");
    }
}
