package com.reaper.client.tests;

import com.reaper.client.core.feature.ScreenshotLibrary;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.inventory.SortLayout;
import com.reaper.client.core.screenshot.ThumbPool;
import com.reaper.client.core.util.FailureGuard;
import com.reaper.client.core.util.FrameClock;
import com.reaper.client.core.util.ScreenRouter;
import com.reaper.client.core.ui.Input;
import com.reaper.client.core.ui.ScreenshotBrowser;
import com.reaper.client.core.ui.TextField;
import com.reaper.client.core.ui.Thumbnails;
import com.reaper.client.core.ui.Ui;
import com.reaper.client.core.util.GameNames;

/** The small pieces of logic the Minecraft layer relies on, kept out of the game so they can be tested here. */
public final class AdapterLogicTests {
    private AdapterLogicTests() {}

    private static final long MS = 1_000_000L;

    public static void run() {
        frameClock();
        names();
        layouts();
        pool();
        clipboards();
        router();
        guard();
        shotNames();
    }

    // ------------------------------------------------------------------ screen router
    private static void router() {
        T.section("Adapter: screen router");
        ScreenRouter<String> r = new ScreenRouter<>();
        ScreenRouter.Outcome<String> o = r.next(false);
        T.check(!o.change(), "nothing requested: nothing happens");
        T.check(!r.hasRequest(), "and no request is pending");

        r.show(() -> "menu");
        T.check(r.hasRequest(), "a request is pending");
        o = r.next(false);
        T.check(o.change() && "menu".equals(o.screen()), "the requested screen is shown");
        T.check(!r.next(false).change(), "and the request is used up");

        // closing a screen of ours with no menu to return to
        r.close();
        o = r.next(true);
        T.check(o.change() && o.screen() == null, "close with a Reaper screen open: no screen");

        // closing must never close somebody else's screen
        r.close();
        o = r.next(false);
        T.check(!o.change(), "close while a game screen is open leaves it alone");

        // a screen opened from the menu goes back to the menu
        r.showFromMenu(() -> "editor", () -> "menu");
        o = r.next(true);
        T.check(o.change() && "editor".equals(o.screen()), "the editor opens from the menu");
        r.close();
        o = r.next(true);
        T.check(o.change() && "menu".equals(o.screen()), "closing the editor returns to the menu");
        r.close();
        o = r.next(true);
        T.check(o.change() && o.screen() == null, "closing the menu itself closes everything");

        // a plain show forgets an earlier return target
        r.showFromMenu(() -> "shots", () -> "menu");
        r.next(true);
        r.show(() -> "other");
        r.next(true);
        r.close();
        o = r.next(true);
        T.check(o.change() && o.screen() == null, "a plain show does not inherit the old return target");

        // the last request in a tick wins
        r.show(() -> "a");
        r.show(() -> "b");
        o = r.next(true);
        T.eq("b", o.screen(), "two requests in one tick: the last one wins");
        r.show(() -> "c");
        r.close();
        o = r.next(true);
        T.check(o.change() && o.screen() == null, "a close after a show wins");
        r.close();
        r.show(() -> "d");
        T.eq("d", r.next(false).screen(), "a show after a close wins");

        // show(null) is a close
        r.show(null);
        o = r.next(true);
        T.check(o.change() && o.screen() == null, "show(null) closes");

        // a failing screen constructor does not leave a stuck request
        r.show(() -> { throw new IllegalStateException("boom"); });
        T.throwsEx(() -> r.next(false), "the failure reaches the caller");
        T.check(!r.hasRequest(), "but the request is gone, so the next tick is clean");

        r.showFromMenu(() -> "x", () -> "m");
        r.clear();
        T.check(!r.hasRequest() && !r.next(true).change(), "clear drops a pending request");
        r.showFromMenu(() -> "x", () -> "m");
        r.next(true);
        r.clear();
        r.close();
        o = r.next(true);
        T.check(o.screen() == null, "clear also forgets the return target");
    }

    // ------------------------------------------------------------------ failure guard
    private static void guard() {
        T.section("Adapter: failure guard");
        FailureGuard g = new FailureGuard(3);
        T.check(!g.tripped(), "starts untripped");
        T.check(!g.failed() && !g.failed(), "two failures in a row are tolerated");
        g.ok();
        T.check(!g.failed() && !g.failed(), "a good frame resets the count");
        T.check(g.failed(), "the third failure in a row trips it");
        T.check(g.tripped(), "which stays");
        T.check(!g.failed(), "and is reported only once");
        g.ok();
        T.check(g.tripped(), "good frames do not undo a trip");
        g.reset();
        T.check(!g.tripped() && !g.failed(), "reset starts over");
        T.check(new FailureGuard(0).failed(), "a limit below one still trips at the first failure");
    }

    // ------------------------------------------------------------------ screenshot messages
    private static void shotNames() {
        T.section("Adapter: screenshot file names in chat lines");
        T.eq("2026-11-14_09.05.31.png", ScreenshotLibrary.vanillaFileName("Saved screenshot as 2026-11-14_09.05.31.png"), "English line");
        T.eq("2026-11-14_09.05.31_1.png", ScreenshotLibrary.vanillaFileName("Screenshot gespeichert: 2026-11-14_09.05.31_1.png"), "German-style line with a counter");
        T.eq("2026-11-14_09.05.31.png", ScreenshotLibrary.vanillaFileName("スクリーンショットを 2026-11-14_09.05.31.png として保存しました"), "other language");
        T.eq(null, ScreenshotLibrary.vanillaFileName("Saved screenshot as holiday.png"), "a renamed file is not a vanilla name");
        T.eq(null, ScreenshotLibrary.vanillaFileName("x2026-11-14_09.05.31.png"), "glued to other characters: no");
        T.eq(null, ScreenshotLibrary.vanillaFileName("2026-11-14_09.05.31.png.exe"), "with an extension after it: no");
        T.eq(null, ScreenshotLibrary.vanillaFileName("hello"), "ordinary chat");
        T.eq(null, ScreenshotLibrary.vanillaFileName(null), "null");
        T.eq(null, ScreenshotLibrary.vanillaFileName("a".repeat(400) + " 2026-11-14_09.05.31.png"), "very long lines are ignored");
        T.eq("2026-11-14_09.05.32.png", ScreenshotLibrary.vanillaFileName("2026-11-14_09.05.31.png then 2026-11-14_09.05.32.png"), "the last name in a line wins");
        T.eq("2026-11-14_09.05.31.png", ScreenshotLibrary.vanillaFileName("../2026-11-14_09.05.31.png/x"), "only the bare name is returned, never the path around it");
    }

    // ------------------------------------------------------------------ frame clock
    private static void frameClock() {
        T.section("Adapter: frame clock");
        FrameClock c = new FrameClock();
        T.eq(0, c.fps(), "no frames yet: 0 fps");
        T.near(0, c.dt(), 1e-9, "no frames yet: dt 0");

        long t = 5_000_000_000L;
        c.frame(t);
        T.near(0, c.dt(), 1e-9, "first frame has no dt");
        // 60 frames per second for 3 seconds
        for (int i = 1; i <= 180; i++) { t += 1_000_000_000L / 60; c.frame(t); }
        T.check(Math.abs(c.fps() - 60) <= 1, "steady 60 fps is reported as about 60, got " + c.fps());
        T.near(16.67, c.frameMs(), 0.2, "frame time of 60 fps");
        T.near(1 / 60.0, c.dt(), 1e-4, "dt is one frame");

        // slow down to 20 fps
        for (int i = 0; i < 60; i++) { t += 50 * MS; c.frame(t); }
        T.check(Math.abs(c.fps() - 20) <= 1, "20 fps after the slowdown, got " + c.fps());
        T.near(0.05, c.dt(), 1e-4, "dt follows");

        // a 5 second stall (loading screen) must not become the frame time, and dt is limited
        t += 5_000_000_000L;
        c.frame(t);
        T.near(0.1, c.dt(), 1e-6, "dt is capped at 0.1 s");
        T.check(c.frameMs() < 100, "a stall does not pollute the frame time: " + c.frameMs());
        for (int i = 0; i < 100; i++) { t += 10 * MS; c.frame(t); }
        T.check(Math.abs(c.fps() - 100) <= 2, "recovers to 100 fps, got " + c.fps());

        // a clock that goes backwards
        c.frame(t - 1_000 * MS);
        T.check(c.dt() >= 0 && c.dt() <= 0.1f, "backwards clock gives a sane dt");
        T.check(c.fps() >= 0, "backwards clock gives a sane fps");

        // early estimate before one second has passed
        FrameClock e = new FrameClock();
        long u = 1_000_000_000L;
        for (int i = 0; i < 10; i++) { u += 8 * MS; e.frame(u); }
        T.check(Math.abs(e.fps() - 125) <= 3, "estimate from the frame time before the first second: " + e.fps());

        c.reset();
        T.eq(0, c.fps(), "reset clears the fps");
    }

    // ------------------------------------------------------------------ names
    private static void names() {
        T.section("Adapter: game names");
        T.eq("Old Growth Pine Taiga", GameNames.pretty("minecraft:old_growth_pine_taiga"), "vanilla biome");
        T.eq("Plains", GameNames.pretty("minecraft:plains"), "single word");
        T.eq("Plains", GameNames.pretty("plains"), "no namespace");
        T.eq("Cherry Grove", GameNames.pretty("  minecraft:cherry_grove  "), "spaces stripped");
        T.eq("Frozen Peaks (somemod)", GameNames.pretty("somemod:frozen_peaks"), "other namespace is kept");
        T.eq("Deep Dark", GameNames.pretty("minecraft:worldgen/biome/deep_dark"), "path segments");
        T.eq("", GameNames.pretty(null), "null");
        T.eq("", GameNames.pretty(""), "empty");
        T.eq("", GameNames.pretty("   "), "blank");
        T.eq("A B", GameNames.pretty("minecraft:a__b"), "double underscore");
        String longName = GameNames.pretty("minecraft:" + "very_long_".repeat(10));
        T.check(longName.length() <= 40 && longName.endsWith("..."), "long names are cut: " + longName.length());
        T.eq("", GameNames.pretty("MOD:"), "an id without a path gives nothing");

        T.eq(HudData.Dimension.OVERWORLD, HudData.Dimension.fromId("minecraft:overworld"), "overworld");
        T.eq(HudData.Dimension.NETHER, HudData.Dimension.fromId("minecraft:the_nether"), "nether");
        T.eq(HudData.Dimension.END, HudData.Dimension.fromId("minecraft:the_end"), "end");
        T.eq(HudData.Dimension.OTHER, HudData.Dimension.fromId("mod:dream"), "modded dimension");
        T.eq(HudData.Dimension.OTHER, HudData.Dimension.fromId(null), "null dimension");
    }

    // ------------------------------------------------------------------ sort layouts
    private static void layouts() {
        T.section("Adapter: sort layouts");
        int[] inv = SortLayout.inventoryScreen(false);
        T.eq(27, inv.length, "inventory storage has 27 slots");
        T.eq(9, inv[0], "starts at slot 9");
        T.eq(35, inv[26], "ends at slot 35");
        int[] invHot = SortLayout.inventoryScreen(true);
        T.eq(36, invHot.length, "with the hotbar 36 slots");
        T.eq(44, invHot[35], "hotbar ends at 44");

        int[] chest = SortLayout.container(3);
        T.eq(27, chest.length, "a 3 row chest");
        T.eq(0, chest[0], "chest starts at 0");
        T.eq(26, chest[26], "chest ends at 26");
        T.eq(54, SortLayout.container(6).length, "a double chest has 54");
        T.eq(54, SortLayout.container(9).length, "rows are limited to 6");
        T.eq(9, SortLayout.container(0).length, "and to at least 1");

        int[] mine = SortLayout.playerInContainer(3, false);
        T.eq(27, mine.length, "player storage under a chest");
        T.eq(27, mine[0], "after a 3 row chest it starts at 27");
        T.eq(53, mine[26], "and ends at 53");
        int[] mineHot = SortLayout.playerInContainer(6, true);
        T.eq(36, mineHot.length, "with the hotbar");
        T.eq(54, mineHot[0], "after a double chest it starts at 54");
        T.eq(89, mineHot[35], "and ends at 89");

        T.check(SortLayout.fits(inv, 46), "the inventory block fits the 46-slot player menu");
        T.check(!SortLayout.fits(invHot, 40), "a menu that is too small is refused");
        T.check(!SortLayout.fits(new int[0], 46), "an empty block is refused");
        T.check(!SortLayout.fits(null, 46), "null is refused");
        T.check(!SortLayout.fits(new int[]{-1, 2}, 46), "a negative slot is refused");
        T.check(SortLayout.fits(mineHot, 90), "double chest menu has 90 slots");

        // the blocks never overlap
        boolean overlap = false;
        for (int a : chest) for (int b : mine) if (a == b) overlap = true;
        T.check(!overlap, "container and player blocks do not overlap");
    }

    // ------------------------------------------------------------------ thumbnail pool
    private static void pool() {
        T.section("Adapter: thumbnail pool");
        T.throwsEx(() -> new ThumbPool(0), "a pool needs at least one slot");

        ThumbPool p = new ThumbPool(3);
        Object a = new Object(), b = new Object(), c = new Object(), d = new Object();
        p.beginFrame();
        T.eq(-1, p.find(a), "nothing found before claiming");
        int sa = p.claim(a), sb = p.claim(b), sc = p.claim(c);
        T.check(sa >= 0 && sb >= 0 && sc >= 0 && sa != sb && sb != sc && sa != sc, "three distinct slots");
        T.eq(-1, p.claim(d), "full pool: the fourth waits");
        T.eq(3, p.count(ThumbPool.State.LOADING), "all loading");

        T.check(p.markReady(sa, p.generation(sa)), "result for the current generation is accepted");
        T.eq(ThumbPool.State.READY, p.state(sa), "slot is ready");
        T.check(!p.markReady(sa, p.generation(sa)), "a second result for the same slot is refused");
        T.check(!p.markReady(sb, p.generation(sb) - 1), "a stale generation is refused");
        T.check(p.markFailed(sb, p.generation(sb)), "a failure is recorded");
        T.eq(ThumbPool.State.FAILED, p.state(sb), "slot is failed");
        T.eq(sb, p.find(b), "a failed owner is still found, so it is not retried every frame");

        // the next frame: a, b used; c not asked for
        p.beginFrame();
        T.eq(sa, p.find(a), "a is found");
        T.eq(sb, p.find(b), "b is found");
        T.eq(-1, p.claim(d), "c was drawn last frame, so it is still protected");
        p.beginFrame();
        p.find(a);
        p.find(b);
        int sd = p.claim(d);
        T.eq(sc, sd, "c was not drawn for two frames: its slot goes to d");
        T.eq(ThumbPool.State.LOADING, p.state(sd), "the reused slot starts loading again");
        T.eq(-1, p.find(c), "c lost its slot");
        T.check(!p.markReady(sc, p.generation(sc) - 1), "the old load of c for that slot is refused");
        T.check(p.markReady(sd, p.generation(sd)), "d's load is accepted");

        // clear
        int genBefore = p.generation(sa);
        p.clear();
        T.eq(0, p.count(ThumbPool.State.READY) + p.count(ThumbPool.State.LOADING) + p.count(ThumbPool.State.FAILED), "clear frees everything");
        T.check(p.generation(sa) > genBefore, "clear invalidates results still on their way");
        T.eq(-1, p.find(a), "owners are forgotten");
        T.check(!p.markReady(sa, genBefore), "a late result after clear is refused");
        p.beginFrame();
        int again = p.claim(a);
        T.check(again >= 0, "slots can be claimed again after clear");

        // heavy use never exceeds the pool
        ThumbPool big = new ThumbPool(32);
        Object[] items = new Object[300];
        for (int i = 0; i < items.length; i++) items[i] = new Object();
        int maxLoaded = 0;
        for (int frame = 0; frame < 400; frame++) {
            big.beginFrame();
            int start = (frame * 7) % 270;
            for (int i = start; i < start + 24; i++) {
                int s = big.find(items[i]);
                if (s < 0) {
                    s = big.claim(items[i]);
                    if (s >= 0) big.markReady(s, big.generation(s));
                }
            }
            maxLoaded = Math.max(maxLoaded, big.count(ThumbPool.State.READY) + big.count(ThumbPool.State.LOADING));
        }
        T.check(maxLoaded <= 32, "a 300-item scroll never holds more than 32 slots: " + maxLoaded);
        T.check(maxLoaded >= 24, "and it does keep the visible ones: " + maxLoaded);
    }

    // ------------------------------------------------------------------ clipboard
    private static void clipboards() {
        T.section("Adapter: clipboard defaults");
        Ui ui = new Ui(new Input());
        T.check(ui.clipboard != null, "a Ui has a clipboard before the game layer provides one");
        ui.clipboard.set("hello");
        T.eq("hello", ui.clipboard.get(), "which keeps what was copied");
        ui.clipboard.set(null);
        T.eq("", ui.clipboard.get(), "and treats null as empty");

        ScreenshotBrowser browser = new ScreenshotBrowser(new ScreenshotLibrary(java.nio.file.Path.of("no-such-folder")),
                new Thumbnails() {
                    @Override public Thumb get(ScreenshotLibrary.Entry entry) { return null; }
                    @Override public void release() { }
                }, new ScreenshotBrowser.Host() {
                    @Override public void openFolder(java.nio.file.Path dir) { }
                    @Override public void toast(com.reaper.client.core.notify.Level level, String message) { }
                    @Override public void close() { }
                });
        T.check(browser.ui.clipboard != null, "the screenshot manager can copy a path even before a system clipboard is attached");
        TextField.Clipboard custom = new TextField.Clipboard() {
            @Override public String get() { return "x"; }
            @Override public void set(String s) { }
        };
        browser.ui.clipboard = custom;
        T.check(browser.ui.clipboard == custom, "and the game layer can replace it");
    }
}
