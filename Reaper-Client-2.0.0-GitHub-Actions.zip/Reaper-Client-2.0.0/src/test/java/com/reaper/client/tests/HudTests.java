package com.reaper.client.tests;

import com.google.gson.JsonObject;
import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.ClickCounter;
import com.reaper.client.core.hud.Compass;
import com.reaper.client.core.hud.Hud;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.hud.HudFormat;
import com.reaper.client.core.hud.HudLayout;
import com.reaper.client.core.hud.HudState;
import com.reaper.client.core.hud.elements.ArmorElement;
import com.reaper.client.core.hud.elements.CoordinatesElement;
import com.reaper.client.core.hud.elements.CpsElement;
import com.reaper.client.core.hud.elements.DirectionElement;
import com.reaper.client.core.hud.elements.DurabilityElement;
import com.reaper.client.core.hud.elements.FpsElement;
import com.reaper.client.core.hud.elements.HudElements;
import com.reaper.client.core.hud.elements.KeystrokesElement;
import com.reaper.client.core.hud.elements.LineElement;
import com.reaper.client.core.hud.elements.ModuleListElement;
import com.reaper.client.core.hud.elements.PingElement;
import com.reaper.client.core.hud.elements.SprintElement;
import com.reaper.client.core.hud.elements.WorldInfoElement;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.notify.NotificationCenter;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.theme.Themes;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import static com.reaper.client.tests.T.check;
import static com.reaper.client.tests.T.eq;
import static com.reaper.client.tests.T.near;

/** Tests of the HUD: maths, every element's output, placement, allocation and the default layout. */
final class HudTests {
    private HudTests() {}

    static void run() throws IOException {
        T.section("HUD: compass and formatting");
        compassAndFormat();
        T.section("HUD: click counter and speed");
        clickCounterAndSpeed();
        T.section("HUD: layout maths");
        layoutMaths();
        T.section("HUD: notification centre");
        notificationCentre();
        T.section("HUD: elements as modules");
        elementsAsModules();
        T.section("HUD: placement and scaling");
        placement();
        T.section("HUD: simple text elements");
        textElements();
        T.section("HUD: coordinates and world info");
        coordinatesAndWorld();
        T.section("HUD: direction");
        direction();
        T.section("HUD: armor and durability");
        armorAndDurability();
        T.section("HUD: keystrokes");
        keystrokes();
        T.section("HUD: module list");
        moduleList();
        T.section("HUD: notification element");
        notificationElement();
        T.section("HUD: default layout");
        defaultLayout();
        T.section("HUD: allocation");
        allocation();
        T.section("HUD: previews");
        previews();
    }

    // ------------------------------------------------------------------ maths
    private static void compassAndFormat() {
        near(180, Compass.bearing(0), 1e-4, "yaw 0 faces south");
        near(0, Compass.bearing(180), 1e-4, "yaw 180 faces north");
        near(0, Compass.bearing(-180), 1e-4, "yaw -180 faces north");
        near(90, Compass.bearing(-90), 1e-4, "yaw -90 faces east");
        near(270, Compass.bearing(90), 1e-4, "yaw 90 faces west");
        near(0, Compass.bearing(540), 1e-4, "yaw wraps");
        near(90, Compass.bearing(-450), 1e-4, "negative yaw wraps");
        float[] yaws = {0, 45, 90, 135, 180, -135, -90, -45};
        String[] names = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        for (int i = 0; i < yaws.length; i++) eq(names[i], Compass.SHORT[Compass.index(Compass.bearing(yaws[i]))], "direction for yaw " + yaws[i]);
        eq("N", Compass.SHORT[Compass.index(359.9f)], "359.9 degrees is still north");
        eq("N", Compass.SHORT[Compass.index(-0.1f)], "-0.1 degrees is north");
        eq("+Z", Compass.AXIS[Compass.index(Compass.bearing(0))], "south is +Z");
        eq("-X", Compass.AXIS[Compass.index(Compass.bearing(90))], "west is -X");
        near(0, Compass.bearingTo(0, -10), 1e-3, "north offset");
        near(90, Compass.bearingTo(10, 0), 1e-3, "east offset");
        near(180, Compass.bearingTo(0, 10), 1e-3, "south offset");
        near(270, Compass.bearingTo(-10, 0), 1e-3, "west offset");
        near(90, Compass.relative(90, 0), 1e-4, "target on the right");
        near(-90, Compass.relative(0, 90), 1e-4, "target on the left");
        near(-20, Compass.relative(350, 10), 1e-4, "wraps across north (left)");
        near(20, Compass.relative(10, 350), 1e-4, "wraps across north (right)");
        near(180, Compass.relative(180, 0), 1e-4, "directly behind is +180, not -180");

        eq("06:00", HudFormat.gameClock(0), "sunrise");
        eq("12:00", HudFormat.gameClock(6000), "noon");
        eq("18:00", HudFormat.gameClock(12000), "sunset");
        eq("00:00", HudFormat.gameClock(18000), "midnight");
        eq("06:30", HudFormat.gameClock(500), "half an hour after sunrise");
        eq("05:59", HudFormat.gameClock(23999), "last tick of the day");
        eq("06:00", HudFormat.gameClock(24000), "wraps to the next day");
        eq("--:--", HudFormat.gameClock(-1), "unknown time");
        eq(0, HudFormat.minuteOfDay(0, 0), "epoch");
        eq(61, HudFormat.minuteOfDay(61 * 60_000L, 0), "one hour one minute");
        eq(121, HudFormat.minuteOfDay(61 * 60_000L, 3_600_000), "zone offset");
        eq(1439, HudFormat.minuteOfDay(-60_000L, 0), "before the epoch wraps backwards");
        eq("01:01", HudFormat.clock(61), "clock text");
        eq("23:59", HudFormat.clock(-1), "negative minutes wrap");
        near(10, HudFormat.convert(80, HudData.Dimension.OVERWORLD), 1e-9, "Overworld to Nether divides");
        near(80, HudFormat.convert(10, HudData.Dimension.NETHER), 1e-9, "Nether to Overworld multiplies");
        near(5, HudFormat.convert(5, HudData.Dimension.END), 1e-9, "the End has no relation");
        eq("7", HudFormat.small(7), "small ints");
        eq("1234", HudFormat.small(1234), "large ints still work");
    }

    private static void clickCounterAndSpeed() {
        ClickCounter cc = new ClickCounter(3);
        long t = 10_000;
        check(cc.poll(0, true, t), "first press is counted");
        check(!cc.poll(0, true, t + 16), "holding is not a new click");
        check(!cc.poll(0, false, t + 32), "release is not a click");
        check(cc.poll(0, true, t + 100), "press again");
        eq(2, cc.cps(0, t + 100), "two clicks in the last second");
        eq(2, cc.cps(0, t + 1000), "still inside the window");
        eq(1, cc.cps(0, t + 1050), "the first click aged out");
        eq(0, cc.cps(0, t + 1200), "all aged out");
        eq(0, cc.cps(1, t), "other buttons are independent");
        for (int i = 0; i < 100; i++) cc.click(1, t + i * 5L);
        eq(64, cc.cps(1, t + 500), "the ring buffer caps at 64");
        cc.reset();
        eq(0, cc.cps(1, t + 500), "reset clears");

        HudState st = new HudState();
        HudData d = new HudData();
        d.inWorld = true;
        long now = 1000;
        d.nowMs = now;
        st.update(d);
        eq(0.0, d.speed, "no speed on the first frame");
        for (int i = 0; i < 120; i++) { now += 16; d.nowMs = now; d.x += 4.3 * 0.016; st.update(d); }
        near(4.3, d.speed, 0.15, "walking speed settles near 4.3 blocks/s");
        now += 16; d.nowMs = now; d.x += 5000; st.update(d);
        check(d.speed < 4.5, "a teleport does not show up as speed (" + d.speed + ")");
        for (int i = 0; i < 120; i++) { now += 16; d.nowMs = now; st.update(d); }
        near(0, d.speed, 0.05, "standing still decays to zero");
        d.inWorld = false; d.speed = 3;
        st.update(d);
        eq(0.0, d.speed, "no speed outside a world");
        // clicks are fed from the mouse buttons
        d.inWorld = true;
        d.keys[HudData.M_LEFT] = true; now += 16; d.nowMs = now; st.update(d);
        d.keys[HudData.M_LEFT] = false; now += 16; d.nowMs = now; st.update(d);
        d.keys[HudData.M_LEFT] = true; now += 16; d.nowMs = now; st.update(d);
        eq(2, st.clicks.cps(0, now), "state counts button presses");
    }

    private static void layoutMaths() {
        int sw = 427, sh = 240, w = 40, h = 15;
        for (Anchor a : Anchor.values()) {
            int ox = HudLayout.offsetX(a, HudLayout.x(a, 9, w, sw), w, sw);
            int oy = HudLayout.offsetY(a, HudLayout.y(a, 11, h, sh), h, sh);
            eq(9, ox, "x offset round trip for " + a);
            eq(11, oy, "y offset round trip for " + a);
        }
        eq(4, HudLayout.x(Anchor.TOP_LEFT, 4, w, sw), "left anchor");
        eq(sw - w - 4, HudLayout.x(Anchor.TOP_RIGHT, 4, w, sw), "right anchor");
        eq((sw - w) / 2, HudLayout.x(Anchor.CENTER, 0, w, sw), "centre anchor");
        eq(sh - h - 6, HudLayout.y(Anchor.BOTTOM_CENTER, 6, h, sh), "bottom anchor");
        eq(Anchor.TOP_LEFT, HudLayout.nearestAnchor(5, 5, w, h, sw, sh), "top-left corner");
        eq(Anchor.BOTTOM_RIGHT, HudLayout.nearestAnchor(sw - w, sh - h, w, h, sw, sh), "bottom-right corner");
        eq(Anchor.CENTER, HudLayout.nearestAnchor((sw - w) / 2, (sh - h) / 2, w, h, sw, sh), "centre");
        eq(Anchor.TOP_CENTER, HudLayout.nearestAnchor((sw - w) / 2, 2, w, h, sw, sh), "top centre");

        HudRig rig = new HudRig(sw, sh);
        HudElement e = rig.get("fps");
        e.rw = w; e.rh = h;
        HudLayout.moveTo(e, 5, 7, sw, sh);
        eq(Anchor.TOP_LEFT, e.anchor.v(), "dragged to the top-left");
        eq(5, e.offsetX.i(), "x offset after the drag");
        eq(7, e.offsetY.i(), "y offset after the drag");
        HudLayout.moveTo(e, 5000, 5000, sw, sh);
        eq(Anchor.BOTTOM_RIGHT, e.anchor.v(), "dragged far off screen lands in the corner");
        eq(sw - w, HudLayout.x(e.anchor.v(), e.offsetX.i(), w, sw), "clamped to the right edge");
        eq(sh - h, HudLayout.y(e.anchor.v(), e.offsetY.i(), h, sh), "clamped to the bottom edge");
        HudLayout.moveTo(e, -50, -50, sw, sh);
        eq(0, HudLayout.x(e.anchor.v(), e.offsetX.i(), w, sw), "clamped to the left edge");
        HudLayout.moveTo(e, (sw - w) / 2, (sh - h) / 2, sw, sh);
        eq(Anchor.CENTER, e.anchor.v(), "dragged to the middle");
        eq(0, e.offsetX.i(), "centred without offset");
        e.resetPosition();
        eq(e.defaultAnchor, e.anchor.v(), "reset position restores the anchor");
        eq(e.defaultOffsetX, e.offsetX.i(), "reset position restores the offset");

        int[] edges = {100, 150};
        eq(21, HudLayout.snap(21, 20, 400, edges, 1, 4, 6), "nothing close: unchanged");
        eq(4, HudLayout.snap(6, 20, 400, edges, 1, 4, 6), "snaps to the margin");
        eq(100, HudLayout.snap(98, 20, 400, edges, 1, 4, 6), "snaps to another element's start");
        eq(376, HudLayout.snap(378, 20, 400, edges, 1, 4, 6), "snaps to the far margin");
        eq(383, HudLayout.snap(383, 20, 400, edges, 1, 4, 6), "too far to snap");
        eq(190, HudLayout.snap(188, 20, 400, edges, 1, 4, 6), "snaps to the centre");
        eq(152, HudLayout.snap(150, 20, 400, edges, 1, 4, 6), "sits just after another element");
        eq(130, HudLayout.snap(131, 20, 400, edges, 1, 4, 6), "aligns end edges");
    }

    private static void notificationCentre() {
        NotificationCenter nc = new NotificationCenter();
        check(nc.push(Level.INFO, "Hello"), "push works");
        eq(1, nc.count(), "one toast");
        eq("Hello", nc.get(0).shown, "text");
        check(nc.push(Level.INFO, "Hello"), "identical message");
        eq(1, nc.count(), "identical messages merge");
        eq(2, nc.get(0).repeats, "repeat count");
        eq("Hello (x2)", nc.get(0).shown, "repeat marker");
        nc.push(Level.WARN, "Hello");
        eq(2, nc.count(), "same text with another level is a different toast");
        nc.clear();
        for (int i = 0; i < 8; i++) nc.push(Level.INFO, "m" + i);
        eq(NotificationCenter.MAX_VISIBLE, nc.count(), "capped at the maximum");
        eq("m2", nc.get(0).message, "the oldest were dropped");
        eq("m7", nc.get(nc.count() - 1).message, "the newest is last");
        nc.clear();
        nc.push(Level.INFO, "later");
        for (int i = 0; i < 20; i++) nc.update(0.25f);
        eq(0, nc.count(), "toasts expire (" + nc.count() + " left)");
        nc.push(Level.INFO, "long pause");
        nc.update(60f);
        eq(1, nc.count(), "one huge frame does not skip the whole display time");
        nc.clear();
        check(!nc.push(Level.INFO, null), "null message ignored");
        check(!nc.push(Level.INFO, "  \n\t "), "blank message ignored");
        nc.setGate(() -> false);
        check(!nc.push(Level.INFO, "nope"), "gate closed");
        eq(0, nc.count(), "nothing shown while the gate is closed");
        nc.setGate(null);
        nc.push(Level.INFO, "a\n\tb   c\u0007d");
        eq("a b c d", nc.get(0).message, "whitespace collapsed, control characters become spaces");
        nc.clear();
        nc.push(Level.INFO, "x".repeat(500));
        eq(NotificationCenter.MAX_LENGTH, nc.get(0).message.length(), "long messages are cut");
        nc.clear();
        nc.push(Level.INFO, "y".repeat(NotificationCenter.MAX_LENGTH - 1) + "😀");
        check(!Character.isHighSurrogate(nc.get(0).message.charAt(nc.get(0).message.length() - 1)), "a surrogate pair is never cut in half");
        nc.clear();
        nc.push(Level.INFO, "fade");
        NotificationCenter.Toast t = nc.get(0);
        near(0, t.appear(), 1e-6, "invisible at the start");
        t.age = 1f;
        near(1, t.appear(), 1e-6, "fully visible in the middle");
        t.age = t.life - 0.05f;
        check(t.appear() < 1f && t.appear() > 0f, "fading out at the end");
    }

    // ------------------------------------------------------------------ elements
    private static void elementsAsModules() {
        List<HudElement> all = HudElements.create();
        Set<String> ids = new HashSet<>(), names = new HashSet<>();
        for (HudElement e : all) {
            check(ids.add(e.id), "unique id " + e.id);
            check(names.add(e.name), "unique name " + e.name);
            check(e.hasCommonSettings(), e.id + " has the shared position and style settings");
            eq(com.reaper.client.core.module.Category.HUD, e.category, e.id + " is in the HUD category");
            check(e.toggleable, e.id + " can be switched");
            check(e.find("scale") != null && e.find("anchor") != null && e.find("offsetX") != null && e.find("offsetY") != null, e.id + " has anchor, offsets and scale");
            check(e.find("resetPosition") != null, e.id + " has a reset button");
        }
        eq(12, all.size(), "twelve HUD elements");
        Set<String> on = new HashSet<>();
        for (HudElement e : all) if (e.isEnabled()) on.add(e.id);
        eq(Set.of("fps", "coordinates", "direction", "armor", "notifications"), on, "the default HUD is small and tidy");

        // every element survives a save and a load with its position and style
        List<HudElement> a = HudElements.create(), b = HudElements.create();
        for (int i = 0; i < a.size(); i++) {
            HudElement x = a.get(i), y = b.get(i);
            x.scale.set(1.5);
            x.anchor.set(Anchor.BOTTOM_LEFT);
            x.offsetX.set(33.0);
            x.offsetY.set(44.0);
            x.color.set(0xFF123456);
            x.shadow.set(false);
            x.background.set(!x.background.on());
            x.setEnabled(!x.isEnabled());
            JsonObject j = x.toJson();
            y.fromJson(j);
            eq(1.5, y.scale.v(), x.id + " scale persists");
            eq(Anchor.BOTTOM_LEFT, y.anchor.v(), x.id + " anchor persists");
            eq(33, y.offsetX.i(), x.id + " x offset persists");
            eq(44, y.offsetY.i(), x.id + " y offset persists");
            eq(0xFF123456, y.color.argb(), x.id + " colour persists");
            eq(x.isEnabled(), y.isEnabled(), x.id + " enabled state persists");
            check(j.get("settings").getAsJsonObject().get("resetPosition") == null, x.id + " does not save the button");
        }
        // a hand-edited file cannot break an element
        HudElement e = HudElements.create().get(0);
        JsonObject bad = new JsonObject();
        JsonObject s = new JsonObject();
        s.addProperty("scale", 9999);
        s.addProperty("anchor", "SOMEWHERE");
        s.addProperty("offsetX", "far");
        s.addProperty("color", "zzz");
        bad.add("settings", s);
        e.fromJson(bad);
        eq(3.0, e.scale.v(), "scale is clamped");
        eq(e.defaultAnchor, e.anchor.v(), "unknown anchor falls back");
        eq(e.defaultOffsetX, e.offsetX.i(), "wrong type falls back to the default");
    }

    private static void placement() {
        HudRig rig = new HudRig(427, 240);
        rig.only("fps");
        rig.frame();
        RasterCanvas.Drawn t = rig.text("FPS: 144");
        eq(7, t.x(), "text sits one padding inside a top-left element");
        eq(7, t.y(), "...vertically too");
        FpsElement fps = rig.get("fps");
        eq(4, fps.rx, "element x");
        eq(4, fps.ry, "element y");
        check(fps.rw > 0 && fps.rh > 0, "size recorded");
        fps.scale.set(2.0);
        rig.frame();
        t = rig.text("FPS: 144");
        eq(10, t.x(), "scaled text moves with the scale (4 + 3 * 2)");
        eq(4 + (fps.rh == 0 ? 0 : 0) , fps.ry, "scaling keeps the corner fixed");
        fps.scale.reset();
        fps.anchor.set(Anchor.BOTTOM_RIGHT);
        fps.offsetX.set(10.0);
        fps.offsetY.set(20.0);
        rig.frame();
        eq(427 - 10, fps.rx + fps.rw, "right edge at the screen edge minus the offset");
        eq(240 - 20, fps.ry + fps.rh, "bottom edge at the screen edge minus the offset");
        fps.anchor.set(Anchor.CENTER);
        fps.offsetX.set(0.0);
        fps.offsetY.set(0.0);
        rig.frame();
        eq((427 - fps.rw) / 2, fps.rx, "centred horizontally");
        eq((240 - fps.rh) / 2, fps.ry, "centred vertically");
        check(rig.hud.at(fps.rx + 1, fps.ry + 1) == fps, "hit testing finds the element");
        check(rig.hud.at(1, 1) == null, "empty space hits nothing");
        fps.setEnabled(false);
        rig.frame();
        eq(0, fps.rw, "a disabled element has no size");
        check(!rig.has("FPS: 144"), "and is not drawn");
        check(rig.hud.at(213, 120) == null, "and cannot be hit");
        // an element whose module is blocked by server rules is skipped too (the fake policy blocks FULLBRIGHT, which no HUD element uses)
        fps.setEnabled(true);
        fps.scale.set(0.5);
        rig.frame();
        check(fps.rw < 40, "half size is smaller");
        // an element can be switched on by a hold key without losing its position
        fps.scale.reset();
        fps.anchor.set(Anchor.TOP_LEFT);
        fps.offsetX.set(4.0);
        fps.offsetY.set(4.0);
        // two elements: the later one is on top for hit testing
        rig.get("cps").setEnabled(true);
        rig.get("cps").anchor.set(Anchor.TOP_LEFT);
        rig.get("cps").offsetX.set(4.0);
        rig.get("cps").offsetY.set(4.0);
        rig.frame();
        check(rig.hud.at(8, 8) == rig.get("cps"), "overlapping elements: the one drawn last is on top");
    }

    private static void textElements() {
        HudRig rig = new HudRig(427, 240);
        // FPS
        rig.only("fps");
        FpsElement fps = rig.get("fps");
        rig.frame();
        check(rig.has("FPS: 144"), "FPS text");
        fps.find("label").fromJson(new com.google.gson.JsonPrimitive(false));
        rig.frame();
        check(rig.has("144"), "FPS without the label");
        fps.find("label").fromJson(new com.google.gson.JsonPrimitive(true));
        fps.find("frameTime").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.frame();
        check(rig.has("FPS: 144 (6.9 ms)"), "FPS with frame time");
        fps.find("frameTime").fromJson(new com.google.gson.JsonPrimitive(false));
        fps.find("colorize").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.d.fps = 144; rig.frame();
        eq(Themes.MIDNIGHT.good(), fps.currentTextColor(), "smooth is green");
        rig.d.fps = 45; rig.frame();
        eq(Themes.MIDNIGHT.warn(), fps.currentTextColor(), "so-so is yellow");
        rig.d.fps = 12; rig.frame();
        eq(Themes.MIDNIGHT.bad(), fps.currentTextColor(), "slow is red");
        check(rig.has("FPS: 12"), "text follows the value");
        rig.d.fps = 0; rig.frame();
        check(rig.has("FPS: 0"), "zero fps is shown");
        rig.d.fps = -5; rig.frame();
        check(rig.has("FPS: 0"), "a negative value is shown as zero");
        check(!fps.find("color").isVisible(), "the text colour setting hides while colouring by performance");

        // CPS
        rig.only("cps");
        CpsElement cps = rig.get("cps");
        rig.d.keys[HudData.M_LEFT] = false;
        rig.frame();
        rig.hud.state.clicks.reset();
        for (int i = 0; i < 7; i++) rig.hud.state.clicks.click(0, rig.now - 10 * i);
        for (int i = 0; i < 3; i++) rig.hud.state.clicks.click(1, rig.now - 10 * i);
        rig.frame();
        check(rig.has("CPS: 7 | 3"), "both buttons");
        cps.find("mode").fromJson(new com.google.gson.JsonPrimitive("LEFT"));
        rig.frame();
        check(rig.has("CPS: 7"), "left only");
        cps.find("mode").fromJson(new com.google.gson.JsonPrimitive("RIGHT"));
        rig.frame();
        check(rig.has("CPS: 3"), "right only");
        rig.frames(80);
        cps.find("mode").fromJson(new com.google.gson.JsonPrimitive("BOTH"));
        rig.frame();
        check(rig.has("CPS: 0 | 0"), "clicks age out after a second");

        // Ping
        rig.only("ping");
        PingElement ping = rig.get("ping");
        rig.frame();
        check(!rig.has("Ping: 38 ms"), "no ping in singleplayer");
        rig.d.singleplayer = false;
        rig.frame();
        check(rig.has("Ping: 38 ms"), "ping on a server");
        eq(Themes.MIDNIGHT.good(), ping.currentTextColor(), "low ping is green");
        rig.d.ping = 100; rig.frame();
        eq(Themes.MIDNIGHT.warn(), ping.currentTextColor(), "medium ping is yellow");
        rig.d.ping = 300; rig.frame();
        eq(Themes.MIDNIGHT.bad(), ping.currentTextColor(), "high ping is red");
        rig.d.ping = -1; rig.frame();
        check(!rig.has("Ping: -- ms") && rig.cv.findPrefix("Ping") == null, "an unknown ping is hidden");
        rig.editing = true; rig.frame();
        check(rig.has("Ping: --"), "the editor shows a placeholder");
        rig.editing = false;
        rig.d.ping = 20; rig.d.inWorld = false; rig.frame();
        check(rig.cv.findPrefix("Ping") == null, "no ping outside a world");
        rig.d.inWorld = true;

        // Sprint
        rig.only("sprint");
        SprintElement spr = rig.get("sprint");
        rig.d.sprinting = false; rig.frame();
        check(rig.cv.texts.isEmpty(), "nothing to say while walking");
        rig.d.sprinting = true; rig.frame();
        check(rig.has("Sprinting"), "sprinting");
        rig.d.sneaking = true; rig.frame();
        check(rig.has("Sneaking"), "sneaking wins over sprinting");
        rig.d.flying = true; rig.frame();
        check(rig.has("Flying"), "flying wins over sneaking");
        rig.d.swimming = true; rig.d.flying = false; rig.d.sneaking = false; rig.frame();
        check(rig.has("Swimming"), "swimming");
        rig.d.gliding = true; rig.frame();
        check(rig.has("Gliding"), "gliding wins over swimming");
        rig.d.gliding = false; rig.d.swimming = false; rig.d.crawling = true; rig.frame();
        check(rig.has("Crawling"), "crawling");
        rig.d.crawling = false; rig.d.sprinting = false;
        spr.find("showWalking").fromJson(new com.google.gson.JsonPrimitive(true)); rig.frame();
        check(rig.has("Walking"), "walking when asked for");
        eq("Sprinting", SprintElement.state(sampleSprint(), false), "state helper");
        rig.d.inWorld = false; rig.frame();
        check(rig.cv.texts.isEmpty(), "nothing outside a world");
        rig.d.inWorld = true;
    }

    private static HudData sampleSprint() { HudData d = new HudData(); d.sprinting = true; return d; }

    private static void coordinatesAndWorld() {
        HudRig rig = new HudRig(427, 240);
        rig.only("coordinates");
        CoordinatesElement co = rig.get("coordinates");
        rig.frame();
        check(rig.has("X: 128.5") && rig.has("Y: 72.0") && rig.has("Z: -301.3"), "three lines with one decimal");
        check(rig.has("Nether: 16 / 72 / -38"), "Nether conversion divides X and Z by 8 (whole blocks)");
        co.find("layout").fromJson(new com.google.gson.JsonPrimitive("COMPACT")); rig.frame();
        check(rig.has("XYZ: 128.5 / 72.0 / -301.3"), "one-line layout");
        co.find("layout").fromJson(new com.google.gson.JsonPrimitive("STACKED"));
        co.find("decimals").fromJson(new com.google.gson.JsonPrimitive(0)); rig.frame();
        check(rig.has("X: 129") && rig.has("Y: 72") && rig.has("Z: -301"), "no decimals");
        co.find("decimals").fromJson(new com.google.gson.JsonPrimitive(3)); rig.frame();
        check(rig.has("X: 128.500") && rig.has("Z: -301.250"), "three decimals");
        co.find("decimals").fromJson(new com.google.gson.JsonPrimitive(1));
        rig.d.dimension = HudData.Dimension.NETHER; rig.d.x = 16; rig.d.z = -37; rig.frame();
        check(rig.has("Overworld: 128 / 72 / -296"), "Nether to Overworld multiplies by 8");
        rig.d.dimension = HudData.Dimension.END; rig.frame();
        check(rig.cv.findPrefix("Nether:") == null && rig.cv.findPrefix("Overworld:") == null, "no conversion in the End");
        rig.d.dimension = HudData.Dimension.OVERWORLD; rig.d.x = 128.5; rig.d.z = -301.25;
        co.find("nether").fromJson(new com.google.gson.JsonPrimitive(false)); rig.frame();
        check(rig.cv.findPrefix("Nether:") == null, "conversion can be turned off");
        co.find("speed").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.d.speed = 4.3;
        rig.cv.begin(0); rig.hud.render(rig.cv, rig.d, rig.theme, 0.016f, false);
        check(rig.has("Speed: 4.3 b/s"), "speed line");
        rig.d.reducedDebug = true; rig.frame();
        check(rig.has("Coordinates hidden by server"), "the server's reduced-debug rule hides the numbers");
        check(rig.cv.findPrefix("X:") == null && rig.cv.findPrefix("Y:") == null && rig.cv.findPrefix("Speed") == null, "none of the numbers are drawn");
        rig.editing = true; rig.frame();
        check(rig.has("X: 128.5"), "the editor still shows the layout");
        rig.editing = false; rig.d.reducedDebug = false; rig.frame();
        check(rig.has("X: 128.5") && rig.cv.findPrefix("Coordinates hidden") == null, "numbers return when the rule no longer applies");
        rig.d.inWorld = false; rig.frame();
        check(rig.cv.texts.isEmpty(), "nothing outside a world");
        rig.d.inWorld = true;

        // world info
        rig.only("worldinfo");
        WorldInfoElement wi = rig.get("worldinfo");
        rig.frame();
        check(rig.has("Dimension: Overworld") && rig.has("Biome: Plains") && rig.has("Light: 7 (sky 15)") && rig.has("Time: 12:00"), "default rows");
        check(rig.cv.findPrefix("Clock:") == null && rig.cv.findPrefix("Chunk:") == null && rig.cv.findPrefix("Server:") == null, "optional rows are off");
        wi.find("clock").fromJson(new com.google.gson.JsonPrimitive(true));
        wi.find("chunk").fromJson(new com.google.gson.JsonPrimitive(true));
        wi.find("server").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.d.serverName = "play.example.org";
        rig.frame();
        int minute = HudFormat.minuteOfDay(rig.d.wallClockMs, TimeZone.getDefault().getOffset(rig.d.wallClockMs));
        check(rig.has("Clock: " + HudFormat.clock(minute)), "real clock row");
        check(rig.has("Chunk: 8, -19"), "chunk row (negative coordinates floor correctly)");
        check(rig.has("Server: play.example.org"), "server row");
        rig.d.dayTime = 18000; rig.d.dimension = HudData.Dimension.NETHER; rig.d.biome = "Nether Wastes"; rig.d.blockLight = 3; rig.d.skyLight = -1; rig.frame();
        check(rig.has("Time: 00:00") && rig.has("Dimension: The Nether") && rig.has("Biome: Nether Wastes") && rig.has("Light: 3"), "rows follow the data");
        rig.d.dayTime = -1; rig.frame();
        check(rig.cv.findPrefix("Time:") == null, "an unknown time is not shown");
        rig.d.reducedDebug = true; rig.frame();
        check(rig.has("Dimension: The Nether") && rig.has("Details hidden by server"), "dimension stays, the note appears");
        check(rig.cv.findPrefix("Biome:") == null && rig.cv.findPrefix("Light:") == null && rig.cv.findPrefix("Chunk:") == null, "biome, light and chunk follow the server rule");
    }

    private static void direction() {
        HudRig rig = new HudRig(427, 240);
        rig.only("direction");
        DirectionElement dir = rig.get("direction");
        rig.d.yaw = 0;
        dir.find("style").fromJson(new com.google.gson.JsonPrimitive("TEXT"));
        rig.frame();
        check(rig.has("South (+Z)"), "text style");
        check(rig.has("180°"), "degrees");
        rig.d.yaw = -135; rig.frame();
        check(rig.has("North-East (+X -Z)") && rig.has("45°"), "diagonal with both axes");
        dir.find("longNames").fromJson(new com.google.gson.JsonPrimitive(false));
        dir.find("axis").fromJson(new com.google.gson.JsonPrimitive(false));
        dir.find("degrees").fromJson(new com.google.gson.JsonPrimitive(false)); rig.frame();
        check(rig.has("NE") && rig.cv.findPrefix("4") == null, "short names without extras");
        dir.find("style").fromJson(new com.google.gson.JsonPrimitive("COMPASS"));
        dir.find("degrees").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.d.yaw = 0; rig.frame();
        check(rig.has("S") && rig.has("SE") && rig.has("SW"), "the strip shows the directions around south");
        check(!rig.has("N") && !rig.has("W"), "and not the far ones");
        check(rig.has("180°"), "heading under the marker");
        eq(130, dir.rw, "default strip width");
        dir.find("width").fromJson(new com.google.gson.JsonPrimitive(200)); rig.frame();
        eq(200, dir.rw, "strip width follows the setting");
        rig.d.yaw = 180; rig.frame();
        check(rig.has("N") && rig.has("NE") && rig.has("NW"), "around north");
        rig.d.yaw = 179.4f; rig.frame();
        check(rig.has("359°") || rig.has("0°"), "wraps cleanly near north");
        rig.d.inWorld = false; rig.frame();
        check(rig.cv.texts.isEmpty(), "hidden outside a world");
    }

    private static void armorAndDurability() {
        HudRig rig = new HudRig(427, 240);
        rig.only("armor");
        ArmorElement armor = rig.get("armor");
        rig.d.mainHand.clear();
        rig.frame();
        check(rig.has("67%") && rig.has("93%") && rig.has("39%") && rig.has("69%"), "percent per piece");
        armor.find("value").fromJson(new com.google.gson.JsonPrimitive("FRACTION")); rig.frame();
        check(rig.has("243/363") && rig.has("552/592") && rig.has("195/495") && rig.has("45/65"), "left / maximum");
        armor.find("value").fromJson(new com.google.gson.JsonPrimitive("REMAINING")); rig.frame();
        check(rig.has("243") && rig.has("45"), "uses left");
        armor.find("value").fromJson(new com.google.gson.JsonPrimitive("NONE")); rig.frame();
        check(rig.cv.texts.isEmpty(), "icons only: no text at all");
        int verticalH = armor.rh;
        armor.find("value").fromJson(new com.google.gson.JsonPrimitive("PERCENT"));
        armor.find("layout").fromJson(new com.google.gson.JsonPrimitive("HORIZONTAL")); rig.frame();
        check(armor.rw > armor.rh, "horizontal layout is wider than tall");
        check(armor.rh < verticalH, "and shorter than the column");
        armor.find("layout").fromJson(new com.google.gson.JsonPrimitive("VERTICAL"));
        rig.d.armor[HudData.HEAD].clear(); rig.frame();
        check(!rig.has("67%"), "an empty slot is skipped");
        int fewer = armor.rh;
        armor.find("hideEmpty").fromJson(new com.google.gson.JsonPrimitive(false)); rig.frame();
        check(armor.rh > fewer, "an empty slot is kept when asked for");
        armor.find("hideEmpty").fromJson(new com.google.gson.JsonPrimitive(true));
        armor.find("hands").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.d.mainHand.set(null, 1, 250, 1561, "Diamond Pickaxe"); rig.frame();
        check(rig.has("84%"), "the main hand joins the list");
        rig.d.mainHand.set(null, 16, 0, 0, "Torch"); rig.frame();
        check(rig.has("x16"), "a stack shows its count");
        for (HudData.ItemInfo it : rig.d.armor) it.clear();
        rig.d.mainHand.clear();
        rig.d.offHand.clear();
        rig.frame();
        check(rig.cv.texts.isEmpty() && armor.rw == 0, "nothing worn: hidden");
        rig.editing = true; rig.frame();
        check(rig.has("Armor Status"), "the editor shows a placeholder so the element can be found");
        rig.editing = false;
        // colours: a nearly broken piece turns red
        rig.d.fillSample(rig.now);
        rig.d.armor[HudData.FEET].set(null, 1, 63, 65, "Leather Boots");
        rig.frame();
        check(rig.has("3%"), "nearly broken boots");

        // durability element
        rig.only("durability", "notifications");
        DurabilityElement du = rig.get("durability");
        rig.d.fillSample(rig.now);
        rig.frame();
        check(rig.has("Diamond Pickaxe: 1311/1561 (84%)"), "held tool with name, fraction and percent");
        du.find("format").fromJson(new com.google.gson.JsonPrimitive("PERCENT")); rig.frame();
        check(rig.has("Diamond Pickaxe: 84%"), "percent only");
        du.find("showName").fromJson(new com.google.gson.JsonPrimitive(false)); rig.frame();
        check(rig.has("84%"), "no name");
        du.find("showName").fromJson(new com.google.gson.JsonPrimitive(true));
        du.find("format").fromJson(new com.google.gson.JsonPrimitive("FRACTION")); rig.frame();
        check(rig.has("Diamond Pickaxe: 1311/1561"), "fraction only");
        rig.d.mainHand.set(null, 1, 0, 0, "Stick"); rig.frame();
        check(rig.cv.texts.isEmpty(), "an item without durability shows nothing");
        rig.d.offHand.set(null, 1, 10, 336, "Shield");
        du.find("offhand").fromJson(new com.google.gson.JsonPrimitive(true)); rig.frame();
        check(rig.has("Shield: 326/336"), "off hand when asked for");
        rig.editing = true; rig.d.offHand.clear(); rig.frame();
        check(rig.has("Durability"), "the editor shows a placeholder");
        rig.editing = false;

        // low durability warnings: once per drop, with hysteresis and a cooldown
        rig.d.fillSample(rig.now);
        rig.frame();
        eq(0L, rig.hud.notifications.totalShown(), "no warning while everything is fine");
        rig.d.armor[HudData.FEET].set(null, 1, 62, 65, "Leather Boots");   // 3 of 65 left: 5 percent
        rig.frame();
        eq(1L, rig.hud.notifications.totalShown(), "one warning when the boots get low");
        check(rig.hud.notifications.get(rig.hud.notifications.count() - 1).message.equals("Low durability: Leather Boots (5%)"), "warning text");
        rig.frames(30);
        eq(1L, rig.hud.notifications.totalShown(), "no repeated warnings while it stays low");
        rig.d.armor[HudData.FEET].set(null, 1, 13, 65, "Leather Boots");   // repaired to 80 percent
        rig.frame();
        rig.d.armor[HudData.FEET].set(null, 1, 62, 65, "Leather Boots");   // broken down again right away
        rig.frame();
        eq(1L, rig.hud.notifications.totalShown(), "the cooldown prevents a second warning right away");
        rig.d.armor[HudData.FEET].set(null, 1, 13, 65, "Leather Boots");
        rig.frames(31 * 60);
        rig.d.armor[HudData.FEET].set(null, 1, 62, 65, "Leather Boots");
        rig.frame();
        eq(2L, rig.hud.notifications.totalShown(), "a warning after the cooldown");
        rig.d.armor[HudData.FEET].set(null, 1, 60, 65, "Leather Boots");   // 5 left: 8 percent, still low and not recovered
        rig.frame();
        eq(2L, rig.hud.notifications.totalShown(), "small changes while low do not warn again");
        du.find("warn").fromJson(new com.google.gson.JsonPrimitive(false));
        rig.d.mainHand.set(null, 1, 1555, 1561, "Diamond Pickaxe");
        rig.frame();
        eq(2L, rig.hud.notifications.totalShown(), "warnings can be turned off");
        du.find("warn").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.frames(40 * 60);
        check(rig.hud.notifications.totalShown() == 3L, "the pickaxe warns once warnings are back on (" + rig.hud.notifications.totalShown() + ")");
        rig.editing = true;
        rig.d.armor[HudData.HEAD].set(null, 1, 360, 363, "Iron Helmet");
        long before = rig.hud.notifications.totalShown();
        rig.frame();
        eq(before, rig.hud.notifications.totalShown(), "no warnings from the editor");
    }

    private static void keystrokes() {
        HudRig rig = new HudRig(427, 240);
        rig.only("keystrokes");
        KeystrokesElement ks = rig.get("keystrokes");
        rig.d.keys[HudData.K_FORWARD] = false; rig.d.keys[HudData.K_SPRINT] = false; rig.d.keys[HudData.M_LEFT] = false;
        rig.frames(5);
        near(0, ks.keyProgress(HudData.K_FORWARD), 1e-6, "released keys are dark");
        check(rig.has("W") && rig.has("A") && rig.has("S") && rig.has("D"), "the movement keys are labelled");
        check(rig.has("Space") && rig.has("LMB") && rig.has("RMB"), "jump and mouse buttons are shown");
        rig.d.keys[HudData.K_FORWARD] = true;
        rig.frame();
        float one = ks.keyProgress(HudData.K_FORWARD);
        check(one > 0.1f && one < 0.9f, "a pressed key lights up gradually (" + one + ")");
        rig.frames(40);
        check(ks.keyProgress(HudData.K_FORWARD) > 0.99f, "and ends fully lit");
        near(0, ks.keyProgress(HudData.K_LEFT), 1e-6, "other keys are unaffected");
        rig.d.keys[HudData.K_FORWARD] = false;
        rig.frames(40);
        check(ks.keyProgress(HudData.K_FORWARD) < 0.01f, "released keys fade out");
        ks.find("fade").fromJson(new com.google.gson.JsonPrimitive(0));
        rig.d.keys[HudData.K_BACK] = true;
        rig.frame();
        near(1, ks.keyProgress(HudData.K_BACK), 1e-6, "no animation: instant");
        rig.d.keys[HudData.K_BACK] = false;
        rig.frame();
        near(0, ks.keyProgress(HudData.K_BACK), 1e-6, "no animation: instant release");

        int base = ks.rh;
        ks.find("sneak").fromJson(new com.google.gson.JsonPrimitive(true)); rig.frame();
        check(rig.has("Shift") && ks.rh > base, "optional sneak bar");
        ks.find("jump").fromJson(new com.google.gson.JsonPrimitive(false)); rig.frame();
        check(!rig.has("Space"), "jump bar can be hidden");
        ks.find("mouse").fromJson(new com.google.gson.JsonPrimitive(false)); rig.frame();
        check(!rig.has("LMB"), "mouse buttons can be hidden");
        ks.find("mouse").fromJson(new com.google.gson.JsonPrimitive(true));
        for (int i = 0; i < 5; i++) rig.hud.state.clicks.click(0, rig.now - 10 * i);
        rig.frame();
        check(rig.has("5"), "the click rate shows under the left button");
        ks.find("showCps").fromJson(new com.google.gson.JsonPrimitive(false)); rig.frame();
        check(!rig.has("5"), "and can be hidden");
        eq(18 * 3 + 2 * 2, ks.rw, "width follows the key size and gap");
        ks.find("keySize").fromJson(new com.google.gson.JsonPrimitive(24)); rig.frame();
        eq(24 * 3 + 2 * 2, ks.rw, "bigger keys");
        rig.d.keyLabels[HudData.K_FORWARD] = "Mouse Button 4 Extra"; rig.frame();
        check(rig.cv.findPrefix("Mouse") == null || rig.cv.findPrefix("Mouse").w() <= 24, "a long key name is shortened to fit the key");
        rig.d.keyLabels[HudData.K_FORWARD] = "W";
    }

    private static void moduleList() {
        HudRig rig = new HudRig(427, 240);
        rig.only("modulelist");
        ModuleListElement ml = rig.get("modulelist");
        rig.frame();
        check(rig.cv.texts.isEmpty(), "an empty list draws nothing");
        rig.fullbright.setEnabled(true);
        rig.frames(40);
        check(rig.has("Fullbright"), "an enabled module is listed");
        check(!rig.has("Zoom"), "a disabled module is not");
        check(!rig.has("FPS Counter") && rig.cv.findPrefix("Module List") == null, "HUD elements and the list itself are not listed");
        rig.zoom.setEnabled(true);
        rig.frames(40);
        check(rig.text("Fullbright").y() < rig.text("Zoom").y(), "longest first by default");
        eq(rig.text("Fullbright").x() + rig.text("Fullbright").w(), rig.text("Zoom").x() + rig.text("Zoom").w(), "right-aligned rows share their right edge");
        ml.find("sort").fromJson(new com.google.gson.JsonPrimitive("ALPHABET"));
        rig.chat.setEnabled(true);
        rig.frames(40);
        check(rig.text("Chat Tools").y() < rig.text("Fullbright").y() && rig.text("Fullbright").y() < rig.text("Zoom").y(), "alphabetical order");
        rig.blocked = Feature.FULLBRIGHT;
        rig.frames(5);
        check(rig.has("Fullbright (blocked)"), "a module the server rules switch off is listed as blocked");
        check(rig.fullbright.isBlockedByPolicy(), "the module knows it is blocked");
        ml.find("showBlocked").fromJson(new com.google.gson.JsonPrimitive(false));
        rig.frames(60);
        check(!rig.has("Fullbright (blocked)") && !rig.has("Fullbright"), "blocked modules can be hidden from the list");
        ml.find("showBlocked").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.blocked = null;
        rig.frames(40);
        check(rig.has("Fullbright"), "and it recovers when the rule is lifted");
        rig.zoom.setEnabled(false);
        rig.frame();
        check(rig.has("Zoom"), "a module that was just switched off is still fading out");
        rig.frames(80);
        check(!rig.has("Zoom"), "and then it is gone");
        ml.find("showHud").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.get("fps").setEnabled(true);
        rig.frames(40);
        check(rig.has("FPS Counter"), "HUD elements can be listed too");
        int before = ml.rh;
        ml.find("bar").fromJson(new com.google.gson.JsonPrimitive(false));
        rig.frames(2);
        eq(before, ml.rh, "the accent bar does not change the height");
        rig.fullbright.setEnabled(false); rig.chat.setEnabled(false); rig.get("fps").setEnabled(false);
        rig.frames(80);
        check(rig.cv.texts.isEmpty(), "everything off: nothing drawn");
        rig.editing = true; rig.frame();
        check(rig.has("Fullbright") && rig.has("Waypoints"), "the editor shows sample entries");
    }

    private static void notificationElement() {
        HudRig rig = new HudRig(427, 240);
        rig.only("notifications");
        rig.frame();
        check(rig.cv.texts.isEmpty(), "no toasts: nothing drawn");
        check(rig.hud.notifications.push(Level.SUCCESS, "Profile loaded"), "toast accepted");
        rig.frames(30);
        check(rig.has("Profile loaded"), "toast is drawn");
        HudElement ne = rig.get("notifications");
        check(ne.rw >= 110, "toasts have a minimum width");
        eq((427 - ne.rw) / 2, ne.rx, "centred at the top by default");
        for (int i = 0; i < 5; i++) rig.hud.notifications.push(Level.INFO, "Message " + i);
        rig.frames(30);
        check(rig.has("Message 4") && rig.has("Message 3") && rig.has("Message 2") && rig.has("Message 1"), "the newest four are shown");
        check(!rig.has("Profile loaded") && !rig.has("Message 0"), "older ones make room");
        ne.find("maxShown").fromJson(new com.google.gson.JsonPrimitive(2)); rig.frames(2);
        check(rig.has("Message 4") && rig.has("Message 3") && !rig.has("Message 2"), "the limit can be lowered");
        rig.frames(60 * 6);
        check(rig.cv.texts.isEmpty(), "toasts disappear after their time");
        rig.hud.notifications.push(Level.WARN, "Same");
        rig.hud.notifications.push(Level.WARN, "Same");
        rig.frames(30);
        check(rig.has("Same (x2)"), "repeats are merged");
        ne.setEnabled(false);
        check(!rig.hud.notifications.push(Level.INFO, "ignored"), "switching the module off silences notifications");
        ne.setEnabled(true);
        rig.hud.notifications.clear();
        rig.editing = true; rig.frame();
        check(rig.has("Profile loaded: Default"), "the editor shows sample toasts");
    }

    // ------------------------------------------------------------------ whole HUD
    private static void defaultLayout() {
        int[][] sizes = {{427, 240}, {480, 270}, {640, 360}, {960, 540}};
        for (int[] sz : sizes) {
            HudRig rig = new HudRig(sz[0], sz[1], 1);
            rig.enableAll();
            rig.get("modulelist").setEnabled(true);
            rig.get("worldinfo").find("clock").fromJson(new com.google.gson.JsonPrimitive(true));
            rig.get("coordinates").find("speed").fromJson(new com.google.gson.JsonPrimitive(true));
            rig.editing = true;
            rig.d.singleplayer = false;
            rig.frame();
            List<HudElement> shown = new ArrayList<>();
            for (HudElement e : rig.el.values()) if (e.rw > 0) shown.add(e);
            eq(rig.el.size(), shown.size(), "every element draws something at " + sz[0] + "x" + sz[1]);
            for (HudElement e : shown) {
                check(e.rx >= 0 && e.ry >= 0 && e.rx + e.rw <= sz[0] && e.ry + e.rh <= sz[1], e.id + " fits on a " + sz[0] + "x" + sz[1] + " screen (at " + e.rx + "," + e.ry + " size " + e.rw + "x" + e.rh + ")");
            }
            for (int i = 0; i < shown.size(); i++) {
                for (int j = i + 1; j < shown.size(); j++) {
                    HudElement a = shown.get(i), b = shown.get(j);
                    boolean overlap = a.rx < b.rx + b.rw && b.rx < a.rx + a.rw && a.ry < b.ry + b.rh && b.ry < a.ry + a.rh;
                    check(!overlap, a.id + " overlaps " + b.id + " on " + sz[0] + "x" + sz[1] + " [" + a.rx + "," + a.ry + " " + a.rw + "x" + a.rh + "] [" + b.rx + "," + b.ry + " " + b.rw + "x" + b.rh + "]");
                }
            }
        }
    }

    private static void allocation() {
        HudRig rig = new HudRig(427, 240);
        rig.enableAll();
        rig.get("modulelist").find("showHud").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.get("armor").find("hands").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.get("worldinfo").find("clock").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.get("coordinates").find("speed").fromJson(new com.google.gson.JsonPrimitive(true));
        rig.d.singleplayer = false;
        rig.d.fillSample(rig.now);
        rig.d.singleplayer = false;
        rig.d.screenW = 427; rig.d.screenH = 240;
        NullCanvas nc = new NullCanvas(427, 240);
        Hud hud = rig.hud;
        long frames = 0;
        for (int i = 0; i < 4000; i++) { rig.now += 16; rig.d.nowMs = rig.now; hud.update(rig.d); hud.render(nc, rig.d, rig.theme, 0.016f, false); frames++; }
        com.sun.management.ThreadMXBean mx = ManagementFactory.getThreadMXBean() instanceof com.sun.management.ThreadMXBean m ? m : null;
        if (mx == null || !mx.isThreadAllocatedMemorySupported()) { System.out.println("  (allocation measurement not supported on this JVM; skipped)"); return; }
        long id = Thread.currentThread().threadId();
        int n = 6000;
        long start = mx.getThreadAllocatedBytes(id);
        for (int i = 0; i < n; i++) { rig.now += 16; rig.d.nowMs = rig.now; hud.update(rig.d); hud.render(nc, rig.d, rig.theme, 0.016f, false); }
        long used = mx.getThreadAllocatedBytes(id) - start;
        double perFrame = used / (double) n;
        System.out.println("  steady-state HUD allocation: " + String.format(java.util.Locale.ROOT, "%.1f", perFrame) + " bytes per frame with every element on");
        check(perFrame < 256, "a steady HUD allocates almost nothing (" + perFrame + " bytes/frame)");
        // moving around changes the coordinates every frame: that costs a few small strings, but stays modest
        start = mx.getThreadAllocatedBytes(id);
        for (int i = 0; i < n; i++) { rig.now += 16; rig.d.nowMs = rig.now; rig.d.x += 0.07; rig.d.z -= 0.05; rig.d.yaw += 0.5f; hud.update(rig.d); hud.render(nc, rig.d, rig.theme, 0.016f, false); }
        used = mx.getThreadAllocatedBytes(id) - start;
        perFrame = used / (double) n;
        System.out.println("  while moving: " + String.format(java.util.Locale.ROOT, "%.1f", perFrame) + " bytes per frame");
        check(perFrame < 2048, "moving costs only a few small strings (" + perFrame + " bytes/frame)");
    }

    private static void previews() {
        // the default HUD
        HudRig rig = new HudRig(427, 240);
        rig.d.singleplayer = false;
        rig.frames(3);
        rig.hud.notifications.push(Level.SUCCESS, "Profile loaded: Default");
        rig.frames(30);
        rig.preview("hud-default");
        check(rig.cv.texts.size() > 5, "the default HUD draws");
        // everything on
        HudRig all = new HudRig(427, 240);
        all.enableAll();
        all.d.singleplayer = false;
        all.fullbright.setEnabled(true); all.zoom.setEnabled(true); all.waypoints.setEnabled(true);
        all.get("armor").find("hands").fromJson(new com.google.gson.JsonPrimitive(true));
        all.get("worldinfo").find("clock").fromJson(new com.google.gson.JsonPrimitive(true));
        all.get("coordinates").find("speed").fromJson(new com.google.gson.JsonPrimitive(true));
        for (int i = 0; i < 5; i++) all.hud.state.clicks.click(0, all.now - 20 * i);
        all.hud.state.clicks.click(1, all.now - 30);
        all.d.keys[HudData.K_FORWARD] = true; all.d.keys[HudData.K_JUMP] = true; all.d.keys[HudData.M_LEFT] = true;
        all.hud.notifications.push(Level.WARN, "Low durability: Leather Boots (7%)");
        all.hud.notifications.push(Level.INFO, "Zoom is off on this server (rules: Strict)");
        all.frames(60);
        all.preview("hud-all-midnight");
        all.theme = Themes.DAYLIGHT;
        all.frames(2);
        all.preview("hud-all-daylight");
        // compass in text mode and a left-aligned module list
        all.theme = Themes.OCEAN;
        ((DirectionElement) all.get("direction")).find("style").fromJson(new com.google.gson.JsonPrimitive("TEXT"));
        all.get("modulelist").anchor.set(Anchor.MIDDLE_LEFT);
        all.frames(2);
        all.preview("hud-all-ocean-text");
        check(all.cv.texts.size() > 30, "the full HUD draws many elements");
    }

    @SuppressWarnings("unused")
    private static void unused(ModuleRegistry r, LineElement l, HudState s) { }
}
