package com.reaper.client.tests;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.reaper.client.core.policy.ServerMode;
import com.reaper.client.core.policy.ServerPolicy;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Input;
import com.reaper.client.core.ui.InterfaceModule;
import com.reaper.client.core.ui.TextField;
import com.reaper.client.core.ui.UiWindow;

import java.io.IOException;

/** Headless tests and preview renders for the ClickGUI. Everything is driven through simulated mouse and keyboard input. */
final class GuiTests {
    private GuiTests() {}

    static void run() throws IOException {
        layoutAndRendering();
        moduleRowsAndWidgets();
        keyBinds();
        colourPicker();
        search();
        windowBehaviour();
        layoutPersistence();
        profilesPanel();
        serverRules();
        tooltipsScaleAnimationsClose();
        leaks();
        textFieldUnit();
        canvasHelpers();
        previews();
    }

    private static GuiHarness fresh() throws IOException { return fresh(360); }

    private static GuiHarness fresh(int height) throws IOException {
        GuiHarness h = new GuiHarness(640, height);
        h.frames(25);
        return h;
    }

    /** GUI coordinates of the first pixel with exactly this colour at or below {@code fromY}, or null. */
    private static int[] findPixel(GuiHarness h, int argb, int fromY) {
        var img = h.cv.img;
        for (int y = fromY * 2; y < img.getHeight(); y++)
            for (int x = 0; x < img.getWidth(); x++)
                if (img.getRGB(x, y) == argb) return new int[]{x / 2, y / 2};
        return null;
    }

    private static boolean overlap(UiWindow a, UiWindow b) {
        return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.height() && b.y < a.y + a.height();
    }

    // ================================================================== rendering
    private static void layoutAndRendering() throws IOException {
        T.section("GUI: layout and rendering");
        GuiHarness h = fresh();
        T.check(h.has("REAPER CLIENT") && h.has("HUD editor") && h.has("Screenshots"), "top bar is drawn");
        T.check(h.has("Search modules and settings..."), "search placeholder is drawn");
        T.check(h.has("Windows") && h.has("Profiles") && h.has("Automation"), "window chips are drawn");
        T.check(h.window("hud").visible && h.window("visual").visible, "first two windows are visible by default");
        T.check(!h.window("utility").visible && !h.window("profiles").visible, "other windows start hidden");
        T.check(h.has("FPS Counter") && h.has("Fullbright"), "module rows are drawn");
        T.check(!h.has("Chat Tools"), "hidden windows are not drawn");
        T.check(h.cv.fills > 100, "a frame draws many primitives");
        for (UiWindow w : h.gui.windows())
            if (w.visible) T.check(w.x >= 0 && w.x + w.w <= h.W && w.y >= 0 && w.y < h.H, "window on screen: " + w.id);

        h.window("hud").x = 5000;
        h.window("hud").y = -300;
        h.frame();
        T.check(h.window("hud").x <= h.W - 70 && h.window("hud").y >= 0, "off-screen windows are pulled back inside");

        T.check(h.cv.pixel(h.W / 2, 2) != h.cv.pixel(h.W / 2, 200), "top bar differs from the backdrop");
        T.check(h.gui.windows().size() == 6, "five category windows plus Profiles");
    }

    // ================================================================== module rows and setting widgets
    private static void moduleRowsAndWidgets() throws IOException {
        T.section("GUI: module rows and setting widgets");
        GuiHarness h = fresh();
        int saves0 = h.saves;
        h.clickText("FPS Counter");
        T.check(h.fps.isEnabled(), "clicking a module row switches it on");
        T.check(h.saves > saves0, "a toggle asks for a save");
        h.clickText("FPS Counter");
        T.check(!h.fps.isEnabled(), "clicking again switches it off");
        T.check(h.coords.isEnabled(), "modules that default on start on");

        h.rightClickText("FPS Counter");
        h.frames(30);
        T.check(h.has("Text shadow") && h.has("Background") && h.has("Size") && h.has("Keybind"), "right-click expands the settings panel");
        h.rightClickText("FPS Counter");
        h.frames(30);
        T.check(!h.has("Text shadow"), "right-click again collapses it");
        h.clickText("FPS Counter");
        h.rightClickText("FPS Counter");
        h.frames(30);
        T.check(h.fps.isEnabled(), "expanding does not change the module state");

        // bool: left toggles, right resets to default
        boolean before = h.fpsShadow.on();
        h.clickText("Text shadow");
        T.check(h.fpsShadow.on() != before, "bool row toggles on click");
        h.rightClickText("Text shadow");
        T.check(h.fpsShadow.on() == before, "right-click resets the bool to its default");

        // slider: click, drag, clamp
        var lab = h.text("Size");
        var val = h.text("1.0x");
        int x0 = lab.x(), x1 = val.x() + val.w(), sy = lab.y() + 21;
        h.click(x0 + (x1 - x0) * 0.5, sy);
        T.near(1.75, h.fpsScale.v(), 0.06, "clicking the middle of the slider sets the middle value");
        h.drag(x0 + 5, sy, x1 + 40, sy);
        T.near(3.0, h.fpsScale.v(), 1e-9, "dragging past the right end clamps to the maximum");
        h.drag(x1 - 5, sy, x0 - 60, sy);
        T.near(0.5, h.fpsScale.v(), 1e-9, "dragging past the left end clamps to the minimum");
        T.check(h.has("0.5x"), "slider shows its value");

        // typing a value (right-click the row)
        h.rightClick(x0 + 10, lab.y() + 4);
        h.type("2.5");
        h.key(KeyNames.ENTER);
        T.near(2.5, h.fpsScale.v(), 1e-9, "typed value is applied on Enter");
        h.rightClick(x0 + 10, lab.y() + 4);
        h.type("99");
        h.key(KeyNames.ENTER);
        T.near(3.0, h.fpsScale.v(), 1e-9, "typed values are clamped");
        h.rightClick(x0 + 10, lab.y() + 4);
        h.type("abc");
        h.key(KeyNames.ENTER);
        T.near(3.0, h.fpsScale.v(), 1e-9, "letters are not accepted in a number box");
        h.rightClick(x0 + 10, lab.y() + 4);
        h.type("1.2");
        h.key(KeyNames.ESCAPE);
        T.near(3.0, h.fpsScale.v(), 1e-9, "Escape cancels typing");
        T.check(h.gui.ui.focus == null, "no field keeps focus afterwards");

        // ctrl + wheel
        h.fpsScale.set(1.0);
        h.frame();
        h.move(x0 + 20, lab.y() + 8);
        h.frame();
        h.gui.in.mods = Input.MOD_CTRL;
        h.gui.in.scroll(1);
        h.frame();
        h.gui.in.mods = 0;
        T.near(1.1, h.fpsScale.v(), 1e-9, "Ctrl+wheel nudges a slider by one step");

        // colour row opens, closes
        h.clickText("Text colour");
        h.frames(30);
        T.check(h.cv.findPrefix("#") != null, "colour row shows its hex value");

        // choice row (Client window)
        GuiHarness c = fresh();
        c.clickText("Client");
        c.solo("client");
        T.check(c.window("client").visible && c.has("Theme") && c.has("Reaper"), "Client window shows the theme choice");
        T.eq(InterfaceModule.ThemeName.REAPER, c.iface.theme.v(), "the default theme is Reaper");
        c.clickText("Theme");
        T.eq(InterfaceModule.ThemeName.MIDNIGHT, c.iface.theme.v(), "left click cycles forward");
        c.rightClickText("Theme");
        T.eq(InterfaceModule.ThemeName.REAPER, c.iface.theme.v(), "right click cycles back");
        c.clickText("Theme");
        c.frames(5);
        T.eq("midnight", c.iface.resolve().id(), "the GUI palette follows the choice");
        c.clickText("Custom accent");
        T.check(c.iface.useAccent.on(), "bool in the interface panel works");
        T.check(c.has("Accent colour"), "dependent setting appears when its switch is on");
        c.clickText("Custom accent");
        c.frames(3);
        T.check(!c.has("Accent colour"), "dependent setting hides again");

        // text, action rows (Utility window)
        GuiHarness u = fresh();
        u.clickText("Utility");
        u.frames(30);
        T.check(u.window("utility").visible && u.has("Chat Tools"), "Utility window opens from its chip");
        u.solo("utility");
        u.rightClickText("Chat Tools");
        u.frames(30);
        var ph = u.text("...");
        u.click(ph.x() + 2, ph.y() + 4);
        u.type("steve alex");
        u.key(KeyNames.ENTER);
        T.eq("steve alex", u.mentions.get(), "text row commits on Enter");
        ph = u.cv.find("steve alex");
        T.check(ph != null, "text row shows its value");
        u.click(ph.x() + 2, ph.y() + 4);
        u.type("zzz");
        T.check(!u.gui.onEscape(), "Escape while editing only cancels the edit");
        T.eq("steve alex", u.mentions.get(), "cancelled edit keeps the old text");
        T.check(u.gui.ui.focus == null, "editing stopped");
        u.clickText("Clear history");
        T.eq(1, u.actionRuns, "action rows run their action");
    }

    // ================================================================== key binds
    private static void keyBinds() throws IOException {
        T.section("GUI: key binds");
        GuiHarness h = fresh();
        h.rightClickText("Fullbright");
        h.frames(30);
        T.check(h.has("Keybind") && !h.has("Key mode"), "key mode row is hidden while no key is bound");
        h.clickText("Keybind");
        T.check(h.has("Press a key..."), "row shows it is listening");
        h.key(KeyNames.C);
        T.eq(KeyNames.C, h.fullbright.bind.get(), "key press binds the key");
        T.check(h.has("Key mode"), "key mode row appears once a key is bound");
        T.check(h.gui.ui.focus == null, "listening ends after binding");

        h.clickText("Keybind");
        h.key(KeyNames.ESCAPE);
        T.eq(KeyNames.C, h.fullbright.bind.get(), "Escape cancels without changing the bind");
        h.clickText("Keybind");
        h.key(KeyNames.BACKSPACE);
        T.eq(Settings.NO_KEY, h.fullbright.bind.get(), "Backspace clears the bind");
        h.clickText("Keybind");
        h.key(KeyNames.C);
        h.rightClickText("Keybind");
        T.eq(Settings.NO_KEY, h.fullbright.bind.get(), "right-click clears the bind");
        h.clickText("Keybind");
        h.key(KeyNames.C);

        // conflict warning
        h.rightClickText("Fullbright");
        h.frames(30);
        h.rightClickText("Zoom");
        h.frames(30);
        h.clickText("Keybind");
        h.key(KeyNames.C);
        T.eq(KeyNames.C, h.zoom.bind.get(), "the same key can be bound twice");
        T.check(h.toasts.stream().anyMatch(s -> s.contains("C is also bound to Fullbright")), "a conflict warning is shown");
    }

    // ================================================================== colour picker
    private static void colourPicker() throws IOException {
        T.section("GUI: colour picker");
        GuiHarness h = fresh();
        h.rightClickText("FPS Counter");
        h.frames(30);
        var label = h.text("Text colour");
        h.click(label.x() + 4, label.y() + 4);
        h.frames(30);
        int[] red = findPixel(h, 0xFFFF4D5E, label.y() + 10);
        T.check(red != null, "preset swatches are drawn");
        h.click(red[0], red[1]);
        T.eq(0xFFFF4D5E, h.fpsColor.argb(), "clicking a preset sets the colour");

        // hex box: the lower of the two "#FF4D5E" texts
        RasterCanvas.Drawn hex = null;
        for (var d : h.cv.texts) if (d.text().equals("#FF4D5E") && (hex == null || d.y() > hex.y())) hex = d;
        T.check(hex != null, "hex box shows the colour");
        h.click(hex.x() + 3, hex.y() + 3);
        h.type("#00FF00");
        h.key(KeyNames.ENTER);
        T.eq(0xFF00FF00, h.fpsColor.argb(), "typed hex colour is applied");
        h.frames(5);
        RasterCanvas.Drawn hex2 = null;
        for (var d : h.cv.texts) if (d.text().equals("#00FF00") && (hex2 == null || d.y() > hex2.y())) hex2 = d;
        h.click(hex2.x() + 3, hex2.y() + 3);
        h.type("#12");
        h.key(KeyNames.ENTER);
        T.eq(0xFF00FF00, h.fpsColor.argb(), "an incomplete hex value is ignored");

        // saturation / value square: drag inside it
        int px = label.x(), py = label.y() + 19;   // picker origin (x + 8, row y + 22 + 4)
        int before = h.fpsColor.argb();
        h.drag(px + 20, py + 10, px + 60, py + 40);
        T.check(h.fpsColor.argb() != before && (h.fpsColor.argb() >>> 24) == 0xFF, "dragging in the square changes the colour and keeps it opaque");

        // alpha is preserved on colours that have alpha (Keystrokes "Pressed colour")
        h.clickText("Text colour");
        h.frames(30);
        GuiHarness k = fresh();
        k.rightClickText("Keystrokes");
        k.frames(30);
        var kl = k.text("Pressed colour");
        T.check(k.cv.findPrefix("#CC") != null, "colours with alpha show eight hex digits");
        k.click(kl.x() + 4, kl.y() + 4);
        k.frames(30);
        int[] green = findPixel(k, 0xFF3DDC84, kl.y() + 10);
        k.click(green[0], green[1]);
        T.eq(0xCC3DDC84, k.keystrokes.find("pressed") instanceof Settings.Color c ? c.argb() : 0, "presets keep the existing alpha");
    }

    // ================================================================== search
    private static void search() throws IOException {
        T.section("GUI: search");
        GuiHarness h = fresh();
        int hudX = h.window("hud").x, hudY = h.window("hud").y;
        h.type("bri");
        h.frames(30);
        T.eq("bri", h.gui.query(), "typing goes to the search box");
        T.check(h.has("Fullbright") && h.has("Baritone Bridge"), "matches are shown, even from hidden windows");
        T.check(!h.has("FPS Counter") && !h.has("Zoom"), "non-matches are hidden");
        T.check(h.has("2 results"), "result count is shown");
        T.check(h.window("automation").visible, "hidden windows with matches are shown while searching");
        h.gui.onEscape();
        h.frames(30);
        T.eq("", h.gui.query(), "Escape clears the query first");
        T.check(h.has("FPS Counter"), "everything is back after clearing");
        T.check(!h.window("automation").visible, "hidden windows are hidden again");
        T.check(h.window("hud").x == hudX && h.window("hud").y == hudY, "the user's layout is restored after a search");
        T.check(h.gui.onEscape(), "Escape with nothing to clear asks the screen to close");

        h.type("qqqq");
        h.frames(5);
        T.check(h.cv.findPrefix("No modules or settings match") != null, "an empty result shows a message");
        h.gui.onEscape();
        h.frames(10);

        h.type("decimals");
        h.frames(40);
        T.check(h.has("Coordinates") && h.has("Decimals"), "searching finds individual settings and shows them");
        h.gui.onEscape();
        h.frames(10);

        h.type("zoom factor");
        h.frames(40);
        T.check(h.has("Zoom") && h.has("Zoom factor"), "multi-word search works");
        h.gui.onEscape();
        h.frames(10);

        h.type("UTILITY");
        h.frames(40);
        T.eq("utility", h.gui.query(), "queries are case-insensitive");
        T.check(h.has("Inventory Sorter"), "category names match their modules");
        h.gui.onEscape();
        h.frames(10);

        // the layout saved to disk during a search is the real one
        h.type("bri");
        h.frames(20);
        JsonObject j = h.gui.layoutToJson();
        T.check(!j.getAsJsonObject("automation").get("visible").getAsBoolean(), "layout JSON written during a search holds the real layout");
        h.gui.onEscape();
        h.frames(5);

        // typing while a text row is focused does not leak into the search box
        GuiHarness u = fresh();
        u.solo("utility");
        u.rightClickText("Chat Tools");
        u.frames(30);
        var ph = u.text("...");
        u.click(ph.x() + 2, ph.y() + 4);
        u.type("bri");
        T.eq("", u.gui.query(), "typing into a text row does not touch the search");
        u.key(KeyNames.ENTER);
        T.eq("bri", u.mentions.get(), "...and lands in the row");
    }

    // ================================================================== windows
    private static void windowBehaviour() throws IOException {
        T.section("GUI: window behaviour");
        GuiHarness h = fresh();
        UiWindow hud = h.window("hud");
        int x0 = hud.x, y0 = hud.y;
        int sx = hud.x + 90, sy = hud.y + 12;
        int saves0 = h.saves;
        h.drag(sx, sy, sx + 100, sy + 50);
        T.near(x0 + 100, hud.x, 1, "dragging the header moves the window (x)");
        T.near(y0 + 50, hud.y, 1, "dragging the header moves the window (y)");
        T.check(h.saves > saves0, "moving a window asks for a save");
        h.wait(30);

        // snapping to the left margin
        int cur = hud.x;
        h.drag(hud.x + 90, hud.y + 12, hud.x + 90 + (13 - cur), hud.y + 12);
        T.eq(12, hud.x, "windows snap to the screen margin");
        h.wait(30);
        cur = hud.x;
        h.drag(hud.x + 90, hud.y + 12, hud.x + 90 + (19 - cur), hud.y + 12);
        T.eq(h.window("visual").x - hud.w - 4, hud.x, "windows snap to the edge of a neighbour (4 px gap)");
        h.wait(30);
        cur = hud.x;
        h.drag(hud.x + 90, hud.y + 12, hud.x + 90 + (40 - cur), hud.y + 12);
        T.eq(40, hud.x, "no snapping when nothing is within reach");
        h.wait(30);

        // collapse: chevron, double click, right-click
        hud.y = 70;
        h.frame();
        h.click(hud.x + hud.w - 10, hud.y + 12);
        T.check(hud.collapsed, "the chevron collapses a window");
        h.frames(30);
        T.eq(UiWindow.HEADER, hud.height(), "a collapsed window is just its header");
        T.check(!h.has("Coordinates"), "collapsed windows draw no rows");
        h.click(hud.x + hud.w - 10, hud.y + 12);
        T.check(!hud.collapsed, "the chevron expands it again");
        h.wait(40);
        h.click(hud.x + 60, hud.y + 12);
        h.click(hud.x + 60, hud.y + 12);
        T.check(hud.collapsed, "double-clicking the header collapses");
        h.wait(40);
        h.rightClick(hud.x + 60, hud.y + 12);
        T.check(!hud.collapsed, "right-clicking the header toggles");
        h.wait(40);

        // resize
        int cx = hud.x + hud.w - 4, cy = hud.y + hud.height() - 4;
        h.drag(cx, cy, cx + 60, cy + 30);
        T.eq(274, hud.w, "the corner grip widens the window");
        T.check(hud.userSized, "the corner grip also sets a custom height");
        h.wait(40);
        cx = hud.x + hud.w - 4;
        cy = hud.y + hud.height() - 4;
        h.drag(cx, cy, cx - 700, cy);
        T.eq(UiWindow.MIN_W, hud.w, "width never goes below the minimum");
        h.wait(40);
        cx = hud.x + hud.w - 4;
        cy = hud.y + hud.height() - 4;
        h.drag(cx, cy, cx + 900, cy);
        T.eq(UiWindow.MAX_W, hud.w, "width never goes above the maximum");
        h.wait(40);
        cx = hud.x + hud.w - 4;
        cy = hud.y + hud.height() - 4;
        h.click(cx, cy);
        h.click(cx, cy);
        T.check(!hud.userSized && hud.w == 214, "double-clicking the corner resets the size");
        h.wait(40);
        h.drag(hud.x + hud.w - 2, hud.y + 60, hud.x + hud.w + 28, hud.y + 60);
        T.eq(244, hud.w, "the right edge resizes the width only");
        T.check(!hud.userSized, "...and leaves the height automatic");

        // scrolling
        h.rightClickText("FPS Counter");
        h.rightClickText("Coordinates");
        h.frames(40);
        int view = Math.round(hud.body.value);
        T.check(hud.contentH > view && hud.maxScroll(view) > 0, "a long window gets a scroll range");
        h.move(hud.x + 100, hud.y + 100);
        h.gui.in.scroll(-2);
        h.frames(40);
        T.check(hud.scroll > 20, "wheel scrolling moves the content");
        float before = hud.scroll;
        h.move(hud.x + hud.w - 6, hud.y + UiWindow.HEADER + 8);
        h.drag(hud.x + hud.w - 6, hud.y + UiWindow.HEADER + 8, hud.x + hud.w - 6, hud.y + UiWindow.HEADER + 80);
        T.check(hud.scroll != before, "dragging the scrollbar scrolls");
        h.gui.in.scroll(50);
        h.move(hud.x + 100, hud.y + 100);
        h.frames(40);
        T.near(0, hud.scroll, 0.5, "scrolling stops at the top");
        h.gui.in.scroll(-500);
        h.frames(60);
        T.check(hud.scroll <= hud.maxScroll(view) + 0.5, "scrolling stops at the bottom");

        // z-order
        h.wait(40);
        UiWindow vis = h.window("visual");
        h.click(vis.x + 60, vis.y + 12);
        T.check(h.gui.windows().get(h.gui.windows().size() - 1) == vis, "clicking a window brings it to the front");

        // chips
        GuiHarness c = fresh();
        c.clickChip("Utility");
        c.frames(40);
        UiWindow util = c.window("utility");
        T.check(util.visible, "a chip shows its window");
        boolean clash = false;
        for (UiWindow o : c.gui.windows()) if (o != util && o.visible && overlap(util, o)) clash = true;
        T.check(!clash, "a newly shown window is placed in free space");
        c.clickChip("Utility");
        T.check(!util.visible, "clicking the chip again hides it");
        c.frames(30);
        T.check(!c.has("Chat Tools"), "hidden windows stop drawing");
    }

    // ================================================================== layout persistence
    private static void layoutPersistence() throws IOException {
        T.section("GUI: layout persistence");
        GuiHarness h = fresh();
        h.window("hud").x = 100;
        h.window("hud").y = 90;
        h.window("hud").w = 260;
        h.window("hud").collapsed = true;
        h.window("visual").userSized = true;
        h.window("visual").userH = 150;
        h.window("utility").visible = true;
        h.click(h.window("visual").x + 40, h.window("visual").y + 12);   // bring Visual to the front
        JsonObject j = h.gui.layoutToJson();

        GuiHarness g = new GuiHarness(640, 360);
        g.gui.layoutFromJson(j);
        g.frames(20);
        for (String id : new String[]{"hud", "visual", "utility", "profiles"}) {
            UiWindow a = h.window(id), b = g.window(id);
            T.check(a.x == b.x && a.y == b.y && a.w == b.w && a.visible == b.visible && a.collapsed == b.collapsed && a.userSized == b.userSized,
                    "layout round trip: " + id);
        }
        T.eq(150, g.window("visual").userH, "custom height round trip");
        T.eq(h.gui.windows().get(h.gui.windows().size() - 1).id, g.gui.windows().get(g.gui.windows().size() - 1).id, "z-order round trip");

        // hostile input
        GuiHarness w = new GuiHarness(640, 360);
        JsonObject bad = JsonParser.parseString("{\"hud\":{\"x\":\"abc\",\"w\":99999,\"visible\":\"yes\",\"h\":-50},\"visual\":[1,2],\"_order\":[1,null,\"nope\",\"hud\"],\"zzz\":{}}").getAsJsonObject();
        w.gui.layoutFromJson(bad);
        w.frames(10);
        T.eq(UiWindow.MAX_W, w.window("hud").w, "oversized width is clamped on load");
        T.check(w.window("hud").userH >= UiWindow.MIN_H, "negative height is clamped on load");
        w.gui.layoutFromJson(null);
        w.gui.layoutFromJson(new JsonObject());
        w.frames(3);
        T.check(true, "null and empty layouts are ignored");
    }

    // ================================================================== profiles window
    private static void profilesPanel() throws IOException {
        T.section("GUI: profiles window");
        GuiHarness h = fresh(480);
        h.clickText("Profiles");
        h.solo("profiles");
        T.check(h.window("profiles").visible && h.has("ACTIVE PROFILE") && h.has("Default"), "profiles window opens with the active profile");

        h.clickText("New");
        T.check(h.cv.findPrefix("Name must be") != null, "creating without a name explains what is wrong");

        var box = h.text("Name for New / Rename / Copy");
        h.click(box.x() + 3, box.y() + 3);
        h.type("a/b?c");
        T.check(h.has("abc"), "characters that are not allowed in profile names are filtered out");
        h.key(KeyNames.A, Input.MOD_CTRL);
        h.type("Work");
        h.clickText("New");
        T.check(h.profiles.list().contains("Work"), "New creates a profile");
        T.check(h.cv.findPrefix("Created Work") != null, "status line confirms it");

        h.clickLast("Work");
        h.clickText("Load");
        T.eq("Work", h.profiles.active(), "Load switches profile");
        T.check(h.toasts.stream().anyMatch(s -> s.contains("loaded")), "loading shows a toast");
        h.fps.setEnabled(true);   // (the module windows are hidden here, so flip it directly)
        h.requestSave();
        h.frame();

        h.clickLast("Default");
        h.clickText("Load");
        T.eq("Default", h.profiles.active(), "switching back works");
        T.check(!h.fps.isEnabled(), "each profile keeps its own settings");
        h.clickLast("Work");
        h.clickText("Load");
        T.check(h.fps.isEnabled(), "settings come back when a profile is loaded again");

        h.clickText("Copy");
        T.check(h.profiles.list().contains("Work copy"), "Copy duplicates the selected profile");
        h.clickLast("Work copy");
        h.clickText("Delete");
        T.check(h.has("Sure?") && h.profiles.list().contains("Work copy"), "Delete asks for a second click");
        h.clickText("Sure?");
        T.check(!h.profiles.list().contains("Work copy"), "the second click deletes");

        h.clickLast("Work");
        h.clickText("Delete");
        h.clickText("Sure?");
        T.check(h.profiles.list().contains("Work") && h.cv.findPrefix("The active profile cannot be deleted") != null, "the active profile cannot be deleted");

        h.clickText("Export");
        T.check(h.clipboard.startsWith("REAPER1:"), "Export puts profile text on the clipboard");
        int n = h.profiles.list().size();
        h.clickText("Import");
        T.eq(n + 1, h.profiles.list().size(), "Import creates a new profile");
        h.clipboard = "garbage";
        h.clickText("Import");
        T.check(h.cv.findPrefix("Clipboard does not hold") != null, "importing junk is refused politely");
        T.eq(n + 1, h.profiles.list().size(), "...and creates nothing");

        h.clickText("Rename");
        T.check(h.cv.findPrefix("Cannot rename") != null, "renaming without a name is refused");

        // two-click confirmation expires
        GuiHarness r = fresh(640);
        r.policy.setContext(new ServerPolicy.Context(true, ""));
        r.clickText("Client");
        r.solo("client");
        r.fpsScale.set(2.0);
        r.clickText("Reset all settings");
        T.check(r.has("Click again to reset everything") && r.fpsScale.v() == 2.0, "reset asks for confirmation");
        for (int i = 0; i < 260; i++) r.frame();   // > 3 seconds
        T.check(r.has("Reset all settings") && !r.has("Click again to reset everything"), "the confirmation expires");
        r.clickText("Reset all settings");
        r.clickText("Click again to reset everything");
        T.near(1.0, r.fpsScale.v(), 1e-9, "confirming resets every setting");
    }

    // ================================================================== server rules
    private static void serverRules() throws IOException {
        T.section("GUI: server rules");
        GuiHarness h = fresh(640);
        h.clickText("Client");
        h.solo("client");
        T.check(h.has("Singleplayer: everything is available."), "singleplayer shows that everything is available");
        T.check(!h.has("Strict"), "no rule buttons in singleplayer");

        h.policy.setContext(new ServerPolicy.Context(false, "play.example.com"));
        h.frames(10);
        T.check(h.has("Server: play.example.com") && h.has("Standard") && h.has("Strict") && h.has("Open"), "multiplayer shows the three rule buttons");
        h.fullbright.setEnabled(true);
        h.bridge.setEnabled(true);
        T.check(h.fullbright.isActive() && !h.bridge.isActive(), "Standard allows fullbright, blocks automation");
        h.clickText("Strict");
        T.eq(ServerMode.STRICT, h.policy.mode(), "Strict button sets Strict");
        T.check(!h.fullbright.isActive() && h.fullbright.isBlockedByPolicy(), "Strict switches fullbright off");
        T.check(h.fullbright.isEnabled(), "...without forgetting the user's choice");
        T.check(h.cv.findPrefix("Off here:") != null, "the list of disabled features is shown");
        h.clickText("Open");
        T.check(h.bridge.isActive() && h.fullbright.isActive(), "Open allows everything");
        T.check(h.policy.hosts().contains("play.example.com"), "the rule is remembered per server");
        h.frames(5);
        T.check(h.has("Saved rules"), "saved rules are listed");
        h.clickText("x");
        T.check(h.policy.hosts().isEmpty() && h.policy.mode() == ServerMode.STANDARD, "a saved rule can be removed");

        h.clickText("Disable all modules");
        T.check(!h.fullbright.isEnabled() && !h.bridge.isEnabled() && !h.coords.isEnabled(), "Disable all turns every module off");
        T.check(h.toasts.stream().anyMatch(s -> s.contains("turned off")), "...and says how many");

        h.policy.setContext(ServerPolicy.Context.NONE);
        h.frames(5);
        T.check(h.has("Join a server to set its rules."), "not in a world: explains how to set rules");

        // the top-bar shortcut opens the Client window at the server rules
        GuiHarness s = fresh(360);
        s.policy.setContext(new ServerPolicy.Context(false, "play.example.com"));
        s.frames(5);
        T.check(!s.window("client").visible, "Client window starts hidden");
        s.clickText("Server rules: Standard");
        s.frames(60);
        T.check(s.window("client").visible, "clicking the server mode in the top bar opens the Client window");
        T.check(s.window("client").scroll > 20, "...scrolled to the server rules");
        T.check(s.has("SERVER RULES"), "...which are visible");
    }

    // ================================================================== tooltips, scale, animations, closing
    private static void tooltipsScaleAnimationsClose() throws IOException {
        T.section("GUI: tooltips, scale, animations, closing");
        GuiHarness h = fresh();
        var d = h.text("Fullbright");
        h.move(d.x() + 5, d.y() + 4);
        for (int i = 0; i < 60; i++) h.frame();
        T.check(h.has("Brightens dark areas."), "hovering a module shows its description");
        h.move(5, 300);
        h.frames(5);
        T.check(!h.has("Brightens dark areas."), "moving away hides the tooltip");
        h.iface.tooltips.set(false);
        h.move(d.x() + 5, d.y() + 4);
        for (int i = 0; i < 60; i++) h.frame();
        T.check(!h.has("Brightens dark areas."), "tooltips can be turned off");

        GuiHarness s = fresh();
        int wAt1 = s.text("Fullbright").w();
        s.iface.scale.set(1.5);
        s.frames(10);
        var fb = s.text("Fullbright");
        T.check(fb.w() > wAt1, "a bigger scale draws bigger (" + wAt1 + " -> " + fb.w() + ")");
        s.click(fb.x() + fb.w() / 2.0, fb.y() + 4);
        T.check(s.fullbright.isEnabled(), "clicks land correctly at GUI scale 1.5");
        s.iface.scale.set(0.75);
        s.frames(10);
        fb = s.text("Fullbright");
        T.check(fb.w() < wAt1, "a smaller scale draws smaller (" + wAt1 + " -> " + fb.w() + ")");
        s.click(fb.x() + fb.w() / 2.0, fb.y() + 4);
        T.check(!s.fullbright.isEnabled(), "clicks land correctly at GUI scale 0.75");

        GuiHarness a = new GuiHarness(640, 360, false);
        a.iface.animations.set(false);
        a.gui.onOpen();
        a.frame();
        T.check(a.cv.pixel(320, 200) != 0xFF000000, "with animations off the first frame is already fully drawn");
        T.check(a.has("FPS Counter"), "...including the rows");
        a.gui.requestClose();
        a.frame();
        T.check(a.gui.isClosed(), "with animations off closing is immediate");

        GuiHarness c = fresh();
        T.check(!c.gui.isClosing() && !c.gui.isClosed(), "open screen is not closing");
        c.gui.requestClose();
        int frames = 0;
        while (!c.gui.isClosed() && frames < 120) { c.frame(); frames++; }
        T.check(c.gui.isClosed() && frames > 2 && frames < 60, "closing fades out within a second (" + frames + " frames)");
        c.gui.onOpen();
        c.frames(30);
        T.check(!c.gui.isClosed() && c.has("FPS Counter"), "reopening works after closing");
    }

    // ================================================================== memory: state maps stay bounded
    private static void leaks() throws IOException {
        T.section("GUI: no per-frame leaks");
        GuiHarness h = fresh(640);
        h.policy.setContext(new ServerPolicy.Context(false, "play.example.com"));
        h.policy.setMode("a.example.org", ServerMode.STRICT);
        h.policy.setMode("b.example.org", ServerMode.OPEN);
        h.clickText("Client");
        h.clickText("Profiles");
        h.clickText("Utility");
        h.rightClickText("FPS Counter");
        h.frames(60);
        h.fast = true;   // the rest only inspects state, so nothing needs painting
        for (int i = 0; i < 700; i++) h.frame();
        int warm = h.gui.ui.stateCount();
        for (int i = 0; i < 2500; i++) h.frame();
        int later = h.gui.ui.stateCount();
        T.check(later <= warm + 2, "widget state does not grow while idle (" + warm + " -> " + later + ")");
        // churn: open and close things many times
        for (int i = 0; i < 200; i++) {
            h.rightClickText("FPS Counter");
            h.frames(2);
        }
        h.frames(700);
        T.check(h.gui.ui.stateCount() <= warm + 6, "state stays bounded after lots of interaction (" + h.gui.ui.stateCount() + ")");
    }

    // ================================================================== TextField
    private static void textFieldUnit() {
        T.section("TextField");
        String[] clip = {""};
        TextField.Clipboard cb = new TextField.Clipboard() {
            @Override public String get() { return clip[0]; }
            @Override public void set(String s) { clip[0] = s; }
        };
        TextField f = new TextField();
        f.maxLen = 8;
        for (char ch : "hello".toCharArray()) f.type(ch);
        T.eq("hello", f.text(), "typing appends");
        T.check(!f.type('\n') && !f.type(7), "control characters are rejected");
        f.type(' ');
        f.type('w');
        f.type('o');
        T.check(!f.type('r'), "maxLen is enforced");
        T.eq("hello wo", f.text(), "text stops at maxLen");

        f.key(KeyNames.HOME, 0, cb);
        T.eq(0, f.caret(), "Home");
        f.key(KeyNames.RIGHT, Input.MOD_CTRL, cb);
        T.eq(5, f.caret(), "Ctrl+Right jumps a word");
        f.key(KeyNames.RIGHT, Input.MOD_CTRL, cb);
        T.eq(8, f.caret(), "Ctrl+Right to the end");
        f.key(KeyNames.LEFT, Input.MOD_CTRL, cb);
        T.eq(6, f.caret(), "Ctrl+Left jumps back");
        f.key(KeyNames.END, Input.MOD_SHIFT, cb);
        T.eq("wo", f.selectedText(), "Shift+End selects to the end");
        f.key(KeyNames.C, Input.MOD_CTRL, cb);
        T.eq("wo", clip[0], "Ctrl+C copies the selection");
        f.key(KeyNames.BACKSPACE, 0, cb);
        T.eq("hello ", f.text(), "Backspace deletes the selection");
        f.key(KeyNames.V, Input.MOD_CTRL, cb);
        T.eq("hello wo", f.text(), "Ctrl+V pastes");
        f.key(KeyNames.A, Input.MOD_CTRL, cb);
        f.key(KeyNames.X, Input.MOD_CTRL, cb);
        T.check(f.text().isEmpty() && clip[0].equals("hello wo"), "Ctrl+A then Ctrl+X cuts everything");
        f.paste("line1\nline2 and more");
        T.eq("line1 li", f.text(), "paste turns newlines into spaces and respects maxLen");
        f.setCaret(3, false);
        f.key(KeyNames.DELETE, 0, cb);
        T.eq("lin1 li", f.text(), "Delete removes the character after the caret");
        f.key(KeyNames.DELETE, Input.MOD_CTRL, cb);
        T.eq("lin li", f.text(), "Ctrl+Delete removes the rest of the word");
        f.setCaret(3, false);
        f.key(KeyNames.BACKSPACE, Input.MOD_CTRL, cb);
        T.eq(" li", f.text(), "Ctrl+Backspace removes the word before the caret");
        f.setCaret(99, false);
        T.eq(3, f.caret(), "the caret is clamped to the end");
        f.setCaret(-5, false);
        T.eq(0, f.caret(), "the caret is clamped to the start");

        TextField g = new TextField();
        g.accept = cp -> cp >= '0' && cp <= '9';
        g.type('1');
        g.type('x');
        g.type('2');
        T.eq("12", g.text(), "the accept filter rejects other characters");
        g.setText("123456789012345678901234567890123456789012345678901234567890123456789");
        T.eq(g.maxLen, g.length(), "setText truncates to maxLen");
        g.setText(null);
        T.eq("", g.text(), "setText(null) clears");
        T.check(!g.key(KeyNames.ENTER, 0, cb) && !g.key(KeyNames.ESCAPE, 0, cb), "Enter and Escape are left to the owner");
        TextField e = new TextField();
        T.check(e.type(0x1F600) && e.length() == 2 && e.caret() == 2, "an emoji is stored as one surrogate pair");
        e.type('a');
        e.key(KeyNames.LEFT, 0, cb);
        e.key(KeyNames.LEFT, 0, cb);
        T.eq(0, e.caret(), "Left steps over a whole surrogate pair");
        e.key(KeyNames.RIGHT, 0, cb);
        T.eq(2, e.caret(), "Right steps over a whole surrogate pair");
        e.key(KeyNames.BACKSPACE, 0, cb);
        T.eq("a", e.text(), "Backspace removes a whole surrogate pair");
        e.setText("\uD83D\uDE00");
        e.setCaret(1, false);
        T.eq(0, e.caret(), "the caret never lands inside a surrogate pair");

        // Input queue limits
        Input in = new Input();
        for (int i = 0; i < 500; i++) { in.key(65, 0); in.character('a'); }
        T.check(in.keyCount() <= 64 && in.charCount() <= 64, "input queues are bounded (" + in.keyCount() + "/" + in.charCount() + ")");
        in.consumeKeys();
        T.check(in.keyCount() == 0 && in.charCount() == 0, "consumeKeys empties the queues");
        in.mouseDown(Input.LEFT, 1, 1);
        T.check(in.wasPressed(Input.LEFT) && in.isDown(Input.LEFT), "press is seen");
        in.endFrame();
        T.check(!in.wasPressed(Input.LEFT) && in.isDown(Input.LEFT), "press lasts one frame, down lasts until release");
        in.mouseUp(Input.LEFT, 1, 1);
        T.check(in.wasReleased(Input.LEFT) && !in.isDown(Input.LEFT), "release is seen");
    }

    // ================================================================== Canvas helpers
    private static void canvasHelpers() {
        T.section("Canvas helpers");
        for (int dir = 0; dir < 4; dir++) {
            RasterCanvas c = new RasterCanvas(16, 16, 1);
            c.begin(0x00000000);
            c.arrow(4, 4, 4, dir, 0xFFFFFFFF);
            int n = 0, minX = 99, maxX = -1, minY = 99, maxY = -1;
            for (int y = 0; y < 16; y++)
                for (int x = 0; x < 16; x++)
                    if ((c.img.getRGB(x, y) >>> 24) != 0) { n++; minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
            T.eq(16, n, "arrow size 4 has 16 pixels (dir " + dir + ")");
            boolean horizontal = dir == 0 || dir == 2;
            T.check((horizontal ? maxX - minX + 1 : maxY - minY + 1) == 4 && (horizontal ? maxY - minY + 1 : maxX - minX + 1) == 7, "arrow bounding box is 4 x 7 (dir " + dir + ")");
        }
        RasterCanvas c = new RasterCanvas(24, 24, 1);
        c.begin(0x00000000);
        c.roundRect(2, 2, 12, 12, 3, 0xFFFFFFFF);
        boolean symmetric = true;
        int lit = 0;
        for (int y = 0; y < 12; y++)
            for (int x = 0; x < 12; x++) {
                int a = c.img.getRGB(2 + x, 2 + y), b = c.img.getRGB(2 + 11 - x, 2 + y), d = c.img.getRGB(2 + x, 2 + 11 - y);
                if (a != b || a != d) symmetric = false;
                if ((a >>> 24) != 0) lit++;
            }
        T.check(symmetric, "roundRect is symmetric");
        T.check(lit < 144 && lit > 120, "roundRect cuts its corners (" + lit + " of 144 pixels)");
        c.begin(0x00000000);
        c.roundRect(2, 2, 3, 3, 5, 0xFFFFFFFF);
        T.check((c.img.getRGB(3, 3) >>> 24) != 0, "tiny roundRect still draws something");
        T.eq("Hello", c.fit("Hello", 100), "fit leaves short text alone");
        String fitted = c.fit("A very long module name indeed", 60);
        T.check(fitted.endsWith("...") && c.textWidth(fitted) <= 60, "fit ellipsizes to the width (" + fitted + ")");
        T.eq("", c.fit("Hello", 2), "fit returns an empty string when nothing fits");
    }

    // ================================================================== previews (PNG files when -Dreaper.preview.dir is set)
    private static void previews() throws IOException {
        T.section("GUI previews");
        GuiHarness h = fresh();
        h.preview("01-default");

        h.rightClickText("FPS Counter");
        h.frames(30);
        h.clickText("Text colour");
        h.frames(30);
        h.preview("02-expanded-picker");

        GuiHarness s = fresh();
        s.type("bri");
        s.frames(30);
        s.preview("03-search");

        GuiHarness a = new GuiHarness(960, 440);
        a.frames(10);
        a.clickText("Utility");
        a.clickText("Client");
        a.clickText("Profiles");
        a.frames(40);
        a.preview("04-more-windows");

        GuiHarness m = fresh();
        m.policy.setContext(new ServerPolicy.Context(false, "play.example.com"));
        m.clickText("Client");
        m.frames(30);
        m.clickText("Strict");
        m.frames(30);
        m.preview("05-server-rules");

        GuiHarness d = fresh();
        d.iface.theme.set(InterfaceModule.ThemeName.DAYLIGHT);
        d.frames(40);
        d.rightClickText("Zoom");
        d.frames(30);
        d.preview("06-daylight");
        T.check(true, "previews rendered");
    }
}
