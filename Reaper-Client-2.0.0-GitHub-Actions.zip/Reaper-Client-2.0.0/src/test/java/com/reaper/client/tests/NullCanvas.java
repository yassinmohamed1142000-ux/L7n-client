package com.reaper.client.tests;

import com.reaper.client.core.ui.Canvas;

/** A canvas that draws nothing. Used to measure how much the HUD code itself allocates. */
final class NullCanvas implements Canvas {
    int calls;
    final int w, h;
    NullCanvas(int w, int h) { this.w = w; this.h = h; }
    @Override public int width() { return w; }
    @Override public int height() { return h; }
    @Override public int textWidth(String s) { return Math.max(0, s.length() * 6 - 1); }
    @Override public int lineHeight() { return 9; }
    @Override public void fill(int x, int y, int w, int h, int argb) { calls++; }
    @Override public void gradientV(int x, int y, int w, int h, int topArgb, int bottomArgb) { calls++; }
    @Override public void text(String s, int x, int y, int argb, boolean shadow) { calls++; }
    @Override public void clip(int x, int y, int w, int h) { }
    @Override public void unclip() { }
    @Override public void push() { }
    @Override public void pop() { }
    @Override public void translate(float x, float y) { }
    @Override public void scale(float s) { }
    @Override public void pushAlpha(float a) { }
    @Override public void popAlpha() { }
    @Override public void item(Object stack, int x, int y, boolean decorations) { calls++; }
    @Override public void image(Object texture, int texW, int texH, int x, int y, int w, int h) { calls++; }
}
