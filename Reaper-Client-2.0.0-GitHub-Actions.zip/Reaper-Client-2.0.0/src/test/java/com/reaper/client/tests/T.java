package com.reaper.client.tests;

import java.util.Objects;

/** A tiny assertion helper so the tests need no external test framework. */
public final class T {
    private T() {}

    private static int passed, failed;
    private static String section = "";
    private static long sectionStart = System.nanoTime();

    public static void section(String name) {
        long now = System.nanoTime();
        if (System.getProperty("reaper.timing") != null && !section.isEmpty()) System.out.println("   (" + section + ": " + (now - sectionStart) / 1_000_000 + " ms)");
        section = name;
        sectionStart = now;
        System.out.println("== " + name);
    }

    public static void check(boolean cond, String msg) {
        if (cond) passed++;
        else { failed++; System.out.println("  FAIL [" + section + "] " + msg); }
    }

    public static void eq(Object expected, Object actual, String msg) {
        boolean ok = Objects.equals(expected, actual);
        if (ok) passed++;
        else { failed++; System.out.println("  FAIL [" + section + "] " + msg + "\n       expected: " + expected + "\n       actual:   " + actual); }
    }

    public static void near(double expected, double actual, double eps, String msg) {
        if (Math.abs(expected - actual) <= eps) passed++;
        else { failed++; System.out.println("  FAIL [" + section + "] " + msg + " expected " + expected + " got " + actual); }
    }

    public static void throwsEx(Runnable r, String msg) {
        try { r.run(); failed++; System.out.println("  FAIL [" + section + "] " + msg + " (no exception)"); }
        catch (RuntimeException ex) { passed++; }
    }

    public static int summary() {
        System.out.println("\n" + passed + " checks passed, " + failed + " failed");
        return failed == 0 ? 0 : 1;
    }

    public static int passed() { return passed; }
    public static int failed() { return failed; }
}
