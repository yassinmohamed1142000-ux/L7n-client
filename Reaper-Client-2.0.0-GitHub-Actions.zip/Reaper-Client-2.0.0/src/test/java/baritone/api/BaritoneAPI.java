package baritone.api;

import baritone.api.command.manager.ICommandManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Test stand-in for Baritone's entry point: same package, same name, same static getter. The implementations are
 * deliberately not public (as in the real mod, where they live in the {@code baritone} package), and what they do is
 * steered through {@link Control} so tests can make them fail.
 */
public final class BaritoneAPI {
    private BaritoneAPI() {}

    /** Test steering; not part of Baritone. */
    public static final class Control {
        private Control() {}
        public static final List<String> SENT = new ArrayList<>();
        public static Set<String> known = Set.of("goto", "mine", "stop", "cancel");
        public static boolean throwInExecute;
        public static boolean noPrimary;

        public static void reset() {
            SENT.clear();
            known = Set.of("goto", "mine", "stop", "cancel");
            throwInExecute = false;
            noPrimary = false;
        }
    }

    private static final IBaritoneProvider PROVIDER = new Provider();

    public static IBaritoneProvider getProvider() {
        return PROVIDER;
    }

    private static final class Provider implements IBaritoneProvider {
        private final IBaritone primary = new Impl();

        @Override public IBaritone getPrimaryBaritone() { return Control.noPrimary ? null : primary; }
    }

    private static final class Impl implements IBaritone {
        private final ICommandManager commands = new Commands();

        @Override public ICommandManager getCommandManager() { return commands; }
    }

    private static final class Commands implements ICommandManager {
        @Override public boolean execute(String string) {
            if (Control.throwInExecute) throw new IllegalStateException("player is null");
            Control.SENT.add(string);
            String name = string.trim().split("\\s+")[0];
            return Control.known.contains(name);
        }

        @Override public boolean execute(List<String> expanded) {
            throw new AssertionError("the bridge must call execute(String)");
        }
    }
}
