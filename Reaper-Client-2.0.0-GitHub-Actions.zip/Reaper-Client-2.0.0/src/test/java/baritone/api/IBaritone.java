package baritone.api;

import baritone.api.command.manager.ICommandManager;

/** Test stand-in for Baritone's interface of the same name (only the method Reaper's bridge uses). */
public interface IBaritone {
    ICommandManager getCommandManager();
}
