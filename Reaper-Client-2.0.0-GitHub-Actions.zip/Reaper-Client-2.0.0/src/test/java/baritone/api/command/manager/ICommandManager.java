package baritone.api.command.manager;

import java.util.List;

/**
 * Test stand-in for Baritone's command manager. Like the real one it has two {@code execute} overloads (the real
 * second one takes a Tuple of the command name and its arguments), so the bridge must pick the String one.
 */
public interface ICommandManager {
    boolean execute(String string);

    boolean execute(List<String> expanded);
}
