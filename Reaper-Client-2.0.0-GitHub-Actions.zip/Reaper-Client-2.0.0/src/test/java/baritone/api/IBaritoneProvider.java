package baritone.api;

/** Test stand-in for Baritone's interface of the same name (only the method Reaper's bridge uses). */
public interface IBaritoneProvider {
    IBaritone getPrimaryBaritone();
}
