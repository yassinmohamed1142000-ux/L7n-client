package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.Compass;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.hud.HudFormat;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Canvas;
import com.reaper.client.core.util.Colors;

/** The way you are facing, as a line of text or as a scrolling compass strip. */
public final class DirectionElement extends HudElement {
    public enum Style implements Settings.Labeled {
        COMPASS("Compass strip"), TEXT("Text");
        private final String label;
        Style(String l) { label = l; }
        @Override public String label() { return label; }
    }

    /** Degrees visible across the strip. */
    private static final float SPAN = 120f;

    private final Settings.Choice<Style> style = new Settings.Choice<>("style", "Style", "A scrolling compass strip, or a line of text.", Style.COMPASS);
    private final Settings.Num width = new Settings.Num("width", "Strip width", "Width of the compass strip.", 130, 80, 320, 10, "px");
    private final Settings.Bool degrees = new Settings.Bool("degrees", "Show degrees", "Also show the heading in degrees.", true);
    private final Settings.Bool axis = new Settings.Bool("axis", "Show axis", "Write which world axis you are facing, like +Z.", true);
    private final Settings.Bool longNames = new Settings.Bool("longNames", "Full names", "\"South\" instead of \"S\".", true);

    private String text = "";
    private int kIndex = -1, kDeg = -1;
    private boolean kAxis, kDegrees, kLong;
    private String degText = "";

    public DirectionElement() {
        super("direction", "Direction", "Shows which way you are facing.", true, "compass facing heading north yaw", Anchor.TOP_CENTER, 0, 4);
        add(style);
        add(width);
        width.visibleWhen(() -> style.v() == Style.COMPASS);
        add(degrees);
        add(axis);
        axis.visibleWhen(() -> style.v() == Style.TEXT);
        add(longNames);
        longNames.visibleWhen(() -> style.v() == Style.TEXT);
        commonSettings();
    }

    @Override protected boolean measure(HudContext x) {
        if (!x.d.inWorld && !x.editing) return false;
        float bearing = Compass.bearing(x.d.yaw);
        int deg = Math.round(bearing) % 360;
        if (deg != kDeg) { kDeg = deg; degText = HudFormat.small(deg) + "°"; }
        int lh = x.c.lineHeight();
        if (style.v() == Style.TEXT) {
            int idx = Compass.index(bearing);
            boolean ax = axis.on(), dg = degrees.on(), lg = longNames.on();
            if (idx != kIndex || ax != kAxis || dg != kDegrees || lg != kLong || text.isEmpty()) {
                kIndex = idx; kAxis = ax; kDegrees = dg; kLong = lg;
                String s = lg ? Compass.LONG[idx] : Compass.SHORT[idx];
                if (ax) s += " (" + Compass.AXIS[idx] + ")";
                text = s;
            }
            // the degrees change often, so they are kept out of the cached part
            w = x.c.textWidth(text) + (degrees.on() ? 4 + x.c.textWidth(degText) : 0) + PAD * 2;
            h = lh + PAD * 2 - 1;
            return true;
        }
        w = width.i();
        h = PAD + lh + 1 + 6 + 4 + PAD + (degrees.on() ? lh + 1 : 0);
        return true;
    }

    @Override protected void draw(HudContext x) {
        panel(x);
        Canvas c = x.c;
        float bearing = Compass.bearing(x.d.yaw);
        if (style.v() == Style.TEXT) {
            text(x, text, PAD, PAD, color.argb());
            if (degrees.on()) text(x, degText, PAD + c.textWidth(text) + 4, PAD, x.theme.textDim());
            return;
        }
        int lh = c.lineHeight();
        int cx = w / 2;
        float perDeg = (w - PAD * 2) / SPAN;
        int labelY = PAD, tickTop = PAD + lh + 1;
        c.clip(PAD, 0, w - PAD * 2, h);
        int first = (int) Math.floor((bearing - SPAN / 2) / 5f) * 5, last = (int) Math.ceil((bearing + SPAN / 2) / 5f) * 5;
        for (int a = first; a <= last; a += 5) {
            float rel = Compass.relative(a, bearing);
            float edge = Math.abs(rel) / (SPAN / 2);
            if (edge > 1f) continue;
            float fade = 1f - edge * edge;
            int px = cx + Math.round(rel * perDeg);
            int norm = Math.floorMod(a, 360);
            if (norm % 45 == 0) {
                String lab = Compass.SHORT[(norm / 45) & 7];
                int col = norm == 0 ? x.theme.bad() : (norm % 90 == 0 ? color.argb() : x.theme.textDim());
                c.text(lab, px - c.textWidth(lab) / 2, labelY, Colors.mulAlpha(col, fade), shadow.on());
                c.fill(px, tickTop, 1, 6, Colors.mulAlpha(color.argb(), fade));
            } else if (norm % 15 == 0) {
                c.fill(px, tickTop + 2, 1, 4, Colors.mulAlpha(x.theme.textDim(), fade));
            } else {
                c.fill(px, tickTop + 4, 1, 2, Colors.mulAlpha(x.theme.textDim(), fade * 0.7f));
            }
        }
        c.unclip();
        int markerY = tickTop + 7;
        c.arrow(cx - 2, markerY, 3, 3, x.theme.accent());
        if (degrees.on()) c.centerText(degText, cx, markerY + 5, color.argb(), shadow.on());
    }
}
