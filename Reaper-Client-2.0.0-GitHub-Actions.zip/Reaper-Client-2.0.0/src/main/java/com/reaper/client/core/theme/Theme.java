package com.reaper.client.core.theme;

import com.reaper.client.core.util.Colors;

/** A complete GUI/HUD colour palette. All values are 0xAARRGGBB. */
public record Theme(String id, String name, boolean dark,
                    int panel, int header, int row, int rowHover, int field, int outline,
                    int text, int textDim,
                    int accent, int accent2,
                    int good, int warn, int bad) {

    /** Same palette with a user-picked accent colour (accent2 becomes a hue-shifted companion). */
    public Theme withAccent(int accentArgb) {
        float[] hsb = Colors.toHsb(accentArgb, new float[3]);
        int second = Colors.hsb(hsb[0] + 0.09f, Math.min(1f, hsb[1] * 0.85f), Math.min(1f, hsb[2] + 0.1f));
        return new Theme(id, name, dark, panel, header, row, rowHover, field, outline, text, textDim,
                accentArgb | 0xFF000000, second, good, warn, bad);
    }

    /** Text colour that is readable on top of the accent. */
    public int onAccent() { return Colors.onColor(accent); }

    /** Backdrop drawn behind the whole ClickGUI. */
    public int backdrop() { return dark ? 0x99060810 : 0x66202838; }

    /** Soft drop shadow colour. */
    public int shadow() { return dark ? 0x55000000 : 0x22000000; }
}
