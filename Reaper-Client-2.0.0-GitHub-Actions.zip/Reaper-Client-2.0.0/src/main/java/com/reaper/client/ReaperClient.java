package com.reaper.client;

import com.reaper.client.mc.Game;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.LoggerFactory;

/**
 * The mod's entry point. It only starts {@link Game}; if that fails for any reason (for example after a game update
 * changed something Reaper relies on) the failure is logged, the player is told once in the chat, and the game carries on
 * without Reaper instead of crashing.
 */
public final class ReaperClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        try {
            Game.init();
        } catch (Throwable t) {
            try {
                Game.initFailed(t);
            } catch (Throwable inner) {
                LoggerFactory.getLogger("Reaper").error("Reaper could not start and stays switched off. The game itself is not affected.", t);
            }
        }
    }
}
