package com.reaper.client.mc;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * The key bindings Reaper adds to the game's Controls screen, under their own "Reaper" heading. Module keys (the ones set
 * in the Reaper menu next to each module) are separate: those are polled by the core's {@code KeyTracker}.
 */
final class ClientKeys {
    private ClientKeys() {}

    private static KeyMapping menu, zoom, hudEditor, waypoint;

    /** Registers the four bindings. Call once, while the mod initialises. */
    static void register() {
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("reaper", "main"));
        menu = add("key.reaper.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, category);
        zoom = add("key.reaper.zoom", GLFW.GLFW_KEY_Z, category);
        hudEditor = add("key.reaper.hud_editor", GLFW.GLFW_KEY_UNKNOWN, category);
        waypoint = add("key.reaper.waypoint", GLFW.GLFW_KEY_UNKNOWN, category);
    }

    private static KeyMapping add(String name, int key, KeyMapping.Category category) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping(name, InputConstants.Type.KEYSYM, key, category));
    }

    /** Opens and closes the Reaper menu. */
    static KeyMapping menu() { return menu; }

    /** Held to zoom. */
    static KeyMapping zoom() { return zoom; }

    /** Opens the HUD editor. Unbound by default. */
    static KeyMapping hudEditor() { return hudEditor; }

    /** Adds a waypoint where the player stands. Unbound by default. */
    static KeyMapping waypoint() { return waypoint; }

    /**
     * The code of the key currently bound to the menu binding, or -1 when it is unbound. A mouse button has a small
     * code that no keyboard key shares (keyboard codes start at 32), so comparing it with a pressed key is safe.
     */
    static int menuKey() {
        try {
            if (menu == null) return -1;
            return KeyMappingHelper.getBoundKeyOf(menu).getValue();
        } catch (RuntimeException ex) {
            return -1;
        }
    }
}
