package com.reaper.client.core.ui;

import com.reaper.client.core.feature.Waypoint;
import com.reaper.client.core.feature.WaypointStore;
import com.reaper.client.core.feature.WaypointsModule;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.util.Colors;
import com.reaper.client.core.util.Text;

import java.util.List;

/** The Waypoints window of the ClickGUI: the list for the current world with add, rename, colour, copy and delete. */
public final class WaypointsPanel {
    private static final int ROW = 20;

    private final WaypointsModule mod;
    private final GuiHost host;
    private final PanelKit kit = new PanelKit();
    private final Object nameKey = new Object();
    private Waypoint selected;
    private String name = "";

    public WaypointsPanel(WaypointsModule mod, GuiHost host) {
        this.mod = mod;
        this.host = host;
    }

    public UiWindow window() { return new UiWindow("waypoints", "Waypoints", this::draw); }

    public Waypoint selected() { return selected; }

    /** Draws the body and handles clicks. Returns the content height. */
    public int draw(Ui ui, UiWindow win, int x, int y, int w, int viewH) {
        Canvas c = ui.c;
        Theme t = ui.theme;
        Input in = ui.in;
        WaypointStore store = mod.store();
        int cy = y;
        c.text("THIS WORLD", x + 4, cy + 2, Colors.withAlpha(t.accent(), 0xDD), false);
        cy += 14;
        String ctx = store.context();
        if (ctx == null) {
            c.text(c.fit("Join a world to use waypoints.", w - 8), x + 6, cy, t.textDim(), false);
            return cy + 14 - y;
        }
        c.text(c.fit(ctx, w - 8), x + 6, cy, t.text(), false);
        cy += 14;
        if (mod.hiddenByServer()) {
            c.text(c.fit("This server hides coordinates.", w - 8), x + 6, cy, t.warn(), false);
            cy += 12;
        } else if (mod.isBlockedByPolicy()) {
            c.text(c.fit("Markers are off by the server rules.", w - 8), x + 6, cy, t.warn(), false);
            cy += 12;
        } else if (!mod.isEnabled()) {
            c.text(c.fit("The Waypoints module is switched off.", w - 8), x + 6, cy, t.textDim(), false);
            cy += 12;
        }
        cy += 2;

        List<Waypoint> list = store.list();
        if (selected != null && !list.contains(selected)) selected = null;
        if (list.isEmpty()) {
            c.text("No waypoints yet.", x + 6, cy + 2, t.textDim(), false);
            cy += 18;
        }
        int top = y + Math.round(win.scroll);
        for (int i = 0; i < list.size(); i++) {
            Waypoint wp = list.get(i);
            if (cy + ROW + 2 < top - 4 || cy > top + viewH + 4) { cy += ROW + 2; continue; }   // not on screen: skip the drawing
            Ui.WState st = ui.stTransient(wp);
            boolean hov = ui.over(x, cy, w, ROW), sel = wp == selected;
            st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
            st.aux = ui.ease(st.aux, sel ? 1f : 0f, 16f);
            c.roundRect(x, cy, w, ROW, 3, Colors.lerp(t.row(), t.rowHover(), Math.max(st.hover * 0.8f, st.aux)));
            if (sel) c.outline(x, cy, w, ROW, Colors.withAlpha(t.accent(), 0x99));
            // visibility box
            int bx = x + w - 17, by = cy + 4;
            boolean overBox = ui.over(bx - 1, by - 1, 14, 14);
            c.outline(bx, by, 12, 12, overBox ? t.text() : t.textDim());
            if (wp.visible) c.fill(bx + 3, by + 3, 6, 6, wp.color);
            if (overBox) ui.tip(wp.name + "-vis", bx, by, 12, 12, wp.visible ? "Shown. Click to hide." : "Hidden. Click to show.");
            c.disc(x + 9, cy + ROW / 2, 3, wp.color);
            double dist = mod.distanceTo(wp);
            String ds = dist < 0 ? "" : WaypointsModule.formatDistance(dist);
            int dw = ds.isEmpty() ? 0 : c.textWidth(ds) + 6;
            c.text(c.fit(wp.name, w - 18 - 24 - dw), x + 18, cy + 6, sel || hov ? t.text() : t.textDim(), false);
            if (!ds.isEmpty()) c.rightText(ds, x + w - 22, cy + 6, t.textDim(), false);
            if (in.wasPressed(Input.LEFT)) {
                if (overBox) { store.setVisible(wp, !wp.visible); host.requestSave(); }
                else if (hov) { if (selected != wp) kit.disarm(); selected = wp; }
            }
            cy += ROW + 2;
        }
        cy += 4;

        if (selected != null) {
            String dim = Text.prettyId(selected.dimension);
            c.text(c.fit(selected.coordinates() + "   " + dim, w - 8), x + 6, cy, t.textDim(), false);
            cy += 13;
        }

        name = kit.edit(ui, nameKey, x, cy, w, 20, name, "Name for Add / Rename", Waypoint.MAX_NAME, Text::isPrintable);
        boolean enter = kit.submitted();
        cy += 25;

        int bw = (w - 4) / 2;
        boolean addClicked = ui.button("wp-add", x, cy, bw, 20, "Add here", true, false);
        if (addClicked || enter) addHere();
        if (ui.button("wp-rename", x + bw + 4, cy, bw, 20, "Rename", false, false)) {
            if (need()) {
                if (store.rename(selected, name)) { kit.say("Renamed to " + selected.name, false); name = ""; host.requestSave(); }
                else kit.say("Names are 1 to " + Waypoint.MAX_NAME + " characters.", true);
            }
        }
        cy += 24;
        if (ui.button("wp-color", x, cy, bw, 20, "Colour", false, false) && need()) {
            store.setColor(selected, WaypointsModule.nextColor(selected.color));
            host.requestSave();
        }
        if (ui.button("wp-copy", x + bw + 4, cy, bw, 20, "Copy XYZ", false, false) && need()) {
            ui.clipboard.set(selected.coordinates());
            kit.say("Copied " + selected.coordinates(), false);
            host.toast(Level.SUCCESS, "Copied " + selected.coordinates());
        }
        cy += 24;
        String delKey = "wp-del";
        boolean delArmed = kit.armed(ui, delKey);
        boolean delClicked = ui.button("wp-delete", x, cy, bw, 20, delArmed ? "Sure?" : "Delete", false, true);
        if (delClicked && !need()) delClicked = false;
        if (kit.twoClick(ui, delKey, delClicked)) {
            String n = selected.name;
            store.remove(selected);
            selected = null;
            kit.say("Deleted " + n, false);
            host.requestSave();
        }
        String clearKey = "wp-clear";
        boolean clearArmed = kit.armed(ui, clearKey);
        if (kit.twoClick(ui, clearKey, ui.button("wp-clear-btn", x + bw + 4, cy, bw, 20, clearArmed ? "Sure?" : "Delete all", false, true))) {
            int n = store.count();
            if (n > 0) { store.removeAllHere(); selected = null; kit.say("Deleted " + n + " waypoints", false); host.requestSave(); }
        }
        cy += 26;
        cy += kit.status(ui, x, cy, w);
        return cy - y;
    }

    private boolean need() {
        if (selected == null) { kit.say("Select a waypoint in the list first.", true); return false; }
        return true;
    }

    private void addHere() {
        Waypoint w = mod.addHere(name);
        if (w == null) { kit.say(mod.problem(), true); return; }
        selected = w;
        name = "";
        kit.say("Added " + w.name + " at " + w.coordinates(), false);
        host.requestSave();
    }
}
