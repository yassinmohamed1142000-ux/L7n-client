package com.reaper.client.core.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.nio.file.Path;

/**
 * Values that are NOT part of a profile: which profile is active, where the GUI windows sit, per-server rules,
 * and one safety value for Fullbright. Stored in {@code client.json}.
 */
public final class ClientConfig {
    public static final int SCHEMA = 1;

    public String activeProfile = ProfileStore.DEFAULT_NAME;
    /** Window positions etc., owned by the GUI model. */
    public JsonObject windows = new JsonObject();
    /** Per-server rules, owned by ServerPolicy. */
    public JsonObject serverRules = new JsonObject();
    /** The player's own brightness before Fullbright changed it; restored on disable and after a crash. NaN = none. */
    public double restoreGamma = Double.NaN;
    public boolean welcomed;

    private final Path file;

    public ClientConfig(Path root) { this.file = root.resolve("client.json"); }

    public void load() {
        JsonObject o = JsonIO.readObject(file);
        if (o == null) return;
        activeProfile = str(o, "activeProfile", activeProfile);
        windows = obj(o, "windows");
        serverRules = obj(o, "serverRules");
        JsonElement g = o.get("restoreGamma");
        restoreGamma = g != null && g.isJsonPrimitive() && g.getAsJsonPrimitive().isNumber() ? g.getAsDouble() : Double.NaN;
        JsonElement w = o.get("welcomed");
        welcomed = w != null && w.isJsonPrimitive() && w.getAsJsonPrimitive().isBoolean() && w.getAsBoolean();
    }

    public boolean save() {
        JsonObject o = new JsonObject();
        o.addProperty("schema", SCHEMA);
        o.addProperty("activeProfile", activeProfile);
        o.add("windows", windows);
        o.add("serverRules", serverRules);
        if (!Double.isNaN(restoreGamma)) o.addProperty("restoreGamma", restoreGamma);
        o.addProperty("welcomed", welcomed);
        return JsonIO.writeAtomic(file, o);
    }

    private static String str(JsonObject o, String k, String def) {
        JsonElement e = o.get(k);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isString() ? e.getAsString() : def;
    }

    private static JsonObject obj(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e != null && e.isJsonObject() ? e.getAsJsonObject() : new JsonObject();
    }
}
