package com.reaper.client.core.feature;

import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.setting.Settings;

/**
 * Hold a key to zoom in, like a spyglass. The module only decides how far to zoom and turns that into a field of
 * view; the game layer feeds it the key state and applies the result. Only changes what you see, sends nothing.
 */
public final class ZoomModule extends Module {
    public static final double MIN_FACTOR = 1.5, MAX_FACTOR = 30;

    public final Settings.Num factor = new Settings.Num("factor", "Zoom factor", "How many times closer things look.", 4.0, MIN_FACTOR, MAX_FACTOR, 0.5, "x");
    public final Settings.Bool smooth = new Settings.Bool("smooth", "Smooth zoom", "Glide in and out instead of jumping.", true);
    public final Settings.Num speed = new Settings.Num("speed", "Zoom speed", "How quickly the zoom changes.", 14, 2, 40, 1, "");
    public final Settings.Bool scroll = new Settings.Bool("scroll", "Scroll to adjust", "Use the mouse wheel while zooming to change the zoom factor.", true);
    public final Settings.Bool cinematic = new Settings.Bool("cinematic", "Steadier camera", "Lowers the mouse sensitivity while zoomed in, so small movements stay easy to control.", true);

    private float cur = 1f;
    private boolean held;

    public ZoomModule() {
        super("zoom", "Zoom", "Hold a key to zoom in on distant things.", Category.VISUAL, true, true, "spyglass telescope optifine fov");
        feature(Feature.ZOOM);
        add(factor);
        add(smooth);
        add(speed);
        speed.visibleWhen(smooth::on);
        add(scroll);
        add(cinematic);
    }

    public void setHeld(boolean h) { held = h; }

    public boolean held() { return held; }

    /** True when the zoom key is down, the module is on and the server rules allow it. */
    public boolean wantsZoom() { return held && isActive(); }

    /** Moves the current zoom towards its target. Call once per frame. */
    public void update(float dt) {
        float target = wantsZoom() ? factor.f() : 1f;
        if (!smooth.on() || dt <= 0f && cur == target) { cur = target; return; }
        float k = 1f - (float) Math.exp(-speed.f() * Math.min(dt, 0.25f));
        float ln = (float) Math.log(cur), lt = (float) Math.log(target);
        cur = (float) Math.exp(ln + (lt - ln) * k);
        if (Math.abs(cur - target) < 0.002f) cur = target;
    }

    /** The current magnification: 1 when not zooming. */
    public float zoom() { return cur; }

    public boolean zooming() { return cur > 1.001f; }

    /** The field of view (degrees) to use instead of {@code baseDegrees}. Zooms by true magnification, not by dividing the angle. */
    public double fov(double baseDegrees) {
        if (cur <= 1.001f) return baseDegrees;
        double half = Math.toRadians(baseDegrees) / 2.0;
        return Math.toDegrees(2.0 * Math.atan(Math.tan(half) / cur));
    }

    /** Mouse wheel while zooming. Returns true when the wheel was used (so the hotbar must not scroll). */
    public boolean onScroll(double dy) {
        if (dy == 0 || !wantsZoom() || !scroll.on()) return false;
        double step = Math.max(0.5, Math.round(factor.v() * 0.1 * 2.0) / 2.0);
        factor.set(factor.v() + (dy > 0 ? step : -step));
        return true;
    }

    /** Whether the mouse sensitivity should be lowered right now. */
    public boolean cinematicWanted() { return zooming() && cinematic.on(); }

    /** Forgets the held state and the zoom, e.g. when a screen opens or the world changes. */
    public void reset() { held = false; cur = 1f; }
}
