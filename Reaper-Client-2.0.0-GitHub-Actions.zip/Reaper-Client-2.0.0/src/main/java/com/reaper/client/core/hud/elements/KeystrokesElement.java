package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.hud.HudFormat;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Canvas;
import com.reaper.client.core.util.Anim;
import com.reaper.client.core.util.Colors;

/** WASD, jump and the mouse buttons, lighting up as you press them. Shows what you are pressing, nothing else. */
public final class KeystrokesElement extends HudElement {
    private final Settings.Bool jump = new Settings.Bool("jump", "Jump bar", "Show the jump key as a wide bar.", true);
    private final Settings.Bool sneak = new Settings.Bool("sneak", "Sneak bar", "Show the sneak key as a wide bar.", false);
    private final Settings.Bool mouse = new Settings.Bool("mouse", "Mouse buttons", "Show the left and right mouse buttons.", true);
    private final Settings.Bool showCps = new Settings.Bool("showCps", "Clicks per second", "Show the click rate on each mouse button.", true);
    private final Settings.Num keySize = new Settings.Num("keySize", "Key size", "Width and height of the letter keys.", 18, 14, 28, 1, "px");
    private final Settings.Num gap = new Settings.Num("gap", "Gap", "Space between keys.", 2, 0, 6, 1, "px");
    private final Settings.Color keyColor = new Settings.Color("keyColor", "Key colour", "Colour of a key that is not pressed.", 0x66000000, true);
    private final Settings.Color pressedColor = new Settings.Color("pressedColor", "Pressed colour", "Colour of a key while it is held down.", 0xCCFFFFFF, true);
    private final Settings.Num fade = new Settings.Num("fade", "Animation speed", "How quickly keys light up and fade. 0 switches instantly.", 22, 0, 40, 1, "");

    private final Anim[] anims = new Anim[HudData.KEY_COUNT];
    private int kw, kh;   // computed layout, see layout()

    public KeystrokesElement() {
        super("keystrokes", "Keystrokes", "Shows the movement keys and mouse buttons you are pressing.", false, "wasd keys input mouse", Anchor.BOTTOM_LEFT, 4, 4, false);
        add(jump);
        add(sneak);
        add(mouse);
        add(showCps);
        showCps.visibleWhen(mouse::on);
        add(keySize);
        add(gap);
        add(keyColor);
        add(pressedColor);
        add(fade);
        commonSettings();
        for (int i = 0; i < anims.length; i++) anims[i] = new Anim();
    }

    /** 0 (released) to 1 (fully lit) for one key, as last animated. */
    public float keyProgress(int key) { return anims[key].value; }

    private int spaceH() { return Math.max(10, keySize.i() * 2 / 3); }
    private int mouseH() { return keySize.i() + (showCps.on() ? 6 : 0); }

    @Override protected boolean measure(HudContext x) {
        if (!x.d.inWorld && !x.editing) return false;
        int ks = keySize.i(), g = gap.i();
        w = ks * 3 + g * 2;
        h = ks * 2 + g;
        if (jump.on()) h += g + spaceH();
        if (sneak.on()) h += g + spaceH();
        if (mouse.on()) h += g + mouseH();
        // animate towards the real key state, once per frame
        float speed = fade.f();
        for (int i = 0; i < anims.length; i++) {
            Anim a = anims[i];
            a.set(x.d.keys[i] ? 1f : 0f);
            if (speed <= 0f) a.snap(a.target); else a.update(x.dt, speed);
        }
        return true;
    }

    private void key(HudContext x, int idx, String label, int kx, int ky, int kw, int kh, String sub) {
        Canvas c = x.c;
        float t = anims[idx].value;
        int bg = Colors.lerp(keyColor.argb(), pressedColor.argb(), t);
        c.roundRect(kx, ky, kw, kh, 2, bg);
        if (t < 0.5f) c.outline(kx, ky, kw, kh, Colors.withAlpha(0xFFFFFF, Math.round(0x22 * (1f - t * 2f))));
        int fg = Colors.lerp(color.argb(), Colors.onColor(pressedColor.argb()), t);
        String shown = c.fit(label, kw - 2);
        if (sub == null) {
            c.text(shown, kx + (kw - c.textWidth(shown)) / 2, ky + (kh - c.lineHeight()) / 2 + 1, fg, shadow.on() && t < 0.5f);
        } else {
            int top = ky + (kh - c.lineHeight() * 2) / 2 + 1;
            c.text(shown, kx + (kw - c.textWidth(shown)) / 2, top, fg, shadow.on() && t < 0.5f);
            c.text(sub, kx + (kw - c.textWidth(sub)) / 2, top + c.lineHeight(), Colors.lerp(x.theme.textDim(), fg, t), false);
        }
    }

    @Override protected void draw(HudContext x) {
        panel(x);
        int ks = keySize.i(), g = gap.i();
        String[] lab = x.d.keyLabels;
        key(x, HudData.K_FORWARD, lab[HudData.K_FORWARD], ks + g, 0, ks, ks, null);
        key(x, HudData.K_LEFT, lab[HudData.K_LEFT], 0, ks + g, ks, ks, null);
        key(x, HudData.K_BACK, lab[HudData.K_BACK], ks + g, ks + g, ks, ks, null);
        key(x, HudData.K_RIGHT, lab[HudData.K_RIGHT], (ks + g) * 2, ks + g, ks, ks, null);
        int y = ks * 2 + g * 2;
        if (jump.on()) { key(x, HudData.K_JUMP, lab[HudData.K_JUMP], 0, y, w, spaceH(), null); y += spaceH() + g; }
        if (sneak.on()) { key(x, HudData.K_SNEAK, lab[HudData.K_SNEAK], 0, y, w, spaceH(), null); y += spaceH() + g; }
        if (mouse.on()) {
            int bw = (w - g) / 2;
            boolean cps = showCps.on();
            long now = x.d.nowMs;
            key(x, HudData.M_LEFT, lab[HudData.M_LEFT], 0, y, bw, mouseH(), cps ? HudFormat.small(x.state.clicks.cps(0, now)) : null);
            key(x, HudData.M_RIGHT, lab[HudData.M_RIGHT], bw + g, y, w - bw - g, mouseH(), cps ? HudFormat.small(x.state.clicks.cps(1, now)) : null);
        }
    }
}
