package com.reaper.client.core.module;

/** Module categories. Each one becomes a window in the ClickGUI. */
public enum Category {
    HUD("HUD", "On-screen information"),
    VISUAL("Visual", "Rendering and camera"),
    UTILITY("Utility", "Quality-of-life tools"),
    AUTOMATION("Automation", "Opt-in helpers, server-policy gated"),
    CLIENT("Client", "Interface and general settings");

    public final String label;
    public final String blurb;

    Category(String label, String blurb) { this.label = label; this.blurb = blurb; }
}
