package com.reaper.client.core.hud;

/**
 * Direction maths. Minecraft's yaw is 0 when facing south (+Z), 90 facing west (-X), 180 (or -180) facing north (-Z)
 * and -90 (or 270) facing east (+X). A compass bearing counts clockwise from north, 0..360.
 */
public final class Compass {
    private Compass() {}

    public static final String[] SHORT = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    public static final String[] LONG = {"North", "North-East", "East", "South-East", "South", "South-West", "West", "North-West"};
    /** The world axis each of the eight directions points along. */
    public static final String[] AXIS = {"-Z", "+X -Z", "+X", "+X +Z", "+Z", "-X +Z", "-X", "-X -Z"};

    /** Compass bearing (0..360, clockwise from north) of a player yaw. */
    public static float bearing(float yaw) {
        float b = (yaw + 180f) % 360f;
        return b < 0f ? b + 360f : b;
    }

    /** Index into {@link #SHORT} for a bearing. */
    public static int index(float bearing) {
        float b = bearing % 360f;
        if (b < 0f) b += 360f;
        return ((int) Math.floor((b + 22.5f) / 45f)) & 7;
    }

    /** Bearing of a horizontal offset (dx east, dz south) as seen from the origin. */
    public static float bearingTo(double dx, double dz) {
        double deg = Math.toDegrees(Math.atan2(dx, -dz));
        if (deg < 0) deg += 360.0;
        return (float) deg;
    }

    /** Angle from where the player looks to the target, in (-180, 180]: positive means the target is to the right. */
    public static float relative(float targetBearing, float playerBearing) {
        float d = (targetBearing - playerBearing) % 360f;
        if (d > 180f) d -= 360f;
        if (d <= -180f) d += 360f;
        return d;
    }
}
