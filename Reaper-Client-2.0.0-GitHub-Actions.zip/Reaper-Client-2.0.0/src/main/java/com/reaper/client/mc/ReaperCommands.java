package com.reaper.client.mc;

import com.reaper.client.core.command.CommandCenter;
import com.reaper.client.core.notify.Level;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * The {@code /reaper} client command. It is only a thin shell: the text after {@code /reaper} goes to the core's
 * {@link CommandCenter}, which parses it, does the work and returns lines to show. Client commands are never sent to the
 * server.
 */
final class ReaperCommands {
    private final CommandCenter center;

    ReaperCommands(CommandCenter center) {
        this.center = center;
    }

    void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommands.literal("reaper")
                .executes(context -> run(context.getSource(), ""))
                .then(ClientCommands.argument("args", StringArgumentType.greedyString())
                        .suggests((context, builder) -> suggest(builder))
                        .executes(context -> run(context.getSource(), StringArgumentType.getString(context, "args")))));
    }

    private int run(FabricClientCommandSource source, String line) {
        List<CommandCenter.Reply> replies = center.run(line);
        for (CommandCenter.Reply reply : replies) {
            Component text = format(reply);
            if (reply.level() == Level.ERROR) source.sendError(text);
            else source.sendFeedback(text);
        }
        return 1;
    }

    private CompletableFuture<Suggestions> suggest(SuggestionsBuilder builder) {
        try {
            for (String candidate : center.complete(builder.getRemaining())) builder.suggest(candidate);
        } catch (RuntimeException ex) {
            Game.logError("Command suggestions failed", ex);
        }
        return builder.buildFuture();
    }

    /** "[Reaper] text", with the text coloured by how serious it is. */
    private static Component format(CommandCenter.Reply reply) {
        ChatFormatting colour = switch (reply.level()) {
            case SUCCESS -> ChatFormatting.GREEN;
            case WARN -> ChatFormatting.YELLOW;
            case ERROR -> ChatFormatting.RED;
            default -> ChatFormatting.WHITE;
        };
        MutableComponent line = Component.literal("[Reaper] ").withStyle(ChatFormatting.AQUA);
        return line.append(Component.literal(reply.text()).withStyle(colour));
    }
}
