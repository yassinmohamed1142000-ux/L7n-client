package com.reaper.client.core.ui;

import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.util.Colors;

import java.util.function.IntPredicate;

/**
 * Small helpers the extra ClickGUI windows (Waypoints, Screenshots) share: a status line that fades out, a
 * two-click confirmation for dangerous buttons, and a text box that takes the keyboard when clicked.
 */
public final class PanelKit {
    private String status = "";
    private boolean statusBad;
    private float statusT;
    private String[] wrapped = new String[0];
    private String wrappedFor;
    private int wrappedW = -1;
    private String confirmKey;
    private double confirmUntilMs;
    private boolean submitted;

    /** Shows a message under the buttons for a few seconds. */
    public void say(String msg, boolean bad) {
        status = msg == null ? "" : msg;
        statusBad = bad;
        statusT = 6f;
    }

    public String statusText() { return statusT > 0 ? status : ""; }

    /** Draws the message, wrapped, fading out in its last second. Returns the height used (0 when there is none). */
    public int status(Ui ui, int x, int y, int w) {
        if (statusT <= 0 || status.isEmpty()) return 0;
        statusT -= ui.dt;
        Theme t = ui.theme;
        int col = statusBad ? t.bad() : t.good();
        if (!status.equals(wrappedFor) || wrappedW != w) { wrapped = wrap(ui.c, status, w); wrappedFor = status; wrappedW = w; }
        int cy = y;
        for (String l : wrapped) { ui.c.text(l, x + 4, cy, Colors.mulAlpha(col, Math.min(1f, Math.max(0f, statusT))), false); cy += 11; }
        return cy - y + 2;
    }

    private static String[] wrap(Canvas c, String s, int maxW) {
        java.util.List<String> lines = new java.util.ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            String trial = cur.length() == 0 ? word : cur + " " + word;
            if (cur.length() > 0 && c.textWidth(trial) > maxW - 8) { lines.add(cur.toString()); cur.setLength(0); cur.append(word); }
            else { cur.setLength(0); cur.append(trial); }
        }
        if (cur.length() > 0) lines.add(cur.toString());
        return lines.toArray(new String[0]);
    }

    // ------------------------------------------------------------------ two-click confirmation
    /** True while the key is armed: first click done, waiting up to three seconds for the confirming click. */
    public boolean armed(Ui ui, String key) { return key.equals(confirmKey) && ui.timeMs < confirmUntilMs; }

    /** Feed it a button's "clicked" result: the first click arms the key, a second one in time confirms (returns true). */
    public boolean twoClick(Ui ui, String key, boolean clicked) {
        if (!clicked) return false;
        if (armed(ui, key)) { confirmKey = null; return true; }
        confirmKey = key;
        confirmUntilMs = ui.timeMs + 3000;
        return false;
    }

    /** Cancels a pending confirmation (the selection changed, so a second click must not hit something else). */
    public void disarm() { confirmKey = null; }

    // ------------------------------------------------------------------ text box
    /** A one-line text box. Click to type, Enter or Esc or a click elsewhere to leave. Returns the current text. */
    public String edit(Ui ui, Object key, int x, int y, int w, int h, String value, String placeholder, int maxLen, IntPredicate accept) {
        Input in = ui.in;
        submitted = false;
        boolean editing = ui.focus == key;
        if (ui.over(x, y, w, h) && in.wasPressed(Input.LEFT) && !editing) {
            ui.focusField(key, value, maxLen, accept, false);
            ui.field.setCaret(ui.field.length(), false);
            editing = true;
        } else if (editing && in.wasPressed(Input.LEFT) && ui.over(x, y, w, h)) {
            ui.field.setCaret(ui.caretFromMouse(x, ui.mx), false);
        }
        if (editing) {
            ui.focusSeen = true;
            int r = ui.pumpField();
            value = ui.field.text();
            boolean clickAway = in.wasPressed(Input.LEFT) && !ui.contains(x, y, w, h, ui.mx, ui.my);
            if (r == 1) submitted = true;
            if (r == 1 || r == 2 || clickAway) { ui.unfocus(); editing = false; }
        }
        ui.textBox(x, y, w, h, value, placeholder, editing);
        return value;
    }

    /** True when Enter was pressed in the box during the last {@link #edit} call. */
    public boolean submitted() { return submitted; }
}
