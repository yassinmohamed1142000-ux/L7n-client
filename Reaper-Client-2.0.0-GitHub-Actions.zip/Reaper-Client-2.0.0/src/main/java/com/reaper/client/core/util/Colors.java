package com.reaper.client.core.util;

/** ARGB colour helpers (0xAARRGGBB). No Minecraft types, no allocation in the hot paths. */
public final class Colors {
    private Colors() {}

    public static int argb(int a, int r, int g, int b) {
        return (clamp255(a) << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(b);
    }

    public static int rgb(int r, int g, int b) { return argb(255, r, g, b); }

    public static int alpha(int c) { return c >>> 24; }
    public static int red(int c) { return (c >> 16) & 255; }
    public static int green(int c) { return (c >> 8) & 255; }
    public static int blue(int c) { return c & 255; }

    public static int clamp255(int v) { return v < 0 ? 0 : Math.min(v, 255); }

    /** Replaces the alpha channel (0-255). */
    public static int withAlpha(int c, int a) { return (clamp255(a) << 24) | (c & 0x00FFFFFF); }

    /** Multiplies the existing alpha by f (0..1). */
    public static int mulAlpha(int c, float f) {
        int a = Math.round(alpha(c) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (c & 0x00FFFFFF);
    }

    public static int lerp(int from, int to, float t) {
        if (t <= 0f) return from;
        if (t >= 1f) return to;
        int a = Math.round(alpha(from) + (alpha(to) - alpha(from)) * t);
        int r = Math.round(red(from) + (red(to) - red(from)) * t);
        int g = Math.round(green(from) + (green(to) - green(from)) * t);
        int b = Math.round(blue(from) + (blue(to) - blue(from)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Mixes towards white by t (keeps alpha). */
    public static int lighten(int c, float t) { return withAlpha(lerp(c, 0xFFFFFFFF, t), alpha(c)); }

    /** Mixes towards black by t (keeps alpha). */
    public static int darken(int c, float t) { return withAlpha(lerp(c, 0xFF000000, t), alpha(c)); }

    /** Opaque colour from hue/saturation/brightness (all 0..1). */
    public static int hsb(float h, float s, float b) { return hsba(h, s, b, 255); }

    public static int hsba(float h, float s, float b, int a) {
        h = h - (float) Math.floor(h);
        s = Math.max(0f, Math.min(1f, s));
        b = Math.max(0f, Math.min(1f, b));
        float r, g, bl;
        if (s == 0f) { r = g = bl = b; }
        else {
            float hh = (h - (float) Math.floor(h)) * 6f;
            int i = (int) hh;
            float f = hh - i, p = b * (1 - s), q = b * (1 - s * f), t = b * (1 - s * (1 - f));
            switch (i) {
                case 0 -> { r = b; g = t; bl = p; }
                case 1 -> { r = q; g = b; bl = p; }
                case 2 -> { r = p; g = b; bl = t; }
                case 3 -> { r = p; g = q; bl = b; }
                case 4 -> { r = t; g = p; bl = b; }
                default -> { r = b; g = p; bl = q; }
            }
        }
        return argb(a, Math.round(r * 255), Math.round(g * 255), Math.round(bl * 255));
    }

    /** Writes h,s,b (0..1) of the colour into out[0..2] and returns it. */
    public static float[] toHsb(int c, float[] out) {
        float r = red(c) / 255f, g = green(c) / 255f, b = blue(c) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float h, s = max == 0f ? 0f : (max - min) / max, v = max;
        if (max == min) h = 0f;
        else {
            float d = max - min;
            if (max == r) h = ((g - b) / d + (g < b ? 6f : 0f)) / 6f;
            else if (max == g) h = ((b - r) / d + 2f) / 6f;
            else h = ((r - g) / d + 4f) / 6f;
        }
        out[0] = h; out[1] = s; out[2] = v;
        return out;
    }

    /** Perceived luminance 0..1. */
    public static float luma(int c) {
        return (0.299f * red(c) + 0.587f * green(c) + 0.114f * blue(c)) / 255f;
    }

    /** Black or white, whichever reads better on top of bg. */
    public static int onColor(int bg) { return luma(bg) > 0.6f ? 0xFF111111 : 0xFFFFFFFF; }

    /** "#RRGGBB" or "#AARRGGBB". */
    public static String toHex(int c, boolean withAlpha) {
        return withAlpha ? String.format("#%08X", c) : String.format("#%06X", c & 0xFFFFFF);
    }

    /** Parses #RGB, #RRGGBB or #AARRGGBB (leading # optional). Returns {@code fallback} when invalid. */
    /** True when {@link #parseHex} accepts the text: #RGB, #RRGGBB or #AARRGGBB, with or without the '#'. */
    public static boolean isHex(String s) {
        if (s == null) return false;
        String t = s.trim();
        if (t.startsWith("#")) t = t.substring(1);
        if (t.length() != 3 && t.length() != 6 && t.length() != 8) return false;
        for (int i = 0; i < t.length(); i++) if (Character.digit(t.charAt(i), 16) < 0) return false;
        return true;
    }

    public static int parseHex(String s, int fallback) {
        if (!isHex(s)) return fallback;
        String t = s.trim();
        if (t.startsWith("#")) t = t.substring(1);
        try {
            if (t.length() == 3) {
                int r = Integer.parseInt(t.substring(0, 1), 16), g = Integer.parseInt(t.substring(1, 2), 16), b = Integer.parseInt(t.substring(2, 3), 16);
                return rgb(r * 17, g * 17, b * 17);
            }
            if (t.length() == 6) return 0xFF000000 | Integer.parseInt(t, 16);
            if (t.length() == 8) return (int) Long.parseLong(t, 16);
        } catch (NumberFormatException ignored) { /* fall through */ }
        return fallback;
    }
}
