package com.reaper.client.core.feature;

import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Canvas;

/** A crosshair you can shape: arms, dot or ring, with size, thickness, gap, colour and an outline. Pure drawing code. */
public final class CrosshairModule extends Module {
    public enum Style implements Settings.Labeled {
        CROSS("Cross"), CROSS_DOT("Cross with dot"), DOT("Dot"), CIRCLE("Ring");
        private final String label;
        Style(String l) { label = l; }
        @Override public String label() { return label; }
    }

    public final Settings.Choice<Style> style = new Settings.Choice<>("style", "Style", "The shape of the crosshair.", Style.CROSS);
    public final Settings.Color color = new Settings.Color("color", "Colour", "Colour of the crosshair.", 0xFFFFFFFF, true);
    public final Settings.Num size = new Settings.Num("size", "Size", "Length of each arm, or the radius of the ring.", 6, 1, 30, 1, "px");
    public final Settings.Num thickness = new Settings.Num("thickness", "Thickness", "Line thickness.", 1, 1, 6, 1, "px");
    public final Settings.Num gap = new Settings.Num("gap", "Gap", "Empty space around the centre.", 3, 0, 20, 1, "px");
    public final Settings.Num dot = new Settings.Num("dot", "Dot size", "Size of the centre dot.", 2, 1, 12, 1, "px");
    public final Settings.Bool outline = new Settings.Bool("outline", "Outline", "A thin dark border so the crosshair stays visible on any background.", true);
    public final Settings.Color outlineColor = new Settings.Color("outlineColor", "Outline colour", "Colour of the border.", 0xFF000000, true);
    public final Settings.Bool dynamic = new Settings.Bool("dynamic", "Open while moving", "The gap widens a little while you move.", false);

    public CrosshairModule() {
        super("crosshair", "Custom Crosshair", "Replaces the crosshair with one you design.", Category.VISUAL, true, false, "aim reticle dot cross ring");
        add(style);
        add(color);
        add(size);
        size.visibleWhen(() -> style.v() != Style.DOT);
        add(thickness);
        thickness.visibleWhen(() -> style.v() != Style.DOT);
        add(gap);
        gap.visibleWhen(() -> style.v() == Style.CROSS || style.v() == Style.CROSS_DOT);
        add(dot);
        dot.visibleWhen(() -> style.v() == Style.DOT || style.v() == Style.CROSS_DOT);
        add(outline);
        add(outlineColor);
        outlineColor.visibleWhen(outline::on);
        add(dynamic);
        dynamic.visibleWhen(() -> style.v() == Style.CROSS || style.v() == Style.CROSS_DOT);
    }

    /** Draws the crosshair with its centre pixel at (cx, cy). {@code speed} is the horizontal speed in blocks per second. */
    public void draw(Canvas c, int cx, int cy, double speed) {
        int argb = color.argb(), t = thickness.i(), len = size.i(), g = gap.i(), d = dot.i();
        if (dynamic.on()) g += (int) Math.min(5, Math.round(Math.max(0, speed) * 0.6));
        boolean ol = outline.on();
        int olc = outlineColor.argb();
        switch (style.v()) {
            case CROSS -> {
                if (ol) arms(c, cx, cy, len, t, g, olc, 1);
                arms(c, cx, cy, len, t, g, argb, 0);
            }
            case CROSS_DOT -> {
                if (ol) { arms(c, cx, cy, len, t, g, olc, 1); square(c, cx, cy, d, olc, 1); }
                arms(c, cx, cy, len, t, g, argb, 0);
                square(c, cx, cy, d, argb, 0);
            }
            case DOT -> {
                if (ol) square(c, cx, cy, d, olc, 1);
                square(c, cx, cy, d, argb, 0);
            }
            case CIRCLE -> {
                if (ol) ring(c, cx, cy, len - 1, len + t + 1, olc);
                ring(c, cx, cy, len, len + t, argb);
            }
        }
    }

    /** The four arms, each {@code len} long and {@code t} thick, {@code gap} away from the centre pixel. {@code grow} widens every edge. */
    static void arms(Canvas c, int cx, int cy, int len, int t, int gap, int argb, int grow) {
        int half = (t - 1) / 2;
        int vx = cx - half - grow, vw = t + grow * 2;
        c.fill(vx, cy - gap - len - grow, vw, len + grow * 2, argb);
        c.fill(vx, cy + 1 + gap - grow, vw, len + grow * 2, argb);
        int hy = cy - half - grow, hh = t + grow * 2;
        c.fill(cx - gap - len - grow, hy, len + grow * 2, hh, argb);
        c.fill(cx + 1 + gap - grow, hy, len + grow * 2, hh, argb);
    }

    static void square(Canvas c, int cx, int cy, int d, int argb, int grow) {
        int half = (d - 1) / 2;
        c.fill(cx - half - grow, cy - half - grow, d + grow * 2, d + grow * 2, argb);
    }

    /** A ring between radius {@code inner} (inclusive) and {@code outer} (exclusive), drawn as one or two spans per row. */
    static void ring(Canvas c, int cx, int cy, int inner, int outer, int argb) {
        if (outer <= 0) return;
        int in = Math.max(0, inner);
        for (int dy = -outer; dy <= outer; dy++) {
            int o2 = outer * outer - dy * dy;
            if (o2 < 0) continue;
            int xo = (int) Math.floor(Math.sqrt(o2));
            if (xo * xo + dy * dy >= outer * outer) xo--;      // outer radius is exclusive
            if (xo < 0) continue;
            int i2 = in * in - dy * dy;
            if (i2 <= 0) {
                c.fill(cx - xo, cy + dy, xo * 2 + 1, 1, argb);
            } else {
                int xi = (int) Math.ceil(Math.sqrt(i2));
                if (xi > xo) continue;
                c.fill(cx - xo, cy + dy, xo - xi + 1, 1, argb);
                c.fill(cx + xi, cy + dy, xo - xi + 1, 1, argb);
            }
        }
    }
}
