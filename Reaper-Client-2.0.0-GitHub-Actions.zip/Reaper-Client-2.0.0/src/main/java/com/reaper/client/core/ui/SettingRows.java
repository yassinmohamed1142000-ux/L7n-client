package com.reaper.client.core.ui;

import com.reaper.client.core.module.KeyTracker;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.setting.Setting;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Ui.WState;
import com.reaper.client.core.util.Colors;
import com.reaper.client.core.util.Text;

/** Draws and handles one row per setting type. Immediate mode: draw + interact in one call, returns the row height. */
final class SettingRows {
    private SettingRows() {}

    static final int PICKER_H = 112;
    private static final int[] PRESETS = {0xFFFFFFFF, 0xFFB0B8C8, 0xFF000000, 0xFFFF4D5E, 0xFFFF9F43, 0xFFFFD93D,
            0xFF3DDC84, 0xFF2DD4BF, 0xFF4DA3FF, 0xFF8B6CFF, 0xFFFF6BB5};

    static int base(Ui ui) { return ui.compact ? 20 : 22; }

    /** Current height of a row (the colour picker animates open). */
    static int height(Ui ui, Setting<?> s) {
        if (s instanceof Settings.Num) return ui.compact ? 28 : 32;
        if (s instanceof Settings.Color) return base(ui) + Math.round(PICKER_H * ui.st(s).aux);
        return base(ui);
    }

    static int draw(Ui ui, GuiHost host, ModuleRegistry reg, Module owner, Setting<?> s, int x, int y, int w, boolean match) {
        int h = height(ui, s);
        if (match) ui.c.fill(x + 2, y + 3, 2, Math.min(h, base(ui)) - 6, ui.theme.accent());
        if (s instanceof Settings.Bool b) boolRow(ui, host, b, x, y, w, match);
        else if (s instanceof Settings.Num n) numRow(ui, host, n, x, y, w, h, match);
        else if (s instanceof Settings.Choice<?> c) choiceRow(ui, host, c, x, y, w, match);
        else if (s instanceof Settings.Color c) colorRow(ui, host, c, x, y, w, match);
        else if (s instanceof Settings.Str t) strRow(ui, host, t, x, y, w, match);
        else if (s instanceof Settings.Key k) keyRow(ui, host, reg, owner, k, x, y, w, match);
        else if (s instanceof Settings.Action a) actionRow(ui, a, x, y, w);
        return h;
    }

    // ------------------------------------------------------------------ helpers
    private static int labelColor(Ui ui, WState st, boolean match) {
        int c = Colors.lerp(ui.theme.textDim(), ui.theme.text(), st.hover);
        return match ? Colors.lerp(c, ui.theme.accent(), 0.65f) : c;
    }

    private static void label(Ui ui, String text, int x, int y, int h, int maxW, int color) {
        ui.c.text(ui.c.fit(text, maxW), x + 8, y + (h - ui.c.lineHeight()) / 2 + 1, color, false);
    }

    private static void changed(Ui ui, GuiHost host) { ui.changed = true; host.requestSave(); }

    // ------------------------------------------------------------------ bool
    private static void boolRow(Ui ui, GuiHost host, Settings.Bool b, int x, int y, int w, boolean match) {
        int h = base(ui);
        WState st = ui.st(b);
        boolean hov = ui.over(x, y, w, h);
        st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
        st.aux = ui.ease(st.aux, b.on() ? 1f : 0f, 16f);
        if (hov && ui.in.wasPressed(Input.LEFT)) { b.toggle(); changed(ui, host); }
        if (hov && ui.in.wasPressed(Input.RIGHT)) { b.reset(); changed(ui, host); }
        label(ui, b.name, x, y, h, w - 56, labelColor(ui, st, match));
        ui.drawSwitch(x + w - 8 - 24, y + (h - 12) / 2, st.aux, true);
        ui.tip(b, x, y, w, h, b.description);
    }

    // ------------------------------------------------------------------ number
    private static void numRow(Ui ui, GuiHost host, Settings.Num n, int x, int y, int w, int h, boolean match) {
        WState st = ui.st(n);
        Input in = ui.in;
        boolean editing = ui.focus == n;
        boolean hov = ui.over(x, y, w, h) || ui.isActive(n, 0);
        st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
        int tx = x + 8, tw = w - 16, ty = y + h - 10;

        // value editing by typing (right click the row)
        if (!editing && ui.over(x, y, w, h) && in.wasPressed(Input.RIGHT)) {
            ui.focusField(n, Text.num(n.v(), n.decimals), 12, cp -> (cp >= '0' && cp <= '9') || cp == '.' || cp == '-', true);
            editing = true;
        }
        if (editing) {
            ui.focusSeen = true;
            int r = ui.pumpField();
            boolean clickAway = in.wasPressed(Input.LEFT) && !ui.over(x, y, w, h);
            if (r == 1 || clickAway) {
                try { n.set(Double.parseDouble(ui.field.text())); changed(ui, host); } catch (NumberFormatException ignored) { /* keep old value */ }
                ui.unfocus();
                editing = false;
            } else if (r == 2) { ui.unfocus(); editing = false; }
        }

        // slider drag / click
        if (!editing) {
            if (ui.over(x, y, w, h) && in.wasPressed(Input.LEFT)) ui.activate(n, 0);
            if (ui.isActive(n, 0)) {
                n.setFraction((ui.mx - tx) / (double) Math.max(1, tw));
                changed(ui, host);
                if (!in.isDown(Input.LEFT)) ui.deactivate();
            }
            if (ui.over(x, y, w, h) && in.ctrl() && in.scroll != 0) {
                n.set(n.v() + Math.signum(in.scroll) * n.step * (in.shift() ? 5 : 1));
                in.scroll = 0;
                changed(ui, host);
            }
        }

        // drawing
        int lh = ui.c.lineHeight();
        int valueW = editing ? 62 : ui.c.textWidth(n.valueText());
        ui.c.text(ui.c.fit(n.name, w - 24 - valueW), x + 8, y + 3, labelColor(ui, st, match), false);
        if (editing) ui.textBox(x + w - 8 - 62, y + 1, 62, lh + 5, null, "", true);
        else ui.c.rightText(n.valueText(), x + w - 8, y + 3, Colors.lerp(ui.theme.textDim(), ui.theme.accent(), 0.5f + 0.5f * st.hover), false);
        ui.c.roundRect(tx, ty, tw, 5, 2, ui.theme.field());
        float f = n.fraction();
        st.aux = ui.ease(st.aux, f, 30f);
        int fw = Math.max(0, Math.round(tw * st.aux));
        if (fw > 0) {
            ui.c.roundRect(tx, ty, fw, 5, 2, ui.theme.accent());
            ui.c.fill(tx + Math.max(2, fw / 2), ty + 1, Math.max(0, fw - Math.max(2, fw / 2) - 2), 1, Colors.withAlpha(ui.theme.accent2(), 0x99));
        }
        int kx = tx + fw;
        ui.c.disc(kx, ty + 2, 4 + Math.round(st.hover), Colors.lerp(0xFFDCE0EA, 0xFFFFFFFF, st.hover));
        ui.tip(n, x, y, w, h, n.description + "\nRight-click to type a value. Ctrl+scroll adjusts. Default: " + Text.num(n.getDefault(), n.decimals) + n.suffix);
    }

    // ------------------------------------------------------------------ choice
    private static void choiceRow(Ui ui, GuiHost host, Settings.Choice<?> c, int x, int y, int w, boolean match) {
        int h = base(ui);
        WState st = ui.st(c);
        boolean hov = ui.over(x, y, w, h);
        st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
        String v = c.valueText();
        int pw = Math.max(64, ui.c.textWidth(v) + 26), px = x + w - 8 - pw, py = y + 2, ph = h - 4;
        if (hov && ui.in.wasPressed(Input.LEFT)) { c.next(); changed(ui, host); }
        if (hov && ui.in.wasPressed(Input.RIGHT)) { c.prev(); changed(ui, host); }
        label(ui, c.name, x, y, h, w - pw - 24, labelColor(ui, st, match));
        ui.c.roundRect(px, py, pw, ph, 3, Colors.lerp(ui.theme.field(), ui.theme.rowHover(), st.hover));
        ui.c.arrow(px + 5, py + ph / 2 - 3, 3, 2, Colors.lerp(ui.theme.textDim(), ui.theme.text(), st.hover));
        ui.c.arrow(px + pw - 8, py + ph / 2 - 3, 3, 0, Colors.lerp(ui.theme.textDim(), ui.theme.text(), st.hover));
        ui.c.centerText(ui.c.fit(v, pw - 22), px + pw / 2, py + (ph - ui.c.lineHeight()) / 2 + 1, ui.theme.text(), false);
        ui.tip(c, x, y, w, h, c.description + "\nClick: next. Right-click: previous.");
    }

    // ------------------------------------------------------------------ text
    private static void strRow(Ui ui, GuiHost host, Settings.Str t, int x, int y, int w, boolean match) {
        int h = base(ui);
        WState st = ui.st(t);
        boolean hov = ui.over(x, y, w, h);
        st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
        int bw = Math.max(60, (w - 16) * 11 / 20), bx = x + w - 8 - bw, by = y + 2, bh = h - 4;
        boolean editing = ui.focus == t;
        if (hov && ui.in.wasPressed(Input.LEFT) && !editing && ui.contains(bx, by, bw, bh, ui.mx, ui.my)) {
            ui.focusField(t, t.get(), t.maxLen, null, false);
            ui.field.setCaret(ui.field.length(), false);
            editing = true;
        } else if (editing && ui.in.wasPressed(Input.LEFT) && ui.contains(bx, by, bw, bh, ui.mx, ui.my)) {
            ui.field.setCaret(ui.caretFromMouse(bx, ui.mx), false);
        }
        if (editing) {
            ui.focusSeen = true;
            int r = ui.pumpField();
            boolean clickAway = ui.in.wasPressed(Input.LEFT) && !ui.contains(bx, by, bw, bh, ui.mx, ui.my);
            if (r == 1 || clickAway) { t.set(ui.field.text()); changed(ui, host); ui.unfocus(); editing = false; }
            else if (r == 2) { ui.unfocus(); editing = false; }
        }
        label(ui, t.name, x, y, h, w - bw - 24, labelColor(ui, st, match));
        ui.textBox(bx, by, bw, bh, t.get(), "...", editing);
        ui.tip(t, x, y, w - bw - 16, h, t.description);
    }

    // ------------------------------------------------------------------ key bind
    private static void keyRow(Ui ui, GuiHost host, ModuleRegistry reg, Module owner, Settings.Key k, int x, int y, int w, boolean match) {
        int h = base(ui);
        WState st = ui.st(k);
        boolean hov = ui.over(x, y, w, h);
        st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
        boolean listening = ui.focus == k && ui.listening;
        if (hov && ui.in.wasPressed(Input.LEFT) && !listening) { ui.focus = k; ui.listening = true; listening = true; ui.in.consumeKeys(); }
        else if (hov && ui.in.wasPressed(Input.RIGHT) && !listening) { k.set(Settings.NO_KEY); changed(ui, host); }
        if (listening) {
            ui.focusSeen = true;
            for (int i = 0; i < ui.in.keyCount(); i++) {
                int key = ui.in.keyAt(i);
                if (key == KeyNames.ESCAPE) { ui.unfocus(); break; }
                if (key == KeyNames.BACKSPACE || key == KeyNames.DELETE) k.set(Settings.NO_KEY);
                else {
                    k.set(key);
                    Module other = KeyTracker.owner(reg, key, owner);
                    if (other != null) host.toast(Level.WARN, KeyNames.of(key) + " is also bound to " + other.name);
                }
                changed(ui, host);
                ui.unfocus();
                break;
            }
            ui.in.consumeKeys();
            if (ui.focus == k && ui.in.wasPressed(Input.LEFT) && !hov) ui.unfocus();
            listening = ui.focus == k && ui.listening;
        }
        String v = listening ? "Press a key..." : k.valueText();
        int pw = Math.max(56, ui.c.textWidth(v) + 16), px = x + w - 8 - pw, py = y + 2, ph = h - 4;
        label(ui, k.name, x, y, h, w - pw - 24, labelColor(ui, st, match));
        int border = listening ? ui.theme.accent() : ui.theme.outline();
        int bg = listening ? Colors.lerp(ui.theme.field(), ui.theme.accent(), 0.18f + 0.1f * (float) Math.sin(ui.timeMs / 180.0)) : Colors.lerp(ui.theme.field(), ui.theme.rowHover(), st.hover);
        ui.c.roundBox(px, py, pw, ph, 3, bg, border);
        int tc = listening ? ui.theme.text() : (k.bound() ? ui.theme.text() : ui.theme.textDim());
        ui.c.centerText(v, px + pw / 2, py + (ph - ui.c.lineHeight()) / 2 + 1, tc, false);
        ui.tip(k, x, y, w, h, k.description + "\nClick to bind, right-click to clear.");
    }

    // ------------------------------------------------------------------ action
    private static void actionRow(Ui ui, Settings.Action a, int x, int y, int w) {
        int h = base(ui);
        if (ui.button(a, x + 8, y + 1, w - 16, h - 2, a.name, !a.danger, a.danger)) a.run();
        ui.tip(a, x + 8, y + 1, w - 16, h - 2, a.description);
    }

    // ------------------------------------------------------------------ colour
    private static void colorRow(Ui ui, GuiHost host, Settings.Color cs, int x, int y, int w, boolean match) {
        int base = base(ui);
        WState st = ui.st(cs);
        st.aux = ui.ease(st.aux, st.open ? 1f : 0f, 14f);
        boolean hov = ui.over(x, y, w, base);
        st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
        if (hov && ui.in.wasPressed(Input.LEFT)) { st.open = !st.open; if (st.open) st.hsvValid = false; }
        label(ui, cs.name, x, y, base, w - 90, labelColor(ui, st, match));
        int sx = x + w - 8 - 30, sy = y + (base - 12) / 2;
        ui.c.roundBox(sx, sy, 30, 12, 3, ui.theme.field(), Colors.lerp(ui.theme.outline(), ui.theme.text(), st.hover * 0.6f));
        ui.c.roundRect(sx + 1, sy + 1, 28, 10, 2, cs.argb());
        ui.c.rightText(Colors.toHex(cs.argb(), cs.hasAlpha), sx - 6, y + (base - ui.c.lineHeight()) / 2 + 1, Colors.withAlpha(ui.theme.textDim(), 0xCC), false);
        ui.tip(cs, x, y, w, base, cs.description);
        int ph = Math.round(PICKER_H * st.aux);
        if (ph > 1) {
            ui.pushClip(x, y + base, w, ph);
            picker(ui, host, cs, st, x, y + base, w);
            ui.popClip();
        }
    }

    private static void picker(Ui ui, GuiHost host, Settings.Color cs, WState st, int x, int y, int w) {
        Canvas c = ui.c;
        Input in = ui.in;
        boolean dragging = ui.active == cs;
        if (!dragging) {
            int cur = Colors.hsb(st.h, st.s, st.v) & 0xFFFFFF;
            if (!st.hsvValid || cur != (cs.get() & 0xFFFFFF)) {
                float[] hsb = Colors.toHsb(cs.get(), new float[3]);
                if (hsb[1] > 0.001f && hsb[2] > 0.001f) st.h = hsb[0];
                if (hsb[2] > 0.001f) st.s = hsb[1];
                st.v = hsb[2];
                st.hsvValid = true;
            }
        }
        int px = x + 8, py = y + 4;
        int sh = 60, sw = Math.max(60, Math.min(120, w - 16 - 16 - (cs.hasAlpha ? 16 : 0)));
        int hueX = px + sw + 6, alphaX = hueX + 16;

        // --- saturation / value square (vertical strips)
        for (int i = 0; i < sw; i += 2) {
            float s = (i + 1) / (float) sw;
            c.gradientV(px + i, py, Math.min(2, sw - i), sh, Colors.hsb(st.h, s, 1f), 0xFF000000);
        }
        c.outline(px - 1, py - 1, sw + 2, sh + 2, ui.theme.outline());
        // --- hue bar
        for (int i = 0; i < sh; i += 2) c.fill(hueX, py + i, 10, Math.min(2, sh - i), Colors.hsb(i / (float) sh, 1f, 1f));
        c.outline(hueX - 1, py - 1, 12, sh + 2, ui.theme.outline());
        // --- alpha bar
        if (cs.hasAlpha) {
            c.fill(alphaX, py, 10, sh, ui.theme.field());
            int solid = Colors.hsb(st.h, st.s, st.v);
            c.gradientV(alphaX, py, 10, sh, Colors.withAlpha(solid, 0), solid);
            c.outline(alphaX - 1, py - 1, 12, sh + 2, ui.theme.outline());
        }

        // --- interaction
        boolean overSv = ui.over(px, py, sw, sh);
        boolean overHue = ui.over(hueX, py, 10, sh);
        boolean overAlpha = cs.hasAlpha && ui.over(alphaX, py, 10, sh);
        if (in.wasPressed(Input.LEFT)) {
            if (overSv) ui.activate(cs, 1); else if (overHue) ui.activate(cs, 2); else if (overAlpha) ui.activate(cs, 3);
        }
        if (ui.active == cs) {
            boolean ch = false;
            if (ui.activePart == 1) {
                st.s = Math.max(0f, Math.min(1f, (ui.mx - px) / (float) (sw - 1)));
                st.v = 1f - Math.max(0f, Math.min(1f, (ui.my - py) / (float) (sh - 1)));
                ch = true;
            } else if (ui.activePart == 2) {
                st.h = Math.max(0f, Math.min(0.999f, (ui.my - py) / (float) (sh - 1)));
                ch = true;
            } else if (ui.activePart == 3) {
                float a = Math.max(0f, Math.min(1f, (ui.my - py) / (float) (sh - 1)));
                cs.set(Colors.withAlpha(cs.get(), Math.round(a * 255)));
                changed(ui, host);
            }
            if (ch) {
                cs.set(Colors.hsba(st.h, st.s, st.v, Colors.alpha(cs.get())));
                changed(ui, host);
            }
            if (!in.isDown(Input.LEFT)) ui.deactivate();
        }

        // --- markers
        int mx = px + Math.round(st.s * (sw - 1)), my = py + Math.round((1f - st.v) * (sh - 1));
        c.outline(mx - 3, my - 3, 7, 7, 0xFF000000);
        c.outline(mx - 2, my - 2, 5, 5, 0xFFFFFFFF);
        int hy = py + Math.round(st.h * (sh - 1));
        c.fill(hueX - 2, hy - 1, 14, 3, 0xFF000000);
        c.fill(hueX - 2, hy, 14, 1, 0xFFFFFFFF);
        if (cs.hasAlpha) {
            int ay = py + Math.round(Colors.alpha(cs.get()) / 255f * (sh - 1));
            c.fill(alphaX - 2, ay - 1, 14, 3, 0xFF000000);
            c.fill(alphaX - 2, ay, 14, 1, 0xFFFFFFFF);
        }

        // --- hex box + preview
        int ry = py + sh + 6;
        c.roundBox(px, ry, 16, 14, 3, ui.theme.field(), ui.theme.outline());
        c.roundRect(px + 1, ry + 1, 14, 12, 2, cs.argb());
        int bx = px + 22, bw = w - 16 - 22;
        boolean editing = ui.focus == st;
        if (ui.over(bx, ry, bw, 14) && in.wasPressed(Input.LEFT) && !editing) {
            ui.focusField(st, Colors.toHex(cs.get(), cs.hasAlpha), cs.hasAlpha ? 9 : 7, cp -> cp == '#' || Character.digit(cp, 16) >= 0, true);
            editing = true;
        }
        if (editing) {
            ui.focusSeen = true;
            int r = ui.pumpField();
            boolean clickAway = in.wasPressed(Input.LEFT) && !ui.contains(bx, ry, bw, 14, ui.mx, ui.my);
            if (r == 1 || clickAway) {
                if (Colors.isHex(ui.field.text())) { cs.set(Colors.parseHex(ui.field.text(), 0)); st.hsvValid = false; changed(ui, host); }
                ui.unfocus(); editing = false;
            } else if (r == 2) { ui.unfocus(); editing = false; }
        }
        ui.textBox(bx, ry, bw, 14, Colors.toHex(cs.get(), cs.hasAlpha), "#RRGGBB", editing);

        // --- presets
        int pyy = ry + 14 + 6, n = PRESETS.length, gap = 3, size = Math.max(8, Math.min(14, (w - 16 - gap * (n - 1)) / n));
        for (int i = 0; i < n; i++) {
            int qx = px + i * (size + gap);
            boolean ph = ui.over(qx, pyy, size, size);
            c.roundBox(qx, pyy, size, size, 2, PRESETS[i], ph ? ui.theme.text() : ui.theme.outline());
            if (ph && in.wasPressed(Input.LEFT)) {
                cs.set(Colors.withAlpha(PRESETS[i], cs.hasAlpha ? Colors.alpha(cs.get()) : 255));
                st.hsvValid = false;
                changed(ui, host);
            }
        }
    }
}
