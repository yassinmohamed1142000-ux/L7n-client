package com.reaper.client.mixin;

import com.reaper.client.mc.Hooks;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.world.entity.player.Inventory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mouse hooks for Zoom (steadier aiming, the wheel changes the zoom factor instead of the hotbar slot) and for the
 * CPS counter (a click shorter than one frame is still counted).
 */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    /**
     * The mouse sensitivity is read as a Double inside turnPlayer; the zoom scales it down. This is the same target
     * Wurst uses on 26.1.2 (see docs/API-AUDIT.md).
     */
    @ModifyExpressionValue(method = "turnPlayer(D)V",
            at = @At(value = "INVOKE", target = "Ljava/lang/Double;doubleValue()D"))
    private double reaper$sensitivity(double original) {
        return Hooks.modifySensitivity(original);
    }

    @Inject(method = "onButton(JLnet/minecraft/client/input/MouseButtonInfo;I)V", at = @At("HEAD"))
    private void reaper$button(long window, MouseButtonInfo info, int action, CallbackInfo ci) {
        Hooks.onMouseButton(info.button(), action);
    }

    @Inject(method = "onScroll(JDD)V", at = @At("HEAD"))
    private void reaper$scrollStart(long window, double horizontal, double vertical, CallbackInfo ci) {
        Hooks.onScroll(vertical);
    }

    @Inject(method = "onScroll(JDD)V", at = @At("RETURN"))
    private void reaper$scrollEnd(long window, double horizontal, double vertical, CallbackInfo ci) {
        Hooks.scrollDone();
    }

    @WrapWithCondition(method = "onScroll(JDD)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Inventory;setSelectedSlot(I)V"))
    private boolean reaper$hotbar(Inventory inventory, int slot) {
        return Hooks.allowHotbarScroll();
    }
}
