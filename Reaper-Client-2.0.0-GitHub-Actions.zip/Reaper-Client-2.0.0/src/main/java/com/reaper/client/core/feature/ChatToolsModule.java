package com.reaper.client.core.feature;

import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.setting.Settings;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Chat helpers that only change what the player sees on their own screen: a time stamp in front of every message,
 * and a notification when somebody writes the player's name or one of their words. Nothing is sent to the server.
 * Pure logic: the game layer decides what text goes in and what is done with the answer.
 */
public final class ChatToolsModule extends Module {
    public enum Clock implements Settings.Labeled {
        H24("24-hour"), H12("12-hour");
        private final String label;
        Clock(String l) { label = l; }
        @Override public String label() { return label; }
    }

    public static final int MAX_WORDS = 20, MAX_WORD_LENGTH = 32, ALERT_LENGTH = 90;

    public final Settings.Bool timestamps = new Settings.Bool("timestamps", "Time stamps", "Puts the time in front of every chat message.", true);
    public final Settings.Choice<Clock> clock = new Settings.Choice<>("clock", "Clock", "24-hour or 12-hour time.", Clock.H24);
    public final Settings.Bool seconds = new Settings.Bool("seconds", "Show seconds", "Adds the seconds to the time.", false);
    public final Settings.Color stampColor = new Settings.Color("stampColor", "Time colour", "Colour of the time in front of a message.", 0xFF8C95A8, false);
    public final Settings.Bool mentions = new Settings.Bool("mentions", "Mention alerts", "Shows a notification when somebody writes your name or one of your words.", true);
    public final Settings.Str words = new Settings.Str("words", "Extra words", "More words to react to, separated by commas.", "", 120);
    public final Settings.Num gap = new Settings.Num("gap", "Alert gap", "The fewest seconds between two alerts.", 5, 0, 60, 1, " s");
    public final Settings.Action clearChat;

    private Runnable clearAction;
    private long lastAlertMs = Long.MIN_VALUE;
    private String parsedFor;
    private String[] parsed = new String[0];

    public ChatToolsModule() {
        super("chat", "Chat Tools", "Time stamps in the chat and a notification when somebody writes your name. Display only.", Category.UTILITY, true, true, "chat time stamp timestamp mention ping name notification");
        clearChat = new Settings.Action("clearChat", "Clear chat history", "Removes the messages from the chat window on this screen. Messages already sent are not affected.", true, () -> { if (clearAction != null) clearAction.run(); });
        add(timestamps);
        add(clock);
        clock.visibleWhen(timestamps::on);
        add(seconds);
        seconds.visibleWhen(timestamps::on);
        add(stampColor);
        stampColor.visibleWhen(timestamps::on);
        add(mentions);
        add(words);
        words.visibleWhen(mentions::on);
        add(gap);
        gap.visibleWhen(mentions::on);
        add(clearChat);
    }

    /** The game layer says what "clear chat history" does. */
    public void setClearAction(Runnable r) { clearAction = r; }

    // ------------------------------------------------------------------ time stamps
    /** True when messages should get a time in front. */
    public boolean stampsOn() { return isActive() && timestamps.on(); }

    /** The stamp colour as 0xRRGGBB. */
    public int stampRgb() { return stampColor.argb() & 0xFFFFFF; }

    /** "[14:05] " or "[2:05 PM] " (with seconds when switched on), for the given moment in the given zone. */
    public String prefix(long epochMs, ZoneId zone) {
        ZonedDateTime t = Instant.ofEpochMilli(epochMs).atZone(zone);
        return "[" + format(t.getHour(), t.getMinute(), t.getSecond()) + "] ";
    }

    /** The time as text in the chosen format. */
    public String format(int hour, int minute, int second) {
        StringBuilder sb = new StringBuilder(11);
        boolean twelve = clock.v() == Clock.H12;
        int h = twelve ? (hour % 12 == 0 ? 12 : hour % 12) : hour;
        if (!twelve && h < 10) sb.append('0');
        sb.append(h).append(':');
        if (minute < 10) sb.append('0');
        sb.append(minute);
        if (seconds.on()) {
            sb.append(':');
            if (second < 10) sb.append('0');
            sb.append(second);
        }
        if (twelve) sb.append(hour < 12 ? " AM" : " PM");
        return sb.toString();
    }

    // ------------------------------------------------------------------ mentions
    /** The extra words, lower case, at most {@value #MAX_WORDS}, each at most {@value #MAX_WORD_LENGTH} characters. */
    public String[] extraWords() {
        String raw = words.get();
        if (!raw.equals(parsedFor)) {
            List<String> out = new ArrayList<>();
            for (String part : raw.split(",")) {
                String w = part.strip().toLowerCase(Locale.ROOT);
                if (w.isEmpty() || out.contains(w)) continue;
                if (w.length() > MAX_WORD_LENGTH) w = w.substring(0, MAX_WORD_LENGTH);
                out.add(w);
                if (out.size() == MAX_WORDS) break;
            }
            parsed = out.toArray(new String[0]);
            parsedFor = raw;
        }
        return parsed;
    }

    /**
     * Decides whether a received message deserves an alert. {@code text} is the message as plain text,
     * {@code ownName} the player's name, {@code sentByMe} true when the game says the player wrote it. Returns the
     * text for the notification, or null for none. A message that starts with the player's own name (the speaker, or
     * a line such as "Steve joined the game") never alerts, and alerts are spaced by the "Alert gap" setting.
     */
    public String check(String text, String ownName, boolean sentByMe, long nowMs) {
        if (sentByMe || text == null || text.isEmpty() || !isActive() || !mentions.on()) return null;
        if (lastAlertMs != Long.MIN_VALUE && nowMs - lastAlertMs < gap.i() * 1000L && nowMs >= lastAlertMs) return null;
        String lower = text.toLowerCase(Locale.ROOT);
        boolean hit = false;
        if (ownName != null && !ownName.isEmpty()) {
            String me = ownName.toLowerCase(Locale.ROOT);
            hit = !startsWithSpeaker(lower, me) && containsWord(lower, me);
        }
        if (!hit) for (String w : extraWords()) if (containsWord(lower, w)) { hit = true; break; }
        if (!hit) return null;
        lastAlertMs = nowMs;
        return "Chat: " + shorten(text.strip());
    }

    private static String shorten(String s) {
        int n = s.codePointCount(0, s.length());
        if (n <= ALERT_LENGTH) return s;
        return s.substring(0, s.offsetByCodePoints(0, ALERT_LENGTH - 1)) + "…";
    }

    private static boolean wordChar(int cp) { return Character.isLetterOrDigit(cp) || cp == '_'; }

    /** True when {@code word} occurs in {@code text} as a whole word (both already lower case). */
    static boolean containsWord(String text, String word) {
        if (word.isEmpty()) return false;
        int from = 0;
        while (true) {
            int i = text.indexOf(word, from);
            if (i < 0) return false;
            int end = i + word.length();
            boolean before = i == 0 || !wordChar(text.codePointBefore(i));
            boolean after = end >= text.length() || !wordChar(text.codePointAt(end));
            if (before && after) return true;
            from = i + 1;
        }
    }

    /** True when the message begins with the name, after optional "<", spaces and [tags]: "<steve> hi", "[VIP] steve: hi", "steve joined". */
    static boolean startsWithSpeaker(String text, String name) {
        int i = 0, n = text.length();
        while (i < n) {
            char c = text.charAt(i);
            if (c == ' ' || c == '<') { i++; continue; }
            if (c == '[') {
                int close = text.indexOf(']', i);
                if (close < 0 || close - i > 24) break;
                i = close + 1;
                continue;
            }
            break;
        }
        if (!text.startsWith(name, i)) return false;
        int end = i + name.length();
        return end >= n || !wordChar(text.codePointAt(end));
    }
}
