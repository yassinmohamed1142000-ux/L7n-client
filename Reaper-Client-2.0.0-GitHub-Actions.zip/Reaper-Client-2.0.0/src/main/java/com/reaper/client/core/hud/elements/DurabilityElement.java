package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.setting.Settings;

/** Durability of the item in your hand, with an optional heads-up when any of your gear is nearly broken. */
public final class DurabilityElement extends LinesElement {
    public enum Format implements Settings.Labeled {
        BOTH("312/363 (86%)"), FRACTION("312/363"), PERCENT("86%");
        private final String label;
        Format(String l) { label = l; }
        @Override public String label() { return label; }
    }

    /** Re-warn at most this often for the same slot, and only after the item recovered a little (hysteresis). */
    static final long COOLDOWN_MS = 30_000L;
    static final int HYSTERESIS = 5;

    private final Settings.Choice<Format> format = new Settings.Choice<>("format", "Format", "How the durability is written.", Format.BOTH);
    private final Settings.Bool showName = new Settings.Bool("showName", "Item name", "Put the item's name in front.", true);
    private final Settings.Bool offhand = new Settings.Bool("offhand", "Off hand", "Also show the item in your off hand (a shield, for example).", false);
    private final Settings.Bool colorize = new Settings.Bool("colorize", "Colour by condition", "Green when fine, red when nearly broken. Replaces the text colour.", true);
    private final Settings.Bool warn = new Settings.Bool("warn", "Low durability warning", "Show a notification when your armour, tool or weapon gets nearly broken.", true);
    private final Settings.Num warnBelow = new Settings.Num("warnBelow", "Warn below", "Durability percentage that triggers the warning.", 15, 5, 50, 1, "%");

    private final boolean[] low = new boolean[6];
    private final long[] lastWarn = new long[6];
    private final long[] key = new long[6];
    private final String[] cached = new String[6];
    private Format kFormat;
    private boolean kName;

    public DurabilityElement() {
        super("durability", "Durability", "Shows how worn the item in your hand is.", false, "tool weapon pickaxe sword damage breaking", Anchor.BOTTOM_RIGHT, 4, 84);
        add(format);
        add(showName);
        add(offhand);
        add(colorize);
        add(warn);
        add(warnBelow);
        warnBelow.visibleWhen(warn::on);
        color.visibleWhen(() -> !colorize.on());
        commonSettings();
        java.util.Arrays.fill(key, Long.MIN_VALUE);
        java.util.Arrays.fill(cached, "");
        java.util.Arrays.fill(lastWarn, Long.MIN_VALUE / 2);
    }

    /** True when a warning should be shown for a slot at {@code pct} percent. Updates the slot's state. Package-private for tests. */
    boolean shouldWarn(int slot, int pct, int threshold, long nowMs) {
        if (low[slot]) {
            if (pct >= threshold + HYSTERESIS) low[slot] = false;
            return false;
        }
        if (pct < threshold) {
            low[slot] = true;
            if (nowMs - lastWarn[slot] >= COOLDOWN_MS) { lastWarn[slot] = nowMs; return true; }
        }
        return false;
    }

    private void checkWarnings(HudContext x) {
        if (x.editing || x.notifications == null || !warn.on() || !x.d.inWorld) return;
        int threshold = warnBelow.i();
        for (int slot = 0; slot < 6; slot++) {
            HudData.ItemInfo it = slot < 4 ? x.d.armor[slot] : slot == 4 ? x.d.mainHand : x.d.offHand;
            if (!it.hasDurability()) { low[slot] = false; continue; }
            int pct = Math.round(it.fraction() * 100f);
            if (shouldWarn(slot, pct, threshold, x.d.nowMs)) x.notifications.push(Level.WARN, "Low durability: " + it.name + " (" + pct + "%)");
        }
    }

    private String describe(HudData.ItemInfo it, Format f, boolean name) {
        String v = f == Format.PERCENT ? Math.round(it.fraction() * 100f) + "%"
                : f == Format.FRACTION ? it.remaining() + "/" + it.maxDamage
                : it.remaining() + "/" + it.maxDamage + " (" + Math.round(it.fraction() * 100f) + "%)";
        return name && !it.name.isEmpty() ? it.name + ": " + v : v;
    }

    @Override protected boolean update(HudContext x) {
        if (!x.d.inWorld && !x.editing) return false;
        checkWarnings(x);
        Format f = format.v();
        boolean nm = showName.on();
        boolean reset = f != kFormat || nm != kName;
        kFormat = f; kName = nm;
        int i = 0;
        HudData.ItemInfo main = x.d.mainHand, off = x.d.offHand;
        if (main.hasDurability()) i = fillLine(i, 4, main, f, nm, reset);
        if (offhand.on() && off.hasDurability()) i = fillLine(i, 5, off, f, nm, reset);
        if (i == 0) {
            if (!x.editing) return false;
            lines[0] = "Durability";
            lineArgb[0] = x.theme.textDim();
            i = 1;
        }
        n = i;
        return true;
    }

    private int fillLine(int i, int slot, HudData.ItemInfo it, Format f, boolean name, boolean reset) {
        long k = ((long) it.damage << 32) ^ ((long) it.maxDamage << 8) ^ it.name.hashCode();
        if (reset || k != key[slot]) { key[slot] = k; cached[slot] = describe(it, f, name); }
        lines[i] = cached[slot];
        lineArgb[i] = colorize.on() ? health(it.fraction()) : color.argb();
        return i + 1;
    }
}
