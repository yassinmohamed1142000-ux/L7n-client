package com.reaper.client.core.ui;

import com.google.gson.JsonObject;
import com.reaper.client.core.util.Anim;

/** A draggable, resizable, collapsible, scrollable ClickGUI window. Layout state only; drawing lives in {@link ClickGui}. */
public final class UiWindow {
    /** Draws the window body. {@code y} already includes the scroll offset. Returns the content height. */
    public interface Content {
        int draw(Ui ui, UiWindow win, int x, int y, int w, int viewH);
    }

    public static final int HEADER = 24, MIN_W = 170, MAX_W = 440, MIN_H = 70;

    public final String id;
    public final String title;
    public final Content content;

    public int x, y, w = 214;
    /** Height chosen by the user (header included); only used when {@link #userSized}. */
    public int userH;
    public boolean visible, collapsed, userSized;

    public float scroll, scrollTarget;
    public int contentH;

    /** 0..1 show/hide, 0..1 collapse, animated body height. */
    public final Anim vis = new Anim(0), col = new Anim(0), body = new Anim(0);
    public boolean bodyInit;

    public UiWindow(String id, String title, Content content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }

    public int maxScroll(int viewH) { return Math.max(0, contentH - viewH); }

    public void clampScroll(int viewH) {
        int max = maxScroll(viewH);
        scrollTarget = Math.max(0, Math.min(max, scrollTarget));
        scroll = Math.max(0, Math.min(max, scroll));
    }

    /** Total pixel height right now (header + animated body). */
    public int height() { return HEADER + Math.round(body.value * (1f - col.value)); }

    // ------------------------------------------------------------------ persistence
    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("x", x);
        o.addProperty("y", y);
        o.addProperty("w", w);
        o.addProperty("visible", visible);
        o.addProperty("collapsed", collapsed);
        if (userSized) o.addProperty("h", userH);
        return o;
    }

    public void fromJson(JsonObject o) {
        if (o == null) return;
        x = num(o, "x", x);
        y = num(o, "y", y);
        w = Math.max(MIN_W, Math.min(MAX_W, num(o, "w", w)));
        visible = bool(o, "visible", visible);
        collapsed = bool(o, "collapsed", collapsed);
        if (o.has("h")) { userSized = true; userH = Math.max(MIN_H, num(o, "h", MIN_H)); }
        vis.snap(visible ? 1f : 0f);
        col.snap(collapsed ? 1f : 0f);
    }

    private static int num(JsonObject o, String k, int def) {
        var e = o.get(k);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber() ? (int) Math.round(e.getAsDouble()) : def;
    }

    private static boolean bool(JsonObject o, String k, boolean def) {
        var e = o.get(k);
        return e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean() ? e.getAsBoolean() : def;
    }
}
