package com.reaper.client.core.feature;

import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.setting.Settings;

/**
 * Inventory sorting. The game layer shows a Sort button in inventory and chest screens, hands the slot contents to
 * {@link #begin}, and then asks for the clicks to make a few at a time ({@link #next}). Off where the server rules
 * say so.
 */
public final class SorterModule extends Module {
    private static final int[] NONE = new int[0];

    public final Settings.Choice<InventorySorter.Order> order = new Settings.Choice<>("order", "Order", "How the items are arranged.", InventorySorter.Order.TYPE);
    public final Settings.Num speed = new Settings.Num("speed", "Clicks per tick", "How many clicks are made each game tick. One is the gentlest on the server.", 1, 1, 4, 1, "");
    public final Settings.Bool hotbar = new Settings.Bool("hotbar", "Include hotbar", "Also sort the nine hotbar slots when sorting your inventory.", false);
    public final Settings.Bool buttons = new Settings.Bool("buttons", "Sort buttons", "Show a Sort button in the inventory and chest screens.", true);

    private int[] run = NONE;
    private int pos;

    public SorterModule() {
        super("sorter", "Inventory Sorter", "Merges stacks and arranges items with ordinary clicks. Off where the server rules say so.", Category.UTILITY, true, true, "inventory sort organize chest stack merge");
        feature(Feature.INVENTORY_SORT);
        add(order);
        add(speed);
        add(hotbar);
        add(buttons);
    }

    /** Whether the Sort button should be shown. */
    public boolean showButtons() { return isActive() && buttons.on(); }

    /**
     * Plans a sort of the given slots (see {@link InventorySorter#plan}). Returns how many clicks it will take,
     * 0 when everything is already tidy, or -1 when sorting is not allowed right now.
     */
    public int begin(String[] key, int[] count, int[] max) {
        run = NONE;
        pos = 0;
        if (!isActive()) return -1;
        run = InventorySorter.plan(key, count, max, order.v());
        return run.length;
    }

    public boolean running() { return pos < run.length; }

    public int remaining() { return run.length - pos; }

    public int total() { return run.length; }

    /** Writes up to "clicks per tick" slot numbers into {@code out}, advances, and returns how many were written. Stops at once when the module was switched off or blocked. */
    public int next(int[] out) {
        if (!isActive()) { cancel(); return 0; }
        int n = Math.min(Math.min(speed.i(), out.length), run.length - pos);
        for (int i = 0; i < n; i++) out[i] = run[pos++];
        return n;
    }

    public void cancel() {
        run = NONE;
        pos = 0;
    }
}
