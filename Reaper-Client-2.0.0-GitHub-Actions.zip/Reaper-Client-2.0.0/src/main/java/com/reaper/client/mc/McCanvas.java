package com.reaper.client.mc;

import com.reaper.client.core.ui.Canvas;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.world.item.ItemStack;

/**
 * The core's {@link Canvas} on top of the game's {@link GuiGraphicsExtractor}. One instance is reused for every frame;
 * {@link #begin} points it at the frame's extractor and {@link #end} puts the clip and transform stacks back in order,
 * so a bug in drawing code can never leave the game's own stacks unbalanced.
 */
final class McCanvas implements Canvas {
    private static final int MAX_ALPHA_DEPTH = 32;

    private GuiGraphicsExtractor g;
    private Font font;
    private final float[] alphaStack = new float[MAX_ALPHA_DEPTH];
    private int alphaDepth;
    private float alpha = 1f;
    private int clipDepth, poseDepth;

    void begin(GuiGraphicsExtractor extractor) {
        g = extractor;
        font = Minecraft.getInstance().font;
        alpha = 1f;
        alphaDepth = 0;
        clipDepth = 0;
        poseDepth = 0;
    }

    /** Restores whatever a failed frame left open. */
    void end() {
        if (g != null) {
            while (clipDepth > 0) { g.disableScissor(); clipDepth--; }
            while (poseDepth > 0) { g.pose().popMatrix(); poseDepth--; }
        }
        g = null;
        alpha = 1f;
        alphaDepth = 0;
    }

    private int mul(int argb) {
        if (alpha >= 0.999f) return argb;
        int a = Math.round((argb >>> 24) * alpha);
        return (a << 24) | (argb & 0xFFFFFF);
    }

    // ------------------------------------------------------------------ primitives
    @Override public int width() { return g.guiWidth(); }

    @Override public int height() { return g.guiHeight(); }

    @Override public int textWidth(String s) { return s == null || s.isEmpty() ? 0 : font.width(s); }

    @Override public int lineHeight() { return font.lineHeight; }

    @Override public void fill(int x, int y, int w, int h, int argb) {
        if (w <= 0 || h <= 0) return;
        int c = mul(argb);
        if ((c >>> 24) == 0) return;
        g.fill(x, y, x + w, y + h, c);
    }

    @Override public void gradientV(int x, int y, int w, int h, int topArgb, int bottomArgb) {
        if (w <= 0 || h <= 0) return;
        int a = mul(topArgb), b = mul(bottomArgb);
        if ((a >>> 24) == 0 && (b >>> 24) == 0) return;
        g.fillGradient(x, y, x + w, y + h, a, b);
    }

    @Override public void text(String s, int x, int y, int argb, boolean shadow) {
        if (s == null || s.isEmpty()) return;
        int c = mul(argb);
        // The game treats a text colour with an alpha below 4 as "no alpha given" and draws it fully opaque.
        if ((c >>> 24) < 4) return;
        g.text(font, s, x, y, c, shadow);
    }

    @Override public void clip(int x, int y, int w, int h) {
        g.enableScissor(x, y, x + Math.max(0, w), y + Math.max(0, h));
        clipDepth++;
    }

    @Override public void unclip() {
        if (clipDepth <= 0) return;
        g.disableScissor();
        clipDepth--;
    }

    @Override public void push() {
        g.pose().pushMatrix();
        poseDepth++;
    }

    @Override public void pop() {
        if (poseDepth <= 0) return;
        g.pose().popMatrix();
        poseDepth--;
    }

    @Override public void translate(float x, float y) { g.pose().translate(x, y); }

    @Override public void scale(float s) { g.pose().scale(s); }

    @Override public void pushAlpha(float a) {
        if (alphaDepth >= MAX_ALPHA_DEPTH) return;
        alphaStack[alphaDepth++] = alpha;
        alpha *= Math.max(0f, Math.min(1f, a));
    }

    @Override public void popAlpha() {
        if (alphaDepth <= 0) return;
        alpha = alphaStack[--alphaDepth];
    }

    @Override public void item(Object stack, int x, int y, boolean decorations) {
        if (!(stack instanceof ItemStack s) || s.isEmpty() || alpha < 0.5f) return;
        g.item(s, x, y);
        if (decorations) g.itemDecorations(font, s, x, y);
    }

    @Override public void image(Object texture, int texW, int texH, int x, int y, int w, int h) {
        if (!(texture instanceof Identifier id) || texW <= 0 || texH <= 0 || w <= 0 || h <= 0 || alpha < 0.01f) return;
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale((float) w / texW, (float) h / texH);
        if (alpha >= 0.999f) g.blit(RenderPipelines.GUI_TEXTURED, id, 0, 0, 0f, 0f, texW, texH, texW, texH);
        else g.blit(RenderPipelines.GUI_TEXTURED, id, 0, 0, 0f, 0f, texW, texH, texW, texH, ARGB.white(alpha));
        pose.popMatrix();
    }
}
