package com.reaper.client.core.screenshot;

/**
 * A small fixed set of picture slots for the screenshot browser. The game layer owns one texture per slot, so the
 * memory used by thumbnails has a hard ceiling however many screenshots the folder holds. The pool only decides who
 * gets which slot: it does not touch the game.
 *
 * <p>Life of a slot: {@link #claim} makes it LOADING, then the loader calls {@link #markReady} (or {@link #markFailed})
 * with the generation it was given; a result that arrives after the slot was given to someone else, or after
 * {@link #clear}, is refused, so a slow decode can never put the wrong picture on a card.</p>
 */
public final class ThumbPool {
    public enum State { FREE, LOADING, READY, FAILED }

    private final Object[] owner;
    private final State[] state;
    private final int[] generation;
    private final long[] usedFrame;
    private long frame = 1;

    public ThumbPool(int size) {
        if (size < 1) throw new IllegalArgumentException("size");
        owner = new Object[size];
        state = new State[size];
        generation = new int[size];
        usedFrame = new long[size];
        java.util.Arrays.fill(state, State.FREE);
    }

    public int size() { return owner.length; }

    /** Call once per drawn frame, before the cards ask for their pictures. */
    public void beginFrame() { frame++; }

    /** The slot that holds this owner (compared by identity), or -1. Counts as a use in this frame. */
    public int find(Object o) {
        for (int i = 0; i < owner.length; i++) {
            if (owner[i] == o && state[i] != State.FREE) { usedFrame[i] = frame; return i; }
        }
        return -1;
    }

    /**
     * Gives the owner a slot, taking a free one or else the one unused for the longest time that was not drawn in
     * this or the previous frame. Returns -1 when every slot is in use right now (the card then waits a frame).
     */
    public int claim(Object o) {
        int pick = -1;
        for (int i = 0; i < owner.length; i++) if (state[i] == State.FREE) { pick = i; break; }
        if (pick < 0) {
            long oldest = Long.MAX_VALUE;
            for (int i = 0; i < owner.length; i++) {
                if (usedFrame[i] >= frame - 1) continue;
                if (usedFrame[i] < oldest) { oldest = usedFrame[i]; pick = i; }
            }
        }
        if (pick < 0) return -1;
        owner[pick] = o;
        state[pick] = State.LOADING;
        generation[pick]++;
        usedFrame[pick] = frame;
        return pick;
    }

    public State state(int slot) { return state[slot]; }

    public int generation(int slot) { return generation[slot]; }

    public Object owner(int slot) { return owner[slot]; }

    /** The loader finished. False (and nothing changes) when the slot has been given away since. */
    public boolean markReady(int slot, int gen) {
        if (!current(slot, gen)) return false;
        state[slot] = State.READY;
        return true;
    }

    public boolean markFailed(int slot, int gen) {
        if (!current(slot, gen)) return false;
        state[slot] = State.FAILED;
        return true;
    }

    /** True while a result for this slot and generation is still wanted. */
    public boolean current(int slot, int gen) {
        return slot >= 0 && slot < owner.length && generation[slot] == gen && state[slot] == State.LOADING;
    }

    /** Forgets every owner (the screen closed). Results that are still on their way will be refused. */
    public void clear() {
        for (int i = 0; i < owner.length; i++) {
            owner[i] = null;
            state[i] = State.FREE;
            generation[i]++;
            usedFrame[i] = 0;
        }
    }

    public int count(State s) {
        int n = 0;
        for (State x : state) if (x == s) n++;
        return n;
    }
}
