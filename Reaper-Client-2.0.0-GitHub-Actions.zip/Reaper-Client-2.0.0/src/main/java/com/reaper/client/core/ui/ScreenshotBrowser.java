package com.reaper.client.core.ui;

import com.reaper.client.core.feature.ScreenshotLibrary;
import com.reaper.client.core.feature.ScreenshotLibrary.Entry;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.util.Colors;
import com.reaper.client.core.util.Text;

import java.nio.file.Path;
import java.util.List;

/**
 * The screenshot manager: a grid of thumbnails, and for the selected picture a larger preview with rename, copy
 * path and delete. The game layer owns the Screen, feeds {@link #in} and calls {@link #render} every frame.
 */
public final class ScreenshotBrowser {
    /** What the browser needs from the game layer. */
    public interface Host {
        void openFolder(Path dir);
        void toast(Level level, String message);
        void close();
    }

    public static final int MARGIN = 12, HEADER_H = 32, CARD_W = 108, CARD_H = 92, THUMB_H = 61, GAP = 8, DETAILS_W = 196, SCROLL_STEP = 44;

    public final Input in = new Input();
    public final Ui ui = new Ui(in);

    private final ScreenshotLibrary lib;
    private final Thumbnails thumbs;
    private final Host host;
    private final PanelKit kit = new PanelKit();
    private final Object nameKey = new Object();
    private Entry selected;
    private float scroll, scrollTarget;
    private String newName = "";
    private boolean folderMissing;
    private int cols = 1;

    public ScreenshotBrowser(ScreenshotLibrary lib, Thumbnails thumbs, Host host) {
        this.lib = lib;
        this.thumbs = thumbs;
        this.host = host;
    }

    public Entry selected() { return selected; }

    /** Reads the folder again; call when the screen opens. */
    public void open() {
        folderMissing = !lib.refresh();
        selected = null;
        scroll = scrollTarget = 0;
        newName = "";
        ui.unfocus();
        in.reset();
    }

    public void close() {
        thumbs.release();
        ui.unfocus();
        in.reset();
    }

    // ------------------------------------------------------------------ frame
    public void render(Canvas c, Theme t, float dt) {
        int W = c.width(), H = c.height();
        ui.begin(c, t, dt, (int) Math.round(in.mx), (int) Math.round(in.my));
        c.fill(0, 0, W, H, t.backdrop());

        boolean details = W >= 520;
        int top = HEADER_H + 10, bottom = H - MARGIN;
        int gridX = MARGIN, gridY = top, gridW = W - 2 * MARGIN - (details ? DETAILS_W + MARGIN : 0), gridH = bottom - top;

        header(c, t, W);
        List<Entry> list = lib.entries();
        if (selected != null && !list.contains(selected)) selected = null;

        c.roundRect(gridX, gridY, gridW, gridH, 5, Colors.withAlpha(t.panel(), 0xE6));
        grid(c, t, list, gridX, gridY, gridW, gridH);
        if (details) detailsPanel(c, t, W - MARGIN - DETAILS_W, top, DETAILS_W, gridH);

        keys(list, gridH);
        ui.drawTooltip(W, H);
        ui.end();
    }

    private void header(Canvas c, Theme t, int W) {
        c.text("SCREENSHOTS", MARGIN, 10, Colors.withAlpha(t.accent(), 0xF0), true);
        int n = lib.entries().size();
        c.text(n == 1 ? "1 picture" : n + " pictures", MARGIN + c.textWidth("SCREENSHOTS") + 10, 10, t.textDim(), false);
        int bx = W - MARGIN;
        bx -= 70;
        if (ui.button("shots-done", bx, 6, 70, 20, "Done", true, false)) host.close();
        bx -= 76;
        if (ui.button("shots-refresh", bx, 6, 72, 20, "Refresh", false, false)) { folderMissing = !lib.refresh(); kit.say("Refreshed.", false); }
        bx -= 94;
        if (ui.button("shots-folder", bx, 6, 90, 20, "Open folder", false, false)) host.openFolder(lib.dir());
    }

    // ------------------------------------------------------------------ grid
    private void grid(Canvas c, Theme t, List<Entry> list, int gx, int gy, int gw, int gh) {
        if (list.isEmpty()) {
            String msg = folderMissing ? "The screenshots folder does not exist yet." : "No screenshots yet.";
            c.centerText(msg, gx + gw / 2, gy + gh / 2 - 8, t.textDim(), false);
            c.centerText("Take one in the game and it will show up here.", gx + gw / 2, gy + gh / 2 + 6, Colors.withAlpha(t.textDim(), 0x99), false);
            return;
        }
        cols = Math.max(1, (gw - GAP) / (CARD_W + GAP));
        int rows = (list.size() + cols - 1) / cols;
        int contentH = rows * (CARD_H + GAP) + GAP;
        int maxScroll = Math.max(0, contentH - gh);
        boolean overGrid = ui.over(gx, gy, gw, gh);
        if (overGrid && in.scroll != 0) scrollTarget -= (float) in.scroll * SCROLL_STEP;
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scroll = ui.ease(scroll, scrollTarget, 16f);
        if (Math.abs(scroll - scrollTarget) < 0.3f) scroll = scrollTarget;

        int usedW = cols * (CARD_W + GAP) - GAP, offX = gx + (gw - usedW) / 2;
        ui.pushClip(gx, gy, gw, gh);
        int off = Math.round(scroll);
        for (int i = 0; i < list.size(); i++) {
            int row = i / cols, col = i % cols;
            int cx = offX + col * (CARD_W + GAP), cy = gy + GAP + row * (CARD_H + GAP) - off;
            if (cy + CARD_H < gy || cy > gy + gh) continue;
            card(c, t, list.get(i), cx, cy);
        }
        ui.popClip();
        if (maxScroll > 0) {   // a thin scroll bar
            int barH = Math.max(24, gh * gh / contentH), barY = gy + (int) ((gh - barH) * (scroll / maxScroll));
            c.roundRect(gx + gw - 5, barY, 3, barH, 1, Colors.withAlpha(t.textDim(), 0x88));
        }
    }

    private void card(Canvas c, Theme t, Entry e, int x, int y) {
        Ui.WState st = ui.stTransient(e);
        boolean hov = ui.over(x, y, CARD_W, CARD_H), sel = e == selected;
        st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
        st.aux = ui.ease(st.aux, sel ? 1f : 0f, 16f);
        c.roundRect(x, y, CARD_W, CARD_H, 4, Colors.lerp(t.row(), t.rowHover(), Math.max(st.hover * 0.8f, st.aux)));
        if (sel) c.outline(x, y, CARD_W, CARD_H, Colors.withAlpha(t.accent(), 0xCC));
        drawThumb(c, t, e, x + 4, y + 4, CARD_W - 8, THUMB_H);
        c.text(c.fit(e.name, CARD_W - 10), x + 5, y + THUMB_H + 9, sel || hov ? t.text() : t.textDim(), false);
        c.text(c.fit(e.dateText, CARD_W - 10), x + 5, y + THUMB_H + 20, Colors.withAlpha(t.textDim(), 0xBB), false);
        if (hov && in.wasPressed(Input.LEFT) && e != selected) select(e);
    }

    private void drawThumb(Canvas c, Theme t, Entry e, int x, int y, int w, int h) {
        c.fill(x, y, w, h, Colors.withAlpha(t.field(), 0xFF));
        Thumbnails.Thumb th = thumbs.get(e);
        if (th == null || th.width() <= 0 || th.height() <= 0) {
            c.centerText("...", x + w / 2, y + h / 2 - 4, Colors.withAlpha(t.textDim(), 0x77), false);
            return;
        }
        float s = Math.min((float) w / th.width(), (float) h / th.height());
        int dw = Math.max(1, Math.round(th.width() * s)), dh = Math.max(1, Math.round(th.height() * s));
        c.image(th.texture(), th.width(), th.height(), x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
    }

    private void select(Entry e) {
        selected = e;
        newName = "";
        kit.disarm();
    }

    // ------------------------------------------------------------------ details
    private void detailsPanel(Canvas c, Theme t, int x, int y, int w, int h) {
        c.roundRect(x, y, w, h, 5, Colors.withAlpha(t.panel(), 0xE6));
        int cy = y + 8, ix = x + 8, iw = w - 16;
        if (selected == null) {
            c.text("Select a screenshot.", ix, cy, t.textDim(), false);
            return;
        }
        int ph = iw * 9 / 16;
        drawThumb(c, t, selected, ix, cy, iw, ph);
        cy += ph + 8;
        c.text(c.fit(selected.fileName(), iw), ix, cy, t.text(), false);
        cy += 12;
        c.text(selected.dateText + "   " + selected.sizeText, ix, cy, t.textDim(), false);
        cy += 16;

        newName = kit.edit(ui, nameKey, ix, cy, iw, 20, newName, "New name", ScreenshotLibrary.MAX_BASE, Text::isPrintable);
        boolean enter = kit.submitted();
        cy += 25;
        int bw = (iw - 4) / 2;
        boolean rename = ui.button("shots-rename", ix, cy, bw, 20, "Rename", true, false) || enter;
        if (ui.button("shots-copy", ix + bw + 4, cy, bw, 20, "Copy path", false, false)) {
            ui.clipboard.set(selected.path.toString());
            kit.say("Path copied.", false);
            host.toast(Level.SUCCESS, "Copied the path of " + selected.fileName());
        }
        cy += 24;
        if (rename) {
            String err = lib.rename(selected, newName);
            if (err == null) { kit.say("Renamed to " + selected.fileName(), false); newName = ""; }
            else kit.say(err, true);
        }
        boolean armed = kit.armed(ui, "shots-del");
        if (kit.twoClick(ui, "shots-del", ui.button("shots-delete", ix, cy, iw, 20, armed ? "Sure? Click again to delete" : "Delete", false, true))) {
            Entry gone = selected;
            List<Entry> list = lib.entries();
            int idx = list.indexOf(gone);
            if (lib.delete(gone)) {
                kit.say("Deleted " + gone.fileName(), false);
                host.toast(Level.INFO, "Deleted " + gone.fileName());
                selected = list.isEmpty() ? null : list.get(Math.min(Math.max(0, idx), list.size() - 1));
                newName = "";
            } else kit.say("Could not delete the file.", true);
        }
        cy += 26;
        kit.status(ui, ix - 4, cy, iw + 8);
    }

    // ------------------------------------------------------------------ keyboard
    private void keys(List<Entry> list, int gridH) {
        if (ui.focus != null || list.isEmpty()) return;
        for (int i = 0; i < in.keyCount(); i++) {
            int k = in.keyAt(i);
            int cur = selected == null ? -1 : list.indexOf(selected), next = cur;
            switch (k) {
                case KeyNames.LEFT -> next = cur <= 0 ? 0 : cur - 1;
                case KeyNames.RIGHT -> next = Math.min(list.size() - 1, cur + 1);
                case KeyNames.UP -> next = cur < 0 ? 0 : Math.max(0, cur - cols);
                case KeyNames.DOWN -> next = cur < 0 ? 0 : Math.min(list.size() - 1, cur + cols);
                case KeyNames.HOME -> next = 0;
                case KeyNames.END -> next = list.size() - 1;
                default -> { continue; }
            }
            if (next != cur) {
                select(list.get(next));
                int rowTop = (next / cols) * (CARD_H + GAP), rowBottom = rowTop + CARD_H + 2 * GAP;
                if (rowTop < scrollTarget) scrollTarget = rowTop;
                else if (rowBottom > scrollTarget + gridH) scrollTarget = rowBottom - gridH;
            }
        }
    }
}
