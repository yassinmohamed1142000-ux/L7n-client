package com.reaper.client.core.hud;

import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.notify.NotificationCenter;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.ui.Canvas;

/** What an element gets to work with while measuring and drawing. */
public final class HudContext {
    public Canvas c;
    public HudData d;
    public HudState state;
    public Theme theme;
    public ModuleRegistry registry;
    public NotificationCenter notifications;
    public float dt;
    /** True inside the HUD editor: elements show something even when they would normally be empty or hidden. */
    public boolean editing;
}
