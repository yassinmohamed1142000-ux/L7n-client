package com.reaper.client.mc;

import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

/**
 * Reads and writes the game's brightness option. Its slider stops at 100 %, and the game refuses larger values when
 * they are set the normal way. When {@code OptionInstanceMixin} is active the value is put in directly; when it is not,
 * the value is clamped to what the game accepts, so Fullbright then reaches the slider's maximum and no further.
 */
final class BrightnessControl {
    private BrightnessControl() {}

    /** True when the mixin that allows values beyond the slider is in place. */
    static boolean beyondSliderPossible(Minecraft mc) {
        try {
            Object option = mc.options.gamma();
            return option instanceof ForceSet<?>;
        } catch (RuntimeException ex) {
            return false;
        }
    }

    /** The brightness option's value now, or NaN when it cannot be read. */
    static double current(Minecraft mc) {
        try {
            if (mc.options == null) return Double.NaN;
            Double value = mc.options.gamma().get();
            return value == null ? Double.NaN : value;
        } catch (RuntimeException ex) {
            return Double.NaN;
        }
    }

    /** Puts a value into the brightness option. */
    @SuppressWarnings("unchecked")
    static void write(Minecraft mc, double value) {
        if (Double.isNaN(value) || mc.options == null) return;
        OptionInstance<Double> option = mc.options.gamma();
        Object plain = option;   // OptionInstance is final: the mixin's interface is only reachable through Object
        if (plain instanceof ForceSet<?> forceable) {
            ((ForceSet<Double>) forceable).reaper$forceSet(value);
        } else {
            option.set(Math.max(0.0, Math.min(1.0, value)));
        }
    }
}
