package com.reaper.client.core.feature;

/**
 * Decides what the game's brightness option should be while Fullbright is on, and puts the player's own value
 * back afterwards. The player's value is never lost: it is remembered here and can be written to disk by the caller
 * so even a crash cannot leave the game stuck bright.
 */
public final class GammaController {
    /** The player's own brightness, valid while {@link #applied}. */
    private double saved = Double.NaN;
    private double lastSet = Double.NaN;
    private boolean applied;

    public boolean applied() { return applied; }

    public double saved() { return saved; }

    /**
     * One tick. Returns the brightness to write into the game's option, or NaN when nothing needs to change.
     * @param active   Fullbright is on and the server rules allow it
     * @param current  what the option holds right now
     * @param level    the brightness Fullbright wants
     */
    public double tick(boolean active, double current, double level) {
        if (active) {
            if (!applied) {
                saved = current;
                applied = true;
                lastSet = level;
                return current == level ? Double.NaN : level;
            }
            // the player moved the brightness slider while Fullbright was on: remember it as the value to go back to
            if (current != lastSet && current != level) saved = current;
            if (current != level) { lastSet = level; return level; }
            lastSet = level;
            return Double.NaN;
        }
        if (applied) {
            applied = false;
            double back = saved;
            saved = Double.NaN;
            lastSet = Double.NaN;
            return back == current ? Double.NaN : back;
        }
        return Double.NaN;
    }

    /** What to restore on shutdown or disconnect, or NaN when Fullbright is not applied. Marks it as restored. */
    public double restore() {
        if (!applied) return Double.NaN;
        applied = false;
        double back = saved;
        saved = Double.NaN;
        lastSet = Double.NaN;
        return back;
    }
}
