package com.reaper.client.core.config;

/**
 * Debounced saving without threads: settings can change many times a second (dragging a slider), but we only
 * touch the disk once things have been quiet for {@code quietMs}, and never later than {@code maxMs} after the
 * first unsaved change. The game layer calls {@link #tick} every client tick and {@link #flush} on shutdown.
 */
public final class SaveScheduler {
    private final Runnable save;
    private final long quietMs, maxMs;
    private boolean dirty;
    private long firstDirty, lastDirty;

    public SaveScheduler(Runnable save, long quietMs, long maxMs) {
        this.save = save;
        this.quietMs = quietMs;
        this.maxMs = maxMs;
    }

    public void markDirty(long nowMs) {
        if (!dirty) { dirty = true; firstDirty = nowMs; }
        lastDirty = nowMs;
    }

    public boolean isDirty() { return dirty; }

    public void tick(long nowMs) {
        if (dirty && (nowMs - lastDirty >= quietMs || nowMs - firstDirty >= maxMs)) flush();
    }

    public void flush() {
        if (!dirty) return;
        dirty = false;
        save.run();
    }
}
