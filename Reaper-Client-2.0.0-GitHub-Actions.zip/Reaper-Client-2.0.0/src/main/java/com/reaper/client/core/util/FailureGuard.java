package com.reaper.client.core.util;

/**
 * Counts failures in a row of something that runs every frame. One failed frame is logged and skipped; when the same
 * thing fails {@code limit} times in a row, the guard trips and the caller switches that part off for the rest of the
 * session instead of throwing an error every frame.
 */
public final class FailureGuard {
    private final int limit;
    private int streak;
    private boolean tripped;

    public FailureGuard(int limit) {
        this.limit = Math.max(1, limit);
    }

    /** True once the limit was reached. */
    public boolean tripped() { return tripped; }

    /** The frame went fine. */
    public void ok() {
        if (!tripped) streak = 0;
    }

    /** The frame failed. Returns true exactly once: at the failure that reaches the limit. */
    public boolean failed() {
        if (tripped) return false;
        streak++;
        if (streak >= limit) {
            tripped = true;
            return true;
        }
        return false;
    }

    public void reset() {
        streak = 0;
        tripped = false;
    }
}
