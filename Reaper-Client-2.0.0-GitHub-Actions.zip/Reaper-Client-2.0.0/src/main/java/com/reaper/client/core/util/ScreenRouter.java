package com.reaper.client.core.util;

import java.util.function.Supplier;

/**
 * Decides which screen the game should show next. Screens are never switched in the middle of drawing or while a
 * command or button is still being handled (the game may close them again right afterwards); a request is stored here
 * and the game layer asks for the outcome once per tick.
 *
 * <p>A screen opened from the Reaper menu (the HUD editor, the screenshot manager) goes back to the menu when it is
 * closed; every other screen simply closes. The type parameter is the game's screen class, so this class has no
 * Minecraft types and is tested on its own.</p>
 */
public final class ScreenRouter<S> {
    /** What to do now: {@code change} false means "leave the current screen alone". A null {@code screen} means "no screen". */
    public record Outcome<S>(boolean change, S screen) {
        private static final Outcome<?> NONE = new Outcome<>(false, null);
        @SuppressWarnings("unchecked")
        public static <S> Outcome<S> none() { return (Outcome<S>) NONE; }
    }

    private Supplier<S> pending;
    private Supplier<S> pendingBack;
    private boolean hasPending;
    private Supplier<S> back;

    /** Show this screen at the next opportunity. Closing it returns to no screen. */
    public void show(Supplier<S> screen) {
        pending = screen;
        pendingBack = null;
        hasPending = screen != null;
        if (screen == null) close();
    }

    /** Show this screen, and when it is closed, show {@code menu} again. */
    public void showFromMenu(Supplier<S> screen, Supplier<S> menu) {
        if (screen == null) { close(); return; }
        pending = screen;
        pendingBack = menu;
        hasPending = true;
    }

    /** Close the current Reaper screen at the next opportunity (back to the menu when it was opened from there). */
    public void close() {
        pending = null;
        pendingBack = null;
        hasPending = true;
    }

    public boolean hasRequest() { return hasPending; }

    /**
     * Called once per tick. {@code currentIsReaper} says whether the screen on display is one of Reaper's own: a request to
     * close never closes a screen that belongs to the game or another mod.
     */
    public Outcome<S> next(boolean currentIsReaper) {
        if (!hasPending) return Outcome.none();
        Supplier<S> open = pending;
        Supplier<S> openBack = pendingBack;
        pending = null;
        pendingBack = null;
        hasPending = false;
        if (open != null) {
            back = openBack;
            return new Outcome<>(true, open.get());
        }
        if (!currentIsReaper) {
            back = null;
            return Outcome.none();
        }
        Supplier<S> target = back;
        back = null;
        return new Outcome<>(true, target == null ? null : target.get());
    }

    /** Forget everything (leaving the world). */
    public void clear() {
        pending = null;
        pendingBack = null;
        hasPending = false;
        back = null;
    }
}
