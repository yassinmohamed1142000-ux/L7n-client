package com.reaper.client.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reads where an inventory screen's picture sits, so the Sort buttons can be placed next to it. An accessor
 * interface is the one kind of mixin that ordinary code may refer to: the screen object is cast to it.
 */
@Mixin(AbstractContainerScreen.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("leftPos")
    int reaper$leftPos();

    @Accessor("topPos")
    int reaper$topPos();

    @Accessor("imageWidth")
    int reaper$imageWidth();
}
