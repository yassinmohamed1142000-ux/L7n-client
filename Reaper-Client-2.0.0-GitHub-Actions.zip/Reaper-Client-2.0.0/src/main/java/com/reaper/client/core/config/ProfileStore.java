package com.reaper.client.core.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.util.Log;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Configuration profiles: one JSON file per profile in {@code <root>/profiles}. A profile is the complete state of
 * every module (on/off, keybind, every setting, HUD layout). Switching saves the current profile first.
 */
public final class ProfileStore {
    public static final int SCHEMA = 1;
    public static final String EXPORT_PREFIX = "REAPER1:";
    public static final String DEFAULT_NAME = "Default";
    private static final int MAX_EXPORT_BYTES = 400_000;
    private static final Set<String> RESERVED = Set.of("con", "prn", "aux", "nul",
            "com1", "com2", "com3", "com4", "com5", "com6", "com7", "com8", "com9",
            "lpt1", "lpt2", "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9");

    private final Path dir;
    private final ModuleRegistry modules;
    private String active = DEFAULT_NAME;
    /** Directory listing, cached so the GUI can ask every frame without touching the disk. Null = stale. */
    private List<String> cache;

    public ProfileStore(Path root, ModuleRegistry modules) {
        this.dir = root.resolve("profiles");
        this.modules = modules;
    }

    // ------------------------------------------------------------------ naming
    /** Characters allowed anywhere in a profile name: ASCII letters and digits, space, underscore, dot, dash. */
    public static boolean validChar(int c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ' || c == '_' || c == '.' || c == '-';
    }

    /** 1-32 chars, starts with a letter or digit, only {@link #validChar} characters, no reserved device names. */
    public static boolean validName(String n) {
        if (n == null || n.isEmpty() || n.length() > 32) return false;
        char first = n.charAt(0);
        if (first == ' ' || first == '_' || first == '.' || first == '-') return false;
        for (int i = 0; i < n.length(); i++) if (!validChar(n.charAt(i))) return false;
        char last = n.charAt(n.length() - 1);
        if (last == ' ' || last == '.') return false;
        String base = n.toLowerCase(Locale.ROOT);
        int dot = base.indexOf('.');
        if (dot >= 0) base = base.substring(0, dot);
        return !RESERVED.contains(base.trim());
    }

    /** Turns arbitrary text into a valid, not yet used profile name. */
    public String uniqueName(String wanted) {
        StringBuilder sb = new StringBuilder();
        String w = wanted == null ? "" : wanted.trim();
        for (int i = 0; i < w.length() && sb.length() < 28; i++) {
            char c = w.charAt(i);
            if (validChar(c)) sb.append(c);
        }
        String base = sb.toString().trim();
        while (base.endsWith(".")) base = base.substring(0, base.length() - 1).trim();
        if (!validName(base)) base = "Profile";
        String candidate = base;
        for (int n = 2; exists(candidate); n++) candidate = base + " " + n;
        return candidate;
    }

    private Path file(String name) { return dir.resolve(name + ".json"); }

    public boolean exists(String name) {
        for (String n : list()) if (n.equalsIgnoreCase(name)) return true;
        return false;
    }

    public String active() { return active; }

    /** Sorted profile names (always contains the active one). Cached; call {@link #refresh()} to rescan the folder. */
    public List<String> list() {
        if (cache == null) cache = Collections.unmodifiableList(scan());
        return cache;
    }

    /** Forget the cached listing (the GUI does this when it opens, to notice files added by hand). */
    public void refresh() { cache = null; }

    private List<String> scan() {
        List<String> names = new ArrayList<>();
        if (Files.isDirectory(dir)) {
            try (Stream<Path> s = Files.list(dir)) {
                s.map(p -> p.getFileName().toString())
                        .filter(f -> f.endsWith(".json"))
                        .map(f -> f.substring(0, f.length() - 5))
                        .filter(ProfileStore::validName)
                        .forEach(names::add);
            } catch (IOException ex) {
                Log.warn("Could not list profiles", ex);
            }
        }
        if (names.stream().noneMatch(n -> n.equalsIgnoreCase(active))) names.add(active);
        names.sort(String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    // ------------------------------------------------------------------ load / save
    /** Reads the named profile into the modules. A missing or corrupt file simply yields defaults. */
    public void load(String name) {
        JsonObject root = JsonIO.readObject(file(name));
        JsonElement mods = root == null ? null : root.get("modules");
        modules.fromJson(mods != null && mods.isJsonObject() ? mods.getAsJsonObject() : null);
        active = name;
        cache = null;
    }

    public boolean saveActive() { return write(active, snapshot(active)); }

    private JsonObject snapshot(String name) {
        JsonObject o = new JsonObject();
        o.addProperty("schema", SCHEMA);
        o.addProperty("name", name);
        o.add("modules", modules.toJson());
        return o;
    }

    private boolean write(String name, JsonObject o) {
        if (!Files.exists(file(name))) cache = null;   // a new file changes the listing; rewriting an existing one does not
        return JsonIO.writeAtomic(file(name), o);
    }

    private JsonObject read(String name) {
        return name.equalsIgnoreCase(active) ? snapshot(active) : JsonIO.readObject(file(name));
    }

    // ------------------------------------------------------------------ management
    public boolean switchTo(String name) {
        String real = realName(name);
        if (real == null) return false;
        if (real.equals(active)) return true;
        saveActive();
        load(real);
        return true;
    }

    private String realName(String name) {
        for (String n : list()) if (n.equalsIgnoreCase(name)) return n;
        return null;
    }

    /** New profile with every module at its defaults. Returns false for invalid or duplicate names. */
    public boolean create(String name) {
        if (!validName(name) || exists(name)) return false;
        JsonObject o = new JsonObject();
        o.addProperty("schema", SCHEMA);
        o.addProperty("name", name);
        o.add("modules", new JsonObject());
        return write(name, o);
    }

    public boolean duplicate(String src, String dst) {
        String s = realName(src);
        if (s == null || !validName(dst) || exists(dst)) return false;
        JsonObject o = read(s);
        if (o == null) return false;
        o.addProperty("name", dst);
        return write(dst, o);
    }

    public boolean rename(String oldName, String newName) {
        String o = realName(oldName);
        if (o == null || !validName(newName)) return false;
        if (!o.equalsIgnoreCase(newName) && exists(newName)) return false;
        JsonObject data = read(o);
        if (data == null) return false;
        data.addProperty("name", newName);
        boolean wasActive = o.equals(active);
        if (!write(newName, data)) return false;
        if (!o.equals(newName)) {
            try { Files.deleteIfExists(file(o)); Files.deleteIfExists(JsonIO.backupOf(file(o))); }
            catch (IOException ex) { Log.warn("Could not remove old profile file", ex); }
        }
        if (wasActive) active = newName;
        cache = null;
        return true;
    }

    /** The active profile and the last remaining profile cannot be deleted. */
    public boolean delete(String name) {
        String n = realName(name);
        if (n == null || n.equals(active) || list().size() <= 1) return false;
        try {
            Files.deleteIfExists(file(n));
            Files.deleteIfExists(JsonIO.backupOf(file(n)));
            cache = null;
            return true;
        } catch (IOException ex) {
            Log.warn("Could not delete profile " + n, ex);
            return false;
        }
    }

    // ------------------------------------------------------------------ sharing
    /** Text a player can paste to a friend: "REAPER1:" + URL-safe base64 of the profile JSON. */
    public String export(String name) {
        String n = realName(name);
        if (n == null) return null;
        JsonObject o = read(n);
        if (o == null) return null;
        return EXPORT_PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(JsonIO.compact(o).getBytes(StandardCharsets.UTF_8));
    }

    /** Imports exported text as a new profile (never overwrites). Returns the new name or null if the text is not valid. */
    public String importText(String text, String wantedName) {
        if (text == null) return null;
        String t = text.trim();
        if (!t.startsWith(EXPORT_PREFIX) || t.length() > MAX_EXPORT_BYTES * 4 / 3 + 16) return null;
        byte[] raw;
        try {
            raw = Base64.getUrlDecoder().decode(t.substring(EXPORT_PREFIX.length()).replaceAll("\\s+", ""));
        } catch (IllegalArgumentException ex) {
            return null;
        }
        if (raw.length > MAX_EXPORT_BYTES) return null;
        JsonObject o = JsonIO.parseObject(new String(raw, StandardCharsets.UTF_8));
        if (o == null || !o.has("modules") || !o.get("modules").isJsonObject()) return null;
        String suggested = wantedName != null && !wantedName.isBlank() ? wantedName
                : (o.has("name") && o.get("name").isJsonPrimitive() ? o.get("name").getAsString() : "Imported");
        String name = uniqueName(suggested);
        JsonObject out = new JsonObject();
        out.addProperty("schema", SCHEMA);
        out.addProperty("name", name);
        out.add("modules", o.get("modules"));
        return write(name, out) ? name : null;
    }

    /** For tests and diagnostics. */
    public List<String> names() { return list(); }
}
