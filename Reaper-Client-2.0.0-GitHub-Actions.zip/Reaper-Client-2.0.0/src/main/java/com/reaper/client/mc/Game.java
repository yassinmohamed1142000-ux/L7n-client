package com.reaper.client.mc;

import com.reaper.client.core.ReaperCore;
import com.reaper.client.core.command.CommandCenter;
import com.reaper.client.core.feature.BaritoneBridge;
import com.reaper.client.core.feature.ScreenshotLibrary;
import com.reaper.client.core.feature.Waypoint;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.module.KeyTracker;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.policy.ServerMode;
import com.reaper.client.core.policy.ServerPolicy;
import com.reaper.client.core.ui.TextField;
import com.reaper.client.core.util.FailureGuard;
import com.reaper.client.core.util.FrameClock;
import com.reaper.client.core.util.Log;
import com.reaper.client.core.util.ScreenRouter;
import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.IntPredicate;
import java.util.function.Supplier;

/**
 * The hub of the game layer. It creates the {@link ReaperCore}, registers Reaper with Fabric (HUD, crosshair, keys, events,
 * commands) and passes what happens in the game to the core. Everything it does is wrapped so that a failure in Reaper is
 * logged and skipped; none of it is allowed to take the game down.
 *
 * <p>All state is static because the game itself is a single instance and Fabric's callbacks are static registrations.
 * Everything here runs on the game's main thread.</p>
 */
public final class Game {
    private Game() {}

    private static final Logger LOG = LoggerFactory.getLogger("Reaper");
    private static final Identifier HUD_ID = Identifier.fromNamespaceAndPath("reaper", "hud");
    private static final Identifier LOGO = Identifier.fromNamespaceAndPath("reaper", "textures/gui/logo.png");
    /** Size in pixels of assets/reaper/textures/gui/logo.png (the GUI keeps its aspect ratio). */
    private static final int LOGO_W = 64, LOGO_H = 64;
    private static final long SLOW_NS = 500_000_000L;
    /** GLFW_KEY_LAST. Key codes outside 32..348 are not asked about, since GLFW reports an error for them. */
    private static final int LAST_GLFW_KEY = 348;

    private static Minecraft mc;
    private static ReaperCore core;
    private static McCanvas canvas;
    private static GameData gameData;
    private static InventoryTools inventory;
    private static KeyTracker moduleKeys;
    private static CommandCenter commands;

    private static final FrameClock frames = new FrameClock();
    private static final ScreenRouter<Screen> router = new ScreenRouter<>();
    private static final FailureGuard hudGuard = new FailureGuard(5);
    private static final FailureGuard screenGuard = new FailureGuard(3);
    private static final Map<String, Integer> logged = new HashMap<>();
    private static long lastSlowNs;
    private static long joinedAtNs;
    private static boolean wasDead;
    private static boolean gammaChecked;
    private static boolean startupToldInChat;

    // ------------------------------------------------------------------ start-up
    /** Sets everything up. Called once from the mod entry point. */
    public static void init() {
        mc = Minecraft.getInstance();
        Log.setSinks(s -> LOG.info(s), s -> LOG.warn(s));

        Path configDir = FabricLoader.getInstance().getConfigDir().resolve("reaper");
        Path screenshotsDir = FabricLoader.getInstance().getGameDir().resolve("screenshots");
        ReaperCore c = new ReaperCore(configDir, screenshotsDir, System::currentTimeMillis);
        canvas = new McCanvas();
        gameData = new GameData();
        moduleKeys = new KeyTracker(c.modules);
        c.automation.setBridge(new BaritoneBridge());
        c.gui.clipboardImpl = CLIPBOARD;
        c.gui.ui.clipboard = CLIPBOARD;
        c.setPlatform(new Platform());
        commands = new CommandCenter(c, new Actions());
        inventory = new InventoryTools(c);

        ClientKeys.register();
        registerHud();
        registerEvents();
        inventory.register();
        core = c;   // published last: the hooks do nothing until this is set
        LOG.info("Reaper {} is ready (profile \"{}\", {} modules)", version(), c.profiles.active(), c.modules.all().size());
    }

    /** The mod could not start. The game goes on without it; the player is told once, in the chat. */
    public static void initFailed(Throwable t) {
        LOG.error("Reaper could not start and stays switched off. The game itself is not affected.", t);
        try {
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                if (startupToldInChat || client.player == null) return;
                startupToldInChat = true;
                client.player.sendSystemMessage(Component.literal("[Reaper] Reaper could not start and is off (" + t.getClass().getSimpleName()
                        + "). The game is not affected. Details are in logs/latest.log.").withStyle(ChatFormatting.RED));
            });
        } catch (Throwable ignored) {
            // nothing more can be done
        }
    }

    private static void registerHud() {
        // After the scoreboard, action bar and title and before the chat, so the chat stays readable on top of the HUD.
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, HUD_ID, Game::renderHud);
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (graphics, delta) -> crosshair(original, graphics, delta));
    }

    private static void registerEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(Game::onTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(Game::onStopping);
        ClientPlayConnectionEvents.JOIN.register((listener, sender, client) -> onJoin(client));
        ClientPlayConnectionEvents.DISCONNECT.register((listener, client) -> onDisconnect(client));
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, buildContext) -> new ReaperCommands(commands).register(dispatcher));
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, received) -> onChatMessage(message, sender));
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) onGameMessage(message);
        });
    }

    // ------------------------------------------------------------------ what the other classes ask for
    /** The core, or null when Reaper did not start. */
    static ReaperCore core() { return core; }

    static McCanvas canvas() { return canvas; }

    /** True while the player is in a world with no screen open (the keys then belong to the game). */
    static boolean playing() {
        Minecraft m = mc;
        return m != null && m.screen == null && m.level != null && m.player != null;
    }

    /** True while the zoom key is held and the player is playing. */
    static boolean zoomHeld() {
        KeyMapping zoom = ClientKeys.zoom();
        return zoom != null && playing() && zoom.isDown();
    }

    /** True when {@code key} is the keyboard key bound to "open the Reaper menu". */
    static boolean isMenuKey(int key) {
        int bound = ClientKeys.menuKey();
        return bound >= 0 && key == bound;
    }

    static TextField.Clipboard clipboard() { return CLIPBOARD; }

    // ------------------------------------------------------------------ screens
    /** Shows a screen at the next tick, or closes the current Reaper screen when {@code screen} is null. */
    static void requestScreen(Supplier<Screen> screen) {
        if (screen == null) router.close();
        else router.show(screen);
    }

    static void openGui() {
        ReaperCore c = core;
        if (c != null) router.show(() -> new GuiScreen(c));
    }

    static void openHudEditor() {
        ReaperCore c = core;
        if (c != null) fromMenuOrPlain(() -> new HudEditorScreen(c));
    }

    static void openScreenshots() {
        ReaperCore c = core;
        if (c != null) fromMenuOrPlain(() -> new ScreenshotScreen(c));
    }

    private static void fromMenuOrPlain(Supplier<Screen> screen) {
        ReaperCore c = core;
        if (mc.screen instanceof GuiScreen) router.showFromMenu(screen, () -> new GuiScreen(c));
        else router.show(screen);
    }

    /** A Reaper screen failed to draw. After a few failures in a row it is closed so the player is never stuck on it. */
    static void screenFailed(String name, Throwable t) {
        logError("The " + name + " screen failed to draw", t);
        if (screenGuard.failed()) {
            router.close();
            tell("The " + name + " screen was closed after repeated errors. Details are in logs/latest.log.", Level.ERROR);
        }
    }

    static void screenOk() { screenGuard.ok(); }

    // ------------------------------------------------------------------ the HUD (every frame)
    /**
     * Copies the game's state into the core's {@link HudData}. Called once per frame, from the HUD pass or from the HUD
     * editor, which draws the HUD itself.
     */
    static void fillHudData(HudData d) {
        long now = System.nanoTime();
        frames.frame(now);
        gameData.fill(d, frames);
        if (d.inWorld && now - lastSlowNs >= SLOW_NS) {
            lastSlowNs = now;
            gameData.slow(d);
        }
    }

    private static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker delta) {
        ReaperCore c = core;
        Minecraft m = mc;
        if (c == null || hudGuard.tripped() || m.options.hideGui) return;
        if (m.screen instanceof HudEditorScreen) return;   // the editor draws the HUD itself
        McCanvas cv = canvas;
        try {
            HudData d = c.data;
            fillHudData(d);
            c.hud.update(d);
            cv.begin(graphics);
            c.hud.render(cv, d, c.theme(), frames.dt(), false);
            if (d.inWorld) c.waypoints.drawMarkers(cv, c.theme());
            hudGuard.ok();
        } catch (Throwable t) {
            logError("The HUD failed to draw", t);
            if (hudGuard.failed()) {
                tell("The Reaper HUD was switched off after repeated errors. Details are in logs/latest.log.", Level.ERROR);
            }
        } finally {
            cv.end();
        }
    }

    private static void crosshair(HudElement vanilla, GuiGraphicsExtractor graphics, DeltaTracker delta) {
        boolean drawn = false;
        try {
            drawn = drawOwnCrosshair(graphics);
        } catch (Throwable t) {
            logError("The crosshair failed to draw; the game's crosshair is used", t);
        }
        if (!drawn) vanilla.extractRenderState(graphics, delta);
    }

    /** Draws Reaper's crosshair when it is on and the game would draw one; false means "let the game draw its own". */
    private static boolean drawOwnCrosshair(GuiGraphicsExtractor graphics) {
        ReaperCore c = core;
        Minecraft m = mc;
        if (c == null || !c.crosshair.isActive()) return false;
        if (m.player == null || m.level == null || m.options.hideGui) return false;
        if (!m.options.getCameraType().isFirstPerson() || m.player.isSpectator()) return false;
        McCanvas cv = canvas;
        cv.begin(graphics);
        try {
            // the centre pixel of the game's own 15 x 15 crosshair
            int cx = (graphics.guiWidth() - 15) / 2 + 7;
            int cy = (graphics.guiHeight() - 15) / 2 + 7;
            c.crosshair.draw(cv, cx, cy, c.data.speed);
        } finally {
            cv.end();
        }
        return true;
    }

    // ------------------------------------------------------------------ the tick (20 times a second)
    private static final IntPredicate KEY_DOWN = code ->
            code >= 32 && code <= LAST_GLFW_KEY && GLFW.glfwGetKey(mc.getWindow().handle(), code) == GLFW.GLFW_PRESS;

    private static void onTick(Minecraft client) {
        ReaperCore c = core;
        if (c == null) return;
        try { c.tick(); } catch (Throwable t) { logError("The core tick failed", t); }
        try { recoverBrightnessOnce(client, c); } catch (Throwable t) { logError("Brightness recovery failed", t); }
        try { tickScreens(client); } catch (Throwable t) { logError("Switching screens failed", t); }
        try { tickKeys(client, c); } catch (Throwable t) { logError("Key handling failed", t); }
        try { tickBrightness(client, c); } catch (Throwable t) { logError("Fullbright failed", t); }
        try { tickDeath(client, c); } catch (Throwable t) { logError("Death watch failed", t); }
        try { inventory.tick(); } catch (Throwable t) { logError("The inventory sorter failed", t); }
    }

    private static void tickScreens(Minecraft client) {
        if (!router.hasRequest()) return;
        ScreenRouter.Outcome<Screen> outcome = router.next(client.screen instanceof ReaperScreen);
        if (outcome.change()) {
            screenGuard.reset();
            client.setScreen(outcome.screen());
        }
    }

    private static void tickKeys(Minecraft client, ReaperCore c) {
        KeyMapping menu = ClientKeys.menu(), editor = ClientKeys.hudEditor(), waypoint = ClientKeys.waypoint();
        while (menu != null && menu.consumeClick()) {
            if (client.screen == null) openGui();
        }
        while (editor != null && editor.consumeClick()) {
            if (client.screen == null) openHudEditor();
        }
        while (waypoint != null && waypoint.consumeClick()) {
            if (client.screen == null) addWaypointHere(c);
        }
        if (playing()) moduleKeys.update(KEY_DOWN);
        else moduleKeys.reset();
    }

    private static void addWaypointHere(ReaperCore c) {
        Waypoint w = c.waypoints.addHere(c.waypointStore.uniqueName("Waypoint"));
        if (w == null) c.toast(Level.WARN, c.waypoints.problem().isEmpty() ? "No waypoint could be added here." : c.waypoints.problem());
        else c.toast(Level.SUCCESS, "Waypoint added: " + w.name);
    }

    /** A crash can leave the brightness at Fullbright's value; the first tick puts the player's own value back. */
    private static void recoverBrightnessOnce(Minecraft client, ReaperCore c) {
        if (gammaChecked || client.options == null) return;
        gammaChecked = true;
        double own = c.takeCrashedGamma();
        if (!Double.isNaN(own)) {
            BrightnessControl.write(client, own);
            Log.info("The previous session ended while Fullbright was on; the brightness was set back to " + own);
        }
    }

    private static void tickBrightness(Minecraft client, ReaperCore c) {
        double current = BrightnessControl.current(client);
        if (Double.isNaN(current)) return;   // cannot read it, so it is not touched
        double out = c.fullbrightTick(current);
        if (!Double.isNaN(out)) BrightnessControl.write(client, out);
    }

    private static void restoreBrightness(Minecraft client, ReaperCore c) {
        double back = c.fullbrightRestore();
        if (!Double.isNaN(back)) BrightnessControl.write(client, back);
    }

    private static void tickDeath(Minecraft client, ReaperCore c) {
        boolean dead = client.screen instanceof DeathScreen;
        if (dead && !wasDead && client.player != null) {
            gameData.fill(c.data, frames);
            gameData.slow(c.data);
            Waypoint w = c.waypoints.onDeath();
            if (w != null) c.toast(Level.INFO, "Death point saved: " + w.name);
        }
        wasDead = dead;
    }

    // ------------------------------------------------------------------ world
    private static void onJoin(Minecraft client) {
        ReaperCore c = core;
        if (c == null) return;
        try {
            boolean single = client.hasSingleplayerServer();
            String host = single ? "" : serverHost(client);
            String world = single ? singleplayerName(client) : host;
            c.enterWorld(new ServerPolicy.Context(single, host), (single ? "sp:" : "mp:") + (world.isEmpty() ? "unknown" : world));
            gameData.setWorldName(single ? world : host);
            lastSlowNs = 0;
            joinedAtNs = System.nanoTime();
            wasDead = false;
            moduleKeys.reset();
            if (c.policy.mode() == ServerMode.STRICT) {
                c.toast(Level.INFO, "Strict rules for this server: Fullbright, Zoom, waypoint markers and the sorter are off. /reaper server changes it.");
            }
        } catch (Throwable t) {
            logError("Joining a world failed", t);
        }
    }

    private static void onDisconnect(Minecraft client) {
        ReaperCore c = core;
        if (c == null) return;
        try {
            restoreBrightness(client, c);
            router.clear();
            c.leaveWorld();
            gameData.setWorldName("");
            moduleKeys.reset();
            wasDead = false;
        } catch (Throwable t) {
            logError("Leaving a world failed", t);
        }
    }

    private static void onStopping(Minecraft client) {
        ReaperCore c = core;
        if (c == null) return;
        try {
            restoreBrightness(client, c);
            c.flush();
        } catch (Throwable t) {
            logError("Saving at shutdown failed", t);
        }
    }

    private static String serverHost(Minecraft client) {
        ServerData server = client.getCurrentServer();
        if (server == null) return "";
        if (server.isRealm()) return "realms";
        return ServerPolicy.normalizeHost(server.ip);
    }

    private static String singleplayerName(Minecraft client) {
        try {
            var server = client.getSingleplayerServer();
            String name = server == null ? "" : server.getWorldData().getLevelName();
            return name == null || name.isBlank() ? "world" : name.strip();
        } catch (RuntimeException ex) {
            logError("The world's name could not be read; its waypoints use a shared name", ex);
            return "world";
        }
    }

    // ------------------------------------------------------------------ chat
    private static void onChatMessage(Component message, GameProfile sender) {
        ReaperCore c = core;
        Minecraft m = mc;
        if (c == null || m.player == null) return;
        try {
            boolean mine = sender != null && m.player.getUUID().equals(sender.id());
            String alert = c.chat.check(message.getString(), m.player.getGameProfile().name(), mine, c.now());
            if (alert != null) c.toast(Level.INFO, alert);
        } catch (Throwable t) {
            logError("Chat alert failed", t);
        }
    }

    private static void onGameMessage(Component message) {
        ReaperCore c = core;
        Minecraft m = mc;
        if (c == null || m.player == null) return;
        try {
            String alert = c.chat.check(message.getString(), m.player.getGameProfile().name(), false, c.now());
            if (alert != null) c.toast(Level.INFO, alert);
        } catch (Throwable t) {
            logError("Chat alert failed", t);
        }
    }

    /**
     * Called for every line that is added to the chat window (from the chat mixin). Shows a notification when the line is
     * the game's "Saved screenshot as ..." message. Any player could type such a line, so the file must exist.
     */
    static void noticeChatLine(Component line) {
        ReaperCore c = core;
        if (c == null) return;
        String name = ScreenshotLibrary.vanillaFileName(line.getString());
        if (name != null && Files.isRegularFile(c.screenshots.dir().resolve(name))) {
            c.toast(Level.SUCCESS, "Screenshot saved: " + name);
        }
    }

    /** A line in the chat window, in Reaper's colour, for the few things the player must be told even without a HUD. */
    static void tell(String text, Level level) {
        try {
            ReaperCore c = core;
            if (c != null) c.toast(level, text);
            Minecraft m = mc;
            if (m != null && m.player != null) {
                ChatFormatting colour = level == Level.ERROR ? ChatFormatting.RED : level == Level.WARN ? ChatFormatting.YELLOW : ChatFormatting.WHITE;
                m.player.sendSystemMessage(Component.literal("[Reaper] ").withStyle(ChatFormatting.AQUA).append(Component.literal(text).withStyle(colour)));
            }
        } catch (RuntimeException ex) {
            LOG.warn("Could not show a message: {}", text, ex);
        }
    }

    // ------------------------------------------------------------------ files, clipboard, logging
    /** Opens a folder in the system's file manager (the screenshot manager's "Open folder"). */
    static void openFolder(Path dir) {
        try {
            Files.createDirectories(dir);
            Util.getPlatform().openFile(dir.toFile());
        } catch (IOException | RuntimeException ex) {
            logError("The folder " + dir + " could not be opened", ex);
            ReaperCore c = core;
            if (c != null) c.toast(Level.WARN, "The folder could not be opened.");
        }
    }

    private static final TextField.Clipboard CLIPBOARD = new TextField.Clipboard() {
        private String last = "";

        @Override
        public String get() {
            Minecraft m = mc;
            if (m != null && m.keyboardHandler != null) {
                String system = Reflect.clipboard(m.keyboardHandler);
                if (system != null) last = system;
            }
            return last;
        }

        @Override
        public void set(String text) {
            last = text == null ? "" : text;
            try {
                Minecraft m = mc;
                if (m != null && m.keyboardHandler != null) m.keyboardHandler.setClipboard(last);
            } catch (RuntimeException ex) {
                logError("The clipboard could not be written", ex);
            }
        }
    };

    /** Logs an error with its stack trace, but only the first few times for the same message. */
    static synchronized void logError(String what, Throwable t) {
        int n = logged.merge(what, 1, Integer::sum);
        if (n <= 3) LOG.error("{}", what, t);
        else if (n == 4) LOG.error("{} (this has happened again; further occurrences are not logged)", what);
    }

    // ------------------------------------------------------------------ platform and commands
    private static final class Platform implements ReaperCore.Platform {
        @Override public void openHudEditor() { Game.openHudEditor(); }
        @Override public void closeHudEditor() { Game.requestScreen(null); }
        @Override public void openScreenshots() { Game.openScreenshots(); }
        @Override public void closeGui() { Game.requestScreen(null); }

        @Override
        public void clearChat() {
            try {
                mc.gui.getChat().clearMessages(true);
            } catch (RuntimeException ex) {
                logError("The chat could not be cleared", ex);
            }
        }

        @Override public Object logo() { return LOGO; }
        @Override public int logoW() { return LOGO_W; }
        @Override public int logoH() { return LOGO_H; }
    }

    private static final class Actions implements CommandCenter.Actions {
        @Override public void openGui() { Game.openGui(); }
        @Override public void openHudEditor() { Game.openHudEditor(); }
        @Override public void openScreenshots() { Game.openScreenshots(); }
        @Override public List<String> statusLines() { return Game.statusLines(); }
    }

    // ------------------------------------------------------------------ status
    private static String version() {
        return FabricLoader.getInstance().getModContainer("reaper")
                .map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("dev");
    }

    private static String minecraftVersion() {
        return FabricLoader.getInstance().getModContainer("minecraft")
                .map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("unknown");
    }

    /** The game-side facts for {@code /reaper status}: what runs, and which hooks have been seen working. */
    private static List<String> statusLines() {
        List<String> out = new ArrayList<>(5);
        out.add("Reaper " + version() + " on Minecraft " + minecraftVersion() + ".");
        boolean inWorld = mc.level != null;
        long seconds = joinedAtNs == 0 ? 0 : (System.nanoTime() - joinedAtNs) / 1_000_000_000L;
        out.add("Hooks seen working: zoom camera " + seen(Hooks.fovCalls() > 0, inWorld && seconds > 5)
                + ", mouse " + seen(Hooks.mouseCalls() > 0, false)
                + ", chat " + seen(Hooks.chatCalls() > 0, false) + ".");
        out.add(BrightnessControl.beyondSliderPossible(mc)
                ? "Fullbright can go beyond the brightness slider."
                : "Fullbright is limited to the brightness slider's maximum (the option hook is not active).");
        ReaperCore c = core;
        out.add("Baritone: " + (c != null && c.automation.bridge().installed() ? "found." : "not installed."));
        return out;
    }

    private static String seen(boolean yes, boolean overdue) {
        return yes ? "yes" : overdue ? "NOT SEEN (the hook may not have applied; see the log)" : "not yet";
    }
}
