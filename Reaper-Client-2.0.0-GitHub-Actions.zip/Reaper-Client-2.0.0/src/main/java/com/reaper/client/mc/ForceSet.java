package com.reaper.client.mc;

/**
 * Added to the game's {@code OptionInstance} by {@code OptionInstanceMixin}. It sets a value without the range
 * check of the options screen, which is what Fullbright needs for a brightness above the slider's maximum. The value
 * is only ever written to the running game, and is put back when Fullbright is switched off, when the player leaves
 * the world and when the game closes.
 */
public interface ForceSet<T> {
    void reaper$forceSet(T value);
}
