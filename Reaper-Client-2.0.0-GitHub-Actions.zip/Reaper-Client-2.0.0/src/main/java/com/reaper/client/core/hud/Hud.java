package com.reaper.client.core.hud;

import com.reaper.client.core.module.Module;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.notify.NotificationCenter;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.ui.Canvas;

import java.util.ArrayList;
import java.util.List;

/** Draws every active {@link HudElement}. Allocation-free per frame. */
public final class Hud {
    private final ModuleRegistry registry;
    private final List<HudElement> elements = new ArrayList<>();
    public final HudState state = new HudState();
    public final NotificationCenter notifications = new NotificationCenter();
    private final HudContext ctx = new HudContext();

    public Hud(ModuleRegistry registry) {
        this.registry = registry;
        ctx.registry = registry;
        ctx.state = state;
        ctx.notifications = notifications;
    }

    public void add(HudElement e) { elements.add(e); }

    public List<HudElement> elements() { return elements; }

    /** Call once per frame before {@link #render}: updates speed and click counts. */
    public void update(HudData d) { state.update(d); }

    /**
     * Draws the HUD. {@code editing} is true in the HUD editor, where empty or hidden elements are still drawn
     * (with sample data) so they can be found and moved.
     */
    public void render(Canvas c, HudData d, Theme theme, float dt, boolean editing) {
        ctx.c = c;
        ctx.d = d;
        ctx.theme = theme;
        ctx.dt = dt;
        ctx.editing = editing;
        notifications.update(dt);
        int sw = d.screenW, sh = d.screenH;
        for (int i = 0, n = elements.size(); i < n; i++) {
            HudElement e = elements.get(i);
            if (!e.isEnabled() || (!editing && !e.isActive())) { e.rw = e.rh = 0; continue; }
            if (!e.doMeasure(ctx)) { e.rw = e.rh = 0; continue; }
            float s = (float) e.scale.v();
            int rw = Math.max(1, Math.round(e.width() * s)), rh = Math.max(1, Math.round(e.height() * s));
            e.rw = rw;
            e.rh = rh;
            e.rx = HudLayout.x(e.anchor.v(), e.offsetX.i(), rw, sw);
            e.ry = HudLayout.y(e.anchor.v(), e.offsetY.i(), rh, sh);
            c.push();
            c.translate(e.rx, e.ry);
            c.scale(s);
            e.doDraw(ctx);
            c.pop();
        }
    }

    /** Topmost element under a point (the last drawn wins), or null. For the editor. */
    public HudElement at(int px, int py) {
        for (int i = elements.size() - 1; i >= 0; i--) {
            HudElement e = elements.get(i);
            if (e.rw > 0 && px >= e.rx && py >= e.ry && px < e.rx + e.rw && py < e.ry + e.rh) return e;
        }
        return null;
    }

    public ModuleRegistry registry() { return registry; }

    /** Convenience for tests and tools: all modules in the HUD category that are elements. */
    public List<Module> asModules() { return new ArrayList<>(elements); }
}
