package com.reaper.client.core.notify;

/** Severity of a notification toast. */
public enum Level { INFO, SUCCESS, WARN, ERROR }
