package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.HudFormat;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.util.Text;

/**
 * Your position. When the server hides debug information (the reducedDebugInfo game rule) the numbers are not
 * shown, only a short note saying so: this client follows the server's wishes.
 */
public final class CoordinatesElement extends LinesElement {
    public enum Layout implements Settings.Labeled {
        STACKED("Three lines"), COMPACT("One line");
        private final String label;
        Layout(String l) { label = l; }
        @Override public String label() { return label; }
    }

    private final Settings.Num decimals = new Settings.Num("decimals", "Decimals", "Digits after the point.", 1, 0, 3, 1, "");
    private final Settings.Choice<Layout> layout = new Settings.Choice<>("layout", "Layout", "Show X, Y and Z on separate lines or on one.", Layout.STACKED);
    private final Settings.Bool nether = new Settings.Bool("nether", "Nether conversion", "Also show the matching position in the other dimension (Overworld and Nether differ by a factor of 8).", true);
    private final Settings.Bool speed = new Settings.Bool("speed", "Speed", "Show your horizontal speed in blocks per second.", false);

    // what the current lines were built from
    private long kx = Long.MIN_VALUE, ky, kz, kSpeed;
    private int kDec = -1;
    private Layout kLayout;
    private boolean kNether, kSpeedOn, kHidden;
    private HudData.Dimension kDim;
    private int kLines;

    public CoordinatesElement() {
        super("coordinates", "Coordinates", "Shows where you are in the world.", true, "xyz position location nether", Anchor.TOP_LEFT, 4, 22);
        add(decimals);
        add(layout);
        add(nether);
        add(speed);
        commonSettings();
    }

    @Override protected boolean update(HudContext x) {
        HudData d = x.d;
        if (!d.inWorld && !x.editing) return false;
        if (d.reducedDebug && !x.editing) {
            if (!kHidden) {
                kHidden = true; kx = Long.MIN_VALUE;
                lines[0] = "Coordinates hidden by server";
            }
            lineArgb[0] = x.theme.textDim();
            n = 1;
            return true;
        }
        kHidden = false;
        int dec = decimals.i();
        double p = Math.pow(10, dec);
        long rx = Math.round(d.x * p), ry = Math.round(d.y * p), rz = Math.round(d.z * p);
        long rs = speed.on() ? Math.round(d.speed * 10) : 0;
        Layout lay = layout.v();
        boolean nt = nether.on() && HudFormat.netherScale(d.dimension) > 0, sp = speed.on();
        if (rx != kx || ry != ky || rz != kz || dec != kDec || lay != kLayout || nt != kNether || sp != kSpeedOn || rs != kSpeed || d.dimension != kDim) {
            kx = rx; ky = ry; kz = rz; kDec = dec; kLayout = lay; kNether = nt; kSpeedOn = sp; kSpeed = rs; kDim = d.dimension;
            int i = 0;
            String sx = Text.num(d.x, dec), sy = Text.num(d.y, dec), sz = Text.num(d.z, dec);
            if (lay == Layout.COMPACT) {
                lines[i++] = "XYZ: " + sx + " / " + sy + " / " + sz;
            } else {
                lines[i++] = "X: " + sx;
                lines[i++] = "Y: " + sy;
                lines[i++] = "Z: " + sz;
            }
            if (nt) {
                String other = d.dimension == HudData.Dimension.OVERWORLD ? "Nether" : "Overworld";
                lines[i++] = other + ": " + Text.num(HudFormat.convert(d.x, d.dimension), 0) + " / " + Text.num(d.y, 0) + " / " + Text.num(HudFormat.convert(d.z, d.dimension), 0);
            }
            if (sp) lines[i++] = "Speed: " + Text.num(d.speed, 1) + " b/s";
            kLines = i;
        }
        n = kLines;
        int c = color.argb();
        for (int i = 0; i < n; i++) lineArgb[i] = c;
        return true;
    }
}
