package com.reaper.client.core.util;

import java.util.function.Consumer;

/** Tiny logging facade so the core has no logging dependency. The Minecraft layer plugs in SLF4J. */
public final class Log {
    private Log() {}

    private static volatile Consumer<String> warnSink = s -> System.err.println("[Reaper] WARN " + s);
    private static volatile Consumer<String> infoSink = s -> System.out.println("[Reaper] " + s);

    public static void setSinks(Consumer<String> info, Consumer<String> warn) {
        infoSink = info == null ? s -> { } : info;
        warnSink = warn == null ? s -> { } : warn;
    }

    public static void info(String msg) { infoSink.accept(msg); }
    public static void warn(String msg) { warnSink.accept(msg); }
    public static void warn(String msg, Throwable t) { warnSink.accept(msg + ": " + t); }
}
