package com.reaper.client.core.hud;

/** Small formatting helpers for the HUD that need no Minecraft types. */
public final class HudFormat {
    private HudFormat() {}

    private static final String[] SMALL = new String[200];
    static { for (int i = 0; i < SMALL.length; i++) SMALL[i] = Integer.toString(i); }

    /** Integer to string without allocating for small values. */
    public static String small(int n) { return n >= 0 && n < SMALL.length ? SMALL[n] : Integer.toString(n); }

    public static final String[] DIGITS2 = new String[100];
    static { for (int i = 0; i < 100; i++) DIGITS2[i] = i < 10 ? "0" + i : Integer.toString(i); }

    /** Minecraft day time in ticks (0 = sunrise = 06:00, 6000 = noon, 18000 = midnight) as "HH:MM". Negative means unknown. */
    public static String gameClock(long dayTime) {
        if (dayTime < 0) return "--:--";
        long t = dayTime % 24000L;
        int hours = (int) ((t / 1000L + 6L) % 24L);
        int minutes = (int) ((t % 1000L) * 60L / 1000L);
        return DIGITS2[hours] + ":" + DIGITS2[minutes];
    }

    /** Minute-of-day of a wall clock time given the zone offset in milliseconds. */
    public static int minuteOfDay(long wallMs, int zoneOffsetMs) {
        long m = Math.floorDiv(wallMs + zoneOffsetMs, 60_000L);
        return (int) Math.floorMod(m, 1440L);
    }

    /** "HH:MM" for a minute of the day. */
    public static String clock(int minuteOfDay) {
        int m = Math.floorMod(minuteOfDay, 1440);
        return DIGITS2[m / 60] + ":" + DIGITS2[m % 60];
    }

    /** Nether and Overworld positions relate by a factor of 8 on X and Z. Returns 8 (Overworld to Nether divides), or 0 when there is no relation. */
    public static double netherScale(HudData.Dimension d) {
        return d == HudData.Dimension.OVERWORLD || d == HudData.Dimension.NETHER ? 8.0 : 0.0;
    }

    /** The coordinate in the other dimension. Overworld -> Nether divides by 8, Nether -> Overworld multiplies by 8. */
    public static double convert(double v, HudData.Dimension from) {
        return from == HudData.Dimension.OVERWORLD ? v / 8.0 : from == HudData.Dimension.NETHER ? v * 8.0 : v;
    }
}
