package com.reaper.client.core.ui;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.reaper.client.core.config.ProfileStore;
import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.policy.ServerMode;
import com.reaper.client.core.policy.ServerPolicy;
import com.reaper.client.core.setting.Setting;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.ui.Ui.WState;
import com.reaper.client.core.util.Anim;
import com.reaper.client.core.util.Colors;
import com.reaper.client.core.util.Text;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/**
 * The ClickGUI model: windows, top bar, search, module lists, profile and server-rule panels.
 * No Minecraft types. The game's Screen forwards input into {@link #in} and calls {@link #render}.
 */
public final class ClickGui {
    public static final int TOP_H = 52, MARGIN = 12, GAP = 10;
    private static final int P_DRAG = 1, P_RIGHT = 2, P_BOTTOM = 3, P_CORNER = 4, P_SCROLL = 5;

    public final ModuleRegistry registry;
    public final InterfaceModule iface;
    public final ProfileStore profiles;
    public final ServerPolicy policy;
    public final GuiHost host;
    public final Input in = new Input();
    public final Ui ui = new Ui(in);

    /** Z-order, bottom to top. */
    private final List<UiWindow> windows = new ArrayList<>();
    /** Stable order of the window chips in the top bar (never reordered by clicking windows). */
    private final List<UiWindow> chips = new ArrayList<>();
    /** Window layout saved while a search is showing its tidy result columns. */
    private final Map<UiWindow, int[]> savedLayout = new IdentityHashMap<>();
    private boolean searchLayout;
    private int[] colBottom = new int[8];
    private final Object searchKey = new Object();
    private String query = "";
    private final Anim open = new Anim(0);
    private boolean closing;
    private boolean layoutDone;
    private int vw, vh;
    private Object lastOwner;
    private int[] snapCand = new int[32];
    /** Set by the top-bar shortcut: the Client window scrolls to the server rules the next time it draws. */
    private boolean scrollToRules;
    private final Map<UiWindow, Category> windowCategory = new IdentityHashMap<>();

    // window interaction
    private UiWindow toFront, lastHeaderWin;
    private double lastHeaderClickMs = -1000;
    private int dragDx, dragDy, dragStartW, dragStartH;

    // profiles panel
    private String selectedProfile;
    private String profileName = "";
    private String status = "";
    private int statusLevel;
    private float statusT;
    private final Object profileNameKey = new Object();
    private String confirmKey;
    private double confirmUntilMs;
    private double lastProfileClickMs = -1000;
    private String lastProfileRow;

    private final Map<String, String[]> wrapCache = new HashMap<>();

    public ClickGui(ModuleRegistry registry, InterfaceModule iface, ProfileStore profiles, ServerPolicy policy, GuiHost host) {
        this.registry = registry;
        this.iface = iface;
        this.profiles = profiles;
        this.policy = policy;
        this.host = host;
        this.selectedProfile = profiles.active();
        for (Category c : new Category[]{Category.HUD, Category.VISUAL, Category.UTILITY, Category.CLIENT, Category.AUTOMATION}) {
            if (registry.in(c).isEmpty()) continue;
            final Category cat = c;
            UiWindow win = new UiWindow(c.name().toLowerCase(java.util.Locale.ROOT), c.label, (u, w, x, y, cw, vhh) -> moduleList(u, w, cat, x, y, cw));
            windowCategory.put(win, cat);
            addWindow(win);
        }
        addWindow(new UiWindow("profiles", "Profiles", (u, w, x, y, cw, vhh) -> profilesContent(u, x, y, cw)));
        ui.clipboard = new TextField.Clipboard() {
            @Override public String get() { return clipboardGet(); }
            @Override public void set(String s) { clipboardSet(s); }
        };
    }

    /** Clipboard bridge, replaced by the game layer. */
    public TextField.Clipboard clipboardImpl = new TextField.Clipboard() {
        private String s = "";
        @Override public String get() { return s; }
        @Override public void set(String v) { s = v; }
    };
    private String clipboardGet() { return clipboardImpl.get(); }
    private void clipboardSet(String s) { clipboardImpl.set(s); }

    /** Adds a window (Waypoints etc.). Must be called before the first frame. */
    public void addWindow(UiWindow w) { windows.add(w); chips.add(w); }

    public List<UiWindow> windows() { return windows; }
    public String query() { return query; }

    // ------------------------------------------------------------------ lifecycle
    public void onOpen() {
        in.reset();
        ui.deactivate();
        ui.unfocus();
        profiles.refresh();
        closing = false;
        open.snap(iface.animations.on() ? 0f : 1f).set(1f);
    }

    /** Starts the fade-out. The screen closes itself once {@link #isClosed()} turns true. */
    public void requestClose() {
        closing = true;
        ui.deactivate();
        ui.unfocus();
    }

    public boolean isClosing() { return closing; }

    /** True when the fade-out has finished (immediately when animations are off). */
    public boolean isClosed() { return closing && open.value <= 0.02f; }

    /** Called when the screen closes. */
    public void onClose() {
        ui.deactivate();
        ui.unfocus();
        in.reset();
    }

    /** Escape pressed. Returns true when the GUI should close. */
    public boolean onEscape() {
        if (ui.focus != null && ui.focus != searchKey) { ui.unfocus(); return false; }
        if (!query.isEmpty()) { query = ""; ui.field.clear(); ui.unfocus(); return false; }
        return true;
    }

    // ------------------------------------------------------------------ persistence
    public JsonObject layoutToJson() {
        JsonObject o = new JsonObject();
        com.google.gson.JsonArray order = new com.google.gson.JsonArray();
        for (UiWindow w : windows) {
            int[] saved = savedLayout.get(w);
            if (saved == null) { o.add(w.id, w.toJson()); }
            else {   // a search is showing temporary positions: write the user's real layout
                int x = w.x, y = w.y, ww = w.w; boolean v = w.visible, c = w.collapsed;
                applyLayout(w, saved);
                o.add(w.id, w.toJson());
                w.x = x; w.y = y; w.w = ww; w.visible = v; w.collapsed = c;
            }
            order.add(w.id);
        }
        o.add("_order", order);
        return o;
    }

    private static void applyLayout(UiWindow w, int[] l) {
        w.x = l[0]; w.y = l[1]; w.w = l[2]; w.visible = l[3] != 0; w.collapsed = l[4] != 0;
    }

    public void layoutFromJson(JsonObject o) {
        if (o == null || o.size() == 0) return;
        savedLayout.clear();
        searchLayout = false;
        for (UiWindow w : windows) {
            JsonElement e = o.get(w.id);
            if (e != null && e.isJsonObject()) w.fromJson(e.getAsJsonObject());
        }
        JsonElement order = o.get("_order");
        if (order != null && order.isJsonArray()) {
            List<UiWindow> sorted = new ArrayList<>();
            for (JsonElement e : order.getAsJsonArray()) {
                if (!e.isJsonPrimitive()) continue;
                for (UiWindow w : windows) if (w.id.equals(e.getAsString()) && !sorted.contains(w)) sorted.add(w);
            }
            for (UiWindow w : windows) if (!sorted.contains(w)) sorted.add(w);
            windows.clear();
            windows.addAll(sorted);
        }
        layoutDone = true;
    }

    /** First-run placement: one window per free column, the rest hidden until their chip is clicked. */
    private void defaultLayout() {
        int cols = columns();
        int i = 0;
        for (UiWindow w : chips) {
            w.x = MARGIN + (i % cols) * (COL_W + GAP);
            w.y = TOP_H + 12;
            w.visible = i < cols;
            w.vis.snap(w.visible ? 1f : 0f);
            i++;
        }
        layoutDone = true;
    }

    private static final int COL_W = 214;

    private int columns() { return Math.max(1, (vw - MARGIN + GAP) / (COL_W + GAP)); }

    /** Shows a window, moving it to free space when its saved position would cover another window. */
    private void showWindow(UiWindow w) {
        w.visible = true;
        boolean covers = false;
        for (UiWindow o : windows) {
            if (o != w && o.visible && w.x < o.x + o.w && o.x < w.x + w.w && w.y < o.y + o.height() && o.y < w.y + 60) { covers = true; break; }
        }
        if (covers) {
            int cols = columns();
            if (colBottom.length < cols) colBottom = new int[cols];
            Arrays.fill(colBottom, 0, cols, TOP_H + 12);
            for (UiWindow o : windows) {
                if (o == w || !o.visible) continue;
                int c0 = Math.max(0, (o.x - MARGIN + (COL_W + GAP) / 2) / (COL_W + GAP));
                int c1 = Math.min(cols - 1, Math.max(c0, (o.x + o.w - 1 - MARGIN) / (COL_W + GAP)));
                for (int c = c0; c <= c1; c++) colBottom[c] = Math.max(colBottom[c], o.y + o.height() + GAP);
            }
            int best = 0;
            for (int c = 1; c < cols; c++) if (colBottom[c] < colBottom[best]) best = c;
            w.x = MARGIN + best * (COL_W + GAP);
            w.y = colBottom[best] + 80 > vh ? TOP_H + 12 : colBottom[best];
        }
        bringIntoView(w);
        toFront = w;
    }

    /** While a query is active, every window with matches is shown in tidy columns; clearing the query restores the layout. */
    private void updateSearchLayout() {
        boolean want = !query.isEmpty();
        if (want && !searchLayout) {
            savedLayout.clear();
            for (UiWindow w : windows) savedLayout.put(w, new int[]{w.x, w.y, w.w, w.visible ? 1 : 0, w.collapsed ? 1 : 0});
            searchLayout = true;
        } else if (!want && searchLayout) {
            for (Map.Entry<UiWindow, int[]> e : savedLayout.entrySet()) applyLayout(e.getKey(), e.getValue());
            savedLayout.clear();
            searchLayout = false;
        }
        if (!searchLayout) return;
        int cols = columns();
        if (colBottom.length < cols) colBottom = new int[cols];
        Arrays.fill(colBottom, 0, cols, TOP_H + 12);
        for (UiWindow w : chips) {
            if (!anyMatch(w)) continue;
            w.visible = true;
            w.collapsed = false;
            if (ui.active == w) {   // being dragged right now: leave it where the user put it
                continue;
            }
            int best = 0;
            for (int c = 1; c < cols; c++) if (colBottom[c] < colBottom[best]) best = c;
            w.w = COL_W;
            w.x = MARGIN + best * (COL_W + GAP);
            w.y = colBottom[best];
            colBottom[best] += w.height() + GAP;
        }
    }

    // ------------------------------------------------------------------ frame
    public void render(Canvas c, int mousePxX, int mousePxY, float dt) {
        float scale = (float) iface.scale.v();
        ui.animations = iface.animations.on();
        ui.compact = iface.compact.on();
        Theme theme = iface.resolve();
        in.mouseMove(mousePxX, mousePxY);
        vw = Math.round(c.width() / scale);
        vh = Math.round(c.height() / scale);
        if (!layoutDone) defaultLayout();

        ui.begin(c, theme, dt, (int) Math.floor(in.mx / scale), (int) Math.floor(in.my / scale));
        open.set(closing ? 0f : 1f).update(ui.dt, 14f);
        if (!ui.animations) open.snap(closing ? 0f : 1f);
        statusT = Math.max(0, statusT - ui.dt);
        for (UiWindow w : windows) {
            w.vis.set(w.visible ? 1f : 0f);
            w.vis.update(ui.dt, 16f);
            if (!ui.animations) w.vis.snap(w.visible ? 1f : 0f);
            w.col.set(w.collapsed ? 1f : 0f);
            w.col.update(ui.dt, 16f);
            if (!ui.animations) w.col.snap(w.collapsed ? 1f : 0f);
        }

        c.push();
        c.scale(scale);
        float a = Anim.outCubic(open.value);
        c.fill(0, 0, vw, vh, Colors.mulAlpha(theme.backdrop(), a));

        // who owns the mouse this frame: the top bar, or the top-most visible window under the cursor
        Object owner = null;
        if (ui.active != null) owner = ui.active instanceof UiWindow ? ui.active : lastOwner;
        else if (ui.my < TOP_H) owner = this;
        else {
            for (int i = windows.size() - 1; i >= 0; i--) {
                UiWindow w = windows.get(i);
                if (w.vis.value > 0.5f && ui.contains(w.x, w.y, w.w, w.height(), ui.mx, ui.my)) { owner = w; break; }
            }
        }
        lastOwner = owner;
        ui.setInputOwner(owner);

        // type-to-search: any typed text while nothing else has focus goes to the search box
        if (ui.focus == null && in.charCount() > 0) {
            ui.focusField(searchKey, query, 40, null, false);
            ui.field.setCaret(ui.field.length(), false);
        }
        if (ui.focus == searchKey) {
            ui.focusSeen = true;
            int r = ui.pumpField();
            query = Text.lower(ui.field.text()).trim();
            if (r == 1) ui.unfocus();
        }
        toFront = null;
        updateSearchLayout();

        c.pushAlpha(a);
        // windows, bottom to top
        for (int i = 0; i < windows.size(); i++) {
            UiWindow w = windows.get(i);
            if (w.vis.value <= 0.01f) continue;
            if (!anyMatch(w)) continue;
            drawWindow(w, theme);
        }
        if (toFront != null && windows.get(windows.size() - 1) != toFront) { windows.remove(toFront); windows.add(toFront); }
        if (!query.isEmpty() && noResults()) {
            c.centerText("No modules or settings match \"" + query + "\"", vw / 2, vh / 2 - 4, theme.textDim(), true);
        }
        ui.setScope(this);
        drawTopBar(theme);
        drawFooter(theme);
        ui.setScope(null);
        c.popAlpha();
        if (iface.tooltips.on()) ui.drawTooltip(vw, vh);
        c.pop();
        ui.end();
    }

    // ------------------------------------------------------------------ top bar
    private void drawTopBar(Theme t) {
        Canvas c = ui.c;
        c.fill(0, 0, vw, TOP_H, Colors.withAlpha(t.panel(), 0xEE));
        c.gradientV(0, TOP_H, vw, 5, 0x44000000, 0x00000000);
        c.fill(0, TOP_H - 1, vw, 1, t.outline());
        c.fill(0, TOP_H - 1, vw / 3, 1, Colors.withAlpha(t.accent(), 0xAA));

        // brand
        int bx = MARGIN;
        Object logo = host.logo();
        if (logo != null && host.logoW() > 0) {
            int lh = 22, lw = Math.round(lh * host.logoW() / (float) host.logoH());
            c.image(logo, host.logoW(), host.logoH(), bx, 4, lw, lh);
            bx += lw + 6;
        }
        c.text(com.reaper.client.core.Version.NAME, bx, 7, t.text(), t.dark());
        c.text("v" + com.reaper.client.core.Version.VERSION, bx, 17, Colors.withAlpha(t.textDim(), 0xCC), false);
        int brandEnd = bx + Math.max(c.textWidth(com.reaper.client.core.Version.NAME), c.textWidth("v" + com.reaper.client.core.Version.VERSION));

        // right side buttons
        int rx = vw - MARGIN;
        String[] labels = {"HUD editor", "Screenshots"};
        for (int i = 0; i < labels.length; i++) {
            int bw = c.textWidth(labels[i]) + 14;
            rx -= bw;
            if (rx < brandEnd + 150) break;
            if (ui.button(labels[i], rx, 5, bw, 20, labels[i], false, false)) {
                if (i == 0) host.openHudEditor(); else host.openScreenshots();
            }
            rx -= 6;
        }

        // search box (centred between the brand and the buttons)
        int sw = Math.max(120, Math.min(300, rx - brandEnd - 24));
        int sx = Math.max(brandEnd + 12, (vw - sw) / 2);
        if (sx + sw > rx - 6) sx = Math.max(brandEnd + 8, rx - 6 - sw);
        boolean focused = ui.focus == searchKey;
        int fh = 20;
        if (ui.over(sx, 5, sw, fh) && in.wasPressed(Input.LEFT)) {
            if (!focused) { ui.focusField(searchKey, query, 40, null, false); ui.field.setCaret(ui.field.length(), false); focused = true; }
            else ui.field.setCaret(ui.caretFromMouse(sx + 14, ui.mx), false);
        }
        if (ui.over(sx, 5, sw, fh) && in.wasPressed(Input.RIGHT)) { query = ""; ui.field.clear(); }
        ui.textBox(sx, 5, sw, fh, query, "Search modules and settings...", focused, 14);
        // magnifier icon inside the box
        int ix = sx + 6, iy = 5 + (fh - 7) / 2;
        int icol = focused ? t.accent() : t.textDim();
        c.fill(ix + 1, iy, 3, 1, icol);
        c.fill(ix + 1, iy + 4, 3, 1, icol);
        c.fill(ix, iy + 1, 1, 3, icol);
        c.fill(ix + 4, iy + 1, 1, 3, icol);
        c.fill(ix + 5, iy + 5, 2, 2, icol);
        if (!query.isEmpty()) {
            int n = countResults();
            String s = n + (n == 1 ? " result" : " results");
            c.rightText(s, sx + sw - 6, 5 + (fh - c.lineHeight()) / 2 + 1, Colors.withAlpha(t.textDim(), 0xCC), false);
        }

        // window chips
        int cy = 31, cx = MARGIN;
        c.text("Windows", cx, cy + 5, Colors.withAlpha(t.textDim(), 0xAA), false);
        cx += c.textWidth("Windows") + 8;
        for (UiWindow w : chips) {
            int cw = c.textWidth(w.title) + 14;
            if (cx + cw > vw - MARGIN) break;
            WState st = ui.st(w);
            boolean hov = !searchLayout && ui.over(cx, cy, cw, 16);
            st.hover = ui.ease(st.hover, hov ? 1f : 0f, 18f);
            st.aux = ui.ease(st.aux, (searchLayout ? anyMatch(w) : w.visible) ? 1f : 0f, 16f);
            int bg = Colors.lerp(Colors.lerp(t.field(), t.rowHover(), st.hover), Colors.withAlpha(t.accent(), 0xFF), st.aux * 0.85f);
            c.roundRect(cx, cy, cw, 16, 8, bg);
            int tc = Colors.lerp(Colors.lerp(t.textDim(), t.text(), st.hover), t.onAccent(), st.aux);
            c.centerText(w.title, cx + cw / 2, cy + 4, tc, false);
            if (hov && in.wasPressed(Input.LEFT)) {
                if (w.visible) w.visible = false; else showWindow(w);
                host.requestSave();
            }
            cx += cw + 5;
        }
        // profile + server mode on the right of the second row
        String mode = modeLabel();
        String info = "Profile: " + profiles.active() + "   |   ";
        int mw = c.textWidth(mode), iw = c.textWidth(info) + mw;
        if (cx + iw + 16 < vw - MARGIN) {
            WState ms = ui.st("mode-label");
            boolean hov = ui.over(vw - MARGIN - mw - 3, cy + 1, mw + 6, 13);
            ms.hover = ui.ease(ms.hover, hov ? 1f : 0f, 16f);
            int dim = Colors.withAlpha(t.textDim(), 0xCC);
            c.rightText(info, vw - MARGIN - mw, cy + 4, dim, false);
            c.text(mode, vw - MARGIN - mw, cy + 4, Colors.lerp(dim, t.accent(), 0.4f + 0.6f * ms.hover), false);
            c.fill(vw - MARGIN - mw, cy + 13, Math.round(mw * ms.hover), 1, t.accent());
            ui.tip("mode-label", vw - MARGIN - mw - 3, cy + 1, mw + 6, 13, "Click to open the server rules for this server.");
            if (hov && in.wasPressed(Input.LEFT)) openRules();
        }
    }

    /** Opens the Client window scrolled to the server rules (the fair-play settings). */
    private void openRules() {
        UiWindow cw = null;
        for (UiWindow w : windows) if (w.id.equals("client")) cw = w;
        if (cw == null) return;
        if (!cw.visible) showWindow(cw);
        cw.collapsed = false;
        scrollToRules = true;
        toFront = cw;
        host.requestSave();
    }

    private String modeLabel() {
        ServerPolicy.Context ctx = policy.context();
        if (ctx.singleplayer()) return "Singleplayer";
        if (!ctx.inWorld()) return "Not in a world";
        return "Server rules: " + policy.mode().label;
    }

    private void bringIntoView(UiWindow w) {
        w.x = Math.max(0, Math.min(vw - w.w, w.x));
        w.y = Math.max(TOP_H + 4, Math.min(vh - UiWindow.HEADER - 4, w.y));
    }

    private void drawFooter(Theme t) {
        String hint = "Type to search   |   Click a module to toggle   |   Right-click or use the arrow for settings   |   Esc to close";
        Canvas c = ui.c;
        if (c.textWidth(hint) > vw - 24) hint = "Type to search   |   Right-click a module for settings   |   Esc closes";
        c.centerText(hint, vw / 2, vh - 12, 0xB8FFFFFF, true);   // sits on the dimmed game view, not on a panel
    }

    // ------------------------------------------------------------------ windows
    private int maxBody(UiWindow w) { return Math.max(UiWindow.MIN_H, vh - w.y - UiWindow.HEADER - 16); }

    private void drawWindow(UiWindow w, Theme t) {
        Canvas c = ui.c;
        Input in = this.in;
        float va = Anim.outCubic(w.vis.value);
        int slide = Math.round((1f - va) * 12);

        // keep inside the screen (also after resolution changes)
        w.w = Math.max(UiWindow.MIN_W, Math.min(UiWindow.MAX_W, w.w));
        w.x = Math.max(-w.w + 70, Math.min(vw - 70, w.x));
        w.y = Math.max(TOP_H - 8, Math.min(Math.max(TOP_H - 8, vh - UiWindow.HEADER), w.y));

        // animated body height
        int want = w.userSized
                ? Math.min(Math.max(UiWindow.MIN_H, w.userH - UiWindow.HEADER), Math.max(UiWindow.MIN_H, vh - w.y - UiWindow.HEADER - 4))
                : Math.min(maxBody(w), Math.max(40, w.contentH + 2));
        if (!w.bodyInit) { w.body.snap(want); w.bodyInit = true; }
        w.body.set(want);
        w.body.update(ui.dt, 16f);
        if (!ui.animations) w.body.snap(want);
        int viewH = Math.max(0, Math.round(w.body.value));

        ui.setScope(w);
        chrome(w, viewH);

        int x = w.x, y = w.y + slide, ww = w.w, hh = w.height();
        c.pushAlpha(va);
        c.shadow(x, y, ww, hh, 5, 4, t.shadow());
        c.roundBox(x, y, ww, hh, 5, t.panel(), t.outline());
        // header: rounded on top; square at the bottom while the body is showing
        c.roundRect(x + 1, y + 1, ww - 2, UiWindow.HEADER - 1, 4, t.header());
        if (hh - UiWindow.HEADER > 4) c.fill(x + 1, y + UiWindow.HEADER / 2, ww - 2, UiWindow.HEADER / 2 - 1, t.header());
        if (hh - UiWindow.HEADER > 4) c.fill(x + 1, y + UiWindow.HEADER - 1, ww - 2, 1, Colors.withAlpha(t.outline(), 0xAA));
        c.gradientV(x + 8, y + 7, 3, 11, t.accent(), t.accent2());
        c.text(w.title, x + 16, y + (UiWindow.HEADER - c.lineHeight()) / 2 + 1, t.text(), false);
        // collapse chevron
        WState st = ui.st(w);
        boolean overChev = ui.over(x + ww - 22, y, 22, UiWindow.HEADER);
        st.hover = ui.ease(st.hover, overChev ? 1f : 0f, 18f);
        int cc = Colors.lerp(t.textDim(), t.text(), st.hover);
        if (w.collapsed) c.arrow(x + ww - 15, y + 8, 4, 0, cc); else c.arrow(x + ww - 17, y + 10, 4, 1, cc);

        // body
        int bodyH = hh - UiWindow.HEADER;
        if (bodyH > 2) {
            int sbw = w.contentH > viewH ? 8 : 0;
            ui.pushClip(x + 1, y + UiWindow.HEADER, ww - 2, bodyH - 1);
            w.clampScroll(viewH);
            w.scroll = ui.animations ? ui.ease(w.scroll, w.scrollTarget, 22f) : w.scrollTarget;
            int cy = y + UiWindow.HEADER + 5 - Math.round(w.scroll);
            int ch = w.content.draw(ui, w, x + 6, cy, ww - 12 - sbw, viewH);
            w.contentH = ch + 8;
            if (sbw > 0) drawScrollbar(w, x, y, ww, viewH, t);
            ui.popClip();
        }
        // resize grip
        if (!w.collapsed) {
            int gx = x + ww - 11, gy = y + hh - 11;
            boolean og = ui.over(gx, gy, 11, 11) || ui.isActive(w, P_CORNER);
            int gc = og ? t.accent() : Colors.withAlpha(t.textDim(), 0x88);
            for (int i = 0; i < 3; i++) c.fill(gx + 8 - i * 3, gy + 8, 2, 2, gc);
            for (int i = 0; i < 2; i++) c.fill(gx + 8, gy + 5 - i * 3, 2, 2, gc);
        }
        c.popAlpha();
        ui.setScope(null);
    }

    private void drawScrollbar(UiWindow w, int x, int y, int ww, int viewH, Theme t) {
        Canvas c = ui.c;
        int tx = x + ww - 8, ty = y + UiWindow.HEADER + 4, th = viewH - 8;
        if (th < 12) return;
        float ratio = viewH / (float) Math.max(viewH, w.contentH);
        int thumb = Math.max(18, Math.round(th * ratio));
        int max = Math.max(1, w.maxScroll(viewH));
        int off = Math.round((th - thumb) * (w.scroll / max));
        boolean hov = ui.over(tx - 2, ty, 8, th) || ui.isActive(w, P_SCROLL);
        c.roundRect(tx, ty, 4, th, 2, Colors.withAlpha(t.field(), 0xAA));
        c.roundRect(tx, ty + off, 4, thumb, 2, hov ? t.accent() : Colors.withAlpha(t.textDim(), 0x99));
        if (ui.over(tx - 3, ty, 10, th) && in.wasPressed(Input.LEFT)) {
            ui.activate(w, P_SCROLL);
            boolean onThumb = ui.my >= ty + off && ui.my < ty + off + thumb;
            dragDy = onThumb ? ui.my - (ty + off) : thumb / 2;
        }
        if (ui.isActive(w, P_SCROLL)) {
            float f = (ui.my - dragDy - ty) / (float) Math.max(1, th - thumb);
            w.scrollTarget = w.scroll = Math.max(0, Math.min(max, f * max));
            if (!in.isDown(Input.LEFT)) ui.deactivate();
        }
    }

    /** Dragging, resizing, collapsing and wheel scrolling for one window. */
    private void chrome(UiWindow w, int viewH) {
        int x = w.x, y = w.y, ww = w.w, hh = w.height();
        // continuing drags
        if (ui.active == w) {
            if (ui.activePart == P_DRAG) {
                if (!in.isDown(Input.LEFT)) { ui.deactivate(); host.requestSave(); return; }
                w.x = snap(ui.mx - dragDx, w, true);
                w.y = snap(ui.my - dragDy, w, false);
            } else if (ui.activePart >= P_RIGHT && ui.activePart <= P_CORNER) {
                if (!in.isDown(Input.LEFT)) { ui.deactivate(); host.requestSave(); return; }
                if (ui.activePart != P_BOTTOM) w.w = Math.max(UiWindow.MIN_W, Math.min(UiWindow.MAX_W, dragStartW + ui.mx - dragDx));
                if (ui.activePart != P_RIGHT) {
                    w.userSized = true;
                    w.userH = Math.max(UiWindow.MIN_H, Math.min(vh - w.y - 4, dragStartH + ui.my - dragDy));
                }
            }
            return;
        }
        if (ui.active != null || !ui.isOwner(w)) return;
        if (in.wasPressed(Input.LEFT)) {
            toFront = w;
            boolean inHeader = ui.contains(x, y, ww, UiWindow.HEADER, ui.mx, ui.my);
            boolean onChev = ui.contains(x + ww - 22, y, 22, UiWindow.HEADER, ui.mx, ui.my);
            if (onChev) { w.collapsed = !w.collapsed; host.requestSave(); }
            else if (inHeader) {
                if (lastHeaderWin == w && ui.timeMs - lastHeaderClickMs < 350) { w.collapsed = !w.collapsed; lastHeaderWin = null; host.requestSave(); }
                else {
                    lastHeaderWin = w; lastHeaderClickMs = ui.timeMs;
                    ui.activate(w, P_DRAG); dragDx = ui.mx - x; dragDy = ui.my - y;
                }
            } else if (!w.collapsed) {
                boolean right = ui.mx >= x + ww - 5, bottom = ui.my >= y + hh - 5;
                boolean corner = ui.mx >= x + ww - 12 && ui.my >= y + hh - 12;
                if (corner) {
                    if (ui.timeMs - lastHeaderClickMs < 350 && lastHeaderWin == w) { w.userSized = false; w.w = 214; lastHeaderWin = null; host.requestSave(); }
                    else { lastHeaderWin = w; lastHeaderClickMs = ui.timeMs; ui.activate(w, P_CORNER); dragDx = ui.mx; dragDy = ui.my; dragStartW = ww; dragStartH = hh; }
                } else if (right) { ui.activate(w, P_RIGHT); dragDx = ui.mx; dragDy = ui.my; dragStartW = ww; dragStartH = hh; }
                else if (bottom) { ui.activate(w, P_BOTTOM); dragDx = ui.mx; dragDy = ui.my; dragStartW = ww; dragStartH = hh; }
            }
        }
        if (in.wasPressed(Input.RIGHT) && ui.contains(x, y, ww, UiWindow.HEADER, ui.mx, ui.my)) { w.collapsed = !w.collapsed; host.requestSave(); }
        if (in.scroll != 0 && !in.ctrl() && !w.collapsed && ui.contains(x, y + UiWindow.HEADER, ww, hh - UiWindow.HEADER, ui.mx, ui.my)) {
            w.scrollTarget -= (float) in.scroll * 28f;
            w.clampScroll(viewH);
            in.scroll = 0;
        }
    }

    /** Snaps to screen edges and to other windows within 6 px. */
    private int snap(int v, UiWindow self, boolean horizontal) {
        int size = horizontal ? self.w : self.height();
        int limit = horizontal ? vw : vh;
        int best = v, bestD = 7;
        int need = 2 + windows.size() * 4;
        if (snapCand.length < need) snapCand = new int[need];
        int[] cand = snapCand;
        int n = 0;
        cand[n++] = horizontal ? MARGIN : TOP_H + 4;
        cand[n++] = limit - size - MARGIN;
        for (UiWindow o : windows) {
            if (o == self || !o.visible) continue;
            int o0 = horizontal ? o.x : o.y, o1 = o0 + (horizontal ? o.w : o.height());
            cand[n++] = o0 - size - 4; cand[n++] = o1 + 4; cand[n++] = o0; cand[n++] = o1 - size;
        }
        for (int i = 0; i < n; i++) {
            int d = Math.abs(v - cand[i]);
            if (d < bestD) { bestD = d; best = cand[i]; }
        }
        return best;
    }

    // ------------------------------------------------------------------ search helpers
    private boolean settingMatches(Setting<?> s) { return !query.isEmpty() && Text.matchesAll(s.searchText(), query); }

    private boolean moduleShown(Module m) {
        if (query.isEmpty() || m.matches(query)) return true;
        for (Setting<?> s : m.allSettings()) if (settingMatches(s)) return true;
        return false;
    }

    private boolean anyMatch(UiWindow w) {
        if (query.isEmpty()) return true;
        Category cat = windowCategory.get(w);
        if (cat == null) return Text.matchesAll(Text.lower(w.title), query);
        for (Module m : registry.in(cat)) if (moduleShown(m)) return true;
        return false;
    }

    private boolean noResults() {
        for (UiWindow w : windows) if (anyMatch(w)) return false;
        return true;
    }

    private int countResults() {
        if (query.isEmpty()) return 0;
        int n = 0;
        for (Module m : registry.all()) if (moduleShown(m)) n++;
        return n;
    }

    // ------------------------------------------------------------------ module list window content
    private int moduleList(Ui ui, UiWindow win, Category cat, int x, int y, int w) {
        int cy = y;
        List<Module> mods = registry.in(cat);
        for (Module m : mods) {
            if (!moduleShown(m)) continue;
            cy += drawModule(ui, m, x, cy, w) + 3;
        }
        if (cat == Category.CLIENT) {
            int rulesOffset = cy - y;
            if (scrollToRules) { scrollToRules = false; win.scrollTarget = Math.max(0, rulesOffset - 6); }
            cy += serverRules(ui, x, cy, w);
        }
        return cy - y;
    }

    private int drawModule(Ui ui, Module m, int x, int y, int w) {
        Canvas c = ui.c;
        Theme t = ui.theme;
        WState st = ui.st(m);
        List<Setting<?>> all = m.allSettings();
        boolean panel = !m.toggleable;                  // settings-only modules are always expanded section panels
        boolean viaSettings = !query.isEmpty() && !m.matches(query);
        boolean open = panel || st.open || viaSettings;
        int rh = ui.rowH();
        int used = 0;

        if (!panel) {
            boolean hov = ui.over(x, y, w, rh);
            st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
            st.aux = ui.ease(st.aux, m.isEnabled() ? 1f : 0f, 14f);
            boolean hasSettings = !all.isEmpty();
            int chevX = x + w - 22;
            if (hov && in.wasPressed(Input.LEFT)) {
                if (hasSettings && ui.mx >= chevX) st.open = !st.open;
                else { m.toggle(); ui.changed = true; host.requestSave(); }
            }
            if (hov && in.wasPressed(Input.RIGHT) && hasSettings) st.open = !st.open;
            int bg = Colors.lerp(t.row(), Colors.lerp(t.row(), t.accent(), 0.20f), st.aux);
            bg = Colors.lerp(bg, t.rowHover(), st.hover * 0.9f);
            c.roundRect(x, y, w, rh, 3, bg);
            if (st.aux > 0.01f) c.roundRect(x, y + 3, 3, rh - 6, 1, Colors.mulAlpha(t.accent(), st.aux));
            int tc = Colors.lerp(Colors.lerp(t.textDim(), t.text(), st.hover), t.text(), st.aux);
            int rightEdge = x + w - 6;
            if (hasSettings) {
                int ax = x + w - 15;
                int ac = Colors.lerp(t.textDim(), t.text(), st.hover);
                if (open) c.arrow(ax, y + rh / 2 - 1, 3, 1, ac); else c.arrow(ax + 1, y + rh / 2 - 3, 3, 0, ac);
                rightEdge = chevX - 2;
            }
            ui.drawSwitch(rightEdge - 24, y + (rh - 12) / 2, st.aux, !m.isBlockedByPolicy());
            rightEdge -= 24 + 6;
            if (m.isBlockedByPolicy()) {
                c.rightText("!", rightEdge, y + (rh - c.lineHeight()) / 2 + 1, t.warn(), false);
                rightEdge -= c.textWidth("!") + 5;
            }
            if (m.bind.bound()) {
                String k = m.bind.valueText();
                c.rightText(k, rightEdge, y + (rh - c.lineHeight()) / 2 + 1, Colors.withAlpha(t.textDim(), 0xBB), false);
                rightEdge -= c.textWidth(k) + 5;
            }
            c.text(c.fit(m.name, rightEdge - (x + 10)), x + 10, y + (rh - c.lineHeight()) / 2 + 1, tc, false);
            String tip = m.description;
            if (m.isBlockedByPolicy()) tip += "\nOff on this server: " + (m.feature() == null ? "" : m.feature().label + " is blocked in " + policy.mode().label + " mode.");
            ui.tip(m, x, y, w, rh, tip);
            used = rh;
            st.aux2 = ui.ease(st.aux2, open ? 1f : 0f, 16f);
        } else {
            // section header for settings-only modules
            c.text(m.name.toUpperCase(), x + 4, y + 2, Colors.withAlpha(t.accent(), 0xDD), false);
            c.fill(x + 4 + c.textWidth(m.name.toUpperCase()) + 6, y + 6, Math.max(0, w - 8 - c.textWidth(m.name.toUpperCase()) - 6), 1, Colors.withAlpha(t.outline(), 0xAA));
            used = 14;
            st.aux2 = 1f;
        }

        if (open || st.aux2 > 0.01f) {
            int total = 6;
            for (Setting<?> s : all) if (s.isVisible()) total += SettingRows.height(ui, s);
            float e = Anim.outCubic(st.aux2);
            int ph = Math.round(total * e);
            if (ph > 0) {
                int py = y + used + (panel ? 0 : 1);
                if (!panel) c.roundRect(x + 3, py, w - 6, ph, 3, Colors.lerp(t.panel(), t.field(), 0.55f));
                ui.pushClip(x + 3, py, w - 6, ph);
                int sy = py + 3;
                for (Setting<?> s : all) {
                    if (!s.isVisible()) continue;
                    sy += SettingRows.draw(ui, host, registry, m, s, x + 3, sy, w - 6, settingMatches(s));
                }
                ui.popClip();
                used += ph + (panel ? 2 : 4);
            }
        }
        return used;
    }

    // ------------------------------------------------------------------ server rules (Client window)
    private String[] wrap(String s, int maxW) {
        String key = s + "|" + maxW;
        String[] cached = wrapCache.get(key);
        if (cached != null) return cached;
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (line.length() > 0 && ui.c.textWidth(test) > maxW) { lines.add(line.toString()); line.setLength(0); line.append(word); }
            else { line.setLength(0); line.append(test); }
        }
        if (line.length() > 0) lines.add(line.toString());
        String[] out = lines.toArray(new String[0]);
        if (wrapCache.size() > 64) wrapCache.clear();
        wrapCache.put(key, out);
        return out;
    }

    private int serverRules(Ui ui, int x, int y, int w) {
        Canvas c = ui.c;
        Theme t = ui.theme;
        int cy = y + 4;
        c.text("SERVER RULES", x + 4, cy, Colors.withAlpha(t.accent(), 0xDD), false);
        c.fill(x + 4 + c.textWidth("SERVER RULES") + 6, cy + 4, Math.max(0, w - 8 - c.textWidth("SERVER RULES") - 6), 1, Colors.withAlpha(t.outline(), 0xAA));
        cy += 15;
        ServerPolicy.Context ctx = policy.context();
        String where = ctx.singleplayer() ? "Singleplayer: everything is available."
                : ctx.inWorld() ? "Server: " + ctx.host() : "Join a server to set its rules.";
        for (String l : wrap(where, w - 12)) { c.text(l, x + 6, cy, t.text(), false); cy += 11; }
        cy += 2;
        if (ctx.inWorld() && !ctx.singleplayer()) {
            ServerMode cur = policy.mode();
            int bw = (w - 12 - 8) / 3;
            for (int i = 0; i < ServerMode.values().length; i++) {
                ServerMode m = ServerMode.values()[i];
                int bx = x + 6 + i * (bw + 4);
                boolean sel = m == cur;
                if (ui.button("rule-" + m.name(), bx, cy, bw, 20, m.label, sel, false)) {
                    policy.setMode(ctx.host(), m);
                    host.toast(Level.INFO, "Server rules for " + ctx.host() + ": " + m.label);
                    host.requestSave();
                }
            }
            cy += 24;
            for (String l : wrap(cur.blurb, w - 12)) { c.text(l, x + 6, cy, Colors.withAlpha(t.textDim(), 0xDD), false); cy += 11; }
            cy += 3;
            StringBuilder off = new StringBuilder();
            for (Feature f : Feature.values()) if (!cur.allows(f)) off.append(off.length() == 0 ? "" : ", ").append(f.label);
            if (off.length() > 0) for (String l : wrap("Off here: " + off, w - 12)) { c.text(l, x + 6, cy, t.warn(), false); cy += 11; }
            cy += 4;
        }
        List<String> hosts = policy.hosts();
        if (!hosts.isEmpty()) {
            c.text("Saved rules", x + 6, cy, Colors.withAlpha(t.textDim(), 0xCC), false);
            cy += 12;
            for (int i = 0; i < Math.min(8, hosts.size()); i++) {
                String h = hosts.get(i);
                ServerMode m = policy.modeFor(h);
                c.text(c.fit(h, w - 100), x + 8, cy + 3, t.text(), false);
                c.rightText(m.label, x + w - 30, cy + 3, m == ServerMode.STRICT ? t.warn() : m == ServerMode.OPEN ? t.good() : t.textDim(), false);
                if (ui.button("rm-" + h, x + w - 22, cy, 16, 15, "x", false, true)) { policy.setMode(h, ServerMode.STANDARD); host.requestSave(); }
                cy += 18;
            }
            cy += 2;
        }
        // global actions
        if (ui.button("disable-all", x + 6, cy, w - 12, 20, "Disable all modules", false, false)) {
            int n = registry.disableAll();
            host.toast(Level.INFO, n + (n == 1 ? " module" : " modules") + " turned off");
            host.requestSave();
        }
        cy += 24;
        boolean resetArmed = armed("reset-all");
        if (twoClick("reset-all", ui.button("reset-all-btn", x + 6, cy, w - 12, 20, resetArmed ? "Click again to reset everything" : "Reset all settings", false, true))) {
            registry.resetAll();
            host.toast(Level.INFO, "All settings reset to defaults");
            host.requestSave();
        }
        cy += 24;
        return cy - y;
    }

    // ------------------------------------------------------------------ two-click confirmation
    /** True while the key is armed (first click done, waiting up to 3 s for the confirming click). */
    private boolean armed(String key) { return key.equals(confirmKey) && ui.timeMs < confirmUntilMs; }

    /** Feed it the button's "clicked" result: the first click arms the key, a second click in time confirms (returns true). */
    private boolean twoClick(String key, boolean clicked) {
        if (!clicked) return false;
        if (armed(key)) { confirmKey = null; return true; }
        confirmKey = key;
        confirmUntilMs = ui.timeMs + 3000;
        return false;
    }

    // ------------------------------------------------------------------ profiles window
    private void say(String msg, int level) { status = msg; statusLevel = level; statusT = 6f; }

    private int profilesContent(Ui ui, int x, int y, int w) {
        Canvas c = ui.c;
        Theme t = ui.theme;
        int cy = y;
        List<String> names = profiles.list();
        if (selectedProfile == null || names.stream().noneMatch(n -> n.equals(selectedProfile))) selectedProfile = profiles.active();

        c.text("ACTIVE PROFILE", x + 4, cy + 2, Colors.withAlpha(t.accent(), 0xDD), false);
        cy += 14;
        c.text(c.fit(profiles.active(), w - 8), x + 6, cy, t.text(), false);
        cy += 14;

        for (String n : names) {
            WState st = ui.st("profile-" + n);
            boolean hov = ui.over(x, cy, w, 20);
            boolean active = n.equals(profiles.active()), sel = n.equals(selectedProfile);
            st.hover = ui.ease(st.hover, hov ? 1f : 0f, 16f);
            st.aux = ui.ease(st.aux, sel ? 1f : 0f, 16f);
            int bg = Colors.lerp(t.row(), t.rowHover(), Math.max(st.hover * 0.8f, st.aux));
            if (active) bg = Colors.lerp(bg, t.accent(), 0.16f);
            c.roundRect(x, cy, w, 20, 3, bg);
            if (sel) c.outline(x, cy, w, 20, Colors.withAlpha(t.accent(), 0x99));
            if (active) c.disc(x + 9, cy + 10, 3, t.accent());
            c.text(c.fit(n, w - 70), x + 18, cy + 6, sel || active ? t.text() : t.textDim(), false);
            if (active) c.rightText("active", x + w - 6, cy + 6, t.accent(), false);
            if (hov && in.wasPressed(Input.LEFT)) {
                boolean doubleClick = n.equals(lastProfileRow) && ui.timeMs - lastProfileClickMs < 350;
                selectedProfile = n;
                lastProfileRow = doubleClick ? null : n;
                lastProfileClickMs = ui.timeMs;
                if (doubleClick) doSwitch();   // double click on the same row loads it
            }
            cy += 22;
        }
        cy += 4;

        // name box
        boolean editing = ui.focus == profileNameKey;
        int bh = 20;
        if (ui.over(x, cy, w, bh) && in.wasPressed(Input.LEFT) && !editing) {
            ui.focusField(profileNameKey, profileName, 32, ProfileStore::validChar, false);
            ui.field.setCaret(ui.field.length(), false);
            editing = true;
        } else if (editing && in.wasPressed(Input.LEFT) && ui.over(x, cy, w, bh)) {
            ui.field.setCaret(ui.caretFromMouse(x, ui.mx), false);
        }
        if (editing) {
            ui.focusSeen = true;
            int r = ui.pumpField();
            profileName = ui.field.text();
            boolean clickAway = in.wasPressed(Input.LEFT) && !ui.contains(x, cy, w, bh, ui.mx, ui.my);
            if (r == 1 || r == 2 || clickAway) { ui.unfocus(); editing = false; }
        }
        ui.textBox(x, cy, w, bh, profileName, "Name for New / Rename / Copy", editing);
        cy += bh + 5;

        int bw = (w - 4) / 2;
        String sel = selectedProfile;
        if (ui.button("p-switch", x, cy, bw, 20, "Load", true, false)) doSwitch();
        if (ui.button("p-new", x + bw + 4, cy, bw, 20, "New", false, false)) {
            if (profiles.create(profileName)) { selectedProfile = profileName; say("Created " + profileName, 1); profileName = ""; host.requestSave(); }
            else say("Name must be 1-32 letters, digits, space, - _ . and not already used", 3);
        }
        cy += 24;
        if (ui.button("p-rename", x, cy, bw, 20, "Rename", false, false)) {
            String old = sel;
            if (profiles.rename(old, profileName)) { selectedProfile = profileName; say("Renamed to " + profileName, 1); profileName = ""; host.requestSave(); }
            else say("Cannot rename: invalid or taken name", 3);
        }
        if (ui.button("p-copy", x + bw + 4, cy, bw, 20, "Copy", false, false)) {
            String dst = profileName.isBlank() ? profiles.uniqueName(sel + " copy") : profileName;
            if (profiles.duplicate(sel, dst)) { selectedProfile = dst; say("Copied to " + dst, 1); profileName = ""; host.requestSave(); }
            else say("Cannot copy: invalid or taken name", 3);
        }
        cy += 24;
        String delKey = "del-" + sel;
        if (twoClick(delKey, ui.button("p-delete", x, cy, bw, 20, armed(delKey) ? "Sure?" : "Delete", false, true))) {
            if (profiles.delete(sel)) { say("Deleted " + sel, 1); selectedProfile = profiles.active(); }
            else say("The active profile cannot be deleted", 3);
        }
        if (ui.button("p-export", x + bw + 4, cy, bw, 20, "Export", false, false)) {
            String txt = profiles.export(sel);
            if (txt != null) { ui.clipboard.set(txt); say("Profile text copied to the clipboard", 1); host.toast(Level.SUCCESS, "Profile \"" + sel + "\" copied to clipboard"); }
            else say("Export failed", 3);
        }
        cy += 24;
        if (ui.button("p-import", x, cy, bw, 20, "Import", false, false)) {
            String name = profiles.importText(ui.clipboard.get(), profileName.isBlank() ? null : profileName);
            if (name != null) { selectedProfile = name; profileName = ""; say("Imported as " + name, 1); host.toast(Level.SUCCESS, "Imported profile \"" + name + "\""); }
            else say("Clipboard does not hold a Reaper profile", 3);
        }
        if (ui.button("p-save", x + bw + 4, cy, bw, 20, "Save now", false, false)) {
            say(profiles.saveActive() ? "Saved" : "Could not save", 1);
        }
        cy += 26;
        if (statusT > 0 && !status.isEmpty()) {
            int col = statusLevel == 3 ? t.bad() : t.good();
            for (String l : wrap(status, w - 8)) { c.text(l, x + 4, cy, Colors.mulAlpha(col, Math.min(1f, statusT)), false); cy += 11; }
            cy += 2;
        }
        return cy - y;
    }

    private void doSwitch() {
        if (selectedProfile == null) return;
        if (profiles.switchTo(selectedProfile)) {
            say("Loaded " + selectedProfile, 1);
            host.toast(Level.SUCCESS, "Profile \"" + selectedProfile + "\" loaded");
            host.requestSave();
        } else say("Profile not found", 3);
    }
}
