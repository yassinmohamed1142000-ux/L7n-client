package com.reaper.client.core.command;

import com.reaper.client.core.ReaperCore;
import com.reaper.client.core.feature.Waypoint;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.policy.ServerMode;
import com.reaper.client.core.policy.ServerPolicy;
import com.reaper.client.core.config.ProfileStore;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The text commands ({@code /reaper ...}), as plain logic: a line goes in, a list of replies comes out. The game layer
 * only registers the command, forwards what was typed and prints the replies, so every command is covered by the
 * plain-JDK tests.
 *
 * <p>Nothing here does more than the GUI does. The commands that change what is allowed on a server ({@code server})
 * only change the player's own record of that server's rules.</p>
 */
public final class CommandCenter {
    /** What only the game layer can do. */
    public interface Actions {
        void openGui();
        void openHudEditor();
        void openScreenshots();
        /** Facts about the game side (version, hooks, Baritone) for {@code /reaper status}. May be empty. */
        List<String> statusLines();
    }

    /** One line for the player. */
    public record Reply(Level level, String text) { }

    public static final int MAX_LINE = 200, MAX_SUGGESTIONS = 60;

    private static final String[] HELP = {
            "/reaper  opens the menu.  /reaper hud  /reaper screenshots",
            "/reaper toggle <module>  turns a module on or off.  /reaper modules  lists the ones that are on.",
            "/reaper profile [load|new|delete <name> | save]  manages settings profiles.",
            "/reaper server [standard|strict|open]  shows or sets the rules for the server you are on.",
            "/reaper waypoint [add <name> | list | remove <name>]  manages waypoints of this world.",
            "/reaper baritone goto <x> <y> <z> | mine <block> | stop  (needs the Baritone mod and Open rules).",
            "/reaper status  shows the state of the client.",
    };

    private final ReaperCore core;
    private final Actions actions;

    public CommandCenter(ReaperCore core, Actions actions) {
        this.core = core;
        this.actions = actions;
    }

    // ------------------------------------------------------------------ running
    /** Runs the text that was typed after {@code /reaper}. Never throws. */
    public List<Reply> run(String line) {
        List<Reply> out = new ArrayList<>(2);
        try {
            String text = line == null ? "" : line.strip();
            if (text.length() > MAX_LINE) {
                out.add(new Reply(Level.WARN, "That command is too long."));
                return out;
            }
            if (text.isEmpty()) {
                actions.openGui();
                return out;
            }
            String[] words = text.split("\\s+");
            String cmd = words[0].toLowerCase(Locale.ROOT);
            String rest = text.length() > words[0].length() ? text.substring(words[0].length()).strip() : "";
            switch (cmd) {
                case "help", "?" -> help(out);
                case "gui", "menu" -> actions.openGui();
                case "hud" -> actions.openHudEditor();
                case "screenshots", "shots" -> actions.openScreenshots();
                case "modules" -> modules(out);
                case "toggle" -> toggle(rest, out);
                case "profile", "profiles" -> profile(rest, out);
                case "server" -> server(rest, out);
                case "waypoint", "waypoints", "wp" -> waypoint(rest, out);
                case "baritone" -> baritone(rest, out);
                case "status" -> status(out);
                default -> out.add(new Reply(Level.WARN, "Unknown command \"" + words[0] + "\". Try /reaper help."));
            }
        } catch (RuntimeException ex) {
            out.add(new Reply(Level.ERROR, "That command failed: " + ex.getClass().getSimpleName()));
            com.reaper.client.core.util.Log.warn("Command failed: " + line, ex);
        }
        return out;
    }

    private static void info(List<Reply> out, String s) { out.add(new Reply(Level.INFO, s)); }

    private static void ok(List<Reply> out, String s) { out.add(new Reply(Level.SUCCESS, s)); }

    private static void warn(List<Reply> out, String s) { out.add(new Reply(Level.WARN, s)); }

    private void help(List<Reply> out) {
        for (String h : HELP) info(out, h);
    }

    // ------------------------------------------------------------------ modules
    private void modules(List<Reply> out) {
        List<String> on = new ArrayList<>();
        int total = 0;
        for (Module m : core.modules.all()) {
            if (!m.toggleable) continue;
            total++;
            if (m.isEnabled()) on.add(m.id);
        }
        info(out, on.size() + " of " + total + " modules are on" + (on.isEmpty() ? "." : ": " + String.join(", ", on) + "."));
    }

    private void toggle(String arg, List<Reply> out) {
        String[] parts = arg.isEmpty() ? new String[0] : arg.split("\\s+");
        if (parts.length == 0) {
            warn(out, "Usage: /reaper toggle <module>. Module names are listed by /reaper modules and shown in tab completion.");
            return;
        }
        Module m = findModule(parts[0]);
        if (m == null) {
            warn(out, "There is no module called \"" + parts[0] + "\".");
            return;
        }
        if (!m.toggleable) {
            warn(out, m.name + " is a settings panel and has no switch.");
            return;
        }
        Boolean want = null;
        if (parts.length > 1) {
            String w = parts[1].toLowerCase(Locale.ROOT);
            if (w.equals("on")) want = Boolean.TRUE;
            else if (w.equals("off")) want = Boolean.FALSE;
            else {
                warn(out, "After the module name, write on or off (or nothing to flip it).");
                return;
            }
        }
        m.setEnabled(want == null ? !m.isEnabled() : want);
        core.requestSave();
        ok(out, m.name + " is now " + (m.isEnabled() ? "on" : "off") + ".");
        if (m.isBlockedByPolicy() && m.feature() != null) warn(out, core.policy.reason(m.feature()));
    }

    /** By id, else by name with spaces ignored; null when nothing or more than one module fits. */
    private Module findModule(String key) {
        String k = key.toLowerCase(Locale.ROOT);
        Module byId = core.modules.get(k);
        if (byId != null) return byId;
        Module found = null;
        for (Module m : core.modules.all()) {
            if (m.name.toLowerCase(Locale.ROOT).replace(" ", "").equals(k.replace(" ", ""))) {
                if (found != null) return null;
                found = m;
            }
        }
        return found;
    }

    // ------------------------------------------------------------------ profiles
    private void profile(String arg, List<Reply> out) {
        ProfileStore p = core.profiles;
        String[] w = arg.isEmpty() ? new String[0] : arg.split("\\s+", 2);
        String sub = w.length == 0 ? "list" : w[0].toLowerCase(Locale.ROOT);
        String name = w.length > 1 ? w[1].strip() : "";
        switch (sub) {
            case "list" -> {
                p.refresh();
                info(out, "Active profile: " + p.active() + ". All: " + String.join(", ", p.list()) + ".");
            }
            case "save" -> {
                if (p.saveActive()) ok(out, "Saved the profile \"" + p.active() + "\".");
                else warn(out, "The profile could not be saved. See the log for the reason.");
            }
            case "load" -> {
                if (name.isEmpty()) { warn(out, "Usage: /reaper profile load <name>"); return; }
                p.refresh();
                if (!p.switchTo(name)) { warn(out, "There is no profile called \"" + name + "\"."); return; }
                core.requestSave();
                ok(out, "Now using the profile \"" + p.active() + "\".");
            }
            case "new" -> {
                if (name.isEmpty()) { warn(out, "Usage: /reaper profile new <name>"); return; }
                p.refresh();
                if (!ProfileStore.validName(name)) { warn(out, "Profile names are 1 to 32 letters, digits, spaces, _ . -"); return; }
                if (p.exists(name)) { warn(out, "A profile called \"" + name + "\" already exists."); return; }
                if (!p.create(name) || !p.switchTo(name)) { warn(out, "The profile could not be created."); return; }
                core.requestSave();
                ok(out, "Created the profile \"" + p.active() + "\" with default settings and switched to it.");
            }
            case "delete" -> {
                if (name.isEmpty()) { warn(out, "Usage: /reaper profile delete <name>"); return; }
                p.refresh();
                if (p.delete(name)) ok(out, "Deleted the profile \"" + name + "\".");
                else warn(out, "Could not delete \"" + name + "\". The active profile and the last remaining one cannot be deleted.");
            }
            default -> warn(out, "Usage: /reaper profile [list | save | load <name> | new <name> | delete <name>]");
        }
    }

    // ------------------------------------------------------------------ server rules
    private void server(String arg, List<Reply> out) {
        ServerPolicy policy = core.policy;
        ServerPolicy.Context ctx = policy.context();
        if (!ctx.inWorld()) {
            warn(out, "Join a world or a server first. The rules are kept per server.");
            return;
        }
        if (arg.isEmpty()) {
            ServerMode mode = policy.mode();
            String where = ctx.singleplayer() ? "Singleplayer" : ctx.host();
            info(out, where + ": " + mode.label + " mode. " + mode.blurb);
            StringBuilder sb = new StringBuilder();
            for (Feature f : Feature.values()) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(f.label).append(policy.allows(f) ? " on" : " off");
            }
            info(out, sb.toString() + ".");
            return;
        }
        if (ctx.singleplayer()) {
            warn(out, "Singleplayer is always Open. The rules can be set on a multiplayer server.");
            return;
        }
        ServerMode mode = null;
        for (ServerMode m : ServerMode.values()) if (m.name().equalsIgnoreCase(arg.strip())) mode = m;
        if (mode == null) {
            warn(out, "Write standard, strict or open.");
            return;
        }
        if (mode == ServerMode.OPEN) {
            info(out, "Open turns the optional automation on. Choose it only where the server's own rules allow it.");
        }
        policy.setMode(ctx.host(), mode);
        core.requestSave();
        ok(out, ctx.host() + " is now treated as " + mode.label + ". " + mode.blurb);
    }

    // ------------------------------------------------------------------ waypoints
    private void waypoint(String arg, List<Reply> out) {
        String[] w = arg.isEmpty() ? new String[0] : arg.split("\\s+", 2);
        String sub = w.length == 0 ? "list" : w[0].toLowerCase(Locale.ROOT);
        String name = w.length > 1 ? w[1].strip() : "";
        switch (sub) {
            case "add" -> {
                Waypoint added = core.waypoints.addHere(name);
                if (added == null) warn(out, core.waypoints.problem());
                else ok(out, "Saved \"" + added.name + "\" at " + added.coordinates() + ".");
            }
            case "list" -> {
                if (core.waypointStore.context() == null) { warn(out, "Join a world first."); return; }
                var all = core.waypointStore.list();
                if (all.isEmpty()) { info(out, "This world has no waypoints yet. Use /reaper waypoint add <name>."); return; }
                StringBuilder sb = new StringBuilder(all.size() + (all.size() == 1 ? " waypoint: " : " waypoints: "));
                int shown = 0;
                for (Waypoint wp : all) {
                    if (shown == 12) { sb.append(" ..."); break; }
                    if (shown > 0) sb.append("; ");
                    sb.append(wp.name).append(" (").append(wp.coordinates()).append(')');
                    shown++;
                }
                info(out, sb.toString());
            }
            case "remove" -> {
                if (name.isEmpty()) { warn(out, "Usage: /reaper waypoint remove <name>"); return; }
                Waypoint found = null;
                for (Waypoint wp : core.waypointStore.list()) if (wp.name.equalsIgnoreCase(name)) { found = wp; break; }
                if (found == null || !core.waypointStore.remove(found)) warn(out, "There is no waypoint called \"" + name + "\" in this world.");
                else ok(out, "Removed \"" + found.name + "\".");
            }
            default -> warn(out, "Usage: /reaper waypoint [add <name> | list | remove <name>]");
        }
    }

    // ------------------------------------------------------------------ Baritone
    private void baritone(String arg, List<Reply> out) {
        String[] w = arg.isEmpty() ? new String[0] : arg.split("\\s+", 2);
        String sub = w.length == 0 ? "" : w[0].toLowerCase(Locale.ROOT);
        String rest = w.length > 1 ? w[1].strip() : "";
        String problem;
        String sent;
        switch (sub) {
            case "goto" -> {
                String[] c = rest.isEmpty() ? new String[0] : rest.split("\\s+");
                if (c.length != 3) { warn(out, "Usage: /reaper baritone goto <x> <y> <z>"); return; }
                int x, y, z;
                try {
                    x = Integer.parseInt(c[0]);
                    y = Integer.parseInt(c[1]);
                    z = Integer.parseInt(c[2]);
                } catch (NumberFormatException ex) {
                    warn(out, "The coordinates must be whole numbers.");
                    return;
                }
                problem = core.automation.goTo(x, y, z);
                sent = "goto " + x + " " + y + " " + z;
            }
            case "mine" -> {
                problem = core.automation.mine(rest);
                sent = "mine " + rest.toLowerCase(Locale.ROOT);
            }
            case "stop" -> {
                problem = core.automation.stopAll();
                sent = "stop";
            }
            default -> {
                warn(out, "Usage: /reaper baritone goto <x> <y> <z> | mine <block> | stop");
                return;
            }
        }
        if (problem != null) warn(out, problem);
        else ok(out, "Sent to Baritone: " + sent);
    }

    // ------------------------------------------------------------------ status
    private void status(List<Reply> out) {
        ServerPolicy.Context ctx = core.policy.context();
        int on = 0, total = 0;
        for (Module m : core.modules.all()) {
            if (!m.toggleable) continue;
            total++;
            if (m.isEnabled()) on++;
        }
        for (String s : actions.statusLines()) info(out, s);
        info(out, "Profile: " + core.profiles.active() + ". Modules on: " + on + " of " + total + ".");
        if (ctx.inWorld()) info(out, (ctx.singleplayer() ? "Singleplayer" : ctx.host()) + ": " + core.policy.mode().label + " mode.");
        else info(out, "Not in a world.");
    }

    // ------------------------------------------------------------------ completion
    /**
     * Whole-line suggestions for what has been typed after {@code /reaper}: every candidate that starts with it, ignoring
     * case. Candidates are complete lines, so the caller offers them as replacements of the typed text.
     */
    public List<String> complete(String typed) {
        String t = typed == null ? "" : typed.stripLeading();
        String lower = t.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String c : candidates()) {
            if (c.toLowerCase(Locale.ROOT).startsWith(lower) && !c.equalsIgnoreCase(t)) {
                out.add(c);
                if (out.size() == MAX_SUGGESTIONS) break;
            }
        }
        return out;
    }

    private List<String> candidates() {
        List<String> c = new ArrayList<>(96);
        for (String s : new String[]{"help", "gui", "hud", "screenshots", "modules", "status", "profile", "server", "waypoint", "baritone", "toggle"}) c.add(s);
        for (Module m : core.modules.all()) if (m.toggleable) c.add("toggle " + m.id);
        for (String s : new String[]{"list", "save"}) c.add("profile " + s);
        for (String n : core.profiles.list()) {
            c.add("profile load " + n);
            c.add("profile delete " + n);
        }
        c.add("profile new ");
        for (ServerMode m : ServerMode.values()) c.add("server " + m.name().toLowerCase(Locale.ROOT));
        c.add("waypoint add ");
        c.add("waypoint list");
        for (Waypoint w : core.waypointStore.list()) c.add("waypoint remove " + w.name);
        c.add("baritone goto ");
        c.add("baritone mine ");
        c.add("baritone stop");
        return c;
    }
}
