package com.reaper.client.core.ui;

import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.theme.Themes;

/** The "Interface" settings panel (theme, accent, scale, animations). Lives in the Client window and in every profile. */
public final class InterfaceModule extends Module {
    public enum ThemeName implements Settings.Labeled {
        REAPER(Themes.REAPER), MIDNIGHT(Themes.MIDNIGHT), OCEAN(Themes.OCEAN), ROSE(Themes.ROSE), FOREST(Themes.FOREST),
        EMBER(Themes.EMBER), MONO(Themes.MONO), DAYLIGHT(Themes.DAYLIGHT);

        public final Theme theme;
        ThemeName(Theme t) { theme = t; }
        @Override public String label() { return theme.name(); }
    }

    public final Settings.Choice<ThemeName> theme =
            add(new Settings.Choice<>("theme", "Theme", "Colour theme for the ClickGUI and HUD windows.", ThemeName.REAPER));
    public final Settings.Bool useAccent =
            add(new Settings.Bool("useAccent", "Custom accent", "Replace the theme's accent colour with your own.", false));
    public final Settings.Color accent =
            add(new Settings.Color("accent", "Accent colour", "Highlight colour used for switches, sliders and the HUD.", 0xFFEF3B52, false));
    public final Settings.Num scale =
            add(new Settings.Num("scale", "GUI scale", "Size of the ClickGUI. Raise it on small or touch screens.", 1.0, 0.75, 1.75, 0.05, "x"));
    public final Settings.Bool animations =
            add(new Settings.Bool("animations", "Animations", "Smooth transitions in the GUI. Turn off on very slow devices.", true));
    public final Settings.Bool compact =
            add(new Settings.Bool("compact", "Compact rows", "Smaller rows so more fits on screen.", false));
    public final Settings.Bool tooltips =
            add(new Settings.Bool("tooltips", "Tooltips", "Show a description when you hover a module or setting.", true));

    public InterfaceModule() {
        super("interface", "Interface", "Theme, accent colour, scale and animation settings.", Category.CLIENT, false, false, "look appearance colors colours dark light");
        accent.visibleWhen(useAccent::on);
    }

    /** The palette currently in force. */
    public Theme resolve() {
        Theme t = theme.v().theme;
        return useAccent.on() ? t.withAccent(accent.argb()) : t;
    }
}
