package com.reaper.client.core.policy;

/**
 * Features that some servers do not allow. Everything not listed here (HUD, ClickGUI, screenshots, chat tools,
 * notifications, profiles) is purely cosmetic or local and is always available.
 */
public enum Feature {
    FULLBRIGHT("Fullbright"),
    ZOOM("Zoom"),
    WAYPOINT_MARKERS("Waypoint markers"),
    INVENTORY_SORT("Inventory sorting"),
    AUTOMATION("Automation (Baritone)");

    public final String label;
    Feature(String label) { this.label = label; }
}
