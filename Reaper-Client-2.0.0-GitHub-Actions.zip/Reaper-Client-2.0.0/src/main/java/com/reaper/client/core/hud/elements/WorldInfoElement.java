package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.HudFormat;
import com.reaper.client.core.setting.Settings;

import java.util.TimeZone;

/**
 * Facts about the world around you: dimension, biome, light level, time of day, chunk. Biome, light and chunk
 * follow the server's reducedDebugInfo rule exactly like the coordinates do.
 */
public final class WorldInfoElement extends LinesElement {
    private final Settings.Bool dimension = new Settings.Bool("dimension", "Dimension", "Overworld, Nether or End.", true);
    private final Settings.Bool biome = new Settings.Bool("biome", "Biome", "The biome you are standing in.", true);
    private final Settings.Bool light = new Settings.Bool("light", "Light level", "Block light and sky light at your position.", true);
    private final Settings.Bool gameTime = new Settings.Bool("gameTime", "In-game time", "Time of day in the world, as a 24-hour clock.", true);
    private final Settings.Bool clock = new Settings.Bool("clock", "Real time", "Your computer's clock.", false);
    private final Settings.Bool chunk = new Settings.Bool("chunk", "Chunk", "The chunk you are in.", false);
    private final Settings.Bool server = new Settings.Bool("server", "Server address", "Show the server you are connected to. Off by default so streams do not leak it.", false);

    private String dimLine = "", biomeLine = "", lightLine = "", timeLine = "", clockLine = "", chunkLine = "", serverLine = "";
    private String kDim = "", kBiome = "", kServer = "";
    private int kBlock = -2, kSky = -2, kChunkX = Integer.MIN_VALUE, kChunkZ, kClock = -1;
    private long kTime = Long.MIN_VALUE;
    private int offsetMs;
    private long offsetStamp;
    private boolean haveOffset;

    public WorldInfoElement() {
        super("worldinfo", "World Info", "Dimension, biome, light level and time of day.", false, "biome light time dimension chunk clock", Anchor.TOP_LEFT, 4, 100);
        add(dimension);
        add(biome);
        add(light);
        add(gameTime);
        add(clock);
        add(chunk);
        add(server);
        commonSettings();
    }

    @Override protected boolean update(HudContext x) {
        HudData d = x.d;
        if (!d.inWorld && !x.editing) return false;
        int i = 0;
        int c = color.argb();
        boolean hidden = d.reducedDebug && !x.editing;
        if (dimension.on()) {
            String lab = d.dimension.label;
            if (!lab.equals(kDim)) { kDim = lab; dimLine = "Dimension: " + lab; }
            lineArgb[i] = c; lines[i++] = dimLine;
        }
        if (biome.on() && !hidden && !d.biome.isEmpty()) {
            if (!d.biome.equals(kBiome)) { kBiome = d.biome; biomeLine = "Biome: " + d.biome; }
            lineArgb[i] = c; lines[i++] = biomeLine;
        }
        if (light.on() && !hidden && d.blockLight >= 0) {
            if (d.blockLight != kBlock || d.skyLight != kSky) {
                kBlock = d.blockLight; kSky = d.skyLight;
                lightLine = d.skyLight >= 0 ? "Light: " + d.blockLight + " (sky " + d.skyLight + ")" : "Light: " + d.blockLight;
            }
            lineArgb[i] = c; lines[i++] = lightLine;
        }
        if (gameTime.on() && d.dayTime >= 0) {
            long minute = d.dayTime * 60L / 1000L;        // a new text only when the shown minute changes
            if (minute != kTime) { kTime = minute; timeLine = "Time: " + HudFormat.gameClock(d.dayTime); }
            lineArgb[i] = c; lines[i++] = timeLine;
        }
        if (clock.on()) {
            if (!haveOffset || d.wallClockMs - offsetStamp > 60_000L || d.wallClockMs < offsetStamp) {   // the zone offset changes at most twice a year
                haveOffset = true;
                offsetStamp = d.wallClockMs;
                offsetMs = TimeZone.getDefault().getOffset(d.wallClockMs);
            }
            int m = HudFormat.minuteOfDay(d.wallClockMs, offsetMs);
            if (m != kClock) { kClock = m; clockLine = "Clock: " + HudFormat.clock(m); }
            lineArgb[i] = c; lines[i++] = clockLine;
        }
        if (chunk.on() && !hidden) {
            int cx = d.chunkX(), cz = d.chunkZ();
            if (cx != kChunkX || cz != kChunkZ) { kChunkX = cx; kChunkZ = cz; chunkLine = "Chunk: " + cx + ", " + cz; }
            lineArgb[i] = c; lines[i++] = chunkLine;
        }
        if (server.on() && !d.serverName.isEmpty()) {
            if (!d.serverName.equals(kServer)) { kServer = d.serverName; serverLine = "Server: " + d.serverName; }
            lineArgb[i] = c; lines[i++] = serverLine;
        }
        if (hidden && i < MAX_LINES) {
            lineArgb[i] = x.theme.textDim(); lines[i++] = "Details hidden by server";
        }
        n = i;
        return i > 0;
    }
}
