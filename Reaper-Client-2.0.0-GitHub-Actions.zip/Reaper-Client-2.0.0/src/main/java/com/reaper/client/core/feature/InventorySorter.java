package com.reaper.client.core.feature;

import com.reaper.client.core.setting.Settings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Works out which slots to left-click, one after another, to tidy a block of slots: partial stacks are merged and
 * everything ends up in order with the gaps at the end. Only plain pick-up/put-down clicks are used, exactly the
 * clicks a player would make by hand, and a plan is always computed from the real contents when the player asks.
 *
 * <p>The click rules are those of the game's {@code PICKUP} click: an empty cursor picks the whole stack up; a cursor
 * over an empty slot puts everything down; over the same item it adds as much as fits and keeps the rest; over a
 * different item the two swap.</p>
 */
public final class InventorySorter {
    private InventorySorter() {}

    public enum Order implements Settings.Labeled {
        TYPE("By type, then name"), NAME("By name"), COUNT("Biggest stacks first");
        private final String label;
        Order(String l) { label = l; }
        @Override public String label() { return label; }
    }

    /** Longest plan that will ever be returned (a safety net, far above what 54 slots need). */
    public static final int MAX_CLICKS = 1000;

    /**
     * @param key   what makes two stacks the same item (null or empty = empty slot); stacks with equal keys can merge.
     *              The part before a {@code #} is the item id, used for ordering.
     * @param count items in each slot
     * @param max   how many of that item fit in one slot (at least 1)
     * @return slot numbers (indices into the arrays) to left-click in order; empty when already tidy
     */
    public static int[] plan(String[] key, int[] count, int[] max, Order order) {
        int n = key.length;
        if (n == 0 || count.length != n || max.length != n) return new int[0];
        Sim s = new Sim(key, count, max);
        List<Integer> clicks = new ArrayList<>();
        merge(s, clicks);
        arrange(s, order == null ? Order.TYPE : order, clicks);
        int[] out = new int[Math.min(clicks.size(), MAX_CLICKS)];
        for (int i = 0; i < out.length; i++) out[i] = clicks.get(i);
        return out;
    }

    // ------------------------------------------------------------------ phase 1: merge partial stacks
    private static void merge(Sim s, List<Integer> clicks) {
        int n = s.k.length;
        for (int guard = 0; guard < n * n; guard++) {
            int a = -1, b = -1;
            // find an item with two or more partial stacks: take the smallest into the largest
            outer:
            for (int i = 0; i < n; i++) {
                if (!s.partial(i)) continue;
                int small = i, large = -1;
                for (int j = 0; j < n; j++) {
                    if (j == i || !s.partial(j) || !s.k[j].equals(s.k[i])) continue;
                    if (s.c[j] < s.c[small]) small = j;
                    if (large == -1 || s.c[j] > s.c[large] ) large = j;
                }
                if (large == -1) continue;
                // pair the smallest partial stack of this item with the largest other one
                int sm = i, lg = -1;
                for (int j = 0; j < n; j++) {
                    if (!s.partial(j) || !s.k[j].equals(s.k[i])) continue;
                    if (s.c[j] < s.c[sm]) sm = j;
                }
                for (int j = 0; j < n; j++) {
                    if (j == sm || !s.partial(j) || !s.k[j].equals(s.k[i])) continue;
                    if (lg == -1 || s.c[j] > s.c[lg]) lg = j;
                }
                if (lg == -1) continue;
                a = sm; b = lg;
                break outer;
            }
            if (a < 0) return;
            clicks.add(a); s.click(a);          // pick the small stack up
            clicks.add(b); s.click(b);          // add it to the large one
            if (!s.cursorEmpty()) { clicks.add(a); s.click(a); }   // what did not fit goes back
        }
    }

    // ------------------------------------------------------------------ phase 2: put the stacks in order
    private static void arrange(Sim s, Order order, List<Integer> clicks) {
        int n = s.k.length;
        List<int[]> items = new ArrayList<>();   // slot index per non-empty slot, then ordered
        for (int i = 0; i < n; i++) if (!s.empty(i)) items.add(new int[]{i});
        String[] wantKey = new String[items.size()];
        int[] wantCount = new int[items.size()];
        Integer[] idx = new Integer[items.size()];
        for (int i = 0; i < idx.length; i++) idx[i] = items.get(i)[0];
        final String[] k = s.k.clone();
        final int[] c = s.c.clone();
        Arrays.sort(idx, comparator(order, k, c));
        for (int i = 0; i < idx.length; i++) { wantKey[i] = k[idx[i]]; wantCount[i] = c[idx[i]]; }

        for (int i = 0; i < wantKey.length; i++) {
            if (!s.empty(i) && s.k[i].equals(wantKey[i]) && s.c[i] == wantCount[i]) continue;
            int j = -1;
            for (int t = i + 1; t < n; t++) {
                if (!s.empty(t) && s.k[t].equals(wantKey[i]) && s.c[t] == wantCount[i]) { j = t; break; }
            }
            if (j < 0) continue;   // cannot happen when the multiset is unchanged; never loop on it
            clicks.add(j); s.click(j);                       // pick up what belongs here
            clicks.add(i); s.click(i);                       // put it down; the old content (if any) is now on the cursor
            if (!s.cursorEmpty()) { clicks.add(j); s.click(j); }   // and the old content goes where we took from
        }
    }

    private static Comparator<Integer> comparator(Order order, String[] k, int[] c) {
        return (x, y) -> {
            String ix = id(k[x]), iy = id(k[y]);
            int r;
            if (order == Order.COUNT) {
                r = Integer.compare(c[y], c[x]);
                if (r != 0) return r;
                r = ix.compareTo(iy);
                if (r != 0) return r;
                return k[x].compareTo(k[y]);
            }
            if (order == Order.TYPE) {
                r = Integer.compare(group(ix), group(iy));
                if (r != 0) return r;
            }
            r = ix.compareTo(iy);
            if (r != 0) return r;
            r = k[x].compareTo(k[y]);
            if (r != 0) return r;
            return Integer.compare(c[y], c[x]);   // fuller stacks first
        };
    }

    /** The item id inside a key: {@code minecraft:stick#1a2b} gives {@code minecraft:stick}. */
    public static String id(String key) {
        int h = key.indexOf('#');
        return h < 0 ? key : key.substring(0, h);
    }

    /** Coarse group used by {@link Order#TYPE}: 0 tools and weapons, 1 armour, 2 everything else. */
    public static int group(String id) {
        int colon = id.indexOf(':');
        String p = colon >= 0 ? id.substring(colon + 1) : id;
        if (p.endsWith("_sword") || p.endsWith("_axe") || p.endsWith("_pickaxe") || p.endsWith("_shovel") || p.endsWith("_hoe") || p.endsWith("_spear")
                || p.equals("bow") || p.equals("crossbow") || p.equals("trident") || p.equals("mace") || p.equals("fishing_rod") || p.equals("shears")) return 0;
        if (p.endsWith("_helmet") || p.endsWith("_chestplate") || p.endsWith("_leggings") || p.endsWith("_boots") || p.equals("elytra") || p.equals("shield")) return 1;
        return 2;
    }

    // ------------------------------------------------------------------ the click rules
    /** The game's pick-up click on a row of slots. */
    static final class Sim {
        final String[] k;
        final int[] c, mx;
        String curKey;
        int curCount, curMax;

        Sim(String[] key, int[] count, int[] max) {
            int n = key.length;
            k = new String[n];
            c = new int[n];
            mx = new int[n];
            for (int i = 0; i < n; i++) {
                boolean has = key[i] != null && !key[i].isEmpty() && count[i] > 0;
                k[i] = has ? key[i] : null;
                c[i] = has ? count[i] : 0;
                mx[i] = has ? Math.max(1, max[i]) : 0;
            }
        }

        boolean empty(int i) { return k[i] == null; }
        boolean partial(int i) { return k[i] != null && c[i] < mx[i]; }
        boolean cursorEmpty() { return curKey == null; }

        void click(int i) {
            if (curKey == null) {
                if (k[i] == null) return;
                curKey = k[i]; curCount = c[i]; curMax = mx[i];
                k[i] = null; c[i] = 0; mx[i] = 0;
            } else if (k[i] == null) {
                k[i] = curKey; c[i] = curCount; mx[i] = curMax;
                curKey = null; curCount = 0; curMax = 0;
            } else if (k[i].equals(curKey)) {
                int room = mx[i] - c[i], move = Math.min(room, curCount);
                c[i] += move;
                curCount -= move;
                if (curCount == 0) { curKey = null; curMax = 0; }
            } else {
                String tk = k[i]; int tc = c[i], tm = mx[i];
                k[i] = curKey; c[i] = curCount; mx[i] = curMax;
                curKey = tk; curCount = tc; curMax = tm;
            }
        }
    }
}
