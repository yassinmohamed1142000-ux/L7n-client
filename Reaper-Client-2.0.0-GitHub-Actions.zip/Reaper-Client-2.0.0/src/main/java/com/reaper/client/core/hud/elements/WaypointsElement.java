package com.reaper.client.core.hud.elements;

import com.reaper.client.core.feature.Glyphs;
import com.reaper.client.core.feature.Waypoint;
import com.reaper.client.core.feature.WaypointStore;
import com.reaper.client.core.feature.WaypointsModule;
import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Canvas;

/**
 * The nearest waypoints as a short list: colour, name, distance and an arrow showing which way to turn. Follows
 * the same rules as the markers: hidden where the server rules say so, and replaced by a note when the server hides
 * coordinates.
 */
public final class WaypointsElement extends HudElement {
    private static final int ROWS = 6, NAME_W = 96, ARROW_R = 4;
    private static final String[] SAMPLE_NAMES = {"Home", "Mine", "Village"};
    private static final int[] SAMPLE_DIST = {12, 140, 980};
    private static final float[] SAMPLE_ANGLE = {0f, 70f, -150f};
    private static final int[] SAMPLE_COLOR = {0xFF4ADE80, 0xFF60A5FA, 0xFFFACC15};

    public final Settings.Num count = new Settings.Num("count", "Rows", "How many of the nearest waypoints to list.", 3, 1, ROWS, 1, "");
    public final Settings.Bool arrows = new Settings.Bool("arrows", "Direction arrows", "An arrow that points towards the waypoint (up means straight ahead).", true);

    private final WaypointsModule module;
    private final WaypointStore store;
    private final Waypoint[] near = new Waypoint[ROWS];
    private final String[] name = new String[ROWS], nameSrc = new String[ROWS], distText = new String[ROWS];
    private final int[] distKey = new int[ROWS], rowColor = new int[ROWS];
    private final float[] angle = new float[ROWS];
    private int rows;
    private boolean hidden;
    private int nameW, distW, rowH;

    public WaypointsElement(WaypointsModule module) {
        super("waypointsHud", "Nearby Waypoints", "Lists the nearest saved waypoints with distance and direction.", false, "waypoints home navigation arrow distance", Anchor.TOP_RIGHT, 4, 64);
        this.module = module;
        this.store = module.store();
        java.util.Arrays.fill(distKey, -1);
        add(count);
        add(arrows);
        commonSettings();
    }

    @Override protected boolean measure(HudContext x) {
        HudData d = x.d;
        Canvas c = x.c;
        hidden = false;
        rows = 0;
        if (!x.editing && (!module.isActive() || !d.inWorld)) return false;
        if (d.reducedDebug && !x.editing) {
            hidden = true;
            String s = "Waypoints hidden by server";
            w = c.textWidth(s) + PAD * 2;
            h = c.lineHeight() + PAD * 2 - 1;
            return true;
        }
        int want = count.i();
        int n = d.inWorld ? store.nearest(d.dimensionId, d.camX, d.camZ, near, want) : 0;
        for (int i = 0; i < n; i++) {
            Waypoint wp = near[i];
            if (nameSrc[i] != wp.name) { nameSrc[i] = wp.name; name[i] = c.fit(wp.name, NAME_W); }
            int m = (int) Math.round(wp.distance(d.camX, d.camY, d.camZ));
            fillDist(i, m);
            rowColor[i] = wp.color;
            angle[i] = module.relativeBearing(wp);
        }
        rows = n;
        if (rows == 0 && x.editing) {
            rows = Math.min(want, SAMPLE_NAMES.length);
            for (int i = 0; i < rows; i++) {
                if (nameSrc[i] != SAMPLE_NAMES[i]) { nameSrc[i] = SAMPLE_NAMES[i]; name[i] = SAMPLE_NAMES[i]; }
                fillDist(i, SAMPLE_DIST[i]);
                rowColor[i] = SAMPLE_COLOR[i];
                angle[i] = SAMPLE_ANGLE[i];
            }
        }
        if (rows == 0) return false;
        nameW = 0;
        distW = 0;
        for (int i = 0; i < rows; i++) {
            nameW = Math.max(nameW, c.textWidth(name[i]));
            distW = Math.max(distW, c.textWidth(distText[i]));
        }
        rowH = Math.max(c.lineHeight(), ARROW_R * 2 + 1) + 1;
        w = PAD + 8 + nameW + 8 + distW + (arrows.on() ? 6 + ARROW_R * 2 + 1 : 0) + PAD;
        h = PAD * 2 + (rows - 1) * rowH + Math.max(c.lineHeight(), ARROW_R * 2 + 1);
        return true;
    }

    private void fillDist(int i, int meters) {
        if (distKey[i] != meters) { distKey[i] = meters; distText[i] = WaypointsModule.formatDistance(meters); }
    }

    @Override protected void draw(HudContext x) {
        panel(x);
        Canvas c = x.c;
        if (hidden) {
            text(x, "Waypoints hidden by server", PAD, PAD, x.theme.textDim());
            return;
        }
        int lh = c.lineHeight();
        for (int i = 0; i < rows; i++) {
            int top = PAD + i * rowH;
            int mid = top + Math.max(lh, ARROW_R * 2 + 1) / 2;
            c.disc(PAD + 3, mid, 2, rowColor[i]);
            text(x, name[i], PAD + 8, mid - lh / 2 + 1, color.argb());
            c.text(distText[i], PAD + 8 + nameW + 8 + (distW - c.textWidth(distText[i])), mid - lh / 2 + 1, x.theme.textDim(), shadow.on());
            if (arrows.on()) Glyphs.pointer(c, w - PAD - ARROW_R - 1, mid, ARROW_R, angle[i], rowColor[i]);
        }
    }
}
