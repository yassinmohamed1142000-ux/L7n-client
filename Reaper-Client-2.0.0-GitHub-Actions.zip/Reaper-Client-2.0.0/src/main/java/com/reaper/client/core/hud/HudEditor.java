package com.reaper.client.core.hud;

import com.reaper.client.core.notify.Level;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.ui.Canvas;
import com.reaper.client.core.ui.Input;
import com.reaper.client.core.ui.Ui;
import com.reaper.client.core.util.Colors;
import com.reaper.client.core.util.Text;

import java.util.List;

/**
 * The screen where HUD elements are moved around: drag to move (with snapping to the screen edges, the centre and
 * other elements), scroll to resize, arrow keys to nudge, right-click to reset, and a palette to show or hide
 * elements. All the logic lives here without Minecraft types so it is testable; the game only forwards input and
 * calls {@link #render}.
 */
public final class HudEditor {
    public interface Host {
        void requestSave();
        void close();
        void toast(Level level, String message);
    }

    private static final String HINT_1 = "Drag: move  |  Scroll: resize  |  Arrows: nudge";
    private static final String HINT_2 = "Right-click: reset  |  Delete: hide  |  Esc: done";
    static final int MARGIN = 4, REACH = 5, DRAG_THRESHOLD = 3, MAX_TOOLBAR_W = 300;
    static final double SCALE_STEP = 0.05, SCALE_STEP_BIG = 0.25;
    private static final int CHIP_H = 13, CHIP_GAP = 3, PANEL_PAD = 6;

    public final Input in = new Input();
    private final Ui ui = new Ui(in);
    private final Hud hud;
    private final Host host;

    private HudElement dragging, selected, hovered;
    private int grabX, grabY, pressX, pressY;
    private boolean moved, dragStarted;
    private final int[] guideX = new int[3], guideY = new int[3];
    private int guideXN, guideYN;
    private final int[] edgesX = new int[2 * 32], edgesY = new int[2 * 32];

    private float fade;
    private boolean paletteOpen = true;
    private double resetArmedUntil = -1;

    private int tbX, tbY, tbW, tbH;
    private final int[] chipX = new int[32], chipY = new int[32], chipW = new int[32];
    private int rows;

    public HudEditor(Hud hud, Host host) {
        this.hud = hud;
        this.host = host;
    }

    public void open() {
        in.reset();
        dragging = selected = hovered = null;
        moved = false;
        fade = 0f;
        guideXN = guideYN = 0;
        resetArmedUntil = -1;
    }

    /** Releases a drag in progress; call when the screen closes so a half-finished drag is still saved. */
    public void close() {
        if (dragging != null && moved) host.requestSave();
        dragging = null;
        moved = false;
        in.reset();
    }

    public HudElement selected() { return selected; }
    public HudElement dragging() { return dragging; }
    public int guideCount() { return guideXN + guideYN; }
    public boolean paletteOpen() { return paletteOpen; }
    public int uiStateCount() { return ui.stateCount(); }

    // ------------------------------------------------------------------ frame
    public void render(Canvas c, HudData d, Theme theme, int mouseX, int mouseY, float dt) {
        int sw = d.screenW, sh = d.screenH;
        ui.begin(c, theme, dt, mouseX, mouseY);
        fade = ui.ease(fade, 1f, 14f);
        layoutToolbar(c, sw, sh);
        handleInput(sw, sh, mouseX, mouseY);
        c.fill(0, 0, sw, sh, Colors.mulAlpha(theme.dark() ? 0x66000000 : 0x44202838, fade));
        hud.render(c, d, theme, dt, true);
        drawOverlays(c, theme, sw, sh);
        drawToolbar(c, theme);
        ui.end();   // also ends the input frame
    }

    private boolean inToolbar(int px, int py) { return ui.contains(tbX, tbY, tbW, tbH, px, py); }

    // ------------------------------------------------------------------ input
    private void handleInput(int sw, int sh, int mx, int my) {
        boolean overBar = inToolbar(mx, my);
        hovered = overBar || dragging != null ? dragging : hud.at(mx, my);

        // wheel: resize the element under the pointer (or the selected one)
        if (in.scroll != 0 && !overBar) {
            HudElement target = hovered != null ? hovered : selected;
            if (target != null) {
                double step = in.shift() ? SCALE_STEP_BIG : SCALE_STEP;
                if (target.scale.set(target.scale.v() + (in.scroll > 0 ? step : -step))) host.requestSave();
                selected = target;
            }
        }

        if (in.wasPressed(Input.LEFT) && !overBar) {
            HudElement hit = hud.at(mx, my);
            // an element that is already selected stays in hand when elements overlap, so a buried one can be pulled out
            if (selected != null && selected.rw > 0 && selected != hit && mx >= selected.rx && my >= selected.ry
                    && mx < selected.rx + selected.rw && my < selected.ry + selected.rh) hit = selected;
            selected = hit;
            if (hit != null) {
                dragging = hit;
                grabX = mx - hit.rx;
                grabY = my - hit.ry;
                pressX = mx;
                pressY = my;
                dragStarted = false;
                moved = false;
            }
        }
        if (in.wasPressed(Input.RIGHT) && !overBar) {
            HudElement hit = hud.at(mx, my);
            if (hit != null) {
                selected = hit;
                hit.resetPosition();
                host.requestSave();
                host.toast(Level.INFO, hit.name + ": position and size reset");
            }
        }
        if (dragging != null) {
            // a plain click must never nudge the element: the drag only starts after the pointer moved a few pixels
            if (!dragStarted && Math.abs(mx - pressX) + Math.abs(my - pressY) >= DRAG_THRESHOLD) dragStarted = true;
            if (in.isDown(Input.LEFT) && dragStarted) {
                if (dragTo(sw, sh, mx, my)) moved = true;
            }
            if (in.wasReleased(Input.LEFT) || !in.isDown(Input.LEFT)) {
                if (moved) host.requestSave();
                dragging = null;
                moved = false;
                guideXN = guideYN = 0;
            }
        }
        for (int i = 0; i < in.keyCount(); i++) key(in.keyAt(i), in.keyModsAt(i), sw, sh);
    }

    private boolean dragTo(int sw, int sh, int mx, int my) {
        HudElement e = dragging;
        int w = Math.max(1, e.rw), h = Math.max(1, e.rh);
        int x = mx - grabX, y = my - grabY;
        guideXN = guideYN = 0;
        if ((in.mods & Input.MOD_ALT) == 0) {
            int n = 0;
            List<HudElement> all = hud.elements();
            for (int i = 0, cnt = all.size(); i < cnt && n < 32; i++) {
                HudElement o = all.get(i);
                if (o == e || o.rw <= 0) continue;
                edgesX[n * 2] = o.rx; edgesX[n * 2 + 1] = o.rx + o.rw;
                edgesY[n * 2] = o.ry; edgesY[n * 2 + 1] = o.ry + o.rh;
                n++;
            }
            x = HudLayout.snap(x, w, sw, edgesX, n, MARGIN, REACH);
            y = HudLayout.snap(y, h, sh, edgesY, n, MARGIN, REACH);
            guideXN = guides(guideX, x, w, sw, edgesX, n);
            guideYN = guides(guideY, y, h, sh, edgesY, n);
        }
        int beforeX = e.rx, beforeY = e.ry;
        HudLayout.moveTo(e, x, y, sw, sh);
        // the element is redrawn next frame; keep its recorded rectangle in step so hit tests stay right during the drag
        e.rx = HudLayout.x(e.anchor.v(), e.offsetX.i(), e.rw, sw);
        e.ry = HudLayout.y(e.anchor.v(), e.offsetY.i(), e.rh, sh);
        return e.rx != beforeX || e.ry != beforeY || moved;
    }

    /** Which of the element's left/centre/right lines coincide with a snap target; fills {@code out} and returns how many. */
    private static int guides(int[] out, int start, int size, int limit, int[] edges, int pairs) {
        int n = 0;
        int[] mine = {start, start + size / 2, start + size};
        for (int line : mine) {
            boolean hit = line == MARGIN || line == limit - MARGIN || line == limit / 2;
            for (int k = 0; k < pairs * 2 && !hit; k++) if (edges[k] == line) hit = true;
            if (hit && n < out.length) out[n++] = line;
        }
        return n;
    }

    private void key(int key, int mods, int sw, int sh) {
        boolean shift = (mods & Input.MOD_SHIFT) != 0;
        switch (key) {
            case KeyNames.ESCAPE -> { close(); host.close(); }
            case KeyNames.LEFT -> nudge(shift ? -10 : -1, 0, sw, sh);
            case KeyNames.RIGHT -> nudge(shift ? 10 : 1, 0, sw, sh);
            case KeyNames.UP -> nudge(0, shift ? -10 : -1, sw, sh);
            case KeyNames.DOWN -> nudge(0, shift ? 10 : 1, sw, sh);
            case KeyNames.DELETE, KeyNames.BACKSPACE -> {
                if (selected != null) {
                    selected.setEnabled(false);
                    host.requestSave();
                    host.toast(Level.INFO, selected.name + " hidden. Bring it back from the list at the bottom.");
                    selected = null;
                    dragging = null;
                }
            }
            case 82 -> {   // R
                if (selected != null && (mods & Input.MOD_CTRL) == 0) {
                    selected.resetPosition();
                    host.requestSave();
                }
            }
            default -> { /* ignored */ }
        }
    }

    private void nudge(int dx, int dy, int sw, int sh) {
        if (selected == null || selected.rw <= 0) return;
        HudLayout.moveTo(selected, selected.rx + dx, selected.ry + dy, sw, sh);
        selected.rx = HudLayout.x(selected.anchor.v(), selected.offsetX.i(), selected.rw, sw);
        selected.ry = HudLayout.y(selected.anchor.v(), selected.offsetY.i(), selected.rh, sh);
        host.requestSave();
    }

    // ------------------------------------------------------------------ drawing
    private void drawOverlays(Canvas c, Theme t, int sw, int sh) {
        List<HudElement> all = hud.elements();
        for (int i = 0, n = all.size(); i < n; i++) {
            HudElement e = all.get(i);
            if (e.rw <= 0) continue;
            boolean sel = e == selected, hov = e == hovered, drag = e == dragging;
            int col = drag || sel ? t.accent() : hov ? Colors.lighten(t.accent(), 0.25f) : Colors.withAlpha(0xFFFFFF, 0x46);
            if (drag) c.fill(e.rx, e.ry, e.rw, e.rh, Colors.withAlpha(t.accent(), 0x30));
            c.outline(e.rx - 1, e.ry - 1, e.rw + 2, e.rh + 2, col);
            if (sel || drag) c.outline(e.rx - 2, e.ry - 2, e.rw + 4, e.rh + 4, Colors.withAlpha(t.accent(), 0x80));
        }
        // snapping guides
        int g = Colors.withAlpha(t.accent2(), 0xC0);
        for (int i = 0; i < guideXN; i++) c.fill(guideX[i], 0, 1, sh, g);
        for (int i = 0; i < guideYN; i++) c.fill(0, guideY[i], sw, 1, g);
        HudElement label = dragging != null ? dragging : hovered != null ? hovered : selected;
        if (label != null && label.rw > 0) {
            String s = label.name + "  " + label.anchor.v().label + "  " + label.offsetX.i() + ", " + label.offsetY.i() + "  " + Text.num(label.scale.v(), 2) + "x";
            int tw = c.textWidth(s) + 8, th = c.lineHeight() + 5;
            int lx = Math.max(2, Math.min(sw - tw - 2, label.rx));
            int ly = label.ry - th - 3 >= 2 ? label.ry - th - 3 : label.ry + label.rh + 3;
            c.roundRect(lx, ly, tw, th, 3, Colors.withAlpha(t.panel(), 0xF0));
            c.text(s, lx + 4, ly + 3, t.text(), false);
        }
    }

    private void layoutToolbar(Canvas c, int sw, int sh) {
        List<HudElement> all = hud.elements();
        int n = Math.min(all.size(), chipX.length);
        int maxW = Math.min(sw - 16, MAX_TOOLBAR_W);   // narrow enough that the screen corners stay free for elements
        int innerW = maxW - PANEL_PAD * 2;
        int x = 0, y = 0;
        rows = 1;
        int widest = 0;
        if (paletteOpen) {
            for (int i = 0; i < n; i++) {
                int w = c.textWidth(all.get(i).name) + 14;
                if (x > 0 && x + w > innerW) { x = 0; y += CHIP_H + CHIP_GAP; rows++; }
                chipX[i] = x; chipY[i] = y; chipW[i] = w;
                x += w + CHIP_GAP;
                widest = Math.max(widest, x - CHIP_GAP);
            }
        }
        int hintH = (c.lineHeight() + 1) * 2 + 3;
        int controlsH = CHIP_H + 4;
        int paletteH = paletteOpen ? rows * (CHIP_H + CHIP_GAP) + 2 : 0;
        tbW = paletteOpen ? Math.max(widest, 230) + PANEL_PAD * 2 : 236 + PANEL_PAD * 2;
        tbW = Math.min(tbW, maxW);
        tbH = PANEL_PAD * 2 + hintH + controlsH + paletteH;
        tbX = (sw - tbW) / 2;
        tbY = sh - tbH - 6;
    }

    private void drawToolbar(Canvas c, Theme t) {
        c.pushAlpha(fade);
        c.shadow(tbX, tbY, tbW, tbH, 5, 4, t.shadow());
        c.roundBox(tbX, tbY, tbW, tbH, 5, Colors.withAlpha(t.panel(), 0xF2), t.outline());
        int x0 = tbX + PANEL_PAD, y0 = tbY + PANEL_PAD;
        c.centerText(c.fit(HINT_1, tbW - PANEL_PAD * 2), tbX + tbW / 2, y0, t.textDim(), false);
        c.centerText(c.fit(HINT_2, tbW - PANEL_PAD * 2), tbX + tbW / 2, y0 + c.lineHeight() + 1, t.textDim(), false);
        y0 += (c.lineHeight() + 1) * 2 + 3;
        // controls row
        int bw = 74;
        if (ui.button("editor-elements", x0, y0, bw, CHIP_H + 2, "Elements", paletteOpen, false)) paletteOpen = !paletteOpen;
        boolean armed = resetArmedUntil > ui.timeMs;
        if (ui.button("editor-reset", x0 + bw + 4, y0, 96, CHIP_H + 2, armed ? "Click to confirm" : "Reset layout", false, armed)) {
            if (armed) {
                for (HudElement e : hud.elements()) e.resetPosition();
                resetArmedUntil = -1;
                host.requestSave();
                host.toast(Level.SUCCESS, "HUD layout reset");
            } else {
                resetArmedUntil = ui.timeMs + 3000.0;
            }
        }
        if (ui.button("editor-done", tbX + tbW - PANEL_PAD - 54, y0, 54, CHIP_H + 2, "Done", true, false)) { close(); host.close(); }
        if (paletteOpen) {
            List<HudElement> all = hud.elements();
            int n = Math.min(all.size(), chipX.length);
            int py = y0 + CHIP_H + 6;
            for (int i = 0; i < n; i++) {
                HudElement e = all.get(i);
                boolean on = e.isEnabled();
                if (ui.button(e, x0 + chipX[i], py + chipY[i], chipW[i], CHIP_H, e.name, on, false)) {
                    e.setEnabled(!on);
                    host.requestSave();
                    if (e == selected && on) selected = null;
                }
            }
        }
        c.popAlpha();
    }
}
