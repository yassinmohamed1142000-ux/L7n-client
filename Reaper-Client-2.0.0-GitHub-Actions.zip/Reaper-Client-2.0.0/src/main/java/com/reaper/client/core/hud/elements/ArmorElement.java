package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.hud.HudFormat;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Canvas;

/** Your armour pieces (and optionally the items in your hands) with their durability. */
public final class ArmorElement extends HudElement {
    public enum Layout implements Settings.Labeled {
        VERTICAL("Vertical list"), HORIZONTAL("Horizontal row");
        private final String label;
        Layout(String l) { label = l; }
        @Override public String label() { return label; }
    }

    public enum Value implements Settings.Labeled {
        PERCENT("Percent"), REMAINING("Uses left"), FRACTION("Left / maximum"), NONE("Icons only");
        private final String label;
        Value(String l) { label = l; }
        @Override public String label() { return label; }
    }

    static final int ICON = 16, ROW = 18, GAP = 3;

    private final Settings.Choice<Layout> layout = new Settings.Choice<>("layout", "Layout", "Stack the pieces in a column or put them side by side.", Layout.VERTICAL);
    private final Settings.Choice<Value> value = new Settings.Choice<>("value", "Durability shown as", "How the remaining durability is written.", Value.PERCENT);
    private final Settings.Bool bar = new Settings.Bool("bar", "Durability bar", "A thin bar under each icon, like the one in your inventory.", true);
    private final Settings.Bool colorize = new Settings.Bool("colorize", "Colour by condition", "Green when fine, red when nearly broken. Replaces the text colour.", true);
    private final Settings.Bool hands = new Settings.Bool("hands", "Held items", "Also list the items in your main hand and off hand.", false);
    private final Settings.Bool hideEmpty = new Settings.Bool("hideEmpty", "Hide empty slots", "Skip armour slots with nothing in them.", true);

    private final HudData.ItemInfo[] rows = new HudData.ItemInfo[6];
    private final String[] rowText = new String[6];
    private final int[] rowTextW = new int[6];
    private final long[] rowKey = new long[6];
    private final int[] rowArgb = new int[6];
    private int count;
    private Value kValue;
    private boolean placeholder;

    public ArmorElement() {
        super("armor", "Armor Status", "Shows your armour with its durability.", true, "armour durability helmet chestplate boots equipment", Anchor.BOTTOM_RIGHT, 4, 4);
        add(layout);
        add(value);
        add(bar);
        add(colorize);
        add(hands);
        add(hideEmpty);
        color.visibleWhen(() -> !colorize.on());
        commonSettings();
        java.util.Arrays.fill(rowText, "");
        java.util.Arrays.fill(rowKey, Long.MIN_VALUE);
    }

    private void collect(HudData d, boolean keepEmpty) {
        count = 0;
        for (int i = 0; i < 4; i++) {
            HudData.ItemInfo it = d.armor[i];
            if (it.present || keepEmpty) rows[count++] = it;
        }
        if (hands.on()) {
            if (d.mainHand.present) rows[count++] = d.mainHand;
            if (d.offHand.present) rows[count++] = d.offHand;
        }
    }

    static String describe(HudData.ItemInfo it, Value v) {
        if (v == Value.NONE) return "";
        if (!it.hasDurability()) return it.count > 1 ? "x" + it.count : "";
        switch (v) {
            case PERCENT: return Math.round(it.fraction() * 100f) + "%";
            case REMAINING: return HudFormat.small(it.remaining());
            default: return it.remaining() + "/" + it.maxDamage;
        }
    }

    @Override protected boolean measure(HudContext x) {
        if (!x.d.inWorld && !x.editing) return false;
        collect(x.d, !hideEmpty.on());
        placeholder = false;
        if (count == 0) {
            if (!x.editing) return false;
            placeholder = true;
            w = x.c.textWidth("Armor Status") + PAD * 2;
            h = x.c.lineHeight() + PAD * 2 - 1;
            return true;
        }
        Value v = value.v();
        boolean reset = v != kValue;
        kValue = v;
        int textMax = 0;
        for (int i = 0; i < count; i++) {
            HudData.ItemInfo it = rows[i];
            long key = ((long) it.damage << 32) ^ ((long) it.maxDamage << 8) ^ it.count ^ (it.present ? 1L << 62 : 0L);
            if (reset || key != rowKey[i]) {
                rowKey[i] = key;
                rowText[i] = it.present ? describe(it, v) : "";
                rowTextW[i] = x.c.textWidth(rowText[i]);
            }
            rowArgb[i] = colorize.on() && it.hasDurability() ? health(it.fraction()) : color.argb();
            textMax = Math.max(textMax, rowTextW[i]);
        }
        if (layout.v() == Layout.VERTICAL) {
            w = PAD * 2 + ICON + (textMax > 0 ? GAP + textMax : 0);
            h = PAD * 2 + count * ROW - (ROW - ICON);
        } else {
            int cell = Math.max(ICON, textMax) + 4;
            w = PAD * 2 + count * cell - 4;
            h = PAD * 2 + ICON + (textMax > 0 ? x.c.lineHeight() : 0);
        }
        return true;
    }

    @Override protected void draw(HudContext x) {
        panel(x);
        Canvas c = x.c;
        if (placeholder) { c.text("Armor Status", PAD, PAD, x.theme.textDim(), shadow.on()); return; }
        boolean vertical = layout.v() == Layout.VERTICAL;
        int textMax = 0;
        for (int i = 0; i < count; i++) textMax = Math.max(textMax, rowTextW[i]);
        int cell = Math.max(ICON, textMax) + 4;
        for (int i = 0; i < count; i++) {
            HudData.ItemInfo it = rows[i];
            int ix = vertical ? PAD : PAD + i * cell + (cell - 4 - ICON) / 2;
            int iy = vertical ? PAD + i * ROW : PAD;
            if (it.present) {
                if (it.stack != null) c.item(it.stack, ix, iy, false);
                else c.roundRect(ix + 1, iy + 1, ICON - 2, ICON - 2, 3, 0x44FFFFFF);
                if (bar.on() && it.hasDurability()) {
                    c.fill(ix + 2, iy + 13, 13, 2, 0xFF000000);
                    c.fill(ix + 2, iy + 13, Math.max(1, Math.round(13 * it.fraction())), 1, health(it.fraction()) | 0xFF000000);
                }
            } else {
                c.roundRect(ix + 1, iy + 1, ICON - 2, ICON - 2, 3, 0x18FFFFFF);
            }
            if (rowTextW[i] > 0) {
                if (vertical) text(x, rowText[i], PAD + ICON + GAP, iy + (ICON - c.lineHeight()) / 2 + 1, rowArgb[i]);
                else text(x, rowText[i], PAD + i * cell + (cell - 4 - rowTextW[i]) / 2, PAD + ICON + 1, rowArgb[i]);
            }
        }
    }
}
