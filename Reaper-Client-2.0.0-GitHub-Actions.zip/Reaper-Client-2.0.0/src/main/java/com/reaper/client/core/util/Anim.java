package com.reaper.client.core.util;

/**
 * A float that eases towards a target. Frame-rate independent (exponential smoothing), allocation free.
 * {@code speed} is "how fast": 12 settles in roughly a quarter of a second.
 */
public final class Anim {
    public float value, target;

    public Anim() {}
    public Anim(float v) { value = target = v; }

    public Anim set(float t) { target = t; return this; }
    public Anim snap(float v) { value = target = v; return this; }

    public float update(float dt, float speed) {
        if (value != target) {
            float k = 1f - (float) Math.exp(-speed * Math.max(0f, dt));
            value += (target - value) * k;
            if (Math.abs(target - value) < 0.0005f) value = target;
        }
        return value;
    }

    public boolean settled() { return value == target; }

    // ---- easing curves (t in 0..1) ----
    public static float outCubic(float t) { t = c01(t); float u = 1 - t; return 1 - u * u * u; }
    public static float inOutCubic(float t) { t = c01(t); return t < 0.5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2; }
    public static float outBack(float t) {
        t = c01(t); float c1 = 1.70158f, c3 = c1 + 1; float u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }
    public static float outQuint(float t) { t = c01(t); float u = 1 - t; return 1 - u * u * u * u * u; }
    public static float c01(float t) { return t < 0f ? 0f : Math.min(t, 1f); }
}
