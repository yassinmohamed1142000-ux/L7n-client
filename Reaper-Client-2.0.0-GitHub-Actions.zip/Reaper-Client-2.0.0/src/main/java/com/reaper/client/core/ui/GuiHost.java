package com.reaper.client.core.ui;

import com.reaper.client.core.notify.Level;

/** What the GUI needs from the game layer. Implemented by the Minecraft adapter (and by a stub in tests). */
public interface GuiHost {
    /** Shows a toast notification. */
    void toast(Level level, String message);

    /** A setting changed: schedule a (debounced) save. */
    void requestSave();

    void openHudEditor();
    void openScreenshots();
    void closeGui();

    /** Opaque texture handle for the logo (may be null) and its pixel size. */
    default Object logo() { return null; }
    default int logoW() { return 0; }
    default int logoH() { return 0; }
}
