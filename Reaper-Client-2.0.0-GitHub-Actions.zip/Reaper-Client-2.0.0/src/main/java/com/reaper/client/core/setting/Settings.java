package com.reaper.client.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;
import com.reaper.client.core.util.Colors;
import com.reaper.client.core.util.Text;

import java.util.Locale;

/** All concrete setting types in one file (they are tiny). */
public final class Settings {
    private Settings() {}

    // ------------------------------------------------------------------ boolean
    public static final class Bool extends Setting<Boolean> {
        public Bool(String id, String name, String desc, boolean def) { super(id, name, desc, def); }
        @Override protected Boolean sanitize(Boolean v) { return v != null && v; }
        public boolean on() { return value; }
        public void toggle() { set(!value); }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) {
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean()) set(e.getAsBoolean());
        }
        @Override public String valueText() { return value ? "On" : "Off"; }
    }

    // ------------------------------------------------------------------ number
    public static final class Num extends Setting<Double> {
        public final double min, max, step;
        public final int decimals;
        public final String suffix;

        public Num(String id, String name, String desc, double def, double min, double max, double step, String suffix) {
            super(id, name, desc, def);
            if (!(max > min)) throw new IllegalArgumentException("max must be > min for " + id);
            this.min = min; this.max = max; this.step = step; this.suffix = suffix == null ? "" : suffix;
            this.decimals = decimalsOf(step);
            this.value = sanitize(def);
        }

        private static int decimalsOf(double step) {
            if (step >= 1) return 0;
            int d = 0; double s = step;
            while (d < 6 && Math.abs(s - Math.rint(s)) > 1e-9) { s *= 10; d++; }
            return d;
        }

        @Override protected Double sanitize(Double v) {
            double x = v == null || v.isNaN() || v.isInfinite() ? def : v;
            x = Math.max(min, Math.min(max, x));
            if (step > 0) x = min + Math.round((x - min) / step) * step;
            x = Math.max(min, Math.min(max, x));
            double p = Math.pow(10, Math.max(decimals, 0));
            return Math.round(x * p) / p;
        }

        public double v() { return value; }
        public int i() { return (int) Math.round(value); }
        public float f() { return value.floatValue(); }
        public float fraction() { return (float) ((value - min) / (max - min)); }
        public void setFraction(double f) { set(min + (max - min) * Math.max(0, Math.min(1, f))); }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) {
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) set(e.getAsDouble());
        }
        @Override public String valueText() { return Text.num(value, decimals) + suffix; }
    }

    // ------------------------------------------------------------------ enum
    /** Optional: enums implementing this show a nicer label than the constant name. */
    public interface Labeled { String label(); }

    public static final class Choice<E extends Enum<E>> extends Setting<E> {
        public final Class<E> type;
        private final E[] values;

        public Choice(String id, String name, String desc, E def) {
            super(id, name, desc, def);
            this.type = def.getDeclaringClass();
            this.values = type.getEnumConstants();
        }

        @Override protected E sanitize(E v) { return v == null ? def : v; }
        public E[] values() { return values; }
        public E v() { return value; }
        public void next() { set(values[(value.ordinal() + 1) % values.length]); }
        public void prev() { set(values[(value.ordinal() + values.length - 1) % values.length]); }
        public static String labelOf(Enum<?> e) {
            return e instanceof Labeled l ? l.label() : Text.prettyId(e.name().toLowerCase(Locale.ROOT));
        }
        @Override public JsonElement toJson() { return new JsonPrimitive(value.name()); }
        @Override public void fromJson(JsonElement e) {
            if (e == null || !e.isJsonPrimitive()) return;
            String s = e.getAsString();
            for (E c : values) if (c.name().equalsIgnoreCase(s)) { set(c); return; }
        }
        @Override public String valueText() { return labelOf(value); }
    }

    // ------------------------------------------------------------------ colour
    public static final class Color extends Setting<Integer> {
        public final boolean hasAlpha;

        public Color(String id, String name, String desc, int def, boolean hasAlpha) {
            super(id, name, desc, hasAlpha ? def : (def | 0xFF000000));
            this.hasAlpha = hasAlpha;
        }
        @Override protected Integer sanitize(Integer v) {
            int c = v == null ? def : v;
            return hasAlpha ? c : (c | 0xFF000000);
        }
        public int argb() { return value; }
        @Override public JsonElement toJson() { return new JsonPrimitive(Colors.toHex(value, hasAlpha)); }
        @Override public void fromJson(JsonElement e) {
            if (e == null || !e.isJsonPrimitive()) return;
            if (e.getAsJsonPrimitive().isString()) {
                if (Colors.isHex(e.getAsString())) set(Colors.parseHex(e.getAsString(), 0));
            } else if (e.getAsJsonPrimitive().isNumber()) set((int) e.getAsLong());
        }
        @Override public String valueText() { return Colors.toHex(value, hasAlpha); }
    }

    // ------------------------------------------------------------------ text
    public static final class Str extends Setting<String> {
        public final int maxLen;
        public Str(String id, String name, String desc, String def, int maxLen) {
            super(id, name, desc, def);
            this.maxLen = maxLen;
            this.value = sanitize(def);
        }
        @Override protected String sanitize(String v) {
            if (v == null) return def;
            StringBuilder sb = new StringBuilder(Math.min(v.length(), maxLen));
            for (int i = 0; i < v.length() && sb.length() < maxLen; i++) {
                char c = v.charAt(i);
                if (c >= 32 && c != 127) sb.append(c);
            }
            return sb.toString();
        }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) {
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isString()) set(e.getAsString());
        }
        @Override public String valueText() { return value; }
    }

    // ------------------------------------------------------------------ key bind
    public static final int NO_KEY = -1;

    /** A keyboard key code (GLFW/Minecraft numbering), -1 = unbound. */
    public static final class Key extends Setting<Integer> {
        public Key(String id, String name, String desc, int def) { super(id, name, desc, def); }
        @Override protected Integer sanitize(Integer v) { return v == null || v < 0 || v > 400 ? NO_KEY : v; }
        public int code() { return value; }
        public boolean bound() { return value >= 0; }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) {
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) set(e.getAsInt());
        }
        @Override public String valueText() { return KeyNames.of(value); }
    }

    // ------------------------------------------------------------------ button
    /** A button in the settings list. Not saved. */
    public static final class Action extends Setting<Void> {
        private final Runnable action;
        public final boolean danger;
        public Action(String id, String label, String desc, boolean danger, Runnable action) {
            super(id, label, desc, null);
            this.action = action;
            this.danger = danger;
        }
        @Override protected Void sanitize(Void v) { return null; }
        public void run() { if (action != null) action.run(); }
        @Override public boolean persistent() { return false; }
        @Override public JsonElement toJson() { return JsonNull.INSTANCE; }
        @Override public void fromJson(JsonElement e) { /* nothing to load */ }
        @Override public String valueText() { return ""; }
    }
}
