package com.reaper.client.core.feature;

import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.setting.Settings;

/**
 * Makes dark places bright by raising the game's brightness option: a display setting on the player's own screen.
 * Servers can still decide whether it is welcome; see the server rules (it is switched off where they say so).
 */
public final class FullbrightModule extends Module {
    public static final double VANILLA_MAX = 1.0;

    public final Settings.Num level = new Settings.Num("level", "Brightness", "How bright. The game's own slider stops at 1; this goes far beyond it.", 12.0, 2.0, 16.0, 1.0, "");
    public final GammaController gamma = new GammaController();

    public FullbrightModule() {
        super("fullbright", "Fullbright", "Brightens dark areas. Turned off automatically on servers that do not allow it.", Category.VISUAL, true, false, "gamma brightness night vision dark light");
        feature(Feature.FULLBRIGHT);
        add(level);
    }

    /** Runs the controller for this tick. Returns the value to write into the brightness option, or NaN. */
    public double tick(double currentGamma) { return gamma.tick(isActive(), currentGamma, level.v()); }
}
