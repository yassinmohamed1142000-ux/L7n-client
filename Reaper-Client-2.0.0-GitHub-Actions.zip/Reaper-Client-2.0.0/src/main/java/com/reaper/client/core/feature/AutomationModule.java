package com.reaper.client.core.feature;

import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.setting.Settings;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BiConsumer;

/**
 * A button panel for the separate Baritone mod (path finding and mining). Reaper adds no automation of its own: it
 * only sends ordinary Baritone commands, and only when the module is switched on AND the server rules the player
 * set say automation is welcome (singleplayer, or a server marked Open). It is off by default, it is off in the
 * Standard and Strict modes, and "Stop" always works.
 * <p>
 * Pure logic. The game layer supplies the {@link Bridge} that talks to Baritone.
 */
public final class AutomationModule extends Module {
    /** The connection to Baritone, supplied by the game layer. */
    public interface Bridge {
        boolean installed();

        /** Runs a Baritone command (written without Baritone's chat prefix). Returns null on success, else a short problem text. */
        String run(String command);
    }

    /** Used until the game layer provides a real bridge. */
    public static final Bridge MISSING = new Bridge() {
        @Override public boolean installed() { return false; }
        @Override public String run(String command) { return "Baritone is not installed."; }
    };

    public static final int MAX_BLOCKS = 6, MAX_COORD = 30_000_000, MAX_Y = 2048;

    public final Settings.Str target = new Settings.Str("target", "Block to mine", "The block for the Mine button, for example diamond_ore. Several names can be separated by spaces.", "diamond_ore", 80);
    public final Settings.Action mine;
    public final Settings.Action stop;

    private Bridge bridge = MISSING;
    private BiConsumer<Level, String> feedback = (l, s) -> { };
    private boolean wasActive;

    public AutomationModule() {
        super("automation", "Baritone Bridge", "Buttons for the separate Baritone mod. Off by default, and only available where the server rules say automation is allowed.", Category.AUTOMATION, true, false, "baritone pathfind goto mine auto walk automation");
        feature(Feature.AUTOMATION);
        mine = new Settings.Action("mine", "Start mining", "Asks Baritone to find and mine the block above.", false, () -> report(mine(target.get())));
        stop = new Settings.Action("stop", "Stop everything", "Cancels whatever Baritone is doing. Works even when this module is off.", true, () -> report(stopAll()));
        add(target);
        add(mine);
        add(stop);
    }

    public void setBridge(Bridge b) { bridge = b == null ? MISSING : b; }

    public Bridge bridge() { return bridge; }

    /** Where messages for the player go (a notification, usually). */
    public void setFeedback(BiConsumer<Level, String> f) { feedback = f == null ? (l, s) -> { } : f; }

    private void report(String problem) {
        if (problem != null) feedback.accept(Level.WARN, problem);
    }

    /** Why automation cannot be used right now, or null when it can. */
    public String unavailable() {
        if (!isEnabled()) return "Switch the Baritone Bridge module on first.";
        if (isBlockedByPolicy()) return "Automation is off under this server's rules. Change the server rules to Open only if the server allows it.";
        if (!bridge.installed()) return "Baritone is not installed. Put its Fabric jar for this game version in the mods folder.";
        return null;
    }

    /** Sends a Baritone command. Returns null when it was sent, else the reason it was not. */
    public String request(String command) {
        if (command == null || command.isBlank()) return "Nothing to do.";
        String why = unavailable();
        if (why != null) return why;
        String problem = bridge.run(command);
        return problem == null || problem.isBlank() ? null : problem;
    }

    public String goTo(int x, int y, int z) {
        if (Math.abs(x) > MAX_COORD || Math.abs(z) > MAX_COORD || Math.abs(y) > MAX_Y) return "Those coordinates are out of range.";
        return request("goto " + x + " " + y + " " + z);
    }

    public String mine(String blocks) {
        String list = cleanBlocks(blocks);
        if (list == null) return "Type a block name such as diamond_ore.";
        return request("mine " + list);
    }

    /** Cancels everything. Allowed whenever Baritone is installed, even if the module is off or the server rules changed. */
    public String stopAll() {
        if (!bridge.installed()) return "Baritone is not installed.";
        String problem = bridge.run("stop");
        return problem == null || problem.isBlank() ? null : problem;
    }

    /**
     * Call every tick. When automation stops being allowed (module switched off, or the player moved to a server
     * whose rules do not allow it) anything Baritone was doing is cancelled at once. Returns true when it did so.
     */
    public boolean tick() {
        boolean active = isActive();
        boolean cancel = wasActive && !active && bridge.installed();
        wasActive = active;
        if (cancel) {
            bridge.run("stop");
            return true;
        }
        return false;
    }

    /**
     * Lower-case block names separated by single spaces, at most {@value #MAX_BLOCKS} different ones. Null when there
     * is nothing usable, or when any part is not a block name (the whole text is refused rather than half-used).
     */
    public static String cleanBlocks(String text) {
        if (text == null) return null;
        List<String> out = new ArrayList<>();
        for (String raw : text.split("[\\s,]+")) {
            if (raw.isEmpty()) continue;
            String t = raw.toLowerCase(Locale.ROOT);
            if (!validName(t)) return null;
            if (!out.contains(t) && out.size() < MAX_BLOCKS) out.add(t);
        }
        return out.isEmpty() ? null : String.join(" ", out);
    }

    /** {@code name} or {@code namespace:name}: lower-case letters, digits and _ . - (and / in the second part). */
    static boolean validName(String t) {
        if (t.length() > 48) return false;
        int colon = t.indexOf(':');
        if (colon != t.lastIndexOf(':')) return false;
        String ns = colon < 0 ? "" : t.substring(0, colon), path = colon < 0 ? t : t.substring(colon + 1);
        if (colon == 0 || path.isEmpty()) return false;
        for (int i = 0; i < ns.length(); i++) if (!idChar(ns.charAt(i), false)) return false;
        for (int i = 0; i < path.length(); i++) if (!idChar(path.charAt(i), true)) return false;
        return true;
    }

    private static boolean idChar(char c, boolean slash) {
        return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '.' || c == '-' || (slash && c == '/');
    }
}
