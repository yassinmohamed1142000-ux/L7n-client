package com.reaper.client.core.feature;

import com.reaper.client.core.hud.Compass;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.ui.Canvas;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * Waypoints: markers drawn on the screen where your saved places are, plus the actions the manager window uses.
 * Follows the server: markers are off where the server rules say so, and nothing is shown or created while the
 * server hides coordinates (the {@code reducedDebugInfo} game rule).
 */
public final class WaypointsModule extends Module {
    /** Colours offered for new waypoints, in the order they are handed out. */
    public static final int[] PALETTE = {0xFF4ADE80, 0xFF60A5FA, 0xFFF87171, 0xFFFACC15, 0xFFC084FC, 0xFFFB923C, 0xFF22D3EE, 0xFFF472B6};
    public static final int DEATH_COLOR = 0xFFFF5D5D;
    private static final int SLOTS = 30;

    public final Settings.Bool markers = new Settings.Bool("markers", "Markers on screen", "Draw a marker where each waypoint of this world is.", true);
    public final Settings.Bool labels = new Settings.Bool("labels", "Names", "Write the waypoint name under its marker.", true);
    public final Settings.Bool distance = new Settings.Bool("distance", "Distance", "Write how far away it is.", true);
    public final Settings.Num size = new Settings.Num("size", "Marker size", "Size of the marker diamond.", 3, 2, 6, 1, "px");
    public final Settings.Num maxMarkers = new Settings.Num("maxMarkers", "Markers shown", "How many of the nearest waypoints get a marker.", 10, 1, SLOTS, 1, "");
    public final Settings.Num maxDistance = new Settings.Num("maxDistance", "Hide beyond", "Hide markers further away than this. 0 means no limit.", 0, 0, 10000, 50, " blocks");
    public final Settings.Bool deathPoint = new Settings.Bool("deathPoint", "Remember deaths", "Save a waypoint where you die so you can find your way back.", true);
    public final Settings.Num deaths = new Settings.Num("deaths", "Death waypoints kept", "Older death waypoints are removed beyond this number.", 3, 1, 10, 1, "");

    private final WaypointStore store;
    private final HudData data;
    private final Projector proj = new Projector();
    private final Waypoint[] near = new Waypoint[SLOTS];
    private final String[] distText = new String[SLOTS];
    private final int[] distKey = new int[SLOTS];
    private String problem = "";

    public WaypointsModule(WaypointStore store, HudData data) {
        super("waypoints", "Waypoints", "Save places and see where they are. Manage them in the Waypoints window.", Category.UTILITY, true, true, "marker home death coordinates navigation locations");
        this.store = store;
        this.data = data;
        feature(Feature.WAYPOINT_MARKERS);
        add(markers);
        add(labels);
        labels.visibleWhen(markers::on);
        add(distance);
        distance.visibleWhen(markers::on);
        add(size);
        size.visibleWhen(markers::on);
        add(maxMarkers);
        maxMarkers.visibleWhen(markers::on);
        add(maxDistance);
        maxDistance.visibleWhen(markers::on);
        add(deathPoint);
        add(deaths);
        deaths.visibleWhen(deathPoint::on);
        java.util.Arrays.fill(distKey, -1);
    }

    public WaypointStore store() { return store; }

    /** Why the last {@link #addHere} returned null, in words for the player. */
    public String problem() { return problem; }

    /** True while waypoint positions must stay hidden because the server hides coordinates. */
    public boolean hiddenByServer() { return data.reducedDebug; }

    // ------------------------------------------------------------------ actions
    /** Saves the current position. A blank name gets "Waypoint 1", "Waypoint 2"... Returns null with {@link #problem()} set on failure. */
    public Waypoint addHere(String name) {
        if (!data.inWorld) { problem = "Join a world first."; return null; }
        if (data.reducedDebug) { problem = "This server hides coordinates, so waypoints are off here."; return null; }
        if (store.context() == null) { problem = "No world is selected."; return null; }
        if (store.count() >= WaypointStore.MAX_PER_WORLD) { problem = "This world already has " + WaypointStore.MAX_PER_WORLD + " waypoints."; return null; }
        String n = name == null || name.isBlank() ? store.uniqueName("Waypoint") : name;
        if (Waypoint.cleanName(n) == null) { problem = "Names are 1 to " + Waypoint.MAX_NAME + " characters."; return null; }
        Waypoint w = store.add(n, floor(data.x), floor(data.y), floor(data.z), data.dimensionId, PALETTE[store.count() % PALETTE.length]);
        if (w == null) { problem = "Could not add the waypoint."; return null; }
        problem = "";
        return w;
    }

    /** Called by the game layer when the player dies: remembers the spot, if the setting is on. */
    public Waypoint onDeath() {
        if (!deathPoint.on() || !data.inWorld || data.reducedDebug || store.context() == null) return null;
        return store.addDeath("Death " + hhmm(data.wallClockMs), floor(data.x), floor(data.y), floor(data.z), data.dimensionId, DEATH_COLOR, deaths.i());
    }

    /** The next palette colour after {@code argb}. */
    public static int nextColor(int argb) {
        int c = 0xFF000000 | argb;
        for (int i = 0; i < PALETTE.length; i++) if (PALETTE[i] == c) return PALETTE[(i + 1) % PALETTE.length];
        return PALETTE[0];
    }

    private static int floor(double v) { return (int) Math.floor(v); }

    static String hhmm(long ms) {
        ZonedDateTime t = Instant.ofEpochMilli(ms <= 0 ? System.currentTimeMillis() : ms).atZone(ZoneId.systemDefault());
        int h = t.getHour(), m = t.getMinute();
        return (h < 10 ? "0" : "") + h + ":" + (m < 10 ? "0" : "") + m;
    }

    /** "850 m" or "1.2 km". */
    public static String formatDistance(double meters) {
        if (meters < 1000) return Math.round(meters) + " m";
        return com.reaper.client.core.util.Text.num(meters / 1000.0, 1) + " km";
    }

    // ------------------------------------------------------------------ markers
    /** Draws the markers over the whole screen. Does nothing while the module is off, blocked by the server rules or the server hides coordinates. */
    public void drawMarkers(Canvas c, Theme theme) {
        HudData d = data;
        if (!isActive() || !markers.on() || !d.inWorld || d.reducedDebug) return;
        int want = Math.min(maxMarkers.i(), SLOTS);
        int n = store.nearest(d.dimensionId, d.camX, d.camZ, near, want);
        if (n == 0) return;
        proj.camera(d.camX, d.camY, d.camZ, d.yaw, d.pitch, d.fov, c.width(), c.height());
        double limit = maxDistance.v();
        int r = size.i(), lh = c.lineHeight();
        boolean showName = labels.on(), showDist = distance.on();
        for (int i = 0; i < n; i++) {
            Waypoint w = near[i];
            double dist = w.distance(d.camX, d.camY, d.camZ);
            if (limit > 0 && dist > limit) continue;
            if (!proj.project(w.x + 0.5, w.y + 1.0, w.z + 0.5) || !proj.onScreen(2)) continue;
            int px = Math.round(proj.sx), py = Math.round(proj.sy);
            Glyphs.diamond(c, px, py, r + 1, 0xDD000000);
            Glyphs.diamond(c, px, py, r, w.color);
            int ty = py + r + 3;
            if (showName) {
                int tw = c.textWidth(w.name);
                c.text(w.name, clampX(px - tw / 2, tw, c.width()), ty, w.color, true);
                ty += lh;
            }
            if (showDist) {
                int m = (int) Math.round(dist);
                if (distKey[i] != m) { distKey[i] = m; distText[i] = formatDistance(m); }
                int tw = c.textWidth(distText[i]);
                c.text(distText[i], clampX(px - tw / 2, tw, c.width()), ty, theme.textDim(), true);
            }
        }
    }

    private static int clampX(int x, int w, int screen) { return Math.max(2, Math.min(screen - w - 2, x)); }

    /** Distance from the camera to a waypoint in blocks, or -1 when it is not known or not allowed to be shown (other dimension, outside a world, server hides coordinates). */
    public double distanceTo(Waypoint w) {
        if (!data.inWorld || data.reducedDebug || !w.dimension.equals(data.dimensionId)) return -1;
        return w.distance(data.camX, data.camY, data.camZ);
    }

    /** For the HUD list and tests: bearing from the camera to a waypoint relative to where the player looks. */
    public float relativeBearing(Waypoint w) {
        double dx = w.x + 0.5 - data.camX, dz = w.z + 0.5 - data.camZ;
        return Compass.relative(Compass.bearingTo(dx, dz), Compass.bearing(data.yaw));
    }
}
