package com.reaper.client.core.ui;

import com.reaper.client.core.feature.ScreenshotLibrary;

/** Supplies small pictures for the screenshot browser. The game layer decodes and uploads them; tests use fakes. */
public interface Thumbnails {
    /** A drawable picture. {@code texture} is the same kind of opaque handle {@link Canvas#image} takes. */
    record Thumb(Object texture, int width, int height) {}

    /**
     * The picture for a file, or null while it is still being loaded or when it cannot be read. Called for the
     * cards that are on screen, so it is also the signal for what to load next.
     */
    Thumb get(ScreenshotLibrary.Entry entry);

    /** The screen closed: free everything. */
    void release();
}
