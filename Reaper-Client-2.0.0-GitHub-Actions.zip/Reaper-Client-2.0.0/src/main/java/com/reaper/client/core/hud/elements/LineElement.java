package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudElement;

/** An element that is one line of text. Subclasses only decide the text and its colour. */
public abstract class LineElement extends HudElement {
    protected String text = "";
    protected int textArgb = 0xFFFFFFFF;

    protected LineElement(String id, String name, String desc, boolean defaultEnabled, String tags, Anchor anchor, int offX, int offY) {
        super(id, name, desc, defaultEnabled, tags, anchor, offX, offY);
    }

    /** The colour the text was last drawn in (the HUD editor and the tests read it). */
    public final int currentTextColor() { return textArgb; }

    /** The text as last measured. */
    public final String currentText() { return text; }

    /** Fills {@link #text} and {@link #textArgb}. Return false to hide the element for now. */
    protected abstract boolean update(HudContext x);

    @Override protected final boolean measure(HudContext x) {
        if (!update(x)) return false;
        w = x.c.textWidth(text) + PAD * 2;
        h = x.c.lineHeight() + PAD * 2 - 1;
        return true;
    }

    @Override protected final void draw(HudContext x) {
        panel(x);
        text(x, text, PAD, PAD, textArgb);
    }
}
