package com.reaper.client.mc;

import com.reaper.client.core.ReaperCore;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.ui.Input;

/** Where the HUD elements are dragged into place. The editor draws the HUD itself, so the normal HUD pass is skipped. */
final class HudEditorScreen extends ReaperScreen {
    private final ReaperCore core;

    HudEditorScreen(ReaperCore core) {
        super("Reaper HUD");
        this.core = core;
        core.hudEditor.open();
    }

    @Override protected Input in() { return core.hudEditor.in; }

    @Override
    protected void draw(McCanvas c, int mouseX, int mouseY, float dt) {
        HudData d = core.data;
        Game.fillHudData(d);
        if (!d.inWorld) d.fillSample(System.nanoTime() / 1_000_000L);   // opened on the title screen: sample values
        core.hud.update(d);
        core.hudEditor.render(c, d, core.theme(), mouseX, mouseY, dt);
    }

    /** The editor decides what Escape means (it closes itself and tells the host). */
    @Override
    protected void escape() {
        in().key(KeyNames.ESCAPE, 0);
    }

    @Override
    protected void closed() {
        core.hudEditor.close();
        core.requestSave();
    }
}
