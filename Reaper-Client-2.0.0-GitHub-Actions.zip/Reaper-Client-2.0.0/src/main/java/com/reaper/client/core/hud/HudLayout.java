package com.reaper.client.core.hud;

/** Placement maths for HUD elements: anchor + offset to a position and back, and snapping while dragging. */
public final class HudLayout {
    private HudLayout() {}

    public static int x(Anchor a, int offset, int w, int screenW) {
        switch (a.col) {
            case 0: return offset;
            case 1: return (screenW - w) / 2 + offset;
            default: return screenW - w - offset;
        }
    }

    public static int y(Anchor a, int offset, int h, int screenH) {
        switch (a.row) {
            case 0: return offset;
            case 1: return (screenH - h) / 2 + offset;
            default: return screenH - h - offset;
        }
    }

    /** The anchor whose third of the screen holds the centre of the rectangle. */
    public static Anchor nearestAnchor(int x, int y, int w, int h, int screenW, int screenH) {
        int cx = x + w / 2, cy = y + h / 2;
        int col = cx < screenW / 3 ? 0 : cx > screenW * 2 / 3 ? 2 : 1;
        int row = cy < screenH / 3 ? 0 : cy > screenH * 2 / 3 ? 2 : 1;
        return Anchor.of(col, row);
    }

    public static int offsetX(Anchor a, int x, int w, int screenW) {
        switch (a.col) {
            case 0: return x;
            case 1: return x - (screenW - w) / 2;
            default: return screenW - w - x;
        }
    }

    public static int offsetY(Anchor a, int y, int h, int screenH) {
        switch (a.row) {
            case 0: return y;
            case 1: return y - (screenH - h) / 2;
            default: return screenH - h - y;
        }
    }

    /** Moves an element so its top-left corner is at (x, y), re-anchoring it to the nearest screen region. */
    public static void moveTo(HudElement e, int x, int y, int screenW, int screenH) {
        int w = Math.max(1, e.rw), h = Math.max(1, e.rh);
        x = Math.max(0, Math.min(screenW - w, x));
        y = Math.max(0, Math.min(screenH - h, y));
        Anchor a = nearestAnchor(x, y, w, h, screenW, screenH);
        e.anchor.set(a);
        e.offsetX.set((double) offsetX(a, x, w, screenW));
        e.offsetY.set((double) offsetY(a, y, h, screenH));
    }

    /**
     * Snaps one coordinate to the screen margin, the far margin, the screen centre and the edges of other
     * elements when within {@code reach} pixels; returns {@code v} unchanged when nothing is close.
     * @param v candidate top-left coordinate on this axis
     * @param size the element's size on this axis
     * @param limit the screen size on this axis
     * @param edges start/end pairs of the other elements on this axis (2 ints each)
     * @param pairs how many pairs of {@code edges} are in use
     */
    public static int snap(int v, int size, int limit, int[] edges, int pairs, int margin, int reach) {
        int best = v, bestD = reach + 1;
        int n = 3 + pairs * 4;
        for (int i = 0; i < n; i++) {
            int cand;
            if (i == 0) cand = margin;
            else if (i == 1) cand = limit - size - margin;
            else if (i == 2) cand = (limit - size) / 2;
            else {
                int k = (i - 3) / 4, s = edges[k * 2], e = edges[k * 2 + 1];
                switch ((i - 3) % 4) {
                    case 0 -> cand = s;              // align start edges
                    case 1 -> cand = e - size;       // align end edges
                    case 2 -> cand = e + 2;          // sit just after the other element
                    default -> cand = s - size - 2;  // sit just before it
                }
            }
            int d = Math.abs(v - cand);
            if (d < bestD) { bestD = d; best = cand; }
        }
        return best;
    }
}
