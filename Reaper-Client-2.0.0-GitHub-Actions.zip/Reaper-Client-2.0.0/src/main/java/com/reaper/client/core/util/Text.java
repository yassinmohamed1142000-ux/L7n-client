package com.reaper.client.core.util;

import java.util.Locale;

/** Small, dependency-free string helpers shared by the GUI, HUD and config code. */
public final class Text {
    private Text() {}

    public static String lower(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT); }

    /** "minecraft:dark_oak_forest" or "dark_oak_forest" -> "Dark Oak Forest". */
    public static String prettyId(String id) {
        if (id == null || id.isEmpty()) return "";
        int colon = id.indexOf(':');
        String path = colon >= 0 ? id.substring(colon + 1) : id;
        StringBuilder sb = new StringBuilder(path.length());
        boolean up = true;
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '_' || c == '/' || c == '-') { sb.append(' '); up = true; }
            else if (up) { sb.append(Character.toUpperCase(c)); up = false; }
            else sb.append(c);
        }
        return sb.toString();
    }

    /** Case-insensitive "all words of the query appear somewhere in the haystack". */
    public static boolean matchesAll(String haystackLower, String queryLower) {
        if (queryLower == null || queryLower.isBlank()) return true;
        int i = 0, n = queryLower.length();
        while (i < n) {
            while (i < n && queryLower.charAt(i) == ' ') i++;
            int j = i;
            while (j < n && queryLower.charAt(j) != ' ') j++;
            if (j > i && !haystackLower.contains(queryLower.substring(i, j))) return false;
            i = j;
        }
        return true;
    }

    /** Formats a double with a fixed number of decimals without locale surprises (always '.'). */
    public static String num(double v, int decimals) {
        if (decimals <= 0) return Long.toString(Math.round(v));
        double p = Math.pow(10, decimals);
        long scaled = Math.round(Math.abs(v) * p);
        long whole = scaled / (long) p, frac = scaled % (long) p;
        StringBuilder sb = new StringBuilder(12);
        if (v < 0 && scaled != 0) sb.append('-');
        sb.append(whole).append('.');
        String f = Long.toString(frac);
        for (int i = f.length(); i < decimals; i++) sb.append('0');
        return sb.append(f).toString();
    }

    /** Human friendly byte count: 1.4 MB. */
    public static String bytes(long b) {
        if (b < 1024) return b + " B";
        double kb = b / 1024.0;
        if (kb < 1024) return num(kb, 1) + " KB";
        double mb = kb / 1024.0;
        if (mb < 1024) return num(mb, 1) + " MB";
        return num(mb / 1024.0, 2) + " GB";
    }

    /** True for characters we allow typing into single-line text boxes. */
    public static boolean isPrintable(int cp) {
        return cp >= 32 && cp != 127 && !Character.isISOControl(cp) && Character.isDefined(cp);
    }
}
