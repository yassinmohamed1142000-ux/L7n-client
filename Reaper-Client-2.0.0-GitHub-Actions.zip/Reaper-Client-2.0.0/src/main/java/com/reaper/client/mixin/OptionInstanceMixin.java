package com.reaper.client.mixin;

import com.reaper.client.mc.ForceSet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Objects;
import java.util.function.Consumer;

/**
 * Gives every game option a way to be set past its slider's range (used by Fullbright for the brightness).
 *
 * <p>The technique (shadowing {@code value} and {@code onValueUpdate} and writing them directly) is the one used by the
 * GPL-3.0 clients Wurst and Meteor, which is how it came to be known to work on 26.1.x; credit to both. See README.md.</p>
 *
 * <p>The field type of {@code onValueUpdate} is the one of Minecraft 26.1.x ({@code Consumer<T>}). On a later game version
 * where it differs, Mixin skips this class with a warning (the mixin config is not "required") and Fullbright then
 * keeps the brightness within the game's own slider range instead of failing.</p>
 */
@Mixin(OptionInstance.class)
public class OptionInstanceMixin<T> implements ForceSet<T> {
    @Shadow
    T value;

    @Shadow
    @Final
    private Consumer<T> onValueUpdate;

    @Override
    public void reaper$forceSet(T newValue) {
        if (!Minecraft.getInstance().isRunning()) {
            value = newValue;
            return;
        }
        if (!Objects.equals(value, newValue)) {
            value = newValue;
            onValueUpdate.accept(value);
        }
    }
}
