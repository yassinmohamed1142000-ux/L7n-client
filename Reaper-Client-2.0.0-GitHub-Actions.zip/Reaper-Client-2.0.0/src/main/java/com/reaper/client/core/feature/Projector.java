package com.reaper.client.core.feature;

/**
 * Turns a point in the world into a point on the screen, given where the camera is and where it looks. Used to put
 * waypoint markers on the HUD. Minecraft conventions: yaw 0 faces +Z (south), 90 faces -X (west); positive pitch
 * looks down; the field of view is the vertical one.
 */
public final class Projector {
    /** Points closer than this in front of the camera are treated as behind it. */
    public static final double NEAR = 0.05;

    private double cx, cy, cz;
    private double fx, fy, fz, rx, rz, ux, uy, uz;
    private double tanHalf = 1, aspect = 1;
    private int w = 1, h = 1;

    /** Result of the last successful {@link #project}: GUI pixel position and distance along the view direction. */
    public float sx, sy;
    public double depth;

    public void camera(double x, double y, double z, float yawDeg, float pitchDeg, float fovDeg, int screenW, int screenH) {
        cx = x; cy = y; cz = z;
        double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
        double sy_ = Math.sin(yaw), cy_ = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        fx = -sy_ * cp; fy = -sp; fz = cy_ * cp;
        rx = -cy_; rz = -sy_;
        ux = -sy_ * sp; uy = cp; uz = cy_ * sp;
        w = Math.max(1, screenW);
        h = Math.max(1, screenH);
        aspect = (double) w / h;
        tanHalf = Math.tan(Math.toRadians(Math.max(1f, Math.min(170f, fovDeg))) / 2.0);
    }

    /** False when the point is behind the camera. Otherwise sets {@link #sx}, {@link #sy} and {@link #depth}. */
    public boolean project(double wx, double wy, double wz) {
        double dx = wx - cx, dy = wy - cy, dz = wz - cz;
        double z = dx * fx + dy * fy + dz * fz;
        if (z <= NEAR) return false;
        double px = dx * rx + dz * rz;
        double py = dx * ux + dy * uy + dz * uz;
        double nx = px / (z * tanHalf * aspect), ny = py / (z * tanHalf);
        sx = (float) ((nx * 0.5 + 0.5) * w);
        sy = (float) ((0.5 - ny * 0.5) * h);
        depth = z;
        return true;
    }

    /** True when the last projected point lies inside the screen shrunk by {@code margin} pixels. */
    public boolean onScreen(int margin) { return sx >= margin && sy >= margin && sx < w - margin && sy < h - margin; }
}
