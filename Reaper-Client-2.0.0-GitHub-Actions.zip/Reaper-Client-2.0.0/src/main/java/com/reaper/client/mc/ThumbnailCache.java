package com.reaper.client.mc;

import com.reaper.client.core.feature.ScreenshotLibrary;
import com.reaper.client.core.screenshot.ThumbPool;
import com.reaper.client.core.ui.Thumbnails;
import com.reaper.client.core.util.Log;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Small pictures for the screenshot manager. At most {@value #POOL} thumbnails of at most
 * {@value #THUMB_W}x{@value #THUMB_H} pixels exist at any time (about 2.6 MB), however many screenshots there are.
 *
 * <p>A single background thread, started when the manager opens and stopped when it closes, reads and shrinks the
 * files; the game's textures are only touched on the render thread, one upload per frame. Files above
 * {@value #MAX_FILE_MB} MB are not decoded at all.</p>
 */
final class ThumbnailCache implements Thumbnails {
    private static final int POOL = 32, THUMB_W = 192, THUMB_H = 108, MAX_FILE_MB = 48;
    private static final long MAX_BYTES = MAX_FILE_MB * 1024L * 1024L;

    private record Job(int slot, int generation, Path path) { }

    private record Result(int slot, int generation, NativeImage image) { }

    private final Minecraft mc = Minecraft.getInstance();
    private final ThumbPool pool = new ThumbPool(POOL);
    private final Identifier[] ids = new Identifier[POOL];
    private final boolean[] registered = new boolean[POOL];
    private final Thumb[] thumbs = new Thumb[POOL];
    private final LinkedBlockingQueue<Job> jobs = new LinkedBlockingQueue<>();
    private final ConcurrentLinkedQueue<Result> results = new ConcurrentLinkedQueue<>();
    private final Object lock = new Object();
    private Thread worker;
    private boolean stop;

    ThumbnailCache() {
        for (int i = 0; i < POOL; i++) ids[i] = Identifier.fromNamespaceAndPath("reaper", "thumb_" + i);
    }

    /** Once per drawn frame, before the cards ask for pictures: takes in at most one finished picture. */
    void beginFrame() {
        pool.beginFrame();
        Result r = results.poll();
        if (r == null) return;
        if (!pool.current(r.slot(), r.generation())) {   // the slot moved on while this was being read
            close(r.image());
            return;
        }
        if (r.image() == null) {
            pool.markFailed(r.slot(), r.generation());
            return;
        }
        try {
            int w = r.image().getWidth(), h = r.image().getHeight();
            DynamicTexture texture = new DynamicTexture(() -> "Reaper thumbnail", r.image());   // the texture owns the image now
            mc.getTextureManager().register(ids[r.slot()], texture);
            registered[r.slot()] = true;
            thumbs[r.slot()] = new Thumb(ids[r.slot()], w, h);
            pool.markReady(r.slot(), r.generation());
        } catch (RuntimeException ex) {
            Log.warn("Could not make a thumbnail texture", ex);
            pool.markFailed(r.slot(), r.generation());
        }
    }

    @Override
    public Thumb get(ScreenshotLibrary.Entry entry) {
        int slot = pool.find(entry);
        if (slot >= 0) return pool.state(slot) == ThumbPool.State.READY ? thumbs[slot] : null;
        slot = pool.claim(entry);
        if (slot < 0) return null;   // every slot is on screen right now; the card waits
        thumbs[slot] = null;
        startWorker();
        jobs.add(new Job(slot, pool.generation(slot), entry.path));
        return null;
    }

    @Override
    public void release() {
        pool.clear();
        synchronized (lock) {
            // From here on the worker closes what it makes instead of handing it over, so nothing can leak.
            stop = true;
            Thread t = worker;
            worker = null;
            if (t != null) t.interrupt();
            jobs.clear();
            for (Result r; (r = results.poll()) != null; ) close(r.image());
        }
        for (int i = 0; i < POOL; i++) {
            thumbs[i] = null;
            if (registered[i]) {
                Reflect.releaseTexture(mc.getTextureManager(), ids[i]);   // not available in every version: then the (small) texture just stays
                registered[i] = false;
            }
        }
    }

    // ------------------------------------------------------------------ worker
    private void startWorker() {
        synchronized (lock) {
            Thread t = worker;
            if (t != null && t.isAlive()) return;
            stop = false;
            t = new Thread(this::loop, "Reaper-thumbnails");
            t.setDaemon(true);
            worker = t;
            t.start();
        }
    }

    private void loop() {
        try {
            while (true) {
                Job j = jobs.poll(200, TimeUnit.MILLISECONDS);
                synchronized (lock) {
                    if (stop || worker != Thread.currentThread()) return;
                }
                if (j == null) continue;
                Result r = decode(j);
                synchronized (lock) {
                    if (stop || worker != Thread.currentThread()) { close(r.image()); return; }
                    results.add(r);
                }
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    private static Result decode(Job j) {
        NativeImage source = null;
        try {
            long size = Files.size(j.path());
            if (size <= 0 || size > MAX_BYTES) return new Result(j.slot(), j.generation(), null);
            try (InputStream in = Files.newInputStream(j.path())) {
                source = NativeImage.read(in);
            }
            return new Result(j.slot(), j.generation(), shrink(source));
        } catch (IOException | RuntimeException ex) {
            return new Result(j.slot(), j.generation(), null);
        } finally {
            close(source);
        }
    }

    /** Box-filter reduction to fit {@value #THUMB_W}x{@value #THUMB_H}. Works on whole pixels of any channel order. */
    private static NativeImage shrink(NativeImage src) {
        int sw = src.getWidth(), sh = src.getHeight();
        if (sw <= 0 || sh <= 0) return null;
        double scale = Math.min(1.0, Math.min((double) THUMB_W / sw, (double) THUMB_H / sh));
        int dw = Math.max(1, (int) Math.round(sw * scale)), dh = Math.max(1, (int) Math.round(sh * scale));
        NativeImage out = new NativeImage(dw, dh, false);
        try {
            for (int y = 0; y < dh; y++) {
                int y0 = (int) ((long) y * sh / dh), y1 = Math.max(y0 + 1, (int) ((long) (y + 1) * sh / dh));
                for (int x = 0; x < dw; x++) {
                    int x0 = (int) ((long) x * sw / dw), x1 = Math.max(x0 + 1, (int) ((long) (x + 1) * sw / dw));
                    long a = 0, b = 0, c = 0, d = 0;
                    int n = 0;
                    for (int yy = y0; yy < y1 && yy < sh; yy++) {
                        for (int xx = x0; xx < x1 && xx < sw; xx++) {
                            int p = src.getPixel(xx, yy);
                            a += p >>> 24;
                            b += (p >>> 16) & 0xFF;
                            c += (p >>> 8) & 0xFF;
                            d += p & 0xFF;
                            n++;
                        }
                    }
                    if (n == 0) n = 1;
                    out.setPixel(x, y, (int) (a / n) << 24 | (int) (b / n) << 16 | (int) (c / n) << 8 | (int) (d / n));
                }
            }
            return out;
        } catch (RuntimeException ex) {
            out.close();
            throw ex;
        }
    }

    private static void close(NativeImage image) {
        if (image == null) return;
        try {
            image.close();
        } catch (RuntimeException ignored) {
            // already closed
        }
    }
}
