package com.reaper.client.core.hud;

/** Derived values the HUD keeps between frames: speed, click counts. Fed once per frame from {@link HudData}. */
public final class HudState {
    public final ClickCounter clicks = new ClickCounter(3);
    private double lastX, lastZ;
    private long lastMs;
    private boolean hadPos;

    /** Updates {@code d.speed} (smoothed horizontal speed) and the click counters. */
    public void update(HudData d) {
        clicks.poll(0, d.keys[HudData.M_LEFT], d.nowMs);
        clicks.poll(1, d.keys[HudData.M_RIGHT], d.nowMs);
        clicks.poll(2, d.keys[HudData.M_MIDDLE], d.nowMs);
        if (!d.inWorld) { hadPos = false; d.speed = 0; return; }
        if (hadPos && d.nowMs > lastMs) {
            double dt = (d.nowMs - lastMs) / 1000.0;
            double dx = d.x - lastX, dz = d.z - lastZ;
            double inst = dt > 0 && dt < 0.5 ? Math.sqrt(dx * dx + dz * dz) / dt : 0;   // a teleport or lag spike counts as zero
            if (inst > 200) inst = 0;
            double k = Math.min(1.0, dt * 6.0);
            d.speed += (inst - d.speed) * k;
        } else {
            d.speed = 0;
        }
        lastX = d.x; lastZ = d.z; lastMs = d.nowMs; hadPos = true;
    }
}
