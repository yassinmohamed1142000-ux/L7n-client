package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Canvas;
import com.reaper.client.core.util.Anim;
import com.reaper.client.core.util.Colors;

import java.util.List;

/**
 * The modules that are switched on. A module that is on but not allowed by the current server rules is listed too,
 * marked "(blocked)", so it is always clear what is really running.
 */
public final class ModuleListElement extends HudElement {
    public enum Sort implements Settings.Labeled {
        LENGTH("Longest first"), ALPHABET("Alphabetical");
        private final String label;
        Sort(String l) { label = l; }
        @Override public String label() { return label; }
    }

    private static final String[] SAMPLE = {"Fullbright", "Zoom", "Waypoints", "Chat Tools"};

    private final Settings.Choice<Sort> sort = new Settings.Choice<>("sort", "Order", "How the list is ordered.", Sort.LENGTH);
    private final Settings.Bool showHud = new Settings.Bool("showHud", "Include HUD elements", "Also list the HUD elements (FPS counter, coordinates and so on).", false);
    private final Settings.Bool showBlocked = new Settings.Bool("showBlocked", "Show blocked modules", "List modules that are on but switched off by the server rules.", true);
    private final Settings.Bool useAccent = new Settings.Bool("useAccent", "Use theme colour", "Colour the names with the interface theme's accent colour.", true);
    private final Settings.Bool bar = new Settings.Bool("bar", "Accent bar", "A thin bar on the outer edge of each entry.", true);

    private Anim[] fade = new Anim[0];
    private String[] label = new String[0];
    private boolean[] blocked = new boolean[0];
    private int[] order = new int[0];
    private int[] width = new int[0];
    private int rows;
    private boolean sample;

    private static final int ROW_PAD = 2;

    public ModuleListElement() {
        super("modulelist", "Module List", "Lists the modules that are switched on.", false, "active enabled hud arraylist", Anchor.TOP_RIGHT, 4, 40);
        add(sort);
        add(showHud);
        add(showBlocked);
        add(useAccent);
        add(bar);
        color.visibleWhen(() -> !useAccent.on());
        commonSettings();
    }

    private void ensure(int n) {
        if (fade.length >= n) return;
        Anim[] f = new Anim[n];
        System.arraycopy(fade, 0, f, 0, fade.length);
        for (int i = fade.length; i < n; i++) f[i] = new Anim();
        fade = f;
        label = java.util.Arrays.copyOf(label, n);
        blocked = java.util.Arrays.copyOf(blocked, n);
        order = new int[n];
        width = new int[n];
    }

    private int rowH(Canvas c) { return c.lineHeight() + ROW_PAD * 2 - 1; }

    @Override protected boolean measure(HudContext x) {
        if (!x.d.inWorld && !x.editing) return false;
        List<Module> all = x.registry.all();
        int total = all.size();
        ensure(total);
        Canvas c = x.c;
        rows = 0;
        boolean any = false;
        for (int i = 0; i < total; i++) {
            Module m = all.get(i);
            boolean listed = m != this && m.toggleable && m.isEnabled()
                    && (showHud.on() || m.category != Category.HUD)
                    && (showBlocked.on() || !m.isBlockedByPolicy());
            Anim a = fade[i];
            a.set(listed ? 1f : 0f);
            if (a.value != a.target) a.update(x.dt, 14f);
            if (listed) any = true;
            if (a.value > 0.01f) {
                boolean b = m.isBlockedByPolicy();
                if (label[i] == null || b != blocked[i]) { blocked[i] = b; label[i] = b ? m.name + " (blocked)" : m.name; width[i] = c.textWidth(label[i]); }
                order[rows++] = i;
            }
        }
        sample = !any && rows == 0 && x.editing;
        if (sample) {
            int widest = 0;
            for (String s : SAMPLE) widest = Math.max(widest, c.textWidth(s));
            w = widest + ROW_PAD * 2 + 4 + (bar.on() ? 3 : 0);
            h = SAMPLE.length * rowH(c);
            return true;
        }
        if (rows == 0) return false;
        // insertion sort: at most a few dozen entries, no allocation
        boolean alpha = sort.v() == Sort.ALPHABET;
        for (int i = 1; i < rows; i++) {
            int v = order[i], j = i - 1;
            while (j >= 0 && before(v, order[j], alpha)) { order[j + 1] = order[j]; j--; }
            order[j + 1] = v;
        }
        int widest = 0;
        float height = 0f;
        for (int k = 0; k < rows; k++) {
            int i = order[k];
            widest = Math.max(widest, width[i]);
            height += rowH(c) * Anim.outCubic(fade[i].value);
        }
        w = widest + ROW_PAD * 2 + 4 + (bar.on() ? 3 : 0);
        h = Math.max(1, Math.round(height));
        return true;
    }

    private boolean before(int a, int b, boolean alpha) {
        if (alpha) return label[a].compareToIgnoreCase(label[b]) < 0;
        return width[a] > width[b] || (width[a] == width[b] && a < b);
    }

    @Override protected void draw(HudContext x) {
        Canvas c = x.c;
        boolean right = anchor.v().col == 2;
        int rh = rowH(c);
        int textColor = useAccent.on() ? x.theme.accent() : color.argb();
        float y = 0;
        int n = sample ? SAMPLE.length : rows;
        for (int k = 0; k < n; k++) {
            float f = sample ? 1f : Anim.outCubic(fade[order[k]].value);
            String s = sample ? SAMPLE[k] : label[order[k]];
            boolean isBlocked = !sample && blocked[order[k]];
            int tw = sample ? c.textWidth(s) : width[order[k]];
            int rowW = tw + ROW_PAD * 2 + 4 + (bar.on() ? 3 : 0);
            int rx = right ? w - rowW : 0;
            int ry = Math.round(y);
            c.pushAlpha(f);
            if (background.on()) c.fill(rx, ry, rowW, rh, backgroundColor.argb());
            if (bar.on()) c.fill(right ? rx + rowW - 2 : rx, ry, 2, rh, isBlocked ? x.theme.warn() : x.theme.accent());
            int tx = right ? rx + ROW_PAD + 2 : rx + (bar.on() ? 3 : 0) + ROW_PAD + 2;
            c.text(s, tx, ry + ROW_PAD, isBlocked ? x.theme.textDim() : textColor, shadow.on());
            c.popAlpha();
            y += rh * f;
        }
    }
}
