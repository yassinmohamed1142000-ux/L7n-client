package com.reaper.client.core.hud;

/**
 * Everything the HUD needs to know about the game, copied in once per frame by the Minecraft layer. Plain fields,
 * preallocated arrays: filling it does not allocate, and the HUD code stays free of Minecraft types so it can be tested.
 */
public final class HudData {
    public enum Dimension { OVERWORLD("Overworld"), NETHER("The Nether"), END("The End"), OTHER("Unknown");
        public final String label;
        Dimension(String l) { label = l; }

        /** The dimension for a resource id such as {@code minecraft:the_nether}; anything unknown is OTHER. */
        public static Dimension fromId(String id) {
            if (id == null) return OTHER;
            return switch (id) {
                case "minecraft:overworld" -> OVERWORLD;
                case "minecraft:the_nether" -> NETHER;
                case "minecraft:the_end" -> END;
                default -> OTHER;
            };
        }
    }

    /** Indices into {@link #keys}. */
    public static final int K_FORWARD = 0, K_LEFT = 1, K_BACK = 2, K_RIGHT = 3, K_JUMP = 4, K_SNEAK = 5, K_SPRINT = 6,
            M_LEFT = 7, M_RIGHT = 8, M_MIDDLE = 9, KEY_COUNT = 10;
    /** Indices into {@link #armor}. */
    public static final int HEAD = 0, CHEST = 1, LEGS = 2, FEET = 3;

    /** One equipment slot. {@code stack} is whatever the Minecraft layer wants to get back in {@code Canvas.item}. */
    public static final class ItemInfo {
        public Object stack;
        public boolean present;
        public int count, damage, maxDamage;
        public String name = "";

        public boolean hasDurability() { return present && maxDamage > 0; }
        public int remaining() { return Math.max(0, maxDamage - damage); }
        /** 0..1 */
        public float fraction() { return maxDamage <= 0 ? 1f : Math.max(0f, Math.min(1f, (maxDamage - damage) / (float) maxDamage)); }

        public void set(Object stack, int count, int damage, int maxDamage, String name) {
            this.stack = stack; present = true; this.count = count; this.damage = damage; this.maxDamage = maxDamage; this.name = name == null ? "" : name;
        }

        public void clear() { stack = null; present = false; count = damage = maxDamage = 0; name = ""; }
    }

    // ---- frame
    public int fps;
    public float frameMs;
    public long nowMs;
    public long wallClockMs;
    /** Size of the screen in GUI units (what the HUD draws into). */
    public int screenW, screenH;

    // ---- world
    public boolean inWorld, singleplayer;
    public String serverName = "";
    /** True when the server hides debug information (gamerule reducedDebugInfo): coordinates, biome and light are then not shown. */
    public boolean reducedDebug;
    public double x, y, z;
    public float yaw, pitch;
    public Dimension dimension = Dimension.OVERWORLD;
    /** The dimension's real id, such as {@code minecraft:overworld}; waypoints are stored per id. */
    public String dimensionId = "minecraft:overworld";
    /** Where the camera is and how wide it sees (vertical field of view in degrees, after zoom), for on-screen markers. */
    public double camX, camY, camZ;
    public float fov = 70f;
    public String biome = "";
    public int blockLight = -1, skyLight = -1;
    /** Time of day in ticks (0 = sunrise), or -1 when the game layer cannot read it. */
    public long dayTime = -1;
    public int ping = -1;
    public boolean sprinting, sneaking, flying, swimming, gliding, crawling;
    /** Horizontal speed in blocks per second, smoothed by {@link HudState}. */
    public double speed;

    // ---- equipment and input
    public final ItemInfo[] armor = {new ItemInfo(), new ItemInfo(), new ItemInfo(), new ItemInfo()};
    public final ItemInfo mainHand = new ItemInfo(), offHand = new ItemInfo();
    public final boolean[] keys = new boolean[KEY_COUNT];
    /** Labels shown on the keystroke display (the player's real bindings). */
    public final String[] keyLabels = {"W", "A", "S", "D", "Space", "Shift", "Ctrl", "LMB", "RMB", "MMB"};

    public int chunkX() { return (int) Math.floor(x) >> 4; }
    public int chunkZ() { return (int) Math.floor(z) >> 4; }

    /** Plausible values, used by the HUD editor when there is no world to read from. */
    public void fillSample(long nowMs) {
        this.nowMs = nowMs;
        wallClockMs = System.currentTimeMillis();
        inWorld = true;
        singleplayer = true;
        serverName = "Singleplayer";
        reducedDebug = false;
        fps = 144;
        frameMs = 6.9f;
        x = 128.5; y = 72.0; z = -301.25;
        yaw = 215f; pitch = 12f;
        dimension = Dimension.OVERWORLD;
        dimensionId = "minecraft:overworld";
        camX = x; camY = y + 1.62; camZ = z;
        fov = 70f;
        biome = "Plains";
        blockLight = 7; skyLight = 15;
        dayTime = 6000;
        ping = 38;
        speed = 4.3;
        sprinting = true;
        armor[HEAD].set(null, 1, 120, 363, "Iron Helmet");
        armor[CHEST].set(null, 1, 40, 592, "Diamond Chestplate");
        armor[LEGS].set(null, 1, 300, 495, "Iron Leggings");
        armor[FEET].set(null, 1, 20, 65, "Leather Boots");
        mainHand.set(null, 1, 250, 1561, "Diamond Pickaxe");
        offHand.set(null, 1, 0, 0, "Shield");
        keys[K_FORWARD] = true;
        keys[K_SPRINT] = true;
        keys[M_LEFT] = true;
    }
}
