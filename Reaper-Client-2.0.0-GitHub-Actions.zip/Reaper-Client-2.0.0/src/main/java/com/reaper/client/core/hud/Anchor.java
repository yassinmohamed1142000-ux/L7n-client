package com.reaper.client.core.hud;

import com.reaper.client.core.setting.Settings;

/** Where on the screen an element is attached. Offsets always move the element inwards from its anchor edge(s). */
public enum Anchor implements Settings.Labeled {
    TOP_LEFT("Top left", 0, 0), TOP_CENTER("Top centre", 1, 0), TOP_RIGHT("Top right", 2, 0),
    MIDDLE_LEFT("Middle left", 0, 1), CENTER("Centre", 1, 1), MIDDLE_RIGHT("Middle right", 2, 1),
    BOTTOM_LEFT("Bottom left", 0, 2), BOTTOM_CENTER("Bottom centre", 1, 2), BOTTOM_RIGHT("Bottom right", 2, 2);

    public final String label;
    /** 0 = left, 1 = centre, 2 = right. */
    public final int col;
    /** 0 = top, 1 = middle, 2 = bottom. */
    public final int row;

    Anchor(String label, int col, int row) { this.label = label; this.col = col; this.row = row; }

    @Override public String label() { return label; }

    private static final Anchor[] GRID = {TOP_LEFT, TOP_CENTER, TOP_RIGHT, MIDDLE_LEFT, CENTER, MIDDLE_RIGHT, BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT};

    public static Anchor of(int col, int row) { return GRID[Math.max(0, Math.min(2, row)) * 3 + Math.max(0, Math.min(2, col))]; }
}
