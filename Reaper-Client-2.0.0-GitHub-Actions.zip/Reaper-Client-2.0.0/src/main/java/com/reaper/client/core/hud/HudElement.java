package com.reaper.client.core.hud;

import com.reaper.client.core.module.Category;
import com.reaper.client.core.module.Module;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.util.Colors;

/**
 * A module that draws something on the HUD. Subclasses implement {@link #measure} (how big is it right now?) and
 * {@link #draw}; the {@link Hud} positions and scales it from the anchor/offset/scale settings, which the HUD editor
 * also writes when the player drags the element around.
 */
public abstract class HudElement extends Module {
    public final Settings.Color color = new Settings.Color("color", "Text colour", "Colour of the text.", 0xFFFFFFFF, false);
    public final Settings.Bool shadow = new Settings.Bool("shadow", "Text shadow", "Draw a soft shadow behind the text.", true);
    public final Settings.Bool background;
    public final Settings.Color backgroundColor = new Settings.Color("backgroundColor", "Background colour", "Colour and opacity of the panel.", 0x88000000, true);
    public final Settings.Num scale = new Settings.Num("scale", "Size", "Size of the element.", 1.0, 0.5, 3.0, 0.05, "x");
    public final Settings.Choice<Anchor> anchor;
    public final Settings.Num offsetX, offsetY;

    /** Size at scale 1, set by {@link #measure}. */
    protected int w, h;
    /** Where the element was last drawn, in screen (GUI) pixels. Used by the editor for hit testing. */
    public int rx, ry, rw, rh;
    public final Anchor defaultAnchor;
    public final int defaultOffsetX, defaultOffsetY;

    protected HudElement(String id, String name, String desc, boolean defaultEnabled, String tags, Anchor anchor, int offX, int offY) {
        this(id, name, desc, defaultEnabled, tags, anchor, offX, offY, true);
    }

    protected HudElement(String id, String name, String desc, boolean defaultEnabled, String tags, Anchor anchor, int offX, int offY, boolean defaultBackground) {
        super(id, name, desc, Category.HUD, true, defaultEnabled, tags);
        this.background = new Settings.Bool("background", "Background", "Draw a dim panel behind the element.", defaultBackground);
        this.defaultAnchor = anchor;
        this.defaultOffsetX = offX;
        this.defaultOffsetY = offY;
        this.anchor = new Settings.Choice<>("anchor", "Anchor", "Which part of the screen the element is attached to.", anchor);
        // The element's own start position is the real default, so "reset" and a profile that does not mention it restore it.
        this.offsetX = new Settings.Num("offsetX", "Offset X", "Distance from the anchored edge. Drag the element in the HUD editor instead if you prefer.", offX, -1000, 1000, 1, "px");
        this.offsetY = new Settings.Num("offsetY", "Offset Y", "Distance from the anchored edge.", offY, -1000, 1000, 1, "px");
    }

    /**
     * Adds the settings every element shares, after the element's own. Each subclass calls this last in its
     * constructor so the shared rows (colours, size, position) come at the end of the panel.
     */
    protected final void commonSettings() {
        add(color);
        add(shadow);
        add(background);
        add(backgroundColor);
        backgroundColor.visibleWhen(background::on);
        add(scale);
        add(anchor);
        add(offsetX);
        add(offsetY);
        add(new Settings.Action("resetPosition", "Reset position", "Put this element back where it started.", false, this::resetPosition));
    }

    public void resetPosition() {
        anchor.reset();
        offsetX.reset();
        offsetY.reset();
        scale.reset();
    }

    /** True when the shared settings have been added (checked by tests). */
    public boolean hasCommonSettings() { return find("anchor") != null && find("scale") != null; }

    /**
     * Works out the content and sets {@link #w} and {@link #h} (unscaled). Return false when there is nothing to show
     * right now (the element is then skipped), unless the HUD editor is open.
     */
    protected abstract boolean measure(HudContext x);

    /** Draws at (0, 0) in unscaled units; the canvas is already translated and scaled. */
    protected abstract void draw(HudContext x);

    // package-private entry points used by Hud
    final boolean doMeasure(HudContext x) { w = 0; h = 0; boolean ok = measure(x); return ok && w > 0 && h > 0; }
    final void doDraw(HudContext x) { draw(x); }
    final int width() { return w; }
    final int height() { return h; }

    // ------------------------------------------------------------------ helpers for subclasses
    protected static final int PAD = 3;

    /** Panel behind the whole element if enabled. */
    protected final void panel(HudContext x) {
        if (background.on()) x.c.roundRect(0, 0, w, h, 2, backgroundColor.argb());
    }

    protected final void text(HudContext x, String s, int px, int py, int argb) {
        x.c.text(s, px, py, argb, shadow.on());
    }

    protected final int line(HudContext x) { return x.c.lineHeight() + 1; }

    /** Text colour with the element's own alpha applied on top. */
    protected final int textColor() { return color.argb(); }

    /** Green (good) to red (bad): 1 = good. */
    protected static int health(float fraction) {
        float f = Math.max(0f, Math.min(1f, fraction));
        return f > 0.5f ? Colors.lerp(0xFFFFD43B, 0xFF4ADE80, (f - 0.5f) * 2f) : Colors.lerp(0xFFFF5D5D, 0xFFFFD43B, f * 2f);
    }
}
