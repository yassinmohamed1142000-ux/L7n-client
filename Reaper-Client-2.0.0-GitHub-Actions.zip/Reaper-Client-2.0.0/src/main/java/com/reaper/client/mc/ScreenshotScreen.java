package com.reaper.client.mc;

import com.reaper.client.core.ReaperCore;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.ui.Input;
import com.reaper.client.core.ui.ScreenshotBrowser;

import java.nio.file.Path;

/** The screenshot manager: the pictures in the game's screenshots folder, with rename, copy path and delete. */
final class ScreenshotScreen extends ReaperScreen {
    private final ReaperCore core;
    private final ThumbnailCache thumbs = new ThumbnailCache();
    private final ScreenshotBrowser browser;

    ScreenshotScreen(ReaperCore core) {
        super("Reaper Screenshots");
        this.core = core;
        this.browser = new ScreenshotBrowser(core.screenshots, thumbs, new ScreenshotBrowser.Host() {
            @Override public void openFolder(Path dir) { Game.openFolder(dir); }
            @Override public void toast(Level level, String message) { core.toast(level, message); }
            @Override public void close() { Game.requestScreen(null); }
        });
        browser.ui.clipboard = Game.clipboard();
        browser.open();
    }

    @Override protected Input in() { return browser.in; }

    @Override
    protected void draw(McCanvas c, int mouseX, int mouseY, float dt) {
        thumbs.beginFrame();
        browser.in.mouseMove(mouseX, mouseY);
        browser.render(c, core.theme(), dt);
    }

    /** Escape first leaves the name box, then closes the manager. */
    @Override
    protected void escape() {
        if (browser.ui.focus != null) in().key(KeyNames.ESCAPE, 0);
        else Game.requestScreen(null);
    }

    @Override
    protected void closed() {
        browser.close();   // also releases the thumbnails
    }
}
