package com.reaper.client.core.feature;

import com.reaper.client.core.util.Text;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * The picture files in the game's screenshots folder, newest first. Only plain {@code .png} files directly inside
 * the folder are listed (no sub-folders, no links), and renames and deletes can only touch those.
 */
public final class ScreenshotLibrary {
    public static final int MAX_ENTRIES = 3000, MAX_BASE = 100;
    private static final int SCAN_LIMIT = 20_000;

    public static final class Entry {
        public Path path;
        /** File name without the ".png". */
        public String name;
        public long modified, size;
        /** Ready-to-draw texts, made once when the folder is read. */
        public String dateText = "", sizeText = "";

        public String fileName() { return name + ".png"; }
    }

    private final Path dir;
    private final List<Entry> entries = new ArrayList<>();
    private final List<Entry> view = Collections.unmodifiableList(entries);

    public ScreenshotLibrary(Path dir) { this.dir = dir; }

    public Path dir() { return dir; }

    /** Newest first. Read-only. */
    public List<Entry> entries() { return view; }

    /** Reads the folder again. False when the folder is missing or cannot be read (the list is then empty). */
    public boolean refresh() {
        entries.clear();
        if (dir == null || !Files.isDirectory(dir)) return false;
        List<Entry> found = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            for (Path p : ds) {
                if (found.size() >= SCAN_LIMIT) break;
                String fn = p.getFileName().toString();
                if (fn.length() <= 4 || !fn.regionMatches(true, fn.length() - 4, ".png", 0, 4)) continue;
                BasicFileAttributes a;
                try { a = Files.readAttributes(p, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS); }
                catch (IOException ex) { continue; }
                if (!a.isRegularFile()) continue;
                Entry e = new Entry();
                e.path = p;
                e.name = fn.substring(0, fn.length() - 4);
                e.modified = a.lastModifiedTime().toMillis();
                e.size = a.size();
                e.dateText = dateText(e.modified);
                e.sizeText = sizeText(e.size);
                found.add(e);
            }
        } catch (IOException | RuntimeException ex) {
            return false;
        }
        found.sort((a, b) -> a.modified != b.modified ? Long.compare(b.modified, a.modified) : a.name.compareToIgnoreCase(b.name));
        for (int i = 0; i < found.size() && i < MAX_ENTRIES; i++) entries.add(found.get(i));
        return true;
    }

    /**
     * Gives a screenshot a new name (the ".png" is kept). Returns null on success, otherwise a short message the
     * player can read.
     */
    public String rename(Entry e, String newBase) {
        String b = cleanBaseName(newBase);
        if (b == null) return "That is not a usable file name.";
        if (!entries.contains(e)) return "That screenshot is no longer in the list.";
        if (b.equals(e.name)) return null;
        for (Entry o : entries) if (o != e && o.name.equalsIgnoreCase(b)) return "A screenshot with that name already exists.";
        Path target = dir.resolve(b + ".png");
        try {
            if (Files.exists(target) && !Files.isSameFile(e.path, target)) return "A file with that name already exists.";
            Files.move(e.path, target);
        } catch (IOException ex) {
            return "Could not rename the file.";
        }
        e.path = target;
        e.name = b;
        return null;
    }

    /** Deletes the file. True when it is gone. */
    public boolean delete(Entry e) {
        if (!entries.contains(e)) return false;
        try { Files.deleteIfExists(e.path); }
        catch (IOException ex) { return false; }
        entries.remove(e);
        return true;
    }

    /**
     * Checks a file name typed by the player: at most {@value #MAX_BASE} printable characters, no path characters,
     * no leading dot (it would hide the file on Linux and macOS), no trailing dot or space, no names Windows
     * reserves. A typed ".png" is dropped. Null when not usable.
     */
    public static String cleanBaseName(String s) {
        if (s == null) return null;
        String t = s.strip();
        if (t.length() > 4 && t.regionMatches(true, t.length() - 4, ".png", 0, 4)) t = t.substring(0, t.length() - 4).strip();
        if (t.isEmpty() || t.codePointCount(0, t.length()) > MAX_BASE || t.startsWith(".") || t.endsWith(".")) return null;
        for (int i = 0; i < t.length(); ) {
            int cp = t.codePointAt(i);
            if (!Text.isPrintable(cp) || "\\/:*?\"<>|".indexOf(cp) >= 0) return null;
            i += Character.charCount(cp);
        }
        int dot = t.indexOf('.');
        String stem = (dot < 0 ? t : t.substring(0, dot)).strip().toUpperCase(Locale.ROOT);
        if (stem.equals("CON") || stem.equals("PRN") || stem.equals("AUX") || stem.equals("NUL")
                || (stem.length() == 4 && (stem.startsWith("COM") || stem.startsWith("LPT")) && stem.charAt(3) >= '1' && stem.charAt(3) <= '9')) return null;
        return t;
    }

    private static final java.util.regex.Pattern VANILLA_NAME =
            java.util.regex.Pattern.compile("(?<![\\w.])(\\d{4}-\\d{2}-\\d{2}_\\d{2}\\.\\d{2}\\.\\d{2}(?:_\\d{1,3})?\\.png)(?![\\w.])");

    /**
     * The name of the file in a chat line such as "Saved screenshot as 2026-11-14_09.05.31.png", or null. The game names
     * its own screenshots by date and time, so the name is found whatever language the rest of the line is in. The caller
     * must still check that the file exists: any player can type such a line.
     */
    public static String vanillaFileName(String chatLine) {
        if (chatLine == null || chatLine.length() > 300) return null;
        java.util.regex.Matcher m = VANILLA_NAME.matcher(chatLine);
        String last = null;
        while (m.find()) last = m.group(1);
        return last;
    }

    /** "2026-11-14 09:05". */
    public static String dateText(long epochMs) {
        LocalDateTime t = LocalDateTime.ofInstant(Instant.ofEpochMilli(epochMs), ZoneId.systemDefault());
        return t.getYear() + "-" + two(t.getMonthValue()) + "-" + two(t.getDayOfMonth()) + " " + two(t.getHour()) + ":" + two(t.getMinute());
    }

    /** "812 B", "340 KB", "2.4 MB". */
    public static String sizeText(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return Math.round(bytes / 1024.0) + " KB";
        return Text.num(bytes / (1024.0 * 1024.0), 1) + " MB";
    }

    private static String two(int v) { return v < 10 ? "0" + v : Integer.toString(v); }
}
