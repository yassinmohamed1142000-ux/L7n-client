package com.reaper.client.core.util;

import java.util.Locale;

/** Turns the game's resource ids into names a player would write: "minecraft:old_growth_pine_taiga" becomes "Old Growth Pine Taiga". */
public final class GameNames {
    private GameNames() {}

    private static final int MAX = 40;

    /**
     * Readable form of an id. The "minecraft:" namespace is dropped; another namespace is kept in brackets so two
     * mods' biomes with the same path stay apart. Null or empty gives an empty string.
     */
    public static String pretty(String id) {
        if (id == null) return "";
        String s = id.strip();
        if (s.isEmpty()) return "";
        String ns = "minecraft", path = s;
        int colon = s.indexOf(':');
        if (colon >= 0) {
            ns = s.substring(0, colon);
            path = s.substring(colon + 1);
        }
        int slash = path.lastIndexOf('/');
        if (slash >= 0) path = path.substring(slash + 1);
        StringBuilder sb = new StringBuilder(path.length() + 8);
        boolean up = true;
        for (int i = 0; i < path.length(); i++) {
            char ch = path.charAt(i);
            if (ch == '_' || ch == '-' || ch == ' ') {
                if (sb.length() > 0 && sb.charAt(sb.length() - 1) != ' ') sb.append(' ');
                up = true;
            } else {
                sb.append(up ? Character.toUpperCase(ch) : Character.toLowerCase(ch));
                up = false;
            }
        }
        String out = sb.toString().strip();
        if (out.isEmpty()) return "";
        if (!ns.isEmpty() && !ns.equals("minecraft")) out = out + " (" + ns.toLowerCase(Locale.ROOT) + ")";
        return out.length() > MAX ? out.substring(0, MAX - 3) + "..." : out;
    }
}
