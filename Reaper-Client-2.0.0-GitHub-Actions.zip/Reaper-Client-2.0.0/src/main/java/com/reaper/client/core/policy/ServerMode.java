package com.reaper.client.core.policy;

import com.reaper.client.core.setting.Settings;

/**
 * What the player has told Reaper about the server's rules. Reaper never guesses and never hides anything:
 * these modes only ever make the client MORE restrictive than the defaults, except OPEN which the player
 * must choose explicitly for a server whose rules allow automation.
 */
public enum ServerMode implements Settings.Labeled {
    /** Default for any multiplayer server: visual/QoL features on, automation off. */
    STANDARD("Standard", "Visual and quality-of-life features only. Automation is off."),
    /** For servers (or tournaments) that ask for a vanilla-equivalent client. */
    STRICT("Strict", "Only HUD, GUI, chat and screenshot tools. Fullbright, zoom, waypoint markers, sorting and automation are off."),
    /** For servers whose rules explicitly allow it. Singleplayer is always treated like this. */
    OPEN("Open", "Everything is available, including opt-in automation.");

    public final String label;
    public final String blurb;
    ServerMode(String label, String blurb) { this.label = label; this.blurb = blurb; }
    @Override public String label() { return label; }

    public boolean allows(Feature f) {
        switch (this) {
            case OPEN: return true;
            case STRICT: return false;
            default: return f != Feature.AUTOMATION;
        }
    }
}
