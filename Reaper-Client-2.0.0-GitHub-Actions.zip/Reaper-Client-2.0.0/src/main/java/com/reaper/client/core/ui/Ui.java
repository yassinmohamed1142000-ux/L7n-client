package com.reaper.client.core.ui;

import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.util.Anim;
import com.reaper.client.core.util.Colors;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Immediate-mode GUI toolkit. Each frame the {@link ClickGui} draws everything and handles input in the same pass,
 * so there is no retained widget tree to keep in sync. Per-widget animation state lives in {@link WState}, keyed by
 * the model object (module, setting, window) so nothing is allocated per frame.
 */
public final class Ui {
    /** Animation/interaction state of one widget. */
    public static final class WState {
        public float hover, press, aux, aux2;
        public float h, s, v;
        public boolean open, hsvValid;
        long seen;
    }

    public Canvas c;
    public Theme theme;
    public final Input in;
    public float dt;
    public boolean animations = true;
    public boolean compact;
    /** Mouse position in the GUI's own (scaled) coordinates. */
    public int mx, my;
    public long frame;
    /** Milliseconds of GUI time, advanced by dt (deterministic in tests). */
    public double timeMs;
    /** Where copy and paste go. The game layer replaces this with the system clipboard; until then it is a private one. */
    public TextField.Clipboard clipboard = new TextField.Clipboard() {
        private String text = "";
        @Override public String get() { return text; }
        @Override public void set(String s) { text = s == null ? "" : s; }
    };

    /** Set to true by any widget that changed a value; the screen then schedules a save. */
    public boolean changed;

    // ---- interaction
    /** Widget being dragged (slider, window...). Hover is suppressed for everything else meanwhile. */
    public Object active;
    /** Which part of the active widget (a colour picker has three draggable parts). */
    public int activePart;
    /** Set by a widget each frame it draws the focused editor; if nobody does, focus is dropped. */
    public boolean focusSeen;
    /** Owner of keyboard focus (a text setting, the search box, a key bind row). */
    public Object focus;
    /** The shared text editor. Only one field has focus at a time. */
    public final TextField field = new TextField();
    /** True while the focused widget is waiting for a key press to bind. */
    public boolean listening;

    private Object inputOwner, scope;
    private final IdentityHashMap<Object, WState> states = new IdentityHashMap<>();
    private final HashMap<String, WState> keyed = new HashMap<>();
    private final IdentityHashMap<Object, WState> transients = new IdentityHashMap<>();

    // ---- clip tracking for hover tests
    private final int[] clipStack = new int[4 * 24];
    private int clipN;
    private int cx0, cy0, cx1, cy1;

    // ---- tooltip
    private Object tipId;
    private float tipT;
    private boolean tipSeen;
    private String tipText;

    public Ui(Input in) { this.in = in; }

    // ------------------------------------------------------------------ frame
    public void begin(Canvas canvas, Theme t, float dtSeconds, int mouseX, int mouseY) {
        c = canvas;
        theme = t;
        dt = Math.min(Math.max(dtSeconds, 0f), 0.1f);
        timeMs += dt * 1000.0;
        mx = mouseX;
        my = mouseY;
        clipN = 0;
        cx0 = cy0 = Integer.MIN_VALUE / 2;
        cx1 = cy1 = Integer.MAX_VALUE / 2;
        scope = null;
        tipSeen = false;
        tipText = null;
        focusSeen = false;
        field.idle += dt;
    }

    public void end() {
        if (!tipSeen) { tipId = null; tipT = 0; }
        if (focus != null && !focusSeen) unfocus();
        frame++;
        if (frame % 600 == 0) prune();
        in.endFrame();
    }

    private void prune() {
        for (Iterator<Map.Entry<String, WState>> it = keyed.entrySet().iterator(); it.hasNext(); ) {
            if (frame - it.next().getValue().seen > 300) it.remove();
        }
        for (Iterator<Map.Entry<Object, WState>> it = transients.entrySet().iterator(); it.hasNext(); ) {
            if (frame - it.next().getValue().seen > 300) it.remove();
        }
    }

    /** Number of widget states currently kept (for leak tests and diagnostics). */
    public int stateCount() { return states.size() + keyed.size() + transients.size(); }

    /** The region that currently receives mouse input (a window, the top bar...). */
    public void setInputOwner(Object owner) { inputOwner = owner; }
    public void setScope(Object owner) { scope = owner; }
    public boolean isOwner(Object o) { return inputOwner == o; }

    // ------------------------------------------------------------------ state
    /** State for a model object (identity) or, for strings, by value. */
    public WState st(Object key) {
        if (key instanceof String str) return st(str);
        WState s = states.get(key);
        if (s == null) { s = new WState(); states.put(key, s); }
        s.seen = frame;
        return s;
    }

    /**
     * State for an object that comes and goes (a waypoint row, a screenshot card). Unlike {@link #st(Object)} it is
     * dropped again when the object has not been drawn for a few seconds, so removed objects are not kept alive.
     */
    public WState stTransient(Object key) {
        WState s = transients.get(key);
        if (s == null) { s = new WState(); transients.put(key, s); }
        s.seen = frame;
        return s;
    }

    public WState st(String key) {
        WState s = keyed.get(key);
        if (s == null) { s = new WState(); keyed.put(key, s); }
        s.seen = frame;
        return s;
    }

    /** Smoothly moves {@code cur} towards {@code target}; instant when animations are off. */
    public float ease(float cur, float target, float speed) {
        if (!animations) return target;
        if (cur == target) return cur;
        float k = 1f - (float) Math.exp(-speed * dt);
        float n = cur + (target - cur) * k;
        return Math.abs(target - n) < 0.002f ? target : n;
    }

    // ------------------------------------------------------------------ clip + hit testing
    public void pushClip(int x, int y, int w, int h) {
        if (clipN < clipStack.length / 4) {
            int i = clipN * 4;
            clipStack[i] = cx0; clipStack[i + 1] = cy0; clipStack[i + 2] = cx1; clipStack[i + 3] = cy1;
            clipN++;
        }
        cx0 = Math.max(cx0, x); cy0 = Math.max(cy0, y);
        cx1 = Math.min(cx1, x + w); cy1 = Math.min(cy1, y + h);
        c.clip(x, y, w, h);
    }

    public void popClip() {
        if (clipN > 0) {
            clipN--;
            int i = clipN * 4;
            cx0 = clipStack[i]; cy0 = clipStack[i + 1]; cx1 = clipStack[i + 2]; cy1 = clipStack[i + 3];
        }
        c.unclip();
    }

    /** True when the point is inside the rectangle AND inside the visible clip. */
    public boolean contains(int x, int y, int w, int h, int px, int py) {
        return px >= x && py >= y && px < x + w && py < y + h && px >= cx0 && py >= cy0 && px < cx1 && py < cy1;
    }

    /** Mouse is over this rectangle, is visible, belongs to the current region and nothing is being dragged. */
    public boolean over(int x, int y, int w, int h) {
        return active == null && inputOwner == scope && contains(x, y, w, h, mx, my);
    }

    public boolean isActive(Object id, int part) { return active == id && activePart == part; }

    public void activate(Object id, int part) { active = id; activePart = part; }

    public void deactivate() { active = null; activePart = 0; }

    /** Left press that started inside this rectangle during this frame. */
    public boolean pressedIn(int x, int y, int w, int h, int button) {
        return in.wasPressed(button) && over(x, y, w, h);
    }

    // ------------------------------------------------------------------ tooltips
    public void tip(Object id, int x, int y, int w, int h, String text) {
        if (text == null || text.isEmpty() || !over(x, y, w, h)) return;
        tipSeen = true;
        if (!java.util.Objects.equals(tipId, id)) { tipId = id; tipT = 0; }
        else tipT += dt;
        if (tipT > 0.45f) tipText = text;
    }

    /** Draws the pending tooltip (call last, outside any clip). */
    public void drawTooltip(int screenW, int screenH) {
        if (tipText == null) return;
        String[] lines = tipText.split("\n");
        int w = 0;
        for (String l : lines) w = Math.max(w, c.textWidth(l));
        int lh = c.lineHeight() + 2, bw = w + 12, bh = lines.length * lh + 8;
        int x = Math.min(mx + 12, screenW - bw - 4), y = my + 14;
        if (y + bh > screenH - 4) y = my - bh - 6;
        x = Math.max(4, x); y = Math.max(4, y);
        c.shadow(x, y, bw, bh, 3, 3, theme.shadow());
        c.roundBox(x, y, bw, bh, 3, Colors.withAlpha(theme.header(), 0xF2), theme.outline());
        for (int i = 0; i < lines.length; i++) c.text(lines[i], x + 6, y + 5 + i * lh, theme.text(), false);
    }

    // ------------------------------------------------------------------ small drawing widgets
    public int rowH() { return compact ? 20 : 24; }

    /** On/off switch, w = 24, h = 12. {@code t} is the animated state 0..1. */
    public void drawSwitch(int x, int y, float t, boolean enabledLook) {
        int off = theme.field(), on = theme.accent();
        int track = Colors.lerp(off, on, t);
        if (!enabledLook) track = Colors.lerp(track, theme.panel(), 0.5f);
        c.roundRect(x, y, 24, 12, 6, track);
        int kx = x + 6 + Math.round(12 * t);
        c.disc(kx, y + 6, 4, enabledLook ? Colors.lerp(theme.textDim(), 0xFFFFFFFF, t) : theme.textDim());
    }

    /** A flat button; returns true when it was clicked this frame. */
    public boolean button(Object id, int x, int y, int w, int h, String label, boolean primary, boolean danger) {
        WState s = st(id);
        boolean hov = over(x, y, w, h);
        s.hover = ease(s.hover, hov ? 1f : 0f, 18f);
        boolean down = hov && in.isDown(Input.LEFT);
        s.press = ease(s.press, down ? 1f : 0f, 30f);
        int base = danger ? Colors.lerp(theme.row(), theme.bad(), 0.30f)
                : primary ? theme.accent() : theme.row();
        int hoverCol = danger ? Colors.lerp(theme.row(), theme.bad(), 0.55f)
                : primary ? Colors.lighten(theme.accent(), 0.18f) : theme.rowHover();
        int fill = Colors.lerp(base, hoverCol, s.hover);
        fill = Colors.lerp(fill, Colors.darken(fill, 0.25f), s.press);
        c.roundRect(x, y, w, h, 3, fill);
        int tc = primary && !danger ? theme.onAccent() : theme.text();
        String fitted = c.fit(label, w - 8);
        c.centerText(fitted, x + w / 2, y + (h - c.lineHeight()) / 2 + 1, tc, false);
        return hov && in.wasPressed(Input.LEFT);
    }

    /** Draws a text box. When {@code focused} it shows the shared editor with caret and selection. */
    public void textBox(int x, int y, int w, int h, String shown, String placeholder, boolean focused) {
        textBox(x, y, w, h, shown, placeholder, focused, 0);
    }

    /** Same, with {@code leftPad} extra pixels reserved on the left (for an icon drawn by the caller). */
    public void textBox(int x, int y, int w, int h, String shown, String placeholder, boolean focused, int leftPad) {
        int bg = theme.field();
        c.roundBox(x, y, w, h, 3, bg, focused ? theme.accent() : theme.outline());
        int ty = y + (h - c.lineHeight()) / 2 + 1;
        int innerX = x + 5 + leftPad, innerW = w - 10 - leftPad;
        pushClip(innerX, y + 1, innerW, h - 2);
        if (focused) {
            String t = field.text();
            int caretPx = c.textWidth(t.substring(0, field.caret()));
            if (caretPx - field.scrollX > innerW - 2) field.scrollX = caretPx - innerW + 2;
            if (caretPx - field.scrollX < 0) field.scrollX = caretPx;
            if (c.textWidth(t) <= innerW) field.scrollX = 0;
            int ox = innerX - Math.round(field.scrollX);
            if (field.hasSelection()) {
                int a = c.textWidth(t.substring(0, field.selStart())), b = c.textWidth(t.substring(0, field.selEnd()));
                c.fill(ox + a, y + 3, b - a, h - 6, Colors.withAlpha(theme.accent(), 0x77));
            }
            c.text(t, ox, ty, theme.text(), false);
            boolean blink = field.idle < 0.5f || ((int) (timeMs / 530)) % 2 == 0;
            if (blink) c.fill(ox + caretPx, y + 3, 1, h - 6, theme.text());
        } else if (shown == null || shown.isEmpty()) {
            c.text(placeholder == null ? "" : placeholder, innerX, ty, Colors.withAlpha(theme.textDim(), 0xAA), false);
        } else {
            c.text(c.fit(shown, innerW), innerX, ty, theme.text(), false);
        }
        popClip();
    }

    /** Places the caret from a mouse click inside a text box drawn at x with the given scroll. */
    public int caretFromMouse(int boxX, int mouseX) {
        String t = field.text();
        int local = mouseX - (boxX + 5) + Math.round(field.scrollX);
        int best = 0, bestDist = Integer.MAX_VALUE;
        for (int i = 0; i <= t.length(); i++) {
            int d = Math.abs(c.textWidth(t.substring(0, i)) - local);
            if (d < bestDist) { bestDist = d; best = i; }
        }
        return best;
    }

    public void focusField(Object owner, String initial, int maxLen, java.util.function.IntPredicate accept, boolean selectAll) {
        focus = owner;
        listening = false;
        field.maxLen = maxLen;
        field.accept = accept == null ? com.reaper.client.core.util.Text::isPrintable : accept;
        field.setText(initial);
        if (selectAll) field.selectAll();
        field.scrollX = 0;
    }

    public void unfocus() { focus = null; listening = false; }

    /** Feeds this frame's typed characters and editing keys to the shared field. Returns 1 for Enter, 2 for Escape, else 0. */
    public int pumpField() {
        int result = 0; // 1 = Enter, 2 = Escape
        for (int i = 0; i < in.charCount(); i++) field.type(in.charAt(i));
        for (int i = 0; i < in.keyCount(); i++) {
            int k = in.keyAt(i), m = in.keyModsAt(i);
            if (k == com.reaper.client.core.setting.KeyNames.ENTER || k == com.reaper.client.core.setting.KeyNames.KP_ENTER) result = 1;
            else if (k == com.reaper.client.core.setting.KeyNames.ESCAPE) result = 2;
            else field.key(k, m, clipboard);
        }
        in.consumeKeys();
        return result;
    }

    public static float clamp01(float v) { return Anim.c01(v); }
}
