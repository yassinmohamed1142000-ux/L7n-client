package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.notify.NotificationCenter;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.ui.Canvas;
import com.reaper.client.core.util.Colors;

/** Draws the toasts of the {@link NotificationCenter}. Turning this module off silences notifications. */
public final class NotificationElement extends HudElement {
    private final Settings.Num duration = new Settings.Num("duration", "Duration", "How long a notification stays on screen.", 4, 1, 15, 0.5, " s");
    private final Settings.Num maxShown = new Settings.Num("maxShown", "At most", "How many notifications are visible at once.", 4, 1, NotificationCenter.MAX_VISIBLE, 1, "");

    private final String[] text = new String[NotificationCenter.MAX_VISIBLE];
    private final Level[] level = new Level[NotificationCenter.MAX_VISIBLE];
    private final float[] appear = new float[NotificationCenter.MAX_VISIBLE];
    private int rows;
    private int rowW;
    /** Toasts never get wider than this, however long the message; the text is shortened with "...". */
    static final int MAX_WIDTH = 200;

    public NotificationElement() {
        super("notifications", "Notifications", "Short messages like \"Profile loaded\" and low durability warnings.", true, "toast message alert popup", Anchor.TOP_CENTER, 0, 44, false);
        add(duration);
        add(maxShown);
        commonSettings();
    }

    private int rowH(Canvas c) { return c.lineHeight() + PAD * 2 + 1; }

    @Override protected boolean measure(HudContext x) {
        Canvas c = x.c;
        NotificationCenter nc = x.notifications;
        if (nc != null) nc.duration = duration.f();
        rows = 0;
        if (nc != null && nc.count() > 0) {
            int total = nc.count(), first = Math.max(0, total - maxShown.i());
            for (int i = first; i < total; i++) {
                NotificationCenter.Toast t = nc.get(i);
                text[rows] = c.fit(t.shown, MAX_WIDTH - PAD * 2 - 8);
                level[rows] = t.level;
                appear[rows] = t.appear();
                rows++;
            }
        } else if (x.editing) {
            text[0] = "Profile loaded: Default"; level[0] = Level.SUCCESS; appear[0] = 1f;
            text[1] = "Low durability: Iron Boots (7%)"; level[1] = Level.WARN; appear[1] = 1f;
            rows = 2;
        }
        if (rows == 0) return false;
        int widest = 110;
        for (int i = 0; i < rows; i++) widest = Math.max(widest, Math.min(MAX_WIDTH, c.textWidth(text[i]) + PAD * 2 + 8));
        rowW = widest;
        w = widest;
        h = rows * rowH(c) + (rows - 1) * 2;
        return true;
    }

    @Override protected void draw(HudContext x) {
        Canvas c = x.c;
        int rh = rowH(c);
        panel(x);
        for (int i = 0; i < rows; i++) {
            float a = appear[i];
            if (a <= 0.01f) continue;
            int y = i * (rh + 2) - Math.round((1f - a) * 6f);
            int accent = switch (level[i]) {
                case SUCCESS -> x.theme.good();
                case WARN -> x.theme.warn();
                case ERROR -> x.theme.bad();
                default -> x.theme.accent();
            };
            c.pushAlpha(a);
            c.shadow(0, y, rowW, rh, 3, 3, x.theme.shadow());
            c.roundRect(0, y, rowW, rh, 3, Colors.withAlpha(x.theme.panel(), 0xEE));
            c.roundRect(0, y + 2, 3, rh - 4, 1, accent);
            c.text(text[i], PAD + 6, y + PAD + 1, color.argb(), shadow.on());
            c.popAlpha();
        }
    }
}
