package com.reaper.client.core.feature;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.reaper.client.core.config.JsonIO;
import com.reaper.client.core.util.Log;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Waypoints for every world, kept in one {@code waypoints.json}. A "context" (a server address or a singleplayer
 * world name, chosen by the game layer) picks which list is current. Loading never throws; a damaged file just
 * means an empty list, and the previous good copy is used when there is one (see {@link JsonIO}).
 */
public final class WaypointStore {
    public static final int SCHEMA = 1, MAX_PER_WORLD = 200, MAX_WORLDS = 300, MAX_COORD = 30_000_000, MAX_Y = 100_000;
    public static final int MAX_KEY = 200, MAX_DIM = 100;

    private final Path file;
    private final Map<String, List<Waypoint>> worlds = new LinkedHashMap<>();
    private String context;
    private List<Waypoint> current = new ArrayList<>(0);
    private List<Waypoint> view = Collections.unmodifiableList(current);
    private boolean dirty;
    private final double[] scratch = new double[16];

    public WaypointStore(Path file) { this.file = file; }

    // ------------------------------------------------------------------ context
    /** Chooses the current world. Null clears it (nothing can be added then). */
    public void setContext(String key) {
        String k = key == null || key.isBlank() ? null : (key.length() > MAX_KEY ? key.substring(0, MAX_KEY) : key);
        context = k;
        rebind();
    }

    public String context() { return context; }

    private void rebind() {
        if (context == null) {
            current = new ArrayList<>(0);
        } else {
            List<Waypoint> l = worlds.get(context);
            if (l == null) {
                l = new ArrayList<>();
                // an empty list for a context is only remembered once something is added to it
                current = l;
            } else {
                current = l;
            }
        }
        view = Collections.unmodifiableList(current);
    }

    /** Waypoints of the current world, oldest first. Read-only, free to call every frame. */
    public List<Waypoint> list() { return view; }

    public int count() { return current.size(); }

    // ------------------------------------------------------------------ editing
    /** Adds a waypoint to the current world. Null when there is no world, the name is invalid or the list is full. */
    public Waypoint add(String name, int x, int y, int z, String dimension, int color) {
        String n = Waypoint.cleanName(name);
        if (n == null || context == null || current.size() >= MAX_PER_WORLD || dimension == null || dimension.isEmpty()) return null;
        if (!inRange(x, y, z)) return null;
        if (!worlds.containsKey(context)) {
            if (worlds.size() >= MAX_WORLDS) return null;
            worlds.put(context, current);
        }
        Waypoint w = new Waypoint(n, x, y, z, dimension.length() > MAX_DIM ? dimension.substring(0, MAX_DIM) : dimension, color);
        w.created = System.currentTimeMillis();
        current.add(w);
        dirty = true;
        return w;
    }

    /** Adds a death marker and forgets the oldest ones beyond {@code keep}. */
    public Waypoint addDeath(String label, int x, int y, int z, String dimension, int color, int keep) {
        Waypoint w = add(label, x, y, z, dimension, color);
        if (w == null) return null;
        w.death = true;
        int seen = 0;
        for (int i = current.size() - 1; i >= 0; i--) {
            Waypoint o = current.get(i);
            if (!o.death) continue;
            if (++seen > Math.max(1, keep)) { current.remove(i); }
        }
        return w;
    }

    public boolean remove(Waypoint w) {
        boolean r = current.remove(w);
        if (r) {
            dirty = true;
            if (current.isEmpty() && context != null) worlds.remove(context);
        }
        return r;
    }

    public boolean rename(Waypoint w, String name) {
        String n = Waypoint.cleanName(name);
        if (n == null || !current.contains(w)) return false;
        if (!n.equals(w.name)) { w.name = n; dirty = true; }
        return true;
    }

    public void setColor(Waypoint w, int argb) { int c = 0xFF000000 | argb; if (w.color != c) { w.color = c; dirty = true; } }

    public void setVisible(Waypoint w, boolean v) { if (w.visible != v) { w.visible = v; dirty = true; } }

    public void removeAllHere() {
        if (current.isEmpty()) return;
        current.clear();
        if (context != null) worlds.remove(context);
        dirty = true;
    }

    /** "Waypoint 1", "Waypoint 2" ... the first free one. */
    public String uniqueName(String base) {
        String b = base == null || base.isBlank() ? "Waypoint" : base;
        for (int i = 1; i < 10_000; i++) {
            String n = b + " " + i;
            boolean taken = false;
            for (int k = 0; k < current.size(); k++) if (current.get(k).name.equalsIgnoreCase(n)) { taken = true; break; }
            if (!taken) return n;
        }
        return b;
    }

    // ------------------------------------------------------------------ queries
    /**
     * Fills {@code out} with the visible waypoints of a dimension that are closest to (px, pz), nearest first, and
     * returns how many. Allocation free, at most 16.
     */
    public int nearest(String dimension, double px, double pz, Waypoint[] out) { return nearest(dimension, px, pz, out, out.length); }

    /** Same, but only the {@code max} nearest. */
    public int nearest(String dimension, double px, double pz, Waypoint[] out, int max) {
        int cap = Math.min(Math.min(out.length, scratch.length), Math.max(0, max)), n = 0;
        if (cap == 0) return 0;
        for (int i = 0; i < current.size(); i++) {
            Waypoint w = current.get(i);
            if (!w.visible || !w.dimension.equals(dimension)) continue;
            double dx = w.x + 0.5 - px, dz = w.z + 0.5 - pz, d = dx * dx + dz * dz;
            if (n == cap && d >= scratch[n - 1]) continue;
            int k = n < cap ? n++ : n - 1;
            while (k > 0 && scratch[k - 1] > d) { out[k] = out[k - 1]; scratch[k] = scratch[k - 1]; k--; }
            out[k] = w;
            scratch[k] = d;
        }
        return n;
    }

    private static boolean inRange(int x, int y, int z) {
        return Math.abs(x) <= MAX_COORD && Math.abs(z) <= MAX_COORD && Math.abs(y) <= MAX_Y;
    }

    // ------------------------------------------------------------------ persistence
    public boolean isDirty() { return dirty; }

    public void load() {
        worlds.clear();
        dirty = false;
        JsonObject root = JsonIO.readObject(file);
        if (root != null) {
            JsonElement ws = root.get("worlds");
            if (ws != null && ws.isJsonObject()) {
                for (Map.Entry<String, JsonElement> e : ws.getAsJsonObject().entrySet()) {
                    if (worlds.size() >= MAX_WORLDS) break;
                    if (e.getKey().isEmpty() || e.getKey().length() > MAX_KEY || !e.getValue().isJsonArray()) continue;
                    List<Waypoint> l = new ArrayList<>();
                    for (JsonElement el : e.getValue().getAsJsonArray()) {
                        if (l.size() >= MAX_PER_WORLD) break;
                        Waypoint w = parse(el);
                        if (w != null) l.add(w);
                    }
                    if (!l.isEmpty()) worlds.put(e.getKey(), l);
                }
            }
        }
        rebind();
    }

    /** Writes the file when something changed. Returns true when the file is up to date afterwards. */
    public boolean save() {
        if (!dirty) return true;
        JsonObject root = new JsonObject();
        root.addProperty("schema", SCHEMA);
        JsonObject ws = new JsonObject();
        for (Map.Entry<String, List<Waypoint>> e : worlds.entrySet()) {
            if (e.getValue().isEmpty()) continue;
            JsonArray arr = new JsonArray();
            for (Waypoint w : e.getValue()) arr.add(toJson(w));
            ws.add(e.getKey(), arr);
        }
        root.add("worlds", ws);
        if (JsonIO.writeAtomic(file, root)) { dirty = false; return true; }
        Log.warn("Waypoints could not be saved");
        return false;
    }

    private static JsonObject toJson(Waypoint w) {
        JsonObject o = new JsonObject();
        o.addProperty("name", w.name);
        o.addProperty("x", w.x);
        o.addProperty("y", w.y);
        o.addProperty("z", w.z);
        o.addProperty("dim", w.dimension);
        o.addProperty("color", w.color & 0xFFFFFF);
        if (!w.visible) o.addProperty("visible", false);
        if (w.death) o.addProperty("death", true);
        o.addProperty("created", w.created);
        return o;
    }

    private static Waypoint parse(JsonElement el) {
        if (el == null || !el.isJsonObject()) return null;
        JsonObject o = el.getAsJsonObject();
        String name = Waypoint.cleanName(str(o, "name"));
        Integer x = integer(o, "x"), y = integer(o, "y"), z = integer(o, "z");
        String dim = str(o, "dim");
        if (name == null || x == null || y == null || z == null || !inRange(x, y, z)) return null;
        if (dim == null || dim.isEmpty()) dim = "minecraft:overworld";
        if (dim.length() > MAX_DIM) return null;
        Integer color = integer(o, "color");
        Waypoint w = new Waypoint(name, x, y, z, dim, color == null ? 0x4ADE80 : color);
        JsonElement v = o.get("visible"), d = o.get("death"), c = o.get("created");
        if (v instanceof JsonPrimitive p && p.isBoolean()) w.visible = p.getAsBoolean();
        if (d instanceof JsonPrimitive p && p.isBoolean()) w.death = p.getAsBoolean();
        if (c instanceof JsonPrimitive p && p.isNumber()) w.created = p.getAsLong();
        return w;
    }

    private static String str(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e instanceof JsonPrimitive p && p.isString() ? p.getAsString() : null;
    }

    private static Integer integer(JsonObject o, String k) {
        JsonElement e = o.get(k);
        if (!(e instanceof JsonPrimitive p) || !p.isNumber()) return null;
        double d = p.getAsDouble();
        if (Double.isNaN(d) || Math.abs(d) > Integer.MAX_VALUE) return null;
        return (int) d;
    }
}
