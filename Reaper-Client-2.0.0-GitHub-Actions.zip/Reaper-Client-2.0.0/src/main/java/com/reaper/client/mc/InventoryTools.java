package com.reaper.client.mc;

import com.reaper.client.core.ReaperCore;
import com.reaper.client.core.inventory.SortLayout;
import com.reaper.client.core.notify.Level;
import com.reaper.client.mixin.AbstractContainerScreenAccessor;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.ShulkerBoxScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * The buttons Reaper adds to vanilla screens (a Sort button in inventory and chest screens, a "Reaper" button on the pause
 * screen) and the executor that carries out a sort. A sort is a list of ordinary pick-up clicks, sent a few per tick
 * through the same call the game's own mouse handling uses; nothing here sends anything a player could not do by hand.
 */
final class InventoryTools {
    private static final int BUTTON_H = 12;

    private final ReaperCore core;
    private final Minecraft mc = Minecraft.getInstance();
    private final int[] clicks = new int[4];

    // the sort in progress, if any
    private AbstractContainerScreen<?> sortScreen;
    private int[] sortBlock;

    InventoryTools(ReaperCore core) {
        this.core = core;
    }

    void register() {
        ScreenEvents.AFTER_INIT.register(this::afterInit);
    }

    // ------------------------------------------------------------------ buttons
    private void afterInit(Minecraft client, Screen screen, int scaledWidth, int scaledHeight) {
        try {
            if (screen instanceof PauseScreen) addMenuButton(screen);
            else if (screen instanceof AbstractContainerScreen<?> container) addSortButtons(container);
        } catch (Throwable t) {
            Game.logError("Could not add Reaper buttons to " + screen.getClass().getSimpleName(), t);
        }
    }

    private void addMenuButton(Screen screen) {
        Button button = Button.builder(Component.literal("Reaper"), b -> Game.openGui()).bounds(6, 6, 52, 20).build();
        Screens.getWidgets(screen).add(button);
    }

    private void addSortButtons(AbstractContainerScreen<?> screen) {
        boolean chest = screen instanceof ContainerScreen || screen instanceof ShulkerBoxScreen;
        if (!chest && !(screen instanceof InventoryScreen)) return;

        List<Sized> buttons = new ArrayList<>(2);
        buttons.add(new Sized(Button.builder(Component.literal(chest ? "Sort chest" : "Sort"), b -> startSort(screen, chest, false))
                .bounds(0, 0, chest ? 56 : 36, BUTTON_H).build(), chest ? 56 : 36));
        if (chest) {
            buttons.add(new Sized(Button.builder(Component.literal("Sort bag"), b -> startSort(screen, true, true))
                    .bounds(0, 0, 46, BUTTON_H).build(), 46));
        }
        var widgets = Screens.getWidgets(screen);
        for (Sized s : buttons) widgets.add(s.button());
        place(screen, buttons);
        ScreenEvents.afterTick(screen).register(s -> place(screen, buttons));   // the recipe book can move the screen
    }

    private record Sized(Button button, int width) { }

    /** Puts the buttons in the free strip above the screen's picture, right-aligned, and shows or hides them. */
    private void place(AbstractContainerScreen<?> screen, List<Sized> buttons) {
        AbstractContainerScreenAccessor a = (AbstractContainerScreenAccessor) screen;
        boolean show = core.sorter.showButtons();
        int y = Math.max(2, a.reaper$topPos() - BUTTON_H - 2);
        int x = a.reaper$leftPos() + a.reaper$imageWidth();
        for (int i = buttons.size() - 1; i >= 0; i--) {
            Sized s = buttons.get(i);
            x -= s.width();
            s.button().setX(x);
            s.button().setY(y);
            s.button().visible = show;
            s.button().active = show && !core.sorter.running();
            x -= 2;
        }
    }

    // ------------------------------------------------------------------ sorting
    private void startSort(AbstractContainerScreen<?> screen, boolean chestScreen, boolean playerPart) {
        try {
            if (core.sorter.running()) return;
            var menu = screen.getMenu();
            var slots = menu.slots;
            if (!menu.getCarried().isEmpty()) {
                core.toast(Level.WARN, "Put down the item you are holding first.");
                return;
            }
            boolean hotbar = core.sorter.hotbar.on();
            int[] block;
            if (!chestScreen) {
                block = SortLayout.inventoryScreen(hotbar);
            } else {
                int rows = screen instanceof ContainerScreen c ? c.getMenu().getRowCount() : 3;
                block = playerPart ? SortLayout.playerInContainer(rows, hotbar) : SortLayout.container(rows);
            }
            if (!SortLayout.fits(block, slots.size())) {
                core.toast(Level.WARN, "This screen has a layout the sorter does not know.");
                return;
            }

            int n = block.length;
            String[] key = new String[n];
            int[] count = new int[n], max = new int[n];
            List<ItemStack> kinds = new ArrayList<>();   // one stack per distinct item-with-components
            for (int i = 0; i < n; i++) {
                ItemStack stack = slots.get(block[i]).getItem();
                if (stack.isEmpty()) {
                    count[i] = 0;
                    max[i] = 1;
                    continue;
                }
                int kind = -1;
                for (int k = 0; k < kinds.size(); k++) {
                    if (ItemStack.isSameItemSameComponents(kinds.get(k), stack)) { kind = k; break; }
                }
                if (kind < 0) { kinds.add(stack); kind = kinds.size() - 1; }
                key[i] = BuiltInRegistries.ITEM.getKey(stack.getItem()) + "#" + kind;
                count[i] = stack.getCount();
                max[i] = Math.max(1, stack.getMaxStackSize());
            }

            int total = core.sorter.begin(key, count, max);
            if (total < 0) core.toast(Level.WARN, "Sorting is off under this server's rules.");
            else if (total == 0) core.toast(Level.INFO, "Already tidy.");
            else {
                sortScreen = screen;
                sortBlock = block;
                core.toast(Level.INFO, "Sorting " + total + " clicks. Please do not click in the meantime.");
            }
        } catch (Throwable t) {
            core.sorter.cancel();
            Game.logError("Sorting failed to start", t);
            core.toast(Level.ERROR, "Sorting could not start.");
        }
    }

    /** Once per client tick: makes the next few clicks of a running sort. */
    void tick() {
        if (!core.sorter.running()) {
            if (sortScreen != null) finish();
            return;
        }
        try {
            if (mc.screen != sortScreen || mc.player == null || mc.gameMode == null) {
                core.sorter.cancel();
                core.toast(Level.WARN, "Sorting stopped: the screen was closed.");
                sortScreen = null;
                return;
            }
            var menu = sortScreen.getMenu();
            int n = core.sorter.next(clicks);
            for (int i = 0; i < n; i++) {
                int position = clicks[i];
                if (position < 0 || position >= sortBlock.length) { core.sorter.cancel(); break; }
                mc.gameMode.handleContainerInput(menu.containerId, sortBlock[position], 0, ContainerInput.PICKUP, mc.player);
            }
            if (!core.sorter.running()) finish();
        } catch (Throwable t) {
            core.sorter.cancel();
            Game.logError("Sorting stopped after an error", t);
            core.toast(Level.ERROR, "Sorting stopped after an error.");
            sortScreen = null;
        }
    }

    private void finish() {
        AbstractContainerScreen<?> screen = sortScreen;
        sortScreen = null;
        sortBlock = null;
        if (screen == null) return;
        if (mc.screen == screen && !screen.getMenu().getCarried().isEmpty()) {
            core.toast(Level.WARN, "Sorted, but an item is still on the cursor. Put it down.");
        } else if (mc.screen == screen) {
            core.toast(Level.SUCCESS, "Sorted.");
        }
    }

    /** True while clicks are being made. */
    boolean busy() { return core.sorter.running(); }
}
