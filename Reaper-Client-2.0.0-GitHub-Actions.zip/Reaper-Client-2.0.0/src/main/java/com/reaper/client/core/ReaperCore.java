package com.reaper.client.core;

import com.reaper.client.core.config.ClientConfig;
import com.reaper.client.core.config.ProfileStore;
import com.reaper.client.core.config.SaveScheduler;
import com.reaper.client.core.feature.AutomationModule;
import com.reaper.client.core.feature.ChatToolsModule;
import com.reaper.client.core.feature.CrosshairModule;
import com.reaper.client.core.feature.FullbrightModule;
import com.reaper.client.core.feature.ScreenshotLibrary;
import com.reaper.client.core.feature.SorterModule;
import com.reaper.client.core.feature.WaypointStore;
import com.reaper.client.core.feature.WaypointsModule;
import com.reaper.client.core.feature.ZoomModule;
import com.reaper.client.core.hud.Hud;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.hud.HudEditor;
import com.reaper.client.core.hud.HudElement;
import com.reaper.client.core.hud.elements.HudElements;
import com.reaper.client.core.hud.elements.WaypointsElement;
import com.reaper.client.core.module.ModuleRegistry;
import com.reaper.client.core.notify.Level;
import com.reaper.client.core.policy.ServerPolicy;
import com.reaper.client.core.theme.Theme;
import com.reaper.client.core.ui.ClickGui;
import com.reaper.client.core.ui.GuiHost;
import com.reaper.client.core.ui.InterfaceModule;
import com.reaper.client.core.ui.WaypointsPanel;
import com.reaper.client.core.util.Log;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.LongSupplier;

/**
 * Everything Reaper is, without a single Minecraft type: the modules, the HUD, the GUI, the settings and profiles on
 * disk and the server rules. The game layer (package {@code mc}) creates one of these, feeds {@link #data} every
 * frame and forwards input and events. Because nothing here touches the game, all of it is covered by the plain-JDK
 * tests.
 */
public final class ReaperCore implements GuiHost, HudEditor.Host {
    /** What only the game layer can do. */
    public interface Platform {
        void openHudEditor();
        void closeHudEditor();
        void openScreenshots();
        void closeGui();
        /** Clears the chat window ("Clear chat history" button). */
        void clearChat();
        /** The logo texture handle (opaque to the core) and its pixel size, or null. */
        default Object logo() { return null; }
        default int logoW() { return 0; }
        default int logoH() { return 0; }
    }

    public static final long SAVE_QUIET_MS = 1500, SAVE_MAX_MS = 10_000;

    public final Path dir;
    public final HudData data = new HudData();
    public final ModuleRegistry modules = new ModuleRegistry();
    public final ServerPolicy policy = new ServerPolicy();
    public final ClientConfig config;
    public final ProfileStore profiles;
    public final WaypointStore waypointStore;
    public final ScreenshotLibrary screenshots;
    public final Hud hud;

    public final InterfaceModule iface = new InterfaceModule();
    public final CrosshairModule crosshair = new CrosshairModule();
    public final ZoomModule zoom = new ZoomModule();
    public final FullbrightModule fullbright = new FullbrightModule();
    public final WaypointsModule waypoints;
    public final SorterModule sorter = new SorterModule();
    public final ChatToolsModule chat = new ChatToolsModule();
    public final AutomationModule automation = new AutomationModule();

    public final ClickGui gui;
    public final HudEditor hudEditor;

    private final LongSupplier clock;
    private final SaveScheduler saver;
    private Platform platform = new Platform() {
        @Override public void openHudEditor() { }
        @Override public void closeHudEditor() { }
        @Override public void openScreenshots() { }
        @Override public void closeGui() { }
        @Override public void clearChat() { }
    };
    private boolean flushing;
    private boolean waypointsWereDirty;

    /**
     * @param dir            the folder for client.json, profiles/ and waypoints.json (created if missing)
     * @param screenshotsDir the game's screenshots folder
     * @param clock          milliseconds, normally {@code System::currentTimeMillis}; a fake in tests
     */
    public ReaperCore(Path dir, Path screenshotsDir, LongSupplier clock) {
        this.dir = dir;
        this.clock = clock;
        try {
            Files.createDirectories(dir);
        } catch (IOException ex) {
            Log.warn("Could not create the settings folder " + dir, ex);
        }
        screenshots = new ScreenshotLibrary(screenshotsDir);
        waypointStore = new WaypointStore(dir.resolve("waypoints.json"));
        waypoints = new WaypointsModule(waypointStore, data);
        hud = new Hud(modules);

        // Registration order is the display order inside each window of the GUI.
        for (HudElement e : HudElements.create()) {
            modules.register(e);
            hud.add(e);
        }
        WaypointsElement waypointList = new WaypointsElement(waypoints);
        modules.register(waypointList);
        hud.add(waypointList);
        modules.register(crosshair);
        modules.register(zoom);
        modules.register(fullbright);
        modules.register(waypoints);
        modules.register(sorter);
        modules.register(chat);
        modules.register(automation);
        modules.register(iface);
        modules.setPolicyGate(policy::allows);
        HudElement notifications = (HudElement) modules.get("notifications");
        hud.notifications.setGate(notifications::isEnabled);

        config = new ClientConfig(dir);
        config.load();
        policy.fromJson(config.serverRules);
        profiles = new ProfileStore(dir, modules);
        profiles.load(ProfileStore.validName(config.activeProfile) ? config.activeProfile : ProfileStore.DEFAULT_NAME);
        waypointStore.load();

        automation.setFeedback(this::toast);
        chat.setClearAction(() -> platform.clearChat());
        saver = new SaveScheduler(this::saveNow, SAVE_QUIET_MS, SAVE_MAX_MS);

        gui = new ClickGui(modules, iface, profiles, policy, this);
        gui.addWindow(new WaypointsPanel(waypoints, this).window());
        gui.layoutFromJson(config.windows);
        hudEditor = new HudEditor(hud, this);
    }

    public void setPlatform(Platform p) { if (p != null) platform = p; }

    /** The colours in force (theme and accent chosen in the Interface settings). */
    public Theme theme() { return iface.resolve(); }

    public long now() { return clock.getAsLong(); }

    // ------------------------------------------------------------------ GuiHost / HudEditor.Host
    @Override public void toast(Level level, String message) { hud.notifications.push(level, message); }
    @Override public void requestSave() { saver.markDirty(clock.getAsLong()); }
    @Override public void openHudEditor() { platform.openHudEditor(); }
    @Override public void openScreenshots() { platform.openScreenshots(); }
    @Override public void closeGui() { platform.closeGui(); }
    @Override public void close() { platform.closeHudEditor(); }
    @Override public Object logo() { return platform.logo(); }
    @Override public int logoW() { return platform.logoW(); }
    @Override public int logoH() { return platform.logoH(); }

    // ------------------------------------------------------------------ time
    /** Once per client tick (20 times a second). Cheap when nothing changed. */
    public void tick() {
        long now = clock.getAsLong();
        boolean dirtyNow = waypointStore.isDirty();
        if (dirtyNow && !waypointsWereDirty) saver.markDirty(now);   // once per change, so the quiet period can run out
        waypointsWereDirty = dirtyNow;
        saver.tick(now);
        if (automation.tick()) toast(Level.INFO, "Automation stopped: it is no longer allowed here.");
    }

    // ------------------------------------------------------------------ world
    /**
     * The player joined a world or server. {@code worldKey} names the world for waypoints (for example the server
     * address, or "sp:" plus the world's folder name); it must not be null for waypoints to work.
     */
    public void enterWorld(ServerPolicy.Context context, String worldKey) {
        policy.setContext(context);
        waypointStore.setContext(worldKey);
        zoom.reset();
        sorter.cancel();
    }

    public void leaveWorld() {
        policy.setContext(ServerPolicy.Context.NONE);
        waypointStore.setContext(null);
        zoom.reset();
        sorter.cancel();
        flush();
    }

    // ------------------------------------------------------------------ saving
    private void saveNow() {
        try {
            profiles.saveActive();
            config.activeProfile = profiles.active();
            config.windows = gui.layoutToJson();
            config.serverRules = policy.toJson();
            config.save();
            if (waypointStore.isDirty()) waypointStore.save();
        } catch (RuntimeException ex) {
            Log.warn("Saving the settings failed", ex);
        }
    }

    /** Writes everything now (shutdown, leaving a world). */
    public void flush() {
        if (flushing) return;
        flushing = true;
        try {
            saver.markDirty(clock.getAsLong());
            saver.flush();
        } finally {
            flushing = false;
        }
    }

    // ------------------------------------------------------------------ Fullbright and the player's own brightness
    /**
     * The brightness the game had before a previous run changed it and then ended without restoring it (a crash),
     * or NaN. Returns it once and forgets it.
     */
    public double takeCrashedGamma() {
        double g = config.restoreGamma;
        if (Double.isNaN(g)) return Double.NaN;
        config.restoreGamma = Double.NaN;
        config.save();
        return g;
    }

    /**
     * One tick of Fullbright. Returns the value to write into the game's brightness option, or NaN for no change.
     * The player's own brightness is written to disk the moment Fullbright takes over, so even a crash cannot lose it.
     */
    public double fullbrightTick(double currentGamma) {
        boolean was = fullbright.gamma.applied();
        double out = fullbright.tick(currentGamma);
        boolean is = fullbright.gamma.applied();
        if (!was && is) {
            config.restoreGamma = fullbright.gamma.saved();
            config.save();
        } else if (was && !is) {
            config.restoreGamma = Double.NaN;
            config.save();
        } else if (is && Double.compare(config.restoreGamma, fullbright.gamma.saved()) != 0) {
            config.restoreGamma = fullbright.gamma.saved();      // the player moved the brightness slider meanwhile
            requestSave();
        }
        return out;
    }

    /** Leaving the game or the world: the value to put back, or NaN. */
    public double fullbrightRestore() {
        double back = fullbright.gamma.restore();
        if (!Double.isNaN(config.restoreGamma)) {
            config.restoreGamma = Double.NaN;
            config.save();
        }
        return back;
    }
}
