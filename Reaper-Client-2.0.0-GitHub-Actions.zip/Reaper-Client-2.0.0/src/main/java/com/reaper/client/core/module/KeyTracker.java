package com.reaper.client.core.module;

import com.reaper.client.core.setting.Settings;

import java.util.function.IntPredicate;

/**
 * Turns "is key X down right now" polling into module toggles. Edge detection lives here (not in the game layer)
 * so it can be tested. Call {@link #update} once per client tick while no screen is open.
 */
public final class KeyTracker {
    private final ModuleRegistry registry;
    /** Last observed state per module, indexed like registry.all(). */
    private boolean[] wasDown = new boolean[0];

    public KeyTracker(ModuleRegistry registry) { this.registry = registry; }

    /** Forget key state, e.g. when a screen opened and polling paused. Prevents phantom presses afterwards. */
    public void reset() { java.util.Arrays.fill(wasDown, false); }

    public void update(IntPredicate isDown) {
        var mods = registry.all();
        if (wasDown.length != mods.size()) wasDown = new boolean[mods.size()];
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            Settings.Key k = m.bind;
            if (!m.toggleable || !k.bound()) { wasDown[i] = false; continue; }
            boolean down = isDown.test(k.code());
            boolean prev = wasDown[i];
            wasDown[i] = down;
            if (m.bindMode.v() == Module.KeyMode.HOLD) {
                if (down != m.isEnabled()) m.setEnabled(down);
            } else if (down && !prev) {
                m.toggle();
            }
        }
    }

    /** True when {@code key} is already used by another module (used to warn in the GUI). */
    public static Module owner(ModuleRegistry r, int key, Module except) {
        if (key < 0) return null;
        for (Module m : r.all()) if (m != except && m.toggleable && m.bind.code() == key) return m;
        return null;
    }
}
