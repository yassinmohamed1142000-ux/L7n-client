package com.reaper.client.mc;

import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.ui.Input;
import com.reaper.client.core.util.FrameClock;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/**
 * Base of Reaper's own screens. All three (menu, HUD editor, screenshot manager) are drawn by the core through a
 * {@link McCanvas}; this class only turns the game's input events into the core's {@link Input}, draws one frame at a
 * time and keeps a failing frame from taking the game down.
 */
abstract class ReaperScreen extends Screen {
    private final FrameClock clock = new FrameClock();

    protected ReaperScreen(String title) {
        super(Component.literal(title));
    }

    /** Where this screen's events go. */
    protected abstract Input in();

    /** Draws one frame. {@code dt} is in seconds. */
    protected abstract void draw(McCanvas c, int mouseX, int mouseY, float dt);

    /** Escape was pressed. */
    protected abstract void escape();

    /** The screen is going away: release anything it holds. */
    protected void closed() { }

    /** Called for every key press before it is passed on; return true to keep it from the core. */
    protected boolean intercept(int key) { return false; }

    // ------------------------------------------------------------------ drawing
    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTicks) {
        clock.frame(System.nanoTime());
        McCanvas c = Game.canvas();
        c.begin(extractor);
        try {
            draw(c, mouseX, mouseY, clock.dt());
            Game.screenOk();
        } catch (Throwable t) {
            Game.screenFailed(getClass().getSimpleName(), t);
        } finally {
            c.end();
        }
    }

    /** The core draws its own backdrop, so the game's blur and dimming are left out. */
    @Override
    public void extractBackground(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float deltaTicks) {
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void removed() {
        try {
            closed();
        } catch (Throwable t) {
            Game.screenFailed(getClass().getSimpleName(), t);
        }
        super.removed();
    }

    // ------------------------------------------------------------------ input
    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == KeyNames.ESCAPE) {
            escape();
            return true;
        }
        if (intercept(key)) return true;
        int mods = (event.hasShiftDown() ? Input.MOD_SHIFT : 0) | (event.hasControlDown() ? Input.MOD_CTRL : 0);
        in().key(key, mods);
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        in().character(event.codepoint());
        return true;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        in().mouseDown(event.button(), event.x(), event.y());
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        in().mouseUp(event.button(), event.x(), event.y());
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        in().mouseMove(event.x(), event.y());
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        in().scroll(verticalAmount);
        return true;
    }
}
