package com.reaper.client.core.ui;

import com.reaper.client.core.setting.KeyNames;
import com.reaper.client.core.util.Text;

import java.util.function.IntPredicate;

/**
 * Single-line text editing model: caret, selection, clipboard shortcuts. No rendering and no Minecraft types,
 * so it is fully unit-testable. The GUI draws it through {@link Ui#textBox}.
 */
public final class TextField {
    /** Where copy/paste go. The game layer supplies the real clipboard. */
    public interface Clipboard { String get(); void set(String s); }

    private final StringBuilder sb = new StringBuilder();
    private int caret, anchor;
    public int maxLen = 64;
    public IntPredicate accept = Text::isPrintable;
    /** Horizontal scroll in pixels, maintained by the renderer. */
    public float scrollX;
    /** Seconds since the last edit; the caret is steady while typing. */
    public float idle;

    public String text() { return sb.toString(); }
    public int length() { return sb.length(); }
    public int caret() { return caret; }
    public boolean hasSelection() { return caret != anchor; }
    public int selStart() { return Math.min(caret, anchor); }
    public int selEnd() { return Math.max(caret, anchor); }

    public void setText(String s) {
        sb.setLength(0);
        if (s != null) sb.append(s, 0, Math.min(s.length(), maxLen));
        caret = anchor = sb.length();
        idle = 0;
    }

    public void clear() { setText(""); }

    public void selectAll() { anchor = 0; caret = sb.length(); }

    public void setCaret(int pos, boolean keepSelection) {
        caret = Math.max(0, Math.min(sb.length(), pos));
        if (caret > 0 && caret < sb.length() && Character.isLowSurrogate(sb.charAt(caret)) && Character.isHighSurrogate(sb.charAt(caret - 1))) caret--;
        if (!keepSelection) anchor = caret;
        idle = 0;
    }

    /** Index of the character before {@code i}, treating a surrogate pair as one character. */
    private int prev(int i) {
        if (i <= 0) return 0;
        return i > 1 && Character.isLowSurrogate(sb.charAt(i - 1)) && Character.isHighSurrogate(sb.charAt(i - 2)) ? i - 2 : i - 1;
    }

    /** Index after the character at {@code i}, treating a surrogate pair as one character. */
    private int next(int i) {
        int n = sb.length();
        if (i >= n) return n;
        return i + 1 < n && Character.isHighSurrogate(sb.charAt(i)) && Character.isLowSurrogate(sb.charAt(i + 1)) ? i + 2 : i + 1;
    }

    public String selectedText() { return hasSelection() ? sb.substring(selStart(), selEnd()) : ""; }

    private void deleteSelection() {
        if (!hasSelection()) return;
        int s = selStart(), e = selEnd();
        sb.delete(s, e);
        caret = anchor = s;
    }

    /** Typed character. Returns true when accepted. */
    public boolean type(int codepoint) {
        if (accept != null && !accept.test(codepoint)) return false;
        int len = Character.charCount(codepoint);
        int selLen = selEnd() - selStart();
        if (sb.length() - selLen + len > maxLen) return false;
        deleteSelection();
        sb.insert(caret, Character.toChars(codepoint));
        caret += len;
        anchor = caret;
        idle = 0;
        return true;
    }

    public void paste(String s) {
        if (s == null) return;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (cp == '\n' || cp == '\r' || cp == '\t') cp = ' ';
            type(cp);
        }
    }

    /**
     * Handles an editing key. Returns true when the key was consumed. Enter/Escape/Tab are NOT handled here: the
     * owner decides what committing and cancelling mean.
     */
    public boolean key(int key, int mods, Clipboard cb) {
        boolean shift = (mods & Input.MOD_SHIFT) != 0, ctrl = (mods & Input.MOD_CTRL) != 0;
        idle = 0;
        switch (key) {
            case KeyNames.LEFT -> { move(ctrl ? wordLeft() : (hasSelection() && !shift ? selStart() : prev(caret)), shift); return true; }
            case KeyNames.RIGHT -> { move(ctrl ? wordRight() : (hasSelection() && !shift ? selEnd() : next(caret)), shift); return true; }
            case KeyNames.HOME -> { move(0, shift); return true; }
            case KeyNames.END -> { move(sb.length(), shift); return true; }
            case KeyNames.BACKSPACE -> {
                if (hasSelection()) deleteSelection();
                else if (caret > 0) { int from = ctrl ? wordLeft() : prev(caret); sb.delete(from, caret); caret = anchor = from; }
                return true;
            }
            case KeyNames.DELETE -> {
                if (hasSelection()) deleteSelection();
                else if (caret < sb.length()) { int to = ctrl ? wordRight() : next(caret); sb.delete(caret, to); anchor = caret; }
                return true;
            }
            default -> { /* shortcuts below */ }
        }
        if (ctrl) {
            switch (key) {
                case KeyNames.A -> { selectAll(); return true; }
                case KeyNames.C -> { if (cb != null && hasSelection()) cb.set(selectedText()); return true; }
                case KeyNames.X -> { if (cb != null && hasSelection()) { cb.set(selectedText()); deleteSelection(); } return true; }
                case KeyNames.V -> { if (cb != null) paste(cb.get()); return true; }
                default -> { return false; }
            }
        }
        return false;
    }

    private void move(int to, boolean keepSelection) { setCaret(to, keepSelection); }

    private int wordLeft() {
        int i = caret;
        while (i > 0 && sb.charAt(i - 1) == ' ') i--;
        while (i > 0 && sb.charAt(i - 1) != ' ') i--;
        return i;
    }

    private int wordRight() {
        int i = caret, n = sb.length();
        while (i < n && sb.charAt(i) == ' ') i++;
        while (i < n && sb.charAt(i) != ' ') i++;
        return i;
    }
}
