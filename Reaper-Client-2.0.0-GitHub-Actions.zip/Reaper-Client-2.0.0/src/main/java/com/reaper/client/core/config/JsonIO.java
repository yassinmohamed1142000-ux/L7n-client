package com.reaper.client.core.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.reaper.client.core.util.Log;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Config file reading and writing.
 * <ul>
 *   <li>Writes go to {@code name.tmp} first and are moved into place, so a crash can never leave half a file.</li>
 *   <li>The previous good file is kept as {@code name.bak}; a corrupt main file falls back to it.</li>
 *   <li>Reads never throw: they return {@code null} and log, and the caller uses defaults.</li>
 * </ul>
 */
public final class JsonIO {
    private JsonIO() {}

    private static final Gson PRETTY = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Gson COMPACT = new GsonBuilder().disableHtmlEscaping().create();
    /** Refuse to parse absurdly large files (a corrupt or malicious import). */
    public static final long MAX_BYTES = 1_000_000;

    public static String pretty(JsonElement e) { return PRETTY.toJson(e); }
    public static String compact(JsonElement e) { return COMPACT.toJson(e); }

    /** Parses a JSON object from text; null when it is not a valid JSON object. */
    public static JsonObject parseObject(String text) {
        if (text == null || text.length() > MAX_BYTES) return null;
        try {
            JsonElement e = com.google.gson.JsonParser.parseString(text);
            return e != null && e.isJsonObject() ? e.getAsJsonObject() : null;
        } catch (RuntimeException ex) {
            return null;
        }
    }

    public static JsonObject readObject(Path file) {
        JsonObject o = readOne(file);
        if (o != null) return o;
        Path bak = backupOf(file);
        if (Files.exists(file)) Log.warn("Config " + file.getFileName() + " is unreadable, trying the backup");
        return Files.exists(bak) ? readOne(bak) : null;
    }

    private static JsonObject readOne(Path file) {
        try {
            if (!Files.isRegularFile(file) || Files.size(file) > MAX_BYTES) return null;
            return parseObject(Files.readString(file, StandardCharsets.UTF_8));
        } catch (IOException | RuntimeException ex) {
            Log.warn("Could not read " + file.getFileName(), ex);
            return null;
        }
    }

    public static Path backupOf(Path file) { return file.resolveSibling(file.getFileName() + ".bak"); }

    /** Atomically replaces {@code file}. Returns false (and logs) instead of throwing. */
    public static boolean writeAtomic(Path file, JsonElement content) {
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            Path dir = file.toAbsolutePath().getParent();
            if (dir != null) Files.createDirectories(dir);
            Files.writeString(tmp, pretty(content), StandardCharsets.UTF_8);
            if (Files.isRegularFile(file)) {
                try { Files.copy(file, backupOf(file), StandardCopyOption.REPLACE_EXISTING); }
                catch (IOException ex) { Log.warn("Could not refresh backup of " + file.getFileName(), ex); }
            }
            try {
                Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException | RuntimeException ex) {
            Log.warn("Could not save " + file.getFileName(), ex);
            try { Files.deleteIfExists(tmp); } catch (IOException ignored) { /* best effort */ }
            return false;
        }
    }
}
