package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudElement;

/**
 * An element made of a few lines of text. The subclass keeps {@link #lines} between frames and only rewrites a
 * line when its content changed, so a steady HUD allocates nothing.
 */
public abstract class LinesElement extends HudElement {
    public static final int MAX_LINES = 8;
    protected final String[] lines = new String[MAX_LINES];
    protected final int[] lineArgb = new int[MAX_LINES];
    /** Number of lines in use; set by {@link #update}. */
    protected int n;

    protected LinesElement(String id, String name, String desc, boolean defaultEnabled, String tags, Anchor anchor, int offX, int offY) {
        super(id, name, desc, defaultEnabled, tags, anchor, offX, offY);
        java.util.Arrays.fill(lines, "");
        java.util.Arrays.fill(lineArgb, 0xFFFFFFFF);
    }

    /** Brings {@link #lines}, {@link #lineArgb} and {@link #n} up to date. Return false to hide the element for now. */
    protected abstract boolean update(HudContext x);

    @Override protected final boolean measure(HudContext x) {
        if (!update(x) || n <= 0) return false;
        int widest = 0;
        for (int i = 0; i < n; i++) widest = Math.max(widest, x.c.textWidth(lines[i]));
        w = widest + PAD * 2;
        h = PAD * 2 + (n - 1) * line(x) + x.c.lineHeight() - 1;
        return true;
    }

    @Override protected final void draw(HudContext x) {
        panel(x);
        int step = line(x);
        for (int i = 0; i < n; i++) text(x, lines[i], PAD, PAD + i * step, lineArgb[i]);
    }
}
