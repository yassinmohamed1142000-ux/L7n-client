package com.reaper.client.core.feature;

import com.reaper.client.core.util.Log;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * The link to the separate Baritone mod. Everything goes through reflection on Baritone's public API, so Reaper builds
 * and runs without Baritone, and starts using it when a Baritone jar for the same game version is in the mods folder.
 *
 * <p>Only the documented entry point is used: {@code BaritoneAPI.getProvider().getPrimaryBaritone()
 * .getCommandManager().execute(String)}, which is the very call that handles a command typed into the chat with
 * Baritone's prefix. Nothing else of Baritone is touched, and Reaper sends no packets and changes no game state itself.</p>
 *
 * <p>Pure Java (no Minecraft types), so it is covered by the plain-JDK tests against a small stand-in for Baritone's
 * API. Call it from the game's main thread only, as Baritone expects.</p>
 */
public final class BaritoneBridge implements AutomationModule.Bridge {
    private static final String API_CLASS = "baritone.api.BaritoneAPI";

    private final ClassLoader loader;
    private boolean resolved;
    private Method getProvider, getPrimary, getCommands, execute;
    private boolean logged;

    public BaritoneBridge() {
        this(BaritoneBridge.class.getClassLoader());
    }

    /** @param loader where Baritone's classes are looked up (the mod's own loader in the game) */
    public BaritoneBridge(ClassLoader loader) {
        this.loader = loader;
    }

    @Override
    public boolean installed() {
        resolve();
        return execute != null;
    }

    /** Looks the four methods up once. A missing class or method just means "not installed". */
    private void resolve() {
        if (resolved) return;
        resolved = true;
        try {
            Class<?> api = Class.forName(API_CLASS, false, loader);
            getProvider = api.getMethod("getProvider");
            getPrimary = getProvider.getReturnType().getMethod("getPrimaryBaritone");
            getCommands = getPrimary.getReturnType().getMethod("getCommandManager");
            execute = getCommands.getReturnType().getMethod("execute", String.class);
            if (execute.getReturnType() != boolean.class && execute.getReturnType() != Boolean.class) {
                throw new NoSuchMethodException("execute(String) does not return a boolean");
            }
        } catch (ClassNotFoundException ex) {
            execute = null;   // Baritone is simply not there: nothing to report
        } catch (ReflectiveOperationException | LinkageError | RuntimeException ex) {
            execute = null;
            Log.warn("Baritone is present but its API looks different from the one Reaper knows; the bridge stays off", ex);
        }
    }

    @Override
    public String run(String command) {
        if (command == null || command.isBlank()) return "Nothing to do.";
        if (!installed()) return "Baritone is not installed.";
        try {
            Object provider = getProvider.invoke(null);
            if (provider == null) return "Baritone is not ready yet.";
            Object baritone = getPrimary.invoke(provider);
            if (baritone == null) return "Baritone is not ready yet.";
            Object commands = getCommands.invoke(baritone);
            if (commands == null) return "Baritone is not ready yet.";
            Object accepted = execute.invoke(commands, command);
            return Boolean.FALSE.equals(accepted) ? "Baritone did not recognise that command." : null;
        } catch (InvocationTargetException ex) {
            Throwable cause = ex.getCause() == null ? ex : ex.getCause();
            note(cause);
            return "Baritone reported an error: " + brief(cause);
        } catch (ReflectiveOperationException | LinkageError | RuntimeException ex) {
            note(ex);
            return "Baritone could not be reached: " + brief(ex);
        }
    }

    private void note(Throwable t) {
        if (logged) return;
        logged = true;
        Log.warn("A Baritone command failed", t);
    }

    private static String brief(Throwable t) {
        String m = t.getMessage();
        String s = t.getClass().getSimpleName() + (m == null || m.isBlank() ? "" : ": " + m);
        return s.length() > 100 ? s.substring(0, 97) + "..." : s;
    }
}
