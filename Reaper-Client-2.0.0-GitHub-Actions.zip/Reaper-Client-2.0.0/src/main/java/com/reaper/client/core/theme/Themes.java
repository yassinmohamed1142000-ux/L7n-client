package com.reaper.client.core.theme;

import java.util.List;
import java.util.Locale;

/** Built-in colour themes. */
public final class Themes {
    private Themes() {}

    /** The default: near-black panels with a crimson accent. */
    public static final Theme REAPER = new Theme("reaper", "Reaper", true,
            0xF00F1014, 0xFF171A20, 0xFF14161B, 0xFF21242C, 0xFF0B0C10, 0xFF2C2F38,
            0xFFECEDF1, 0xFF8D909B, 0xFFEF3B52, 0xFFFF8A5C, 0xFF3DDC97, 0xFFFFC857, 0xFFFF5D73);

    public static final Theme MIDNIGHT = new Theme("midnight", "Midnight", true,
            0xF0151823, 0xFF1C2030, 0xFF1B1F2E, 0xFF252B40, 0xFF10131B, 0xFF2A3045,
            0xFFE8EBF5, 0xFF8A93AD, 0xFF7C5CFF, 0xFF4CC9F0, 0xFF3DDC97, 0xFFFFC857, 0xFFFF5D73);

    public static final Theme OCEAN = new Theme("ocean", "Ocean", true,
            0xF00E1A24, 0xFF132633, 0xFF122230, 0xFF1B3347, 0xFF0A131B, 0xFF22404F,
            0xFFE6F4F8, 0xFF7FA3B3, 0xFF00B4D8, 0xFF48E5C2, 0xFF3DDC97, 0xFFFFC857, 0xFFFF5D73);

    public static final Theme ROSE = new Theme("rose", "Rose", true,
            0xF01C141C, 0xFF281A28, 0xFF251A25, 0xFF352436, 0xFF130D14, 0xFF42304A,
            0xFFF6E9F2, 0xFFAD8FA6, 0xFFFF5C9A, 0xFFFFA26B, 0xFF3DDC97, 0xFFFFC857, 0xFFFF5D73);

    public static final Theme FOREST = new Theme("forest", "Forest", true,
            0xF0111A14, 0xFF18271D, 0xFF16231B, 0xFF203428, 0xFF0B120E, 0xFF2A4333,
            0xFFE8F5EC, 0xFF86A894, 0xFF3DDC84, 0xFFB8E65C, 0xFF3DDC97, 0xFFFFC857, 0xFFFF5D73);

    public static final Theme EMBER = new Theme("ember", "Ember", true,
            0xF01A1512, 0xFF261D17, 0xFF231A14, 0xFF34261C, 0xFF110D0A, 0xFF47362A,
            0xFFF8EDE3, 0xFFB09580, 0xFFFF8A3D, 0xFFFFD166, 0xFF3DDC97, 0xFFFFC857, 0xFFFF5D73);

    public static final Theme MONO = new Theme("mono", "Mono", true,
            0xF0161616, 0xFF202020, 0xFF1E1E1E, 0xFF2B2B2B, 0xFF0F0F0F, 0xFF363636,
            0xFFF0F0F0, 0xFF8C8C8C, 0xFFE6E6E6, 0xFF9A9A9A, 0xFF3DDC97, 0xFFFFC857, 0xFFFF5D73);

    public static final Theme DAYLIGHT = new Theme("daylight", "Daylight", false,
            0xF5F4F6FA, 0xFFE6E9F2, 0xFFEDEFF6, 0xFFDDE2F0, 0xFFFFFFFF, 0xFFC9CFDF,
            0xFF1B2030, 0xFF667088, 0xFF5B5BFF, 0xFF22B8CF, 0xFF1FA971, 0xFFE0A100, 0xFFD6335A);

    public static final List<Theme> ALL = List.of(REAPER, MIDNIGHT, OCEAN, ROSE, FOREST, EMBER, MONO, DAYLIGHT);

    public static Theme byId(String id) {
        if (id != null) {
            String k = id.toLowerCase(Locale.ROOT);
            for (Theme t : ALL) if (t.id().equals(k)) return t;
        }
        return REAPER;
    }
}
