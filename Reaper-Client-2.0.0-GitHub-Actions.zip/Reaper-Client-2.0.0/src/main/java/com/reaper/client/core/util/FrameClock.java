package com.reaper.client.core.util;

/**
 * Counts rendered frames. Gives frames per second (counted over about one second, like the game's own counter), a
 * smoothed frame time and the time since the previous frame for animations. Time stamps are supplied by the caller
 * ({@code System.nanoTime()} in the game), so the class has no dependency on the game and is unit-tested.
 */
public final class FrameClock {
    private static final long SECOND = 1_000_000_000L;
    /** A gap this long (a loading screen, the window being dragged) is not a frame time. */
    private static final long STALL = 2 * SECOND;
    private static final float MAX_DT = 0.1f;

    private boolean started;
    private long windowStart, last;
    private int frames, fps;
    private float frameMs, dt;

    /** Call once per rendered frame. */
    public void frame(long nowNs) {
        if (!started) {
            started = true;
            windowStart = last = nowNs;
            frames = 1;
            dt = 0;
            return;
        }
        long gap = nowNs - last;
        last = nowNs;
        if (gap < 0) gap = 0;   // a clock that went backwards must not produce nonsense
        dt = Math.min(MAX_DT, gap / (float) SECOND);
        if (gap >= STALL) {
            windowStart = nowNs;
            frames = 1;
            return;
        }
        float ms = gap / 1_000_000f;
        frameMs = frameMs <= 0 ? ms : frameMs + (ms - frameMs) * 0.1f;
        frames++;
        long elapsed = nowNs - windowStart;
        if (elapsed >= SECOND) {
            fps = Math.round(frames * (float) SECOND / elapsed);
            frames = 0;
            windowStart = nowNs;
        }
    }

    /** Frames per second over the last full second; a rough estimate from the frame time until one second has passed. */
    public int fps() {
        if (fps > 0) return fps;
        return frameMs > 0 ? Math.round(1000f / frameMs) : 0;
    }

    /** Smoothed milliseconds per frame. */
    public float frameMs() { return frameMs; }

    /** Seconds since the previous frame, between 0 and 0.1. */
    public float dt() { return dt; }

    public void reset() {
        started = false;
        frames = fps = 0;
        frameMs = dt = 0;
    }
}
