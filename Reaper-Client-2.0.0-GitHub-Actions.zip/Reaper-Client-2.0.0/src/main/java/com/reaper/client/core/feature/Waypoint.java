package com.reaper.client.core.feature;

import com.reaper.client.core.util.Text;

/** One saved place. Plain data; the {@link WaypointStore} owns and validates it. */
public final class Waypoint {
    public static final int MAX_NAME = 32;

    public String name;
    public int x, y, z;
    /** Dimension id as the game names it, for example {@code minecraft:overworld}. */
    public String dimension;
    /** Opaque ARGB. */
    public int color;
    public boolean visible = true;
    /** Created automatically where the player died. */
    public boolean death;
    public long created;

    public Waypoint(String name, int x, int y, int z, String dimension, int color) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.z = z;
        this.dimension = dimension;
        this.color = 0xFF000000 | color;
    }

    /** Straight-line distance from a point to the middle of this waypoint's block. */
    public double distance(double px, double py, double pz) {
        double dx = x + 0.5 - px, dy = y + 0.5 - py, dz = z + 0.5 - pz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Distance ignoring height. */
    public double horizontal(double px, double pz) {
        double dx = x + 0.5 - px, dz = z + 0.5 - pz;
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** "12 34 -56" — the form the game's own {@code /tp} command accepts. */
    public String coordinates() { return x + " " + y + " " + z; }

    /** Trims and checks a name: 1 to {@value #MAX_NAME} printable characters. Null when it is not acceptable. */
    public static String cleanName(String s) {
        if (s == null) return null;
        String t = s.strip();
        if (t.isEmpty() || t.codePointCount(0, t.length()) > MAX_NAME) return null;
        for (int i = 0; i < t.length(); ) {
            int cp = t.codePointAt(i);
            if (!Text.isPrintable(cp)) return null;
            i += Character.charCount(cp);
        }
        return t;
    }
}
