package com.reaper.client.core.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Owns every module. Registration order is the display order. */
public final class ModuleRegistry {
    private final List<Module> all = new ArrayList<>();
    private final List<Module> allView = Collections.unmodifiableList(all);
    private final Map<String, Module> byId = new HashMap<>();
    /** Per-category lists (read-only views), built once so the GUI can ask every frame without allocating. */
    private final Map<Category, List<Module>> byCategory = new EnumMap<>(Category.class);
    private final Map<Category, List<Module>> byCategoryView = new EnumMap<>(Category.class);
    private Module.PolicyGate gate = Module.PolicyGate.OPEN;

    public <M extends Module> M register(M m) {
        if (byId.putIfAbsent(m.id, m) != null) throw new IllegalArgumentException("duplicate module id " + m.id);
        all.add(m);
        List<Module> cat = byCategory.computeIfAbsent(m.category, c -> new ArrayList<>());
        cat.add(m);
        byCategoryView.put(m.category, Collections.unmodifiableList(cat));
        m.setGate(f -> gate.allows(f));
        return m;
    }

    public void setPolicyGate(Module.PolicyGate g) { gate = g == null ? Module.PolicyGate.OPEN : g; }

    public Module get(String id) { return byId.get(id); }

    /** Every module in registration order. A cached read-only view: free to call every frame. */
    public List<Module> all() { return allView; }

    /** Modules of one category in registration order. Read-only, allocation-free. */
    public List<Module> in(Category c) {
        List<Module> l = byCategoryView.get(c);
        return l == null ? List.of() : l;
    }

    public void resetAll() { for (Module m : all) m.reset(); }

    public int disableAll() {
        int n = 0;
        for (Module m : all) if (m.toggleable && m.isEnabled()) { m.setEnabled(false); n++; }
        return n;
    }

    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        for (Module m : all) o.add(m.id, m.toJson());
        return o;
    }

    /** Applies a saved profile. Modules the file does not mention are reset, so loading is deterministic. */
    public void fromJson(JsonObject o) {
        for (Module m : all) {
            JsonElement e = o == null ? null : o.get(m.id);
            m.fromJson(e != null && e.isJsonObject() ? e.getAsJsonObject() : null);
        }
    }
}
