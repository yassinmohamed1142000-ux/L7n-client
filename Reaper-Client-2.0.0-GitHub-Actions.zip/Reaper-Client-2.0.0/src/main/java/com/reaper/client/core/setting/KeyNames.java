package com.reaper.client.core.setting;

/**
 * Display names for GLFW-style key codes (the numbering Minecraft's InputConstants.KEY_* uses).
 * Kept here, with no Minecraft types, so key labels are testable and do not depend on a game call.
 */
public final class KeyNames {
    private KeyNames() {}

    // GLFW key codes that the GUI cares about.
    public static final int ESCAPE = 256, ENTER = 257, TAB = 258, BACKSPACE = 259, INSERT = 260, DELETE = 261,
            RIGHT = 262, LEFT = 263, DOWN = 264, UP = 265, PAGE_UP = 266, PAGE_DOWN = 267, HOME = 268, END = 269,
            KP_ENTER = 335, LSHIFT = 340, LCTRL = 341, LALT = 342, LSUPER = 343, RSHIFT = 344, RCTRL = 345, RALT = 346, RSUPER = 347,
            A = 65, C = 67, V = 86, X = 88, Z = 90;

    public static String of(int key) {
        if (key < 0) return "None";
        if (key >= 65 && key <= 90) return String.valueOf((char) key);
        if (key >= 48 && key <= 57) return String.valueOf((char) key);
        if (key >= 290 && key <= 314) return "F" + (key - 289);
        if (key >= 320 && key <= 329) return "Num " + (key - 320);
        switch (key) {
            case 32: return "Space";
            case 39: return "'";
            case 44: return ",";
            case 45: return "-";
            case 46: return ".";
            case 47: return "/";
            case 59: return ";";
            case 61: return "=";
            case 91: return "[";
            case 92: return "\\";
            case 93: return "]";
            case 96: return "`";
            case ESCAPE: return "Esc";
            case ENTER: return "Enter";
            case TAB: return "Tab";
            case BACKSPACE: return "Backspace";
            case INSERT: return "Insert";
            case DELETE: return "Delete";
            case RIGHT: return "Right";
            case LEFT: return "Left";
            case DOWN: return "Down";
            case UP: return "Up";
            case PAGE_UP: return "Page Up";
            case PAGE_DOWN: return "Page Down";
            case HOME: return "Home";
            case END: return "End";
            case 280: return "Caps Lock";
            case 281: return "Scroll Lock";
            case 282: return "Num Lock";
            case 283: return "Print Screen";
            case 284: return "Pause";
            case 330: return "Num .";
            case 331: return "Num /";
            case 332: return "Num *";
            case 333: return "Num -";
            case 334: return "Num +";
            case KP_ENTER: return "Num Enter";
            case LSHIFT: return "L Shift";
            case LCTRL: return "L Ctrl";
            case LALT: return "L Alt";
            case LSUPER: return "L Super";
            case RSHIFT: return "R Shift";
            case RCTRL: return "R Ctrl";
            case RALT: return "R Alt";
            case RSUPER: return "R Super";
            case 348: return "Menu";
            default: return "Key " + key;
        }
    }

    /** True for keys that must never be bound to a module (they are used by the GUI itself). */
    public static boolean reserved(int key) { return key == ESCAPE; }
}
