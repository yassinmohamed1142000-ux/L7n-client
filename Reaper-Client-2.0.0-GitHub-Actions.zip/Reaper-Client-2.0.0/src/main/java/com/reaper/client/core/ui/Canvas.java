package com.reaper.client.core.ui;

/**
 * The only drawing surface the GUI and HUD code knows about. The game layer implements it on top of Minecraft's
 * GuiGraphicsExtractor; the tests implement it with a software rasteriser. Coordinates are GUI pixels.
 * Everything beyond the primitives is built from {@code fill}, so it is cheap and looks identical everywhere.
 */
public interface Canvas {
    // ------------------------------------------------------------------ primitives (implemented by the game layer)
    int width();
    int height();
    int textWidth(String s);
    int lineHeight();

    void fill(int x, int y, int w, int h, int argb);
    void gradientV(int x, int y, int w, int h, int topArgb, int bottomArgb);
    void text(String s, int x, int y, int argb, boolean shadow);

    /** Intersects the clip with this rectangle until {@link #unclip()}. */
    void clip(int x, int y, int w, int h);
    void unclip();

    void push();
    void pop();
    void translate(float x, float y);
    void scale(float s);

    /** Multiplies the alpha of everything drawn until {@link #popAlpha()} (nestable). */
    void pushAlpha(float a);
    void popAlpha();

    /** An item icon. {@code stack} is an opaque handle owned by the game layer; null is ignored. */
    void item(Object stack, int x, int y, boolean decorations);

    /** Draws a whole texture scaled into the box. {@code texture} is an opaque handle; null is ignored. */
    void image(Object texture, int texW, int texH, int x, int y, int w, int h);

    // ------------------------------------------------------------------ helpers (shared)
    default void outline(int x, int y, int w, int h, int argb) {
        if (w <= 0 || h <= 0) return;
        fill(x, y, w, 1, argb);
        fill(x, y + h - 1, w, 1, argb);
        if (h > 2) { fill(x, y + 1, 1, h - 2, argb); fill(x + w - 1, y + 1, 1, h - 2, argb); }
    }

    /** Pixel-art rounded rectangle (corner radius up to about 6 looks right). */
    default void roundRect(int x, int y, int w, int h, int r, int argb) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { fill(x, y, w, h, argb); return; }
        for (int i = 0; i < r; i++) {
            int inset = cornerInset(r, i);
            fill(x + inset, y + i, w - 2 * inset, 1, argb);
            fill(x + inset, y + h - 1 - i, w - 2 * inset, 1, argb);
        }
        if (h - 2 * r > 0) fill(x, y + r, w, h - 2 * r, argb);
    }

    /** Rounded rectangle with a 1 px border drawn as two stacked shapes. */
    default void roundBox(int x, int y, int w, int h, int r, int fillArgb, int borderArgb) {
        roundRect(x, y, w, h, r, borderArgb);
        roundRect(x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fillArgb);
    }

    static int cornerInset(int r, int row) {
        double dy = r - row - 0.5;
        double hw = Math.sqrt(Math.max(0, (double) r * r - dy * dy));
        return (int) Math.max(0, Math.round(r - hw));
    }

    /** Filled circle, centred on (cx, cy). */
    default void disc(int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(Math.max(0, (double) r * r + r * 0.6 - (double) dy * dy)));
            fill(cx - dx, cy + dy, 2 * dx + 1, 1, argb);
        }
    }

    /** Soft shadow: a few translucent rounded rectangles growing outwards. */
    default void shadow(int x, int y, int w, int h, int r, int spread, int argb) {
        int base = argb >>> 24;
        for (int i = spread; i >= 1; i--) {
            int a = Math.max(1, base * (spread - i + 1) / (spread * (spread + 1) / 2 + 1));
            roundRect(x - i, y - i + 1, w + 2 * i, h + 2 * i, r + i, (a << 24) | (argb & 0xFFFFFF));
        }
    }

    default void centerText(String s, int cx, int y, int argb, boolean shadow) {
        text(s, cx - textWidth(s) / 2, y, argb, shadow);
    }

    default void rightText(String s, int rightX, int y, int argb, boolean shadow) {
        text(s, rightX - textWidth(s), y, argb, shadow);
    }

    /** Vertically centres one line of text inside a box. */
    default void textInBox(String s, int x, int y, int h, int argb, boolean shadow) {
        text(s, x, y + (h - lineHeight()) / 2 + 1, argb, shadow);
    }

    /** Shortens with "..." so the result fits in maxW pixels. */
    default String fit(String s, int maxW) {
        if (s == null) return "";
        if (maxW <= 0) return "";
        if (textWidth(s) <= maxW) return s;
        int dots = textWidth("...");
        if (maxW <= dots) return "";
        int lo = 0, hi = s.length();
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (textWidth(s.substring(0, mid)) + dots <= maxW) lo = mid; else hi = mid - 1;
        }
        return s.substring(0, lo).stripTrailing() + "...";
    }

    /**
     * Small solid triangle in a box of {@code size} (along the arrow) by {@code 2*size-1} (across).
     * dir: 0 right, 1 down, 2 left, 3 up.
     */
    default void arrow(int x, int y, int size, int dir, int argb) {
        for (int i = 0; i < size; i++) {
            int wide = 2 * (size - i) - 1;   // base is widest, the tip is 1 px
            switch (dir) {
                case 0 -> fill(x + i, y + i, 1, wide, argb);
                case 1 -> fill(x + i, y + i, wide, 1, argb);
                case 2 -> fill(x + size - 1 - i, y + i, 1, wide, argb);
                default -> fill(x + i, y + size - 1 - i, wide, 1, argb);
            }
        }
    }
}
