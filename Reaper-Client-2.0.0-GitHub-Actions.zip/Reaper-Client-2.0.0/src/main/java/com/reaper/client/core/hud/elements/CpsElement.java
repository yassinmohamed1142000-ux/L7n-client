package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.setting.Settings;

/** Clicks per second, counted from the mouse buttons the player is physically pressing. */
public final class CpsElement extends LineElement {
    public enum Mode implements Settings.Labeled {
        BOTH("Left | Right"), LEFT("Left button"), RIGHT("Right button");
        private final String label;
        Mode(String l) { label = l; }
        @Override public String label() { return label; }
    }

    private final Settings.Choice<Mode> mode = new Settings.Choice<>("mode", "Buttons", "Which mouse buttons to count.", Mode.BOTH);
    private final Settings.Bool label = new Settings.Bool("label", "Show label", "Write \"CPS\" before the numbers.", true);

    private int lastL = -1, lastR = -1;
    private Mode lastMode;
    private boolean lastLabel;

    public CpsElement() {
        super("cps", "CPS Counter", "Shows how many times per second you click.", false, "clicks per second mouse", Anchor.TOP_RIGHT, 4, 4);
        add(mode);
        add(label);
        commonSettings();
    }

    @Override protected boolean update(HudContext x) {
        int l = x.state.clicks.cps(0, x.d.nowMs), r = x.state.clicks.cps(1, x.d.nowMs);
        Mode m = mode.v();
        boolean lb = label.on();
        if (l != lastL || r != lastR || m != lastMode || lb != lastLabel) {
            lastL = l; lastR = r; lastMode = m; lastLabel = lb;
            String v = m == Mode.LEFT ? Integer.toString(l) : m == Mode.RIGHT ? Integer.toString(r) : l + " | " + r;
            text = lb ? "CPS: " + v : v;
        }
        textArgb = color.argb();
        return true;
    }
}
