package com.reaper.client.core.ui;

/**
 * Collects mouse and keyboard events between frames. The game's Screen pushes events in; the GUI consumes them once
 * per frame and calls {@link #endFrame()}. Fixed-size queues, no allocation.
 */
public final class Input {
    public static final int LEFT = 0, RIGHT = 1, MIDDLE = 2;
    public static final int MOD_SHIFT = 1, MOD_CTRL = 2, MOD_ALT = 4;

    /** Mouse position in GUI pixels (updated immediately). */
    public double mx, my;
    private final boolean[] down = new boolean[3];
    private final boolean[] pressed = new boolean[3];
    private final boolean[] released = new boolean[3];
    /** Wheel movement accumulated since the last frame (positive = up/away from the user, like Minecraft). */
    public double scroll;
    /** Modifier keys currently held. */
    public int mods;

    private final int[] keyQ = new int[64];   // pairs: key, mods
    private int keyN;
    private final int[] charQ = new int[64];
    private int charN;

    public void mouseMove(double x, double y) { mx = x; my = y; }

    public void mouseDown(int button, double x, double y) {
        mx = x; my = y;
        if (button >= 0 && button < 3) { down[button] = true; pressed[button] = true; }
    }

    public void mouseUp(int button, double x, double y) {
        mx = x; my = y;
        if (button >= 0 && button < 3) { down[button] = false; released[button] = true; }
    }

    public void scroll(double dy) { scroll += dy; }

    public void key(int key, int modifiers) {
        mods = modifiers;
        if (keyN < keyQ.length / 2) { keyQ[keyN * 2] = key; keyQ[keyN * 2 + 1] = modifiers; keyN++; }
    }

    public void character(int codepoint) {
        if (charN < charQ.length) charQ[charN++] = codepoint;
    }

    // ------------------------------------------------------------------ reading (during a frame)
    public boolean isDown(int b) { return down[b]; }
    public boolean wasPressed(int b) { return pressed[b]; }
    public boolean wasReleased(int b) { return released[b]; }
    public int keyCount() { return keyN; }
    public int keyAt(int i) { return keyQ[i * 2]; }
    public int keyModsAt(int i) { return keyQ[i * 2 + 1]; }
    public int charCount() { return charN; }
    public int charAt(int i) { return charQ[i]; }
    public boolean shift() { return (mods & MOD_SHIFT) != 0; }
    public boolean ctrl() { return (mods & MOD_CTRL) != 0; }

    /** Marks every key/char as handled (e.g. consumed by a text field). */
    public void consumeKeys() { keyN = 0; charN = 0; }

    public void endFrame() {
        for (int i = 0; i < 3; i++) { pressed[i] = false; released[i] = false; }
        scroll = 0;
        keyN = 0;
        charN = 0;
    }

    /** Clears everything, e.g. when the screen closes mid-drag. */
    public void reset() {
        endFrame();
        for (int i = 0; i < 3; i++) down[i] = false;
        mods = 0;
    }
}
