package com.reaper.client.mc;

import com.reaper.client.core.util.Log;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Method;

/**
 * Lookups for a few game members that could not be confirmed against 26.1 sources while this project was written
 * (there was no way to compile against the game). They are found by name when first needed, and every one of them
 * fails soft: a member that is missing gives "unknown" and the feature falls back to a safe behaviour. The unconfirmed
 * list is in docs/API-AUDIT.md.
 */
final class Reflect {
    private Reflect() {}

    private static boolean reducedSearched, latencySearched;
    private static Method reducedOnGame, reducedOnPlayer, latency;
    private static boolean releaseSearched;
    private static Method release;

    /** 1 when the server asked for reduced debug information, 0 when not, -1 when the game does not say. */
    static int reducedDebug(Object minecraft, Object player) {
        try {
            if (!reducedSearched) {
                reducedSearched = true;
                reducedOnGame = find(minecraft.getClass(), "showOnlyReducedInfo");
                if (player != null) {
                    reducedOnPlayer = find(player.getClass(), "isReducedDebugInfo");
                    if (reducedOnPlayer == null) reducedOnPlayer = find(player.getClass(), "hasReducedDebugInfo");
                }
                if (reducedOnGame == null && reducedOnPlayer == null) {
                    Log.warn("The game's reduced-debug-info flag was not found; coordinates stay hidden on multiplayer servers");
                }
            }
            if (reducedOnGame != null) return Boolean.TRUE.equals(reducedOnGame.invoke(minecraft)) ? 1 : 0;
            if (reducedOnPlayer != null && player != null) return Boolean.TRUE.equals(reducedOnPlayer.invoke(player)) ? 1 : 0;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            // fall through: unknown
        }
        return -1;
    }

    /** Round-trip time in milliseconds of a player-list entry, or -1 when unknown. */
    static int latency(Object playerInfo) {
        try {
            if (!latencySearched) {
                latencySearched = true;
                latency = find(playerInfo.getClass(), "getLatency");
                if (latency == null) latency = find(playerInfo.getClass(), "latency");
                if (latency == null) Log.warn("PlayerInfo.getLatency was not found; the ping display shows nothing");
            }
            if (latency != null && latency.invoke(playerInfo) instanceof Integer i) return Math.max(0, i);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            // unknown
        }
        return -1;
    }

    private static boolean clipboardSearched;
    private static Method clipboard;

    /** The text on the system clipboard, read through the game's own keyboard handler, or null when that is not possible. */
    static String clipboard(Object keyboardHandler) {
        try {
            if (!clipboardSearched) {
                clipboardSearched = true;
                clipboard = find(keyboardHandler.getClass(), "getClipboard");
                if (clipboard == null) Log.warn("KeyboardHandler.getClipboard was not found; paste uses Reaper's own copy buffer");
            }
            if (clipboard != null && clipboard.invoke(keyboardHandler) instanceof String s) return s;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            // unknown: the caller uses its own buffer
        }
        return null;
    }

    /** Frees a texture registered under this id, when the game has a method for it. Returns true when it did. */
    static boolean releaseTexture(Object textureManager, Identifier id) {
        try {
            if (!releaseSearched) {
                releaseSearched = true;
                release = find(textureManager.getClass(), "release", Identifier.class);
            }
            if (release == null) return false;
            release.invoke(textureManager, id);
            return true;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return false;
        }
    }

    private static Method find(Class<?> type, String name, Class<?>... params) {
        for (Class<?> c = type; c != null; c = c.getSuperclass()) {
            try {
                Method m = c.getDeclaredMethod(name, params);
                m.setAccessible(true);
                return m;
            } catch (NoSuchMethodException | RuntimeException ex) {
                // keep looking in the parent class
            }
        }
        return null;
    }
}
