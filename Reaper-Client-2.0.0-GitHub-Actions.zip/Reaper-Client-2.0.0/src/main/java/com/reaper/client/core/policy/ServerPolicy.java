package com.reaper.client.core.policy;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.reaper.client.core.util.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Per-server rules chosen by the PLAYER. The client does not try to detect anti-cheats or server software and
 * does nothing to conceal itself; it simply lets the player declare how strict a server is and then enforces that
 * on the client's own optional features.
 */
public final class ServerPolicy {
    /** Where the player currently is. */
    public record Context(boolean singleplayer, String host) {
        public static final Context NONE = new Context(false, "");
        public boolean inWorld() { return singleplayer || !host.isEmpty(); }
    }

    private Context ctx = Context.NONE;
    /** host (or "*.suffix") -> mode. Only non-default entries are stored. */
    private final Map<String, ServerMode> rules = new LinkedHashMap<>();

    public Context context() { return ctx; }
    public void setContext(Context c) { ctx = c == null ? Context.NONE : c; }

    /** The mode in force right now. Singleplayer and LAN-hosting are always OPEN. */
    public ServerMode mode() { return ctx.singleplayer() ? ServerMode.OPEN : modeFor(ctx.host()); }

    public boolean allows(Feature f) { return mode().allows(f); }

    public String reason(Feature f) {
        return f.label + " is off on this server (" + mode().label + " mode). Change it in Client > Server rules.";
    }

    public ServerMode modeFor(String host) {
        String h = normalizeHost(host);
        if (h.isEmpty()) return ServerMode.STANDARD;
        ServerMode exact = rules.get(h);
        if (exact != null) return exact;
        for (Map.Entry<String, ServerMode> e : rules.entrySet()) {
            String k = e.getKey();
            if (k.startsWith("*.") && (h.endsWith(k.substring(1)) || h.equals(k.substring(2)))) return e.getValue();
        }
        return ServerMode.STANDARD;
    }

    public void setMode(String host, ServerMode m) {
        String h = normalizeHost(host);
        if (h.isEmpty()) return;
        if (m == null || m == ServerMode.STANDARD) rules.remove(h); else rules.put(h, m);
    }

    public List<String> hosts() { return new ArrayList<>(rules.keySet()); }

    /**
     * "Play.Example.com:25565" -> "play.example.com"; "[::1]:25565" -> "::1"; "*.example.com" kept as is.
     * Returns "" for blank input.
     */
    public static String normalizeHost(String addr) {
        if (addr == null) return "";
        String s = addr.trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return "";
        if (s.startsWith("[")) {
            int end = s.indexOf(']');
            if (end > 0) s = s.substring(1, end);
        } else {
            int first = s.indexOf(':'), last = s.lastIndexOf(':');
            if (first >= 0 && first == last) s = s.substring(0, first); // host:port (not a bare IPv6 address)
        }
        while (s.endsWith(".")) s = s.substring(0, s.length() - 1);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_' || c == ':' || (c == '*' && i == 0);
            if (!ok) return "";
        }
        return s;
    }

    // ------------------------------------------------------------------ persistence
    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        for (Map.Entry<String, ServerMode> e : rules.entrySet()) o.addProperty(e.getKey(), e.getValue().name());
        return o;
    }

    public void fromJson(JsonObject o) {
        rules.clear();
        if (o == null) return;
        for (Map.Entry<String, JsonElement> e : o.entrySet()) {
            if (!e.getValue().isJsonPrimitive()) continue;
            String name = Text.lower(e.getValue().getAsString());
            for (ServerMode m : ServerMode.values()) if (m.name().toLowerCase(Locale.ROOT).equals(name)) setMode(e.getKey(), m);
        }
    }
}
