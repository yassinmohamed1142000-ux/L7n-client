package com.reaper.client.mixin;

import com.reaper.client.mc.Hooks;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Lets the Zoom module change the field of view. Everything else about the camera is left alone. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyReturnValue(method = "calculateFov(F)F", at = @At("RETURN"))
    private float reaper$fov(float original) {
        return Hooks.modifyFov(original);
    }
}
