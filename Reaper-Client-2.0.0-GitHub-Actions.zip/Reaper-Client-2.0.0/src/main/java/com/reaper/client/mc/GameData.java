package com.reaper.client.mc;

import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.util.FrameClock;
import com.reaper.client.core.util.GameNames;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LightLayer;
import org.lwjgl.glfw.GLFW;

/**
 * Copies what the HUD needs from the game into {@link HudData}. {@link #fill} runs once per frame and allocates
 * nothing; {@link #slow} runs every half second for the things that cost more (biome, light, ping) and for texts that
 * rarely change (item names, key labels).
 */
final class GameData {
    private final Minecraft mc = Minecraft.getInstance();
    private final Object[] seenArmor = new Object[4];
    private final String[] armorNames = {"", "", "", ""};
    private Object seenMain, seenOff;
    private String mainName = "", offName = "";
    private String worldName = "";

    void setWorldName(String name) { worldName = name == null ? "" : name; }

    // ------------------------------------------------------------------ every frame
    void fill(HudData d, FrameClock clock) {
        d.nowMs = System.nanoTime() / 1_000_000L;
        d.wallClockMs = System.currentTimeMillis();
        var window = mc.getWindow();
        d.screenW = window.getGuiScaledWidth();
        d.screenH = window.getGuiScaledHeight();
        d.fps = clock.fps();
        d.frameMs = clock.frameMs();

        var player = mc.player;
        var level = mc.level;
        if (player == null || level == null) {
            d.inWorld = false;
            return;
        }
        d.inWorld = true;
        d.singleplayer = mc.hasSingleplayerServer();
        d.serverName = worldName;

        float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
        d.x = player.getX();
        d.y = player.getY();
        d.z = player.getZ();
        d.yaw = player.getViewYRot(partial);
        d.pitch = player.getViewXRot(partial);
        d.camX = Mth.lerp(partial, player.xOld, player.getX());
        d.camY = Mth.lerp(partial, player.yOld, player.getY()) + player.getEyeHeight(player.getPose());
        d.camZ = Mth.lerp(partial, player.zOld, player.getZ());
        d.fov = Hooks.fov();

        d.sprinting = player.isSprinting();
        d.sneaking = player.isShiftKeyDown();
        d.flying = player.getAbilities().flying;
        d.swimming = player.isSwimming();
        d.gliding = player.isFallFlying();
        d.crawling = player.getPose() == Pose.SWIMMING && !player.isSwimming();

        equipment(d.armor[HudData.HEAD], player.getItemBySlot(EquipmentSlot.HEAD), 0);
        equipment(d.armor[HudData.CHEST], player.getItemBySlot(EquipmentSlot.CHEST), 1);
        equipment(d.armor[HudData.LEGS], player.getItemBySlot(EquipmentSlot.LEGS), 2);
        equipment(d.armor[HudData.FEET], player.getItemBySlot(EquipmentSlot.FEET), 3);
        hand(d.mainHand, player.getMainHandItem(), true);
        hand(d.offHand, player.getOffhandItem(), false);

        // Nothing is "pressed" while a menu is open: the keys then belong to the menu.
        boolean play = mc.screen == null;
        var o = mc.options;
        d.keys[HudData.K_FORWARD] = play && o.keyUp.isDown();
        d.keys[HudData.K_LEFT] = play && o.keyLeft.isDown();
        d.keys[HudData.K_BACK] = play && o.keyDown.isDown();
        d.keys[HudData.K_RIGHT] = play && o.keyRight.isDown();
        d.keys[HudData.K_JUMP] = play && o.keyJump.isDown();
        d.keys[HudData.K_SNEAK] = play && o.keyShift.isDown();
        d.keys[HudData.K_SPRINT] = play && o.keySprint.isDown();
        long handle = window.handle();
        d.keys[HudData.M_LEFT] = play && (GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS || Hooks.takeClick(0));
        d.keys[HudData.M_RIGHT] = play && (GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS || Hooks.takeClick(1));
        d.keys[HudData.M_MIDDLE] = play && (GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS || Hooks.takeClick(2));
        if (!play) Hooks.clearClicks();
    }

    private void equipment(HudData.ItemInfo info, ItemStack stack, int slot) {
        if (stack == null || stack.isEmpty()) {
            info.clear();
            seenArmor[slot] = null;
            return;
        }
        if (seenArmor[slot] != stack) {
            seenArmor[slot] = stack;
            armorNames[slot] = stack.getHoverName().getString();
        }
        int max = stack.isDamageableItem() ? stack.getMaxDamage() : 0;
        info.set(stack, stack.getCount(), max > 0 ? stack.getDamageValue() : 0, max, armorNames[slot]);
    }

    private void hand(HudData.ItemInfo info, ItemStack stack, boolean main) {
        if (stack == null || stack.isEmpty()) {
            info.clear();
            if (main) seenMain = null; else seenOff = null;
            return;
        }
        if (main) {
            if (seenMain != stack) { seenMain = stack; mainName = stack.getHoverName().getString(); }
        } else if (seenOff != stack) {
            seenOff = stack;
            offName = stack.getHoverName().getString();
        }
        int max = stack.isDamageableItem() ? stack.getMaxDamage() : 0;
        info.set(stack, stack.getCount(), max > 0 ? stack.getDamageValue() : 0, max, main ? mainName : offName);
    }

    // ------------------------------------------------------------------ twice a second
    void slow(HudData d) {
        var player = mc.player;
        var level = mc.level;
        if (player == null || level == null) return;

        d.dimensionId = level.dimension().identifier().toString();
        d.dimension = HudData.Dimension.fromId(d.dimensionId);

        // The server can ask clients not to show coordinates, light and biome (reducedDebugInfo). If the game does not
        // let us read that, we assume it is set on a multiplayer server rather than show something it asked us not to.
        int reduced = Reflect.reducedDebug(mc, player);
        d.reducedDebug = reduced == 1 || (reduced < 0 && !mc.hasSingleplayerServer());

        BlockPos pos = player.blockPosition();
        if (d.reducedDebug) {
            d.biome = "";
            d.blockLight = d.skyLight = -1;
        } else {
            d.biome = GameNames.pretty(level.getBiome(pos).unwrapKey().map(k -> k.identifier().toString()).orElse(""));
            d.blockLight = level.getBrightness(LightLayer.BLOCK, pos);
            d.skyLight = level.getBrightness(LightLayer.SKY, pos);
        }
        d.dayTime = Math.floorMod(level.getOverworldClockTime(), 24000L);

        d.ping = -1;
        var connection = mc.getConnection();
        if (connection != null) {
            var info = connection.getPlayerInfo(player.getUUID());
            if (info != null) d.ping = Reflect.latency(info);
        }

        // names are looked up again now and then, in case an item was renamed in place
        java.util.Arrays.fill(seenArmor, null);
        seenMain = seenOff = null;

        d.keyLabels[HudData.K_FORWARD] = label(mc.options.keyUp, "W");
        d.keyLabels[HudData.K_LEFT] = label(mc.options.keyLeft, "A");
        d.keyLabels[HudData.K_BACK] = label(mc.options.keyDown, "S");
        d.keyLabels[HudData.K_RIGHT] = label(mc.options.keyRight, "D");
        d.keyLabels[HudData.K_JUMP] = label(mc.options.keyJump, "Space");
        d.keyLabels[HudData.K_SNEAK] = label(mc.options.keyShift, "Shift");
        d.keyLabels[HudData.K_SPRINT] = label(mc.options.keySprint, "Ctrl");
    }

    /** The key the player has bound, in a few characters. */
    private static String label(KeyMapping mapping, String fallback) {
        try {
            String s = KeyMappingHelper.getBoundKeyOf(mapping).getDisplayName().getString();
            if (s == null || s.isBlank()) return fallback;
            s = s.replace("Left ", "").replace("Right ", "R-").replace("Control", "Ctrl");
            return s.length() > 6 ? s.substring(0, 6) : s;
        } catch (RuntimeException ex) {
            return fallback;
        }
    }
}
