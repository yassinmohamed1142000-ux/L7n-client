package com.reaper.client.mc;

import com.reaper.client.core.ReaperCore;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

import java.time.ZoneId;

/**
 * What the mixins call. Each hook is wrapped so that an error in Reaper's code can only ever mean "do what the game
 * would have done": the original value is returned and the problem is logged once.
 *
 * <p>Mixin classes may not be referenced from ordinary code, so the mixins call these static methods and the rest of
 * the mod never touches a mixin class.</p>
 */
public final class Hooks {
    private Hooks() {}

    private static final float DEFAULT_FOV = 70f;

    private static volatile float lastFov = DEFAULT_FOV;
    private static long lastFovNs;
    private static int fovCalls;
    private static boolean scrollConsumed;
    private static final boolean[] clicks = new boolean[3];
    private static boolean reported;
    private static int mouseCalls, chatCalls;

    // ------------------------------------------------------------------ field of view (CameraMixin)
    /** The field of view for this frame: the game's value, or the zoomed one. */
    public static float modifyFov(float original) {
        try {
            fovCalls++;
            lastFov = original;
            ReaperCore core = Game.core();
            if (core == null) return original;
            long now = System.nanoTime();
            float dt = lastFovNs == 0 ? 0f : Math.min(0.1f, (now - lastFovNs) / 1_000_000_000f);
            lastFovNs = now;
            core.zoom.setHeld(Game.zoomHeld());
            core.zoom.update(dt);
            if (!core.zoom.zooming()) return original;
            float zoomed = (float) core.zoom.fov(original);
            lastFov = zoomed;
            return zoomed;
        } catch (Throwable t) {
            report(t);
            return original;
        }
    }

    /** The field of view of the last frame (for placing waypoint markers). */
    static float fov() { return lastFov; }

    /** How many times the field-of-view hook has run. Zero after a while in a world means the mixin did not apply. */
    static int fovCalls() { return fovCalls; }

    /** How many mouse events the mouse hook has seen. Zero after clicking means the mixin did not apply. */
    static int mouseCalls() { return mouseCalls; }

    /** How many chat lines the chat hook has seen. Zero after some chat means the mixin did not apply. */
    static int chatCalls() { return chatCalls; }

    // ------------------------------------------------------------------ mouse (MouseHandlerMixin)
    /** Mouse sensitivity: lower while zoomed in. */
    public static double modifySensitivity(double original) {
        try {
            ReaperCore core = Game.core();
            if (core != null && core.zoom.cinematicWanted()) return original / Math.max(1.0, core.zoom.zoom());
        } catch (Throwable t) {
            report(t);
        }
        return original;
    }

    /** The mouse wheel turned (start of the game's handler). */
    public static void onScroll(double vertical) {
        scrollConsumed = false;
        try {
            ReaperCore core = Game.core();
            if (core != null && Game.playing()) {
                core.zoom.setHeld(Game.zoomHeld());
                scrollConsumed = core.zoom.onScroll(vertical);
            }
        } catch (Throwable t) {
            report(t);
        }
    }

    /** False while the wheel was used for zooming, so the hotbar does not move as well. */
    public static boolean allowHotbarScroll() { return !scrollConsumed; }

    public static void scrollDone() { scrollConsumed = false; }

    /** A mouse button changed (start of the game's handler). Presses are counted even if they are shorter than a frame. */
    public static void onMouseButton(int button, int action) {
        try {
            mouseCalls++;
            if (action == 1 && button >= 0 && button < clicks.length && Game.playing()) clicks[button] = true;
        } catch (Throwable t) {
            report(t);
        }
    }

    static boolean takeClick(int button) {
        boolean was = clicks[button];
        clicks[button] = false;
        return was;
    }

    static void clearClicks() {
        for (int i = 0; i < clicks.length; i++) clicks[i] = false;
    }

    // ------------------------------------------------------------------ chat (ChatComponentMixin)
    /** Puts the time in front of a chat line when time stamps are on. */
    public static Component stampChat(Component original) {
        try {
            chatCalls++;
            ReaperCore core = Game.core();
            if (core == null || original == null) return original;
            Game.noticeChatLine(original);
            if (!core.chat.stampsOn()) return original;
            String prefix = core.chat.prefix(System.currentTimeMillis(), ZoneId.systemDefault());
            if (prefix == null || prefix.isEmpty()) return original;
            MutableComponent stamp = Component.literal(prefix).setStyle(Style.EMPTY.withColor(core.chat.stampRgb()));
            return stamp.append(original);
        } catch (Throwable t) {
            report(t);
            return original;
        }
    }

    // ------------------------------------------------------------------ errors
    private static void report(Throwable t) {
        if (reported) return;
        reported = true;
        Game.logError("A hook failed; the game continues without it", t);
    }
}
