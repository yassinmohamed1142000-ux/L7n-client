package com.reaper.client.core.feature;

import com.reaper.client.core.ui.Canvas;

/** Small pixel-art shapes built from rectangles, so they look the same on every renderer. */
public final class Glyphs {
    private Glyphs() {}

    /** A filled diamond of the given radius, centred on (cx, cy). */
    public static void diamond(Canvas c, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int hw = r - Math.abs(dy);
            c.fill(cx - hw, cy + dy, 2 * hw + 1, 1, argb);
        }
    }

    /**
     * A solid arrow head whose tip is {@code r} pixels from (cx, cy) in the direction {@code angleDeg}
     * (0 = up, 90 = right, clockwise). Drawn row by row, no allocation.
     */
    public static void pointer(Canvas c, int cx, int cy, int r, float angleDeg, int argb) {
        double a = Math.toRadians(angleDeg);
        double tx = Math.sin(a) * r, ty = -Math.cos(a) * r;
        double wing = Math.toRadians(135);   // a right-angled arrow head: wide enough to read at 9 px
        double bx1 = Math.sin(a + wing) * r, by1 = -Math.cos(a + wing) * r;
        double bx2 = Math.sin(a - wing) * r, by2 = -Math.cos(a - wing) * r;
        int ext = r + 1;
        for (int y = -ext; y <= ext; y++) {
            int first = Integer.MAX_VALUE, last = Integer.MIN_VALUE;
            for (int x = -ext; x <= ext; x++) {
                if (inTriangle(x, y, tx, ty, bx1, by1, bx2, by2)) { if (x < first) first = x; if (x > last) last = x; }
            }
            if (first != Integer.MAX_VALUE) c.fill(cx + first, cy + y, last - first + 1, 1, argb);
        }
    }

    private static boolean inTriangle(double px, double py, double ax, double ay, double bx, double by, double cx, double cy) {
        double d1 = (px - bx) * (ay - by) - (ax - bx) * (py - by);
        double d2 = (px - cx) * (by - cy) - (bx - cx) * (py - cy);
        double d3 = (px - ax) * (cy - ay) - (cx - ax) * (py - ay);
        boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
        return !(neg && pos);
    }
}
