package com.reaper.client.core.inventory;

/**
 * Which slots of an inventory screen get sorted. Numbers are positions in the screen's slot list, which is what the
 * game's click packets use. The layouts are the vanilla ones: in the player's own screen the 27 storage slots come at
 * 9..35 and the hotbar at 36..44; in a chest-like screen the container's slots come first and the player's 27 storage
 * slots and 9 hotbar slots follow them.
 */
public final class SortLayout {
    private SortLayout() {}

    public static final int STORAGE = 27, HOTBAR = 9, ROW = 9, MAX_ROWS = 6;
    private static final int PLAYER_SCREEN_STORAGE_START = 9;

    /** The player's own inventory screen: storage slots, plus the hotbar when asked. */
    public static int[] inventoryScreen(boolean withHotbar) {
        return range(PLAYER_SCREEN_STORAGE_START, STORAGE + (withHotbar ? HOTBAR : 0));
    }

    /** A chest-like screen with {@code rows} rows of nine: the container's own slots. */
    public static int[] container(int rows) {
        return range(0, clampRows(rows) * ROW);
    }

    /** A chest-like screen: the player's storage slots shown under the container, plus the hotbar when asked. */
    public static int[] playerInContainer(int rows, boolean withHotbar) {
        return range(clampRows(rows) * ROW, STORAGE + (withHotbar ? HOTBAR : 0));
    }

    public static int clampRows(int rows) { return Math.max(1, Math.min(MAX_ROWS, rows)); }

    /** True when every slot of the block exists in a menu that has {@code slotCount} slots. */
    public static boolean fits(int[] block, int slotCount) {
        if (block == null || block.length == 0) return false;
        for (int s : block) if (s < 0 || s >= slotCount) return false;
        return true;
    }

    private static int[] range(int start, int count) {
        int[] r = new int[count];
        for (int i = 0; i < count; i++) r[i] = start + i;
        return r;
    }
}
