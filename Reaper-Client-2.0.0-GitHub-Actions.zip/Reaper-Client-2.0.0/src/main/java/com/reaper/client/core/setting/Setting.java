package com.reaper.client.core.setting;

import com.google.gson.JsonElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * One configurable value. Pure data: no Minecraft types, safe to unit test.
 * Every setting validates what it is given ({@link #sanitize}) and loads tolerantly from JSON,
 * so a hand-edited or corrupt config can never put the client into an invalid state.
 */
public abstract class Setting<T> {
    public final String id;
    public final String name;
    public final String description;
    protected T value;
    protected final T def;
    private BooleanSupplier visible;
    private List<Consumer<T>> listeners;

    protected Setting(String id, String name, String description, T def) {
        this.id = id;
        this.name = name;
        this.description = description == null ? "" : description;
        this.def = def;
        this.value = def;
    }

    public final T get() { return value; }
    public final T getDefault() { return def; }

    /** Sets a (sanitised) value. Returns true when the value actually changed. */
    public final boolean set(T v) {
        T n = sanitize(v);
        if (Objects.equals(n, value)) return false;
        value = n;
        if (listeners != null) for (Consumer<T> l : listeners) l.accept(n);
        return true;
    }

    public final void reset() { set(def); }
    public final boolean isDefault() { return Objects.equals(value, def); }

    protected abstract T sanitize(T v);
    public abstract JsonElement toJson();
    /** Never throws: wrong types are ignored, numbers are clamped. */
    public abstract void fromJson(JsonElement e);

    /** False for buttons and other values that must not be written to the config. */
    public boolean persistent() { return true; }

    public Setting<T> visibleWhen(BooleanSupplier s) { visible = s; return this; }
    public boolean isVisible() { return visible == null || visible.getAsBoolean(); }

    public Setting<T> onChange(Consumer<T> c) {
        if (listeners == null) listeners = new ArrayList<>(2);
        listeners.add(c);
        return this;
    }

    /** Lower-case text used by the search box. */
    public String searchText() { return (name + ' ' + description + ' ' + id).toLowerCase(Locale.ROOT); }

    /** Short text shown next to the setting in the GUI. */
    public String valueText() { return String.valueOf(value); }
}
