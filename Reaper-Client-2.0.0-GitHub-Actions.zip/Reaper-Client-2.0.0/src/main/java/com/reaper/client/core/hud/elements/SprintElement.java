package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.hud.HudData;
import com.reaper.client.core.setting.Settings;

/** Shows how the player is moving: sprinting, sneaking, flying, swimming, gliding or crawling. */
public final class SprintElement extends LineElement {
    private final Settings.Bool showWalking = new Settings.Bool("showWalking", "Show when walking", "Also show \"Walking\" when no special movement is active.", false);
    private final Settings.Bool colorize = new Settings.Bool("colorize", "Colour by state", "Use a different colour for each movement state. Replaces the text colour.", true);

    public SprintElement() {
        super("sprint", "Sprint Indicator", "Shows whether you are sprinting, sneaking, flying or swimming.", false, "movement state toggle sneak", Anchor.TOP_LEFT, 4, 82);
        add(showWalking);
        add(colorize);
        color.visibleWhen(() -> !colorize.on());
        commonSettings();
    }

    /** The label for the current movement state, or null when there is nothing to say. Public so tests can check it. */
    public static String state(HudData d, boolean walking) {
        if (d.gliding) return "Gliding";
        if (d.flying) return "Flying";
        if (d.swimming) return "Swimming";
        if (d.crawling) return "Crawling";
        if (d.sneaking) return "Sneaking";
        if (d.sprinting) return "Sprinting";
        return walking ? "Walking" : null;
    }

    @Override protected boolean update(HudContext x) {
        if (!x.d.inWorld && !x.editing) return false;
        String s = state(x.d, showWalking.on());
        if (s == null) {
            if (!x.editing) return false;
            s = "Walking";
        }
        text = s;
        if (!colorize.on()) textArgb = color.argb();
        else if (x.d.gliding || x.d.flying) textArgb = x.theme.accent2();
        else if (x.d.swimming) textArgb = x.theme.accent();
        else if (x.d.sneaking || x.d.crawling) textArgb = x.theme.warn();
        else if (x.d.sprinting) textArgb = x.theme.good();
        else textArgb = x.theme.textDim();
        return true;
    }
}
