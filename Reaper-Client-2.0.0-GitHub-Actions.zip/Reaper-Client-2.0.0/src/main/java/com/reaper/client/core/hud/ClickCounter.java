package com.reaper.client.core.hud;

/**
 * Clicks per second without any hook into the game: the HUD polls the mouse button state every frame and this
 * counts the presses (rising edges). A fixed ring buffer per button, so nothing is allocated.
 */
public final class ClickCounter {
    private static final int CAP = 64;
    private final long[][] stamps;
    private final int[] head, size;
    private final boolean[] was;

    public ClickCounter(int buttons) {
        stamps = new long[buttons][CAP];
        head = new int[buttons];
        size = new int[buttons];
        was = new boolean[buttons];
    }

    /** Call once per frame with the current button state. Returns true when this frame saw a new press. */
    public boolean poll(int button, boolean down, long nowMs) {
        boolean press = down && !was[button];
        was[button] = down;
        if (press) click(button, nowMs);
        return press;
    }

    public void click(int button, long nowMs) {
        stamps[button][head[button]] = nowMs;
        head[button] = (head[button] + 1) % CAP;
        if (size[button] < CAP) size[button]++;
    }

    /** Presses within the last second. */
    public int cps(int button, long nowMs) {
        int n = 0;
        int count = size[button];
        for (int i = 0; i < count; i++) {
            long t = stamps[button][(head[button] - 1 - i + CAP * 2) % CAP];
            if (nowMs - t <= 1000) n++; else break;
        }
        return n;
    }

    public void reset() {
        for (int b = 0; b < size.length; b++) { size[b] = 0; head[b] = 0; was[b] = false; }
    }
}
