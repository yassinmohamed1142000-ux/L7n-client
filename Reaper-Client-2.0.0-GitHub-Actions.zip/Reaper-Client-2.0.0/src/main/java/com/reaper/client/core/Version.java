package com.reaper.client.core;

/** Version string shown in the GUI. The Gradle build keeps this in sync with gradle.properties (see build.gradle). */
public final class Version {
    private Version() {}

    public static final String VERSION = "2.0.0";
    public static final String NAME = "REAPER CLIENT";
}
