package com.reaper.client.mixin;

import com.reaper.client.mc.Hooks;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.multiplayer.chat.GuiMessageSource;
import net.minecraft.client.multiplayer.chat.GuiMessageTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Puts the time in front of every line that reaches the chat. The line keeps its signature and tag; only the text
 * that is shown is changed, and only when the time stamp option is on.
 */
@Mixin(ChatComponent.class)
public class ChatComponentMixin {
    @Inject(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
            at = @At("HEAD"))
    private void reaper$stamp(Component unused, MessageSignature signature, GuiMessageSource source, GuiMessageTag tag,
                           CallbackInfo ci, @Local(argsOnly = true) LocalRef<Component> message) {
        message.set(Hooks.stampChat(message.get()));
    }
}
