package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.HudElement;

import java.util.List;

/** Every HUD element in draw order (later ones are drawn on top). One place, so the game and the tests agree. */
public final class HudElements {
    private HudElements() {}

    public static List<HudElement> create() {
        return List.of(
                new FpsElement(),
                new CoordinatesElement(),
                new CpsElement(),
                new PingElement(),
                new SprintElement(),
                new WorldInfoElement(),
                new DirectionElement(),
                new ArmorElement(),
                new DurabilityElement(),
                new KeystrokesElement(),
                new ModuleListElement(),
                new NotificationElement());
    }
}
