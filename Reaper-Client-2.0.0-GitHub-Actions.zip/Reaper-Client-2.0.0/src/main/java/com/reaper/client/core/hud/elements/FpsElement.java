package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.setting.Settings;
import com.reaper.client.core.util.Text;

public final class FpsElement extends LineElement {
    private final Settings.Bool label = new Settings.Bool("label", "Show label", "Write \"FPS\" before the number.", true);
    private final Settings.Bool frameTime = new Settings.Bool("frameTime", "Frame time", "Also show how long one frame takes, in milliseconds.", false);
    private final Settings.Bool colorize = new Settings.Bool("colorize", "Colour by performance", "Green when smooth, yellow when so-so, red when slow. Replaces the text colour.", false);

    private int lastFps = -1, lastMs10 = -1;
    private boolean lastLabel, lastFrameTime;

    public FpsElement() {
        super("fps", "FPS Counter", "Shows your frame rate.", true, "framerate performance frames", Anchor.TOP_LEFT, 4, 4);
        add(label);
        add(frameTime);
        add(colorize);
        color.visibleWhen(() -> !colorize.on());
        commonSettings();
    }

    @Override protected boolean update(HudContext x) {
        int fps = Math.max(0, x.d.fps);
        boolean ft = frameTime.on(), lb = label.on();
        int ms10 = ft ? Math.round(x.d.frameMs * 10f) : 0;
        if (fps != lastFps || ms10 != lastMs10 || ft != lastFrameTime || lb != lastLabel) {
            lastFps = fps; lastMs10 = ms10; lastFrameTime = ft; lastLabel = lb;
            String base = lb ? "FPS: " + fps : Integer.toString(fps);
            text = ft ? base + " (" + Text.num(ms10 / 10.0, 1) + " ms)" : base;
        }
        textArgb = colorize.on() ? (fps >= 60 ? x.theme.good() : fps >= 30 ? x.theme.warn() : x.theme.bad()) : color.argb();
        return true;
    }
}
