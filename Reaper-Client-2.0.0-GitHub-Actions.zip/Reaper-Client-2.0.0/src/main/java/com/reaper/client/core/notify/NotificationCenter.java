package com.reaper.client.core.notify;

import java.util.function.BooleanSupplier;

/**
 * Short on-screen messages ("Profile loaded", "Boots durability low"). A fixed pool of toast objects, so showing one
 * never allocates beyond the message string itself. Pure logic: the HUD draws it and the game layer feeds it.
 */
public final class NotificationCenter {
    public static final int MAX_VISIBLE = 6;
    public static final int MAX_LENGTH = 120;
    /** Seconds a toast takes to slide in and to fade out. */
    public static final float ENTER = 0.25f, EXIT = 0.35f;

    public static final class Toast {
        public Level level = Level.INFO;
        public String message = "";
        /** What is drawn: the message, with a repeat count when identical messages were merged. */
        public String shown = "";
        /** How many identical messages were merged into this one (1 = just one). */
        public int repeats = 1;
        public float age, life;

        /** 0..1 visibility: slides in, holds, fades out. */
        public float appear() {
            if (age < ENTER) return ease(age / ENTER);
            float left = life - age;
            if (left < EXIT) return ease(Math.max(0f, left) / EXIT);
            return 1f;
        }

        private static float ease(float t) { float u = 1f - Math.min(1f, Math.max(0f, t)); return 1f - u * u * u; }
    }

    private final Toast[] pool = new Toast[MAX_VISIBLE];
    private final Toast[] active = new Toast[MAX_VISIBLE];
    private int count;
    private BooleanSupplier gate = () -> true;
    /** Seconds a new toast stays on screen. */
    public float duration = 4f;
    private long totalShown;

    public NotificationCenter() {
        for (int i = 0; i < MAX_VISIBLE; i++) pool[i] = new Toast();
    }

    /** Toasts are only shown while this returns true (the Notifications module being on). */
    public void setGate(BooleanSupplier g) { gate = g == null ? () -> true : g; }

    /** Returns false when the message was not shown (empty, or notifications are off). */
    public boolean push(Level level, String message) {
        if (message == null) return false;
        String msg = clean(message);
        if (msg.isEmpty() || !gate.getAsBoolean()) return false;
        Level lv = level == null ? Level.INFO : level;
        for (int i = 0; i < count; i++) {
            Toast t = active[i];
            if (t.level == lv && t.message.equals(msg) && t.age < t.life - EXIT) {   // same message still on screen: count it instead of stacking
                t.repeats++;
                t.shown = msg + " (x" + t.repeats + ")";
                t.age = Math.min(t.age, ENTER);
                t.life = t.age + Math.max(1f, duration);
                return true;
            }
        }
        Toast t;
        if (count == MAX_VISIBLE) {                      // full: the oldest makes room
            t = active[0];
            System.arraycopy(active, 1, active, 0, MAX_VISIBLE - 1);
            count--;
        } else {
            t = freeToast();
        }
        t.level = lv;
        t.message = msg;
        t.shown = msg;
        t.repeats = 1;
        t.age = 0f;
        t.life = Math.max(1f, duration);
        active[count++] = t;
        totalShown++;
        return true;
    }

    private Toast freeToast() {
        for (Toast p : pool) {
            boolean used = false;
            for (int i = 0; i < count; i++) if (active[i] == p) { used = true; break; }
            if (!used) return p;
        }
        return pool[0];   // unreachable while count < MAX_VISIBLE
    }

    /** Advances time and drops expired toasts. Call once per frame. */
    public void update(float dt) {
        if (count == 0) return;
        float step = Math.max(0f, Math.min(dt, 0.25f));   // a long pause must not skip the whole animation
        int out = 0;
        for (int i = 0; i < count; i++) {
            Toast t = active[i];
            t.age += step;
            if (t.age < t.life) active[out++] = t;
        }
        for (int i = out; i < count; i++) active[i] = null;
        count = out;
    }

    public int count() { return count; }

    /** Oldest first. */
    public Toast get(int i) { return active[i]; }

    public void clear() {
        for (int i = 0; i < count; i++) active[i] = null;
        count = 0;
    }

    /** How many toasts were shown since start (for tests and diagnostics). */
    public long totalShown() { return totalShown; }

    /** Removes control characters, collapses whitespace runs and caps the length. */
    static String clean(String s) {
        StringBuilder sb = new StringBuilder(Math.min(s.length(), MAX_LENGTH));
        boolean lastSpace = true;
        for (int i = 0; i < s.length() && sb.length() < MAX_LENGTH; i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c) || Character.isISOControl(c)) {
                if (!lastSpace) { sb.append(' '); lastSpace = true; }
            } else {
                sb.append(c);
                lastSpace = false;
            }
        }
        int end = sb.length();
        if (end > 0 && sb.charAt(end - 1) == ' ') end--;
        if (end > 0 && Character.isHighSurrogate(sb.charAt(end - 1))) end--;   // never cut a surrogate pair in half
        sb.setLength(end);
        return sb.toString();
    }
}
