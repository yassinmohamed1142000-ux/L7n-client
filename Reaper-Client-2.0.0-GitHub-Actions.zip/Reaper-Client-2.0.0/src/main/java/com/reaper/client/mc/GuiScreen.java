package com.reaper.client.mc;

import com.reaper.client.core.ReaperCore;
import com.reaper.client.core.ui.Input;

/** The Reaper menu (the ClickGUI). */
final class GuiScreen extends ReaperScreen {
    private final ReaperCore core;

    GuiScreen(ReaperCore core) {
        super("Reaper");
        this.core = core;
        core.gui.onOpen();
    }

    @Override protected Input in() { return core.gui.in; }

    @Override
    protected void draw(McCanvas c, int mouseX, int mouseY, float dt) {
        core.gui.render(c, mouseX, mouseY, dt);
        if (core.gui.isClosed()) Game.requestScreen(null);
    }

    /** Escape closes the menu, unless it is only leaving a text box, a key capture or the search. */
    @Override
    protected void escape() {
        if (core.gui.onEscape()) core.gui.requestClose();
    }

    /** The menu key closes the menu again, except while a text box or a key capture is using the keyboard. */
    @Override
    protected boolean intercept(int key) {
        if (core.gui.ui.focus == null && Game.isMenuKey(key)) {
            core.gui.requestClose();
            return true;
        }
        return false;
    }

    @Override
    protected void closed() {
        core.gui.onClose();
        core.requestSave();
    }
}
