package com.reaper.client.core.hud.elements;

import com.reaper.client.core.hud.Anchor;
import com.reaper.client.core.hud.HudContext;
import com.reaper.client.core.setting.Settings;

/** Latency to the server as reported by the server's own player list. Hidden in singleplayer. */
public final class PingElement extends LineElement {
    private final Settings.Bool colorize = new Settings.Bool("colorize", "Colour by latency", "Green is fast, red is slow. Replaces the text colour.", true);
    private final Settings.Bool label = new Settings.Bool("label", "Show label", "Write \"Ping\" before the number.", true);

    private int lastPing = Integer.MIN_VALUE;
    private boolean lastLabel;

    public PingElement() {
        super("ping", "Ping", "Shows your latency to the server.", false, "latency ms network lag", Anchor.TOP_RIGHT, 4, 22);
        add(colorize);
        add(label);
        color.visibleWhen(() -> !colorize.on());
        commonSettings();
    }

    @Override protected boolean update(HudContext x) {
        int ping = x.d.ping;
        boolean known = x.d.inWorld && !x.d.singleplayer && ping >= 0;
        if (!known && !x.editing) return false;
        int shown = known ? ping : -1;
        boolean lb = label.on();
        if (shown != lastPing || lb != lastLabel) {
            lastPing = shown; lastLabel = lb;
            String v = shown < 0 ? "--" : shown + " ms";
            text = lb ? "Ping: " + v : v;
        }
        if (!colorize.on() || shown < 0) textArgb = color.argb();
        else textArgb = shown <= 60 ? x.theme.good() : shown <= 150 ? x.theme.warn() : x.theme.bad();
        return true;
    }
}
