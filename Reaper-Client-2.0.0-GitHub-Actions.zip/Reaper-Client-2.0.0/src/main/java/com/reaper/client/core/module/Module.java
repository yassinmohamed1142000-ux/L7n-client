package com.reaper.client.core.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.reaper.client.core.policy.Feature;
import com.reaper.client.core.setting.Setting;
import com.reaper.client.core.setting.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * A feature the user can switch on and configure. Pure data + state: what a module actually does in the game
 * is attached by the Minecraft layer (it reads {@link #isActive()} every tick and reconciles), so the whole module
 * system can be tested without a running game.
 */
public class Module {
    /** How a bound key drives the module. */
    public enum KeyMode implements Settings.Labeled {
        TOGGLE("Toggle"), HOLD("Hold");
        private final String label;
        KeyMode(String l) { label = l; }
        @Override public String label() { return label; }
    }

    public final String id;
    public final String name;
    public final String description;
    public final Category category;
    /** False for pure settings panels (no on/off switch). */
    public final boolean toggleable;
    private final boolean defaultEnabled;
    /** Search keywords in addition to name and description. */
    private final String tags;

    private final List<Setting<?>> settings = new ArrayList<>();
    private List<Setting<?>> allCache;
    private boolean enabled;
    private Feature feature;
    private PolicyGate gate = PolicyGate.OPEN;
    private List<Consumer<Boolean>> toggleListeners;

    public final Settings.Key bind;
    public final Settings.Choice<KeyMode> bindMode;

    public interface PolicyGate { boolean allows(Feature f); PolicyGate OPEN = f -> true; }

    public Module(String id, String name, String description, Category category, boolean toggleable, boolean defaultEnabled, String tags) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.toggleable = toggleable;
        this.defaultEnabled = toggleable && defaultEnabled;
        this.tags = tags == null ? "" : tags.toLowerCase(Locale.ROOT);
        this.enabled = this.defaultEnabled;
        this.bind = new Settings.Key("bind", "Keybind", "Press a key to toggle this module. Esc cancels, Backspace clears.", Settings.NO_KEY);
        this.bindMode = new Settings.Choice<>("bindMode", "Key mode", "Toggle on press, or active while held.", KeyMode.TOGGLE);
        this.bindMode.visibleWhen(bind::bound);
    }

    public Module(String id, String name, String description, Category category) {
        this(id, name, description, category, true, false, "");
    }

    // ------------------------------------------------------------------ settings
    public <S extends Setting<?>> S add(S s) {
        for (Setting<?> o : settings) if (o.id.equals(s.id)) throw new IllegalArgumentException("duplicate setting id " + s.id + " in " + id);
        if (s.id.equals(bind.id) || s.id.equals(bindMode.id)) throw new IllegalArgumentException("reserved setting id " + s.id);
        settings.add(s);
        allCache = null;
        return s;
    }

    /** Own settings (without the key bind rows). */
    public List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }

    /** Everything the GUI lists for this module, key bind rows last. Cached: safe to call every frame. */
    public List<Setting<?>> allSettings() {
        if (allCache == null) {
            List<Setting<?>> l = new ArrayList<>(settings.size() + 2);
            l.addAll(settings);
            if (toggleable) { l.add(bind); l.add(bindMode); }
            allCache = Collections.unmodifiableList(l);
        }
        return allCache;
    }

    public Setting<?> find(String settingId) {
        for (Setting<?> s : allSettings()) if (s.id.equals(settingId)) return s;
        return null;
    }

    // ------------------------------------------------------------------ state
    public boolean isEnabled() { return enabled; }

    /** Enabled by the user AND allowed by the current server policy. */
    public boolean isActive() { return enabled && (feature == null || gate.allows(feature)); }

    /** Why the module is on but not running (null when it is fine). */
    public boolean isBlockedByPolicy() { return enabled && feature != null && !gate.allows(feature); }

    public Module feature(Feature f) { this.feature = f; return this; }
    public Feature feature() { return feature; }
    void setGate(PolicyGate g) { this.gate = g == null ? PolicyGate.OPEN : g; }

    public boolean setEnabled(boolean on) {
        if (!toggleable || on == enabled) return false;
        enabled = on;
        if (toggleListeners != null) for (Consumer<Boolean> l : new ArrayList<>(toggleListeners)) l.accept(on);
        return true;
    }

    public void toggle() { setEnabled(!enabled); }

    public Module onToggle(Consumer<Boolean> l) {
        if (toggleListeners == null) toggleListeners = new ArrayList<>(2);
        toggleListeners.add(l);
        return this;
    }

    /** Back to factory settings and default on/off state. */
    public void reset() {
        for (Setting<?> s : allSettings()) if (s.persistent()) s.reset();
        setEnabled(defaultEnabled);
    }

    public boolean matches(String queryLower) {
        if (queryLower == null || queryLower.isBlank()) return true;
        return com.reaper.client.core.util.Text.matchesAll(searchText(), queryLower);
    }

    public String searchText() {
        return (name + ' ' + description + ' ' + tags + ' ' + id + ' ' + category.label).toLowerCase(Locale.ROOT);
    }

    // ------------------------------------------------------------------ persistence
    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        if (toggleable) o.addProperty("enabled", enabled);
        JsonObject s = new JsonObject();
        for (Setting<?> st : allSettings()) if (st.persistent()) s.add(st.id, st.toJson());
        o.add("settings", s);
        return o;
    }

    /** Applies saved values. Unknown settings are ignored, missing ones fall back to their defaults. */
    public void fromJson(JsonObject o) {
        reset();
        if (o == null) return;
        JsonElement en = o.get("enabled");
        if (toggleable && en != null && en.isJsonPrimitive() && en.getAsJsonPrimitive().isBoolean()) setEnabled(en.getAsBoolean());
        JsonElement st = o.get("settings");
        if (st != null && st.isJsonObject()) {
            JsonObject so = st.getAsJsonObject();
            for (Setting<?> s : allSettings()) if (s.persistent() && so.has(s.id)) s.fromJson(so.get(s.id));
        }
    }
}
