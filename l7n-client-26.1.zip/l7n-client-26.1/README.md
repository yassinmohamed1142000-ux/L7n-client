# L7N CLIENT (Fabric, Minecraft 26.1)

Build: install **JDK 25**, then `gradle wrapper --gradle-version 9.4.0` (or copy a Gradle 9.4+ wrapper) and run `./gradlew build`.
Jar: `build/libs/l7n-client-1.1.0.jar` -> put it in `.minecraft/mods` with Fabric Loader 0.18.4+ and Fabric API for 26.1.
Open the ClickGUI with Right Shift (or the "L7N" button in the pause menu).

## Baritone (optional)
Drop a Baritone build for your Minecraft version into `mods`. L7N finds it automatically (reflection only, no build dependency).
- `AutoWalk` pathfinds in the direction you were facing when you enabled it (`distance` setting) instead of just holding W.
- `AutoMine` mines the blocks on its list (`.automine add diamond_ore`) with Baritone; with an empty list, or without Baritone, it falls back to holding left click.
- Commands: `.goto <x y z | x z | waypoint>`, `.mine <block...>`, `.explore [x z]`, `.farm`, `.stop`, `.baritone <any baritone command>`.

Written from scratch; ideas inspired by Meteor (GPLv3) - keep GPL + credit if you copy any real Meteor code.
