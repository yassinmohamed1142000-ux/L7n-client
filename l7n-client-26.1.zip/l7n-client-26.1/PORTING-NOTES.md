# Porting notes: 1.21.11 -> 26.1

This port was done from the official 26.1 migration notes **without being able to compile or launch the game**
(no JDK 25 / Fabric / Mojang downloads were available). Expect a handful of compile errors on the first build;
this file says where to look.

## Changes taken from the docs (fairly safe)
| Area | Change | Where |
|---|---|---|
| Build | `net.fabricmc.fabric-loom`, no `mappings`, `implementation`, Java 25 | build.gradle |
| Fabric API | `KeyBindingHelper.registerKeyBinding` -> `KeyMappingHelper.registerKeyMapping` (package `keymapping.v1`) | L7NClient |
| Fabric API | `Screens.getButtons` -> `Screens.getWidgets` | L7NClient |
| Fabric API | HUD registered with `HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, id, element)` (as in the 26.1 Fabric docs) | gui/Hud |
| Vanilla | `GuiGraphics` -> `GuiGraphicsExtractor`; `Screen#render` -> `extractRenderState` | gui/*, module/* |
| Vanilla | `ClickType` -> `ContainerInput` | CombatModules |
| Vanilla | `Player#displayClientMessage` split; client chat line now uses `sendSystemMessage` | CommandManager.info |

## Assumptions to check first if the build fails
1. **`gui/Gfx.java`** is the only file that calls the renamed drawing methods:
   `text(Font, String, x, y, color, shadow)`, `item(...)`, `itemDecorations(...)`, `PlayerFaceExtractor.extractRenderState(...)`.
   The *names* come from the primer; the argument lists for `item`, `itemDecorations` and the face call are assumed unchanged.
2. Things that were **not mentioned** in the migration notes and so were left as in 1.21.11 (fix here if the compiler complains):
   `Abilities.mayfly/flying`, `ClientInput` (Freecam), `LocalPlayer.input`, `ServerboundMovePlayerPacket.Pos/StatusOnly`,
   `LevelChunkSection.maybeHas`, `ChunkAccess.getBlockEntitiesPos/getSections`, `PlayerInfo.getProfile/getSkin/getTabListDisplayName`,
   `Entity.setGlowingTag`, `KeyMapping.Category.register`.
3. `gradle.properties`: Fabric API `0.145.4+26.1.2` (from the Modrinth listing), Loom `1.15-SNAPSHOT`, Loader `0.18.4`.
   Use the versions your Fabric template generator recommends if these are stale. There is no Gradle wrapper in the folder:
   run `gradle wrapper --gradle-version 9.4.0` once.

## Baritone
`BaritoneBridge` is reflection only (no build dependency). It calls `BaritoneAPI.getProvider().getPrimaryBaritone()`, then the
command manager's `execute(String)` and each process's `isActive()`. Its logic was tested against a stand-in API with the same
shape, not against the real Baritone for 26.1.
