package com.l7n.client.module.impl;

import com.l7n.client.Data;
import com.l7n.client.gui.Gfx;
import com.l7n.client.gui.Projector;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public final class RenderModules {
    private RenderModules() {}

    public static class Radar extends Module {
        public Radar() { super("Radar", "List nearby players", Category.RENDER); addSetting("max", 5, 1); }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() {
            Minecraft mc = Minecraft.getInstance();
            List<String> l = new ArrayList<>();
            if (mc.level == null || mc.player == null) return l;
            for (var p : mc.level.players()) {
                if (p == mc.player) continue;
                l.add(p.getName().getString() + " " + (int) mc.player.distanceTo(p) + "m");
                if (l.size() >= (int) get("max")) break;
            }
            return l;
        }
    }

    public static class Speedometer extends Module {
        public Speedometer() { super("Speedometer", "Show your speed in blocks/second", Category.RENDER); }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return List.of();
            Vec3 v = mc.player.getDeltaMovement();
            return List.of(String.format("Speed: %.1f b/s", Math.sqrt(v.x * v.x + v.z * v.z) * 20));
        }
    }

    public static class Keystrokes extends Module {
        public Keystrokes() { super("Keystrokes", "Show WASD keys", Category.RENDER); }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() {
            var o = Minecraft.getInstance().options;
            return List.of((o.keyUp.isDown() ? "W" : "-") + " " + (o.keyLeft.isDown() ? "A" : "-") + " "
                    + (o.keyDown.isDown() ? "S" : "-") + " " + (o.keyRight.isDown() ? "D" : "-") + (o.keyJump.isDown() ? "  SPACE" : ""));
        }
    }

    /** Name, distance, hearts, armor, held items and totem above every player. */
    public static class Nametags extends Module {
        private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        public Nametags() {
            super("Nametags", "Name, hearts, armor and totem above players", Category.RENDER);
            addSetting("range", 64, 8); addToggle("health", true); addToggle("armor", true); addToggle("totem", true); addToggle("distance", true);
        }
        @Override public void renderOverlay(GuiGraphicsExtractor g, Minecraft mc, Projector p, float pt) {
            Entity camEnt = mc.getCameraEntity();
            for (Player pl : mc.level.players()) {
                if (pl == camEnt) continue;
                double dist = camEnt.distanceTo(pl);
                if (dist > get("range")) continue;
                double[] s = p.project(pl.getEyePosition(pt).add(0, 0.55, 0));
                if (s == null) continue;
                int cx = (int) s[0], y = (int) s[1];
                String name = pl.getName().getString();
                String label = name + (on("distance") ? " " + (int) dist + "m" : "");
                int tw = mc.font.width(label);
                g.fill(cx - tw / 2 - 3, y - 2, cx + tw / 2 + 3, y + 10, 0xA00B0618);
                Gfx.text(g, mc.font, label, cx - tw / 2, y, Data.isFriend(name) ? 0xFF4ADE80 : 0xFFFFFFFF);
                int ny = y + 12;
                if (on("health")) {
                    float hp = pl.getHealth() + pl.getAbsorptionAmount(), ratio = hp / Math.max(1f, pl.getMaxHealth());
                    int col = ratio > 0.6f ? 0xFF4ADE80 : ratio > 0.3f ? 0xFFFACC15 : 0xFFEF4444;
                    String t = "♥ " + String.format("%.1f", hp);
                    Gfx.text(g, mc.font, t, cx - mc.font.width(t) / 2, ny, col);
                    ny += 10;
                }
                if (on("totem") && (pl.getMainHandItem().is(Items.TOTEM_OF_UNDYING) || pl.getOffhandItem().is(Items.TOTEM_OF_UNDYING))) {
                    String t = "TOTEM";
                    Gfx.text(g, mc.font, t, cx - mc.font.width(t) / 2, ny, 0xFFFBBF24);
                }
                if (on("armor")) {
                    List<ItemStack> items = new ArrayList<>();
                    for (EquipmentSlot sl : SLOTS) { ItemStack st = pl.getItemBySlot(sl); if (!st.isEmpty()) items.add(st); }
                    if (!pl.getMainHandItem().isEmpty()) items.add(pl.getMainHandItem());
                    if (!pl.getOffhandItem().isEmpty()) items.add(pl.getOffhandItem());
                    int x = cx - items.size() * 17 / 2, iy = y - 20;
                    for (ItemStack st : items) {
                        Gfx.item(g, mc.font, st, x, iy);
                        x += 17;
                    }
                }
            }
        }
    }
}
