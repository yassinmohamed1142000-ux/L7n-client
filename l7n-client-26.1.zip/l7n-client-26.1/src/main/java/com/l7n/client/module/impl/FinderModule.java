package com.l7n.client.module.impl;

import com.l7n.client.CommandManager;
import com.l7n.client.gui.Gfx;
import com.l7n.client.gui.Projector;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import java.util.*;

/** Scans loaded chunks every 2 seconds, lists results on the HUD and draws green areas + tracer lines. */
public abstract class FinderModule extends Module {
    public record Found(BlockPos pos, String label, AABB area) {
        public Found(BlockPos pos, String label) { this(pos, label, null); }
    }
    private final List<String> lines = new ArrayList<>();
    private final List<Found> shown = new ArrayList<>();
    private final Set<Long> announced = new HashSet<>();
    private int cd;

    protected FinderModule(String n, String d) {
        super(n, d, Category.MISC);
        addSetting("radius", 5, 1);
        addToggle("chat", true); addToggle("boxes", true); addToggle("tracers", true);
    }
    protected abstract void scan(ChunkAccess chunk, List<Found> out);
    protected int color() { return 0xFF22C55E; }

    @Override public boolean hasHud() { return true; }
    @Override public List<String> hudLines() { return lines; }
    @Override protected void onDisable() { lines.clear(); shown.clear(); announced.clear(); }

    @Override public void tick(Minecraft mc) {
        if (cd-- > 0 || mc.level == null) return;
        cd = 40;
        List<Found> found = new ArrayList<>();
        BlockPos me = mc.player.blockPosition();
        int r = (int) get("radius"), pcx = me.getX() >> 4, pcz = me.getZ() >> 4;
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) {
                ChunkAccess c = mc.level.getChunkSource().getChunk(pcx + dx, pcz + dz, ChunkStatus.FULL, false);
                if (c != null) scan(c, found);
            }
        found.sort(Comparator.comparingDouble((Found f) -> f.pos().distSqr(me)));
        lines.clear(); shown.clear();
        int said = 0;
        for (Found f : found) {
            BlockPos p = f.pos();
            String t = f.label() + " " + p.getX() + " " + p.getY() + " " + p.getZ() + " (" + (int) Math.sqrt(p.distSqr(me)) + "m)";
            if (lines.size() < 6) lines.add(t);
            if (shown.size() < 40) shown.add(f);
            if (on("chat") && said < 3 && announced.add(p.asLong())) { said++; CommandManager.info("Found: " + t); }
        }
    }

    @Override public void renderOverlay(GuiGraphicsExtractor g, Minecraft mc, Projector p, float pt) {
        int col = color();
        for (Found f : shown) {
            AABB bb = f.area() != null ? f.area() : new AABB(f.pos());
            if (on("boxes")) {
                if (f.area() != null) { double[] r = p.rect(bb); if (r != null) p.rectFill(g, r, (col & 0xFFFFFF) | 0x33000000); }
                p.box(g, bb, col);
            }
            if (on("tracers")) p.tracer(g, bb.getCenter(), col);
            double[] s = p.project(bb.getCenter());
            if (s != null) Gfx.centered(g, mc.font, f.label(), (int) s[0], (int) s[1] - 10, col);
        }
    }
}
