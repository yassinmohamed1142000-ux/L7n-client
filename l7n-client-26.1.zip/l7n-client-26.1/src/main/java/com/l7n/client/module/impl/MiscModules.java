package com.l7n.client.module.impl;

import com.l7n.client.BaritoneBridge;
import com.l7n.client.CommandManager;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;

public final class MiscModules {
    private MiscModules() {}

    /**
     * Walks forward. With Baritone installed it pathfinds (jumps gaps, goes around obstacles) toward a point
     * "distance" blocks ahead in the direction you were facing when you switched it on, and picks a new point when it arrives.
     * Without Baritone, or with the "baritone" toggle off, it just holds the forward key like before.
     */
    public static class AutoWalk extends Module {
        private double dirX, dirZ;
        private int cd;
        private boolean issued;

        public AutoWalk() {
            super("AutoWalk", "Walk forward automatically (Baritone pathfinding if installed)", Category.MISC);
            addToggle("baritone", true); addSetting("distance", 200, 25); addSetting("minhealth", 0, 1);
        }
        private boolean smart() { return on("baritone") && BaritoneBridge.available(); }

        @Override protected void onEnable() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            double yaw = Math.toRadians(mc.player.getYRot());
            dirX = -Math.sin(yaw); dirZ = Math.cos(yaw);
            cd = 0; issued = false;
            if (on("baritone") && !BaritoneBridge.available()) CommandManager.info("Baritone not found - walking straight forward instead");
        }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null) return;
            if (!smart()) { mc.options.keyUp.setDown(true); return; }
            if (get("minhealth") > 0 && mc.player.getHealth() < get("minhealth")) {
                CommandManager.info("§cHealth low - AutoWalk stopped");
                setEnabled(false);
                return;
            }
            if (cd-- > 0) return;
            cd = 20;
            if (BaritoneBridge.busy()) return;
            int x = (int) Math.floor(mc.player.getX() + dirX * get("distance"));
            int z = (int) Math.floor(mc.player.getZ() + dirZ * get("distance"));
            issued = BaritoneBridge.run("goto " + x + " " + z);
        }
        @Override protected void onDisable() {
            Minecraft.getInstance().options.keyUp.setDown(false);
            if (issued) { BaritoneBridge.cancel(); issued = false; }
        }
    }

    public static class AutoSneak extends Module {
        public AutoSneak() { super("AutoSneak", "Always sneak", Category.MISC); }
        @Override public void tick(Minecraft mc) { if (mc.screen == null) mc.options.keyShift.setDown(true); }
        @Override protected void onDisable() { Minecraft.getInstance().options.keyShift.setDown(false); }
    }

    public static class AutoJump extends Module {
        public AutoJump() { super("AutoJump", "Jump automatically while moving", Category.MISC); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen == null && mc.player.onGround() && (mc.options.keyUp.isDown() || mc.options.keyDown.isDown() || mc.options.keyLeft.isDown() || mc.options.keyRight.isDown())) {
                Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, 0.42, v.z);
            }
        }
    }

    public static class AntiAFK extends Module {
        private int t; private boolean flip;
        public AntiAFK() { super("AntiAFK", "Small movements so you don't get kicked", Category.MISC); }
        @Override public void tick(Minecraft mc) {
            if (++t < 400) return;
            t = 0; flip = !flip;
            mc.player.swing(InteractionHand.MAIN_HAND);
            mc.player.setYRot(mc.player.getYRot() + (flip ? 5 : -5));
            if (mc.player.onGround()) { Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, 0.42, v.z); }
        }
    }

    public static class AutoRespawn extends Module {
        public AutoRespawn() { super("AutoRespawn", "Respawn instantly", Category.MISC); }
        @Override public void tick(Minecraft mc) { if (mc.screen instanceof DeathScreen) mc.player.respawn(); }
    }
}
