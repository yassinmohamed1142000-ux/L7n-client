package com.l7n.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.PlayerFaceExtractor;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.ItemStack;

/**
 * Every call that touches the renamed 26.1 GUI drawing API lives here, so that if a signature differs
 * from what this file assumes there is exactly one place to fix.
 *
 * 26.1 renames (GuiGraphics -> GuiGraphicsExtractor):
 *   drawString -> text (now takes a shadow flag), drawCenteredString -> centeredText,
 *   renderItem -> item, renderItemDecorations -> itemDecorations,
 *   PlayerFaceRenderer.draw -> PlayerFaceExtractor.extractRenderState.
 * fill(...) and blit(RenderPipelines.GUI_TEXTURED, ...) keep their names and argument order.
 */
public final class Gfx {
    private Gfx() {}

    /** Text with shadow (what drawString(font, s, x, y, color) did in 1.21.11). Color must be ARGB. */
    public static void text(GuiGraphicsExtractor g, Font f, String s, int x, int y, int color) {
        g.text(f, s, x, y, color, true);
    }

    /** Horizontally centered text with shadow, written with text() so it does not depend on centeredText's signature. */
    public static void centered(GuiGraphicsExtractor g, Font f, String s, int centerX, int y, int color) {
        g.text(f, s, centerX - f.width(s) / 2, y, color, true);
    }

    /** An item icon plus its count/durability decorations. */
    public static void item(GuiGraphicsExtractor g, Font f, ItemStack stack, int x, int y) {
        g.item(stack, x, y);
        g.itemDecorations(f, stack, x, y);
    }

    /** A player's face from their skin. */
    public static void face(GuiGraphicsExtractor g, PlayerSkin skin, int x, int y, int size) {
        PlayerFaceExtractor.extractRenderState(g, skin, x, y, size);
    }
}
