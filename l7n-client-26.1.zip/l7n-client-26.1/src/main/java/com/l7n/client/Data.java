package com.l7n.client;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** Friends and waypoints (saved in the config file). */
public final class Data {
    private Data() {}
    public static final Set<String> friends = new LinkedHashSet<>();
    public static final Map<String, double[]> waypoints = new LinkedHashMap<>();
    public static boolean isFriend(String name) { return friends.contains(name.toLowerCase()); }
}
