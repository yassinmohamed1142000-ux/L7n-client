package com.l7n.client.gui;

import com.l7n.client.Config;
import com.l7n.client.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

/** Settings of one module. Opened with right click in the ClickGUI or with ".settings <module>". */
public class ModuleSettingsScreen extends Screen {
    private static final int W = 230, RH = 16, TOP = 38, PURPLE = 0xFFA855F7;
    private final Module m;
    private final Screen parent;
    private record Item(int kind, String key) {} // 0 enabled, 1 toggle, 2 number, 3 move, 4 back

    public ModuleSettingsScreen(Module m, Screen parent) { super(Component.literal(m.name)); this.m = m; this.parent = parent; }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { Config.save(); }

    private List<Item> items() {
        List<Item> l = new ArrayList<>();
        l.add(new Item(0, ""));
        for (String k : m.settings.keySet()) l.add(new Item(m.toggles.contains(k) ? 1 : 2, k));
        if (m.hasHud()) l.add(new Item(3, ""));
        l.add(new Item(4, ""));
        return l;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0xE005020D);
        Gfx.centered(g, font, m.name, width / 2, 12, PURPLE);
        Gfx.centered(g, font, font.plainSubstrByWidth(m.description, width - 20), width / 2, 25, 0xFFAAAAAA);
        int x = (width - W) / 2, y = TOP;
        for (Item it : items()) {
            boolean hover = mx >= x && mx < x + W && my >= y && my < y + RH;
            g.fill(x, y, x + W, y + RH, hover ? 0xF02A1550 : 0xF0140A2A);
            switch (it.kind()) {
                case 0 -> { g.fill(x, y, x + 3, y + RH, m.isEnabled() ? PURPLE : 0xFF444444); Gfx.text(g, font, "Enabled: " + (m.isEnabled() ? "ON" : "OFF"), x + 8, y + 4, 0xFFFFFFFF); }
                case 1 -> Gfx.text(g, font, it.key() + ": " + m.valueText(it.key()), x + 8, y + 4, 0xFFFFFFFF);
                case 2 -> {
                    Gfx.text(g, font, it.key() + ": " + m.valueText(it.key()), x + 8, y + 4, 0xFFFFFFFF);
                    g.fill(x + W - 44, y + 2, x + W - 24, y + RH - 2, 0xFF3B1D72);
                    g.fill(x + W - 22, y + 2, x + W - 2, y + RH - 2, 0xFF3B1D72);
                    Gfx.centered(g, font, "-", x + W - 34, y + 4, 0xFFFFFFFF);
                    Gfx.centered(g, font, "+", x + W - 12, y + 4, 0xFFFFFFFF);
                }
                case 3 -> Gfx.text(g, font, "Move on screen (HUD editor)", x + 8, y + 4, PURPLE);
                default -> Gfx.text(g, font, "Back", x + 8, y + 4, 0xFFAAAAAA);
            }
            y += RH + 2;
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        int x = (width - W) / 2, y = TOP;
        for (Item it : items()) {
            if (ev.x() >= x && ev.x() < x + W && ev.y() >= y && ev.y() < y + RH) {
                switch (it.kind()) {
                    case 0 -> m.toggle();
                    case 1 -> m.adjust(it.key(), 1);
                    case 2 -> { if (ev.x() >= x + W - 44 && ev.x() < x + W - 24) m.adjust(it.key(), -1); else if (ev.x() >= x + W - 22) m.adjust(it.key(), 1); }
                    case 3 -> minecraft.setScreen(new HudEditorScreen(this));
                    default -> minecraft.setScreen(parent);
                }
                return true;
            }
            y += RH + 2;
        }
        return super.mouseClicked(ev, dbl);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}
