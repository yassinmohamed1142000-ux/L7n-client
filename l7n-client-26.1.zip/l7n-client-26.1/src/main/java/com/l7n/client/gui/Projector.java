package com.l7n.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Projects world positions onto the GUI so we can draw lines/boxes/tags without touching the world renderer. */
public final class Projector {
    private final double cx, cy, cz, fx, fy, fz, rx, rz, ux, uy, uz, tanHalf, aspect;
    public final int w, h;

    private Projector(double cx, double cy, double cz, double fx, double fy, double fz, double rx, double rz,
                      double ux, double uy, double uz, double tanHalf, double aspect, int w, int h) {
        this.cx = cx; this.cy = cy; this.cz = cz; this.fx = fx; this.fy = fy; this.fz = fz; this.rx = rx; this.rz = rz;
        this.ux = ux; this.uy = uy; this.uz = uz; this.tanHalf = tanHalf; this.aspect = aspect; this.w = w; this.h = h;
    }

    public static Projector create(Minecraft mc, float pt) {
        Entity cam = mc.getCameraEntity();
        if (cam == null || mc.level == null) return null;
        if (cam == mc.player && !mc.options.getCameraType().isFirstPerson()) return null;
        Vec3 eye = cam.getEyePosition(pt);
        double yaw = Math.toRadians(cam.getViewYRot(pt)), pitch = Math.toRadians(cam.getViewXRot(pt));
        double sy = Math.sin(yaw), cyw = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        double fov = Math.toRadians(mc.options.fov().get());
        return new Projector(eye.x, eye.y, eye.z, -sy * cp, -sp, cyw * cp, -cyw, -sy, -sy * sp, cp, cyw * sp,
                Math.tan(fov / 2), (double) w / h, w, h);
    }

    private double[] cam(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        return new double[]{dx * rx + dz * rz, dx * ux + dy * uy + dz * uz, dx * fx + dy * fy + dz * fz};
    }
    private double[] scr(double[] c) {
        return new double[]{(c[0] / (c[2] * tanHalf * aspect) * 0.5 + 0.5) * w, (0.5 - c[1] / (c[2] * tanHalf) * 0.5) * h};
    }

    /** @return {screenX, screenY, depth} or null when the point is behind the camera. */
    public double[] project(Vec3 p) {
        double[] c = cam(p.x, p.y, p.z);
        if (c[2] < 0.05) return null;
        double[] s = scr(c);
        return new double[]{s[0], s[1], c[2]};
    }

    private void line2d(GuiGraphicsExtractor g, double x0, double y0, double x1, double y1, int color) {
        double dx = x1 - x0, dy = y1 - y0;
        int n = (int) Math.min(Math.max(Math.abs(dx), Math.abs(dy)), 1200);
        if (n < 1) return;
        for (int i = 0; i <= n; i++) {
            int x = (int) (x0 + dx * i / n), y = (int) (y0 + dy * i / n);
            if (x < 0 || y < 0 || x >= w || y >= h) continue;
            g.fill(x, y, x + 1, y + 1, color);
        }
    }

    public void line(GuiGraphicsExtractor g, Vec3 a, Vec3 b, int color) {
        double near = 0.05;
        double[] pa = cam(a.x, a.y, a.z), pb = cam(b.x, b.y, b.z);
        if (pa[2] < near && pb[2] < near) return;
        if (pa[2] < near) pa = clip(pa, pb, near); else if (pb[2] < near) pb = clip(pb, pa, near);
        double[] sa = scr(pa), sb = scr(pb);
        line2d(g, sa[0], sa[1], sb[0], sb[1], color);
    }
    private double[] clip(double[] p, double[] q, double near) {
        double t = (near - p[2]) / (q[2] - p[2]);
        return new double[]{p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, near};
    }

    /** Line from the bottom centre of the screen to a world position. */
    public void tracer(GuiGraphicsExtractor g, Vec3 target, int color) {
        double[] s = project(target);
        if (s == null) return;
        line2d(g, w / 2.0, h, s[0], s[1], color);
    }

    private Vec3[] corners(AABB b) {
        Vec3[] c = new Vec3[8];
        for (int i = 0; i < 8; i++) c[i] = new Vec3((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
        return c;
    }

    /** Wireframe box. */
    public void box(GuiGraphicsExtractor g, AABB b, int color) {
        Vec3[] c = corners(b);
        for (int i = 0; i < 8; i++)
            for (int bit = 0; bit < 3; bit++)
                if ((i & (1 << bit)) == 0) line(g, c[i], c[i | (1 << bit)], color);
    }

    /** Screen rectangle {minX, minY, maxX, maxY} around a box, or null if any corner is behind the camera. */
    public double[] rect(AABB b) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (Vec3 v : corners(b)) {
            double[] s = project(v);
            if (s == null) return null;
            minX = Math.min(minX, s[0]); maxX = Math.max(maxX, s[0]);
            minY = Math.min(minY, s[1]); maxY = Math.max(maxY, s[1]);
        }
        return new double[]{minX, minY, maxX, maxY};
    }
    public void rectOutline(GuiGraphicsExtractor g, double[] r, int color) {
        int x0 = (int) r[0], y0 = (int) r[1], x1 = (int) r[2], y1 = (int) r[3];
        g.fill(x0, y0, x1, y0 + 1, color); g.fill(x0, y1 - 1, x1, y1, color);
        g.fill(x0, y0, x0 + 1, y1, color); g.fill(x1 - 1, y0, x1, y1, color);
    }
    public void rectFill(GuiGraphicsExtractor g, double[] r, int color) {
        int x0 = (int) Math.max(0, r[0]), y0 = (int) Math.max(0, r[1]), x1 = (int) Math.min(w, r[2]), y1 = (int) Math.min(h, r[3]);
        if (x1 > x0 && y1 > y0) g.fill(x0, y0, x1, y1, color);
    }
}
