package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class PlayerModules {
    private PlayerModules() {}

    public static class HighJump extends Module {
        public HighJump() { super("HighJump", "Jump higher", Category.MOVEMENT); addSetting("height", 0.8, 0.1); }
        @Override public void tick(Minecraft mc) {
            if (mc.player.onGround() && mc.options.keyJump.isDown()) { Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, get("height"), v.z); }
        }
    }

    public static class FastFall extends Module {
        public FastFall() { super("FastFall", "Fall faster", Category.MOVEMENT); addSetting("speed", 0.8, 0.1); }
        @Override public void tick(Minecraft mc) {
            Vec3 v = mc.player.getDeltaMovement();
            if (!mc.player.onGround() && !mc.player.getAbilities().flying && !mc.player.isFallFlying() && !mc.player.isInWater() && v.y < 0)
                mc.player.setDeltaMovement(v.x, -get("speed"), v.z);
        }
    }

    public static class ElytraBoost extends Module {
        public ElytraBoost() { super("ElytraBoost", "Hold forward while gliding to speed up", Category.MOVEMENT); addSetting("speed", 1.2, 0.1); }
        @Override public void tick(Minecraft mc) {
            if (mc.player.isFallFlying() && mc.options.keyUp.isDown()) mc.player.setDeltaMovement(mc.player.getLookAngle().scale(get("speed")));
        }
    }

    public static class Jesus extends Module {
        public Jesus() { super("Jesus", "Float up in water", Category.MOVEMENT); }
        @Override public void tick(Minecraft mc) {
            if (mc.player.isInWater() && !mc.options.keyShift.isDown()) { Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, 0.11, v.z); }
        }
    }

    public static class Parkour extends Module {
        public Parkour() { super("Parkour", "Auto jump at the edge of blocks", Category.MOVEMENT); }
        @Override public void tick(Minecraft mc) {
            if (!mc.player.onGround() || mc.player.isShiftKeyDown() || mc.level == null) return;
            Vec3 v = mc.player.getDeltaMovement();
            if (Math.abs(v.x) + Math.abs(v.z) < 0.02) return;
            AABB next = mc.player.getBoundingBox().move(v.x * 2, -0.5, v.z * 2);
            if (mc.level.noCollision(mc.player, next)) mc.player.setDeltaMovement(v.x, 0.42, v.z);
        }
    }
}
