package com.l7n.client.module.impl;

import com.l7n.client.BaritoneBridge;
import com.l7n.client.CommandManager;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class WorldModules {
    private WorldModules() {}

    /**
     * Mines continuously. Add blocks with ".automine add diamond_ore"; with Baritone installed it then walks to the nearest
     * ones and mines them. With an empty list, or without Baritone, it holds left click like before.
     */
    public static class AutoMine extends Module {
        /** Block ids (without "minecraft:") that Baritone should go for. */
        public final Set<String> blocks = new LinkedHashSet<>();
        private int cd, idle;
        private boolean issued, holding;

        public AutoMine() {
            super("AutoMine", "Mines continuously (Baritone goes for the blocks on your list: .automine add <block>)", Category.MISC);
            addToggle("baritone", true); addSetting("minhealth", 0, 1);
        }
        private boolean smart() { return on("baritone") && BaritoneBridge.available() && !blocks.isEmpty(); }

        /** Called when the block list changed: restart Baritone's mining with the new list. */
        public void refresh() {
            if (issued) { BaritoneBridge.cancel(); issued = false; }
            cd = 0; idle = 0;
        }

        @Override public void saveExtra(com.google.gson.JsonObject o) {
            com.google.gson.JsonArray a = new com.google.gson.JsonArray();
            blocks.forEach(a::add);
            o.add("blocks", a);
        }
        @Override public void loadExtra(com.google.gson.JsonObject o) {
            if (!o.has("blocks")) return;
            blocks.clear();
            o.getAsJsonArray("blocks").forEach(e -> blocks.add(e.getAsString()));
        }

        @Override protected void onEnable() {
            cd = 0; idle = 0; issued = false;
            if (on("baritone") && !blocks.isEmpty() && !BaritoneBridge.available())
                CommandManager.info("Baritone not found - holding left click instead");
        }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null) return;
            if (!smart()) { mc.options.keyAttack.setDown(true); holding = true; return; }
            if (holding) { mc.options.keyAttack.setDown(false); holding = false; }
            if (get("minhealth") > 0 && mc.player.getHealth() < get("minhealth")) {
                CommandManager.info("§cHealth low - AutoMine stopped");
                setEnabled(false);
                return;
            }
            if (cd-- > 0) return;
            if (BaritoneBridge.busy()) { idle = 0; cd = 20; return; }
            // Nothing running: (re)start mining. If Baritone knows no such block nearby this backs off up to 30 s so chat is not spammed.
            issued = BaritoneBridge.run("mine " + String.join(" ", blocks));
            cd = Math.min(40 + idle * 40, 600);
            idle++;
        }
        @Override protected void onDisable() {
            Minecraft.getInstance().options.keyAttack.setDown(false);
            holding = false;
            if (issued) { BaritoneBridge.cancel(); issued = false; }
        }
    }

    /** Places the block you hold under your feet. */
    public static class Scaffold extends Module {
        public Scaffold() { super("Scaffold", "Places held blocks under you", Category.MISC); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (!(mc.player.getMainHandItem().getItem() instanceof BlockItem)) return;
            BlockUtil.place(mc, mc.player.blockPosition().below());
        }
    }

    /** Builds under and around you automatically: bridging, filling holes, with hotbar auto-switch. */
    public static class LimitlessBuilder extends Module {
        private int cd;
        public LimitlessBuilder() {
            super("LimitlessBuilder", "Auto-places blocks under/around you (bridge, tower, fill)", Category.MISC);
            addSetting("radius", 1, 1); addSetting("delay", 0, 1); addToggle("autoswitch", true);
        }
        private boolean ensureBlock(Minecraft mc) {
            if (mc.player.getMainHandItem().getItem() instanceof BlockItem) return true;
            if (!on("autoswitch")) return false;
            int slot = BlockUtil.hotbar(mc, s -> s.getItem() instanceof BlockItem);
            if (slot < 0) return false;
            BlockUtil.select(mc, slot);
            return true;
        }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (cd > 0) { cd--; return; }
            if (!ensureBlock(mc)) return;
            BlockPos feet = mc.player.blockPosition().below();
            int r = (int) get("radius");
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                    if (BlockUtil.place(mc, feet.offset(dx, 0, dz))) { cd = (int) get("delay"); return; }
        }
    }

    /** All block entities of a chunk. */
    static List<BlockEntity> blockEntities(ChunkAccess c) {
        List<BlockEntity> l = new java.util.ArrayList<>();
        for (BlockPos p : c.getBlockEntitiesPos()) {
            BlockEntity be = c.getBlockEntity(p);
            if (be != null) l.add(be);
        }
        return l;
    }

    private static boolean storage(BlockEntity be) {
        return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity
                || be instanceof AbstractFurnaceBlockEntity || be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity
                || be instanceof BrewingStandBlockEntity || be instanceof EnderChestBlockEntity || be instanceof BedBlockEntity;
    }
    private static boolean stash(BlockEntity be) {
        return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity;
    }

    /** Shared by BaseFinder/ChestFinder: counts matching block entities in a chunk and returns the area they occupy. */
    private static void scanCluster(FinderModule m, ChunkAccess c, List<FinderModule.Found> out, boolean onlyStash, String label, int minimum) {
        int n = 0, minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (BlockEntity be : blockEntities(c)) {
            if (!(onlyStash ? stash(be) : storage(be))) continue;
            BlockPos p = be.getBlockPos();
            n++;
            minX = Math.min(minX, p.getX()); minY = Math.min(minY, p.getY()); minZ = Math.min(minZ, p.getZ());
            maxX = Math.max(maxX, p.getX()); maxY = Math.max(maxY, p.getY()); maxZ = Math.max(maxZ, p.getZ());
        }
        if (n == 0 || n < minimum) return;
        AABB area;
        if (m.on("chunkbox")) {
            int cx = c.getPos().getMinBlockX(), cz = c.getPos().getMinBlockZ();
            area = new AABB(cx, minY, cz, cx + 16, maxY + 1, cz + 16);
        } else {
            area = new AABB(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1).inflate(1.0);
        }
        out.add(new FinderModule.Found(BlockPos.containing(area.getCenter()), label + " " + n, area));
    }

    public static class BaseFinder extends FinderModule {
        public BaseFinder() { super("BaseFinder", "Finds bases: green area over chunks with many containers"); addSetting("minimum", 5, 1); addToggle("chunkbox", false); }
        @Override protected void scan(ChunkAccess c, List<Found> out) { scanCluster(this, c, out, false, "Base", (int) get("minimum")); }
    }

    public static class ChestFinder extends FinderModule {
        public ChestFinder() { super("ChestFinder", "Finds stashes (many chests/barrels/shulkers)"); addSetting("minimum", 8, 1); addToggle("chunkbox", false); }
        @Override protected void scan(ChunkAccess c, List<Found> out) { scanCluster(this, c, out, true, "Stash", (int) get("minimum")); }
    }

    /** Spawners (normal + trial) with boxes and tracer lines. */
    public static class SpawnerEsp extends FinderModule {
        public SpawnerEsp() { super("SpawnerESP", "Finds mob spawners (boxes + lines)"); addSetting("radius", 8, 1); }
        @Override protected int color() { return 0xFFEF4444; }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            for (BlockEntity be : blockEntities(c)) {
                if (be instanceof SpawnerBlockEntity) out.add(new Found(be.getBlockPos(), "Spawner"));
                else if (be instanceof TrialSpawnerBlockEntity) out.add(new Found(be.getBlockPos(), "Trial Spawner"));
            }
        }
    }

    /** Chests, barrels, shulkers, ender chests, furnaces, hoppers... with boxes and tracer lines. */
    public static class StorageEsp extends FinderModule {
        public StorageEsp() { super("StorageESP", "Finds containers (boxes + lines)"); addSetting("radius", 6, 1); }
        @Override protected int color() { return 0xFFFACC15; }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            for (BlockEntity be : blockEntities(c))
                if (storage(be)) out.add(new Found(be.getBlockPos(), be.getClass().getSimpleName().replace("BlockEntity", "")));
        }
    }

    public static class ShulkerFinder extends FinderModule {
        public ShulkerFinder() { super("ShulkerFinder", "Finds shulker boxes"); }
        @Override protected int color() { return 0xFFC084FC; }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            for (BlockEntity be : blockEntities(c)) if (be instanceof ShulkerBoxBlockEntity) out.add(new Found(be.getBlockPos(), "Shulker"));
        }
    }

    public static class BlockEsp extends FinderModule {
        public final Set<Block> blocks = new LinkedHashSet<>();
        public BlockEsp() {
            super("BlockESP", "Finds chosen blocks (.blockesp add <id>)");
            blocks.add(Blocks.ANCIENT_DEBRIS); blocks.add(Blocks.DIAMOND_ORE); blocks.add(Blocks.DEEPSLATE_DIAMOND_ORE);
        }
        @Override protected int color() { return 0xFFFACC15; }
        @Override public void saveExtra(com.google.gson.JsonObject o) {
            com.google.gson.JsonArray arr = new com.google.gson.JsonArray();
            for (Block b : blocks) arr.add(BuiltInRegistries.BLOCK.getKey(b).toString());
            o.add("blocks", arr);
        }
        @Override public void loadExtra(com.google.gson.JsonObject o) {
            if (!o.has("blocks")) return;
            blocks.clear();
            for (var e : o.getAsJsonArray("blocks")) {
                var id = net.minecraft.resources.Identifier.tryParse(e.getAsString());
                if (id != null) BuiltInRegistries.BLOCK.getOptional(id).ifPresent(blocks::add);
            }
        }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            if (blocks.isEmpty()) return;
            int minX = c.getPos().getMinBlockX(), minZ = c.getPos().getMinBlockZ();
            LevelChunkSection[] secs = c.getSections();
            for (int i = 0; i < secs.length; i++) {
                LevelChunkSection s = secs[i];
                if (s == null || s.hasOnlyAir() || !s.maybeHas(st -> blocks.contains(st.getBlock()))) continue;
                int baseY = (c.getMinSectionY() + i) << 4;
                for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                    BlockState st = s.getBlockState(x, y, z);
                    if (blocks.contains(st.getBlock())) {
                        out.add(new Found(new BlockPos(minX + x, baseY + y, minZ + z), BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath()));
                        if (out.size() > 400) return;
                    }
                }
            }
        }
    }
}
