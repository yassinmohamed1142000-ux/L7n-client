package com.l7n.client.gui;

import com.l7n.client.L7NClient;
import com.l7n.client.module.Module;
import com.l7n.client.module.impl.*;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.Identifier;
import java.util.ArrayList;
import java.util.List;

public class Hud {
    public static final int PURPLE = 0xFFA855F7, DARK = 0xE60B0618, ICON = 11;

    public record Box(Module m, int x, int y, int w, int h, List<String> lines, List<PlayerInfo> icons) {}

    /** Layout of all movable HUD elements (shared with the HUD editor). */
    public static List<Box> boxes(Minecraft mc, boolean editor) {
        List<Box> out = new ArrayList<>();
        int ly = 30;
        for (Module m : L7NClient.modules.all) {
            if (!m.hasHud()) continue;
            if (!m.isEnabled() && !editor) continue;
            List<String> lines = m.isEnabled() ? m.hudLines() : List.of(m.name + " (off)");
            List<PlayerInfo> icons = m.isEnabled() ? new ArrayList<>(m.lineIcons()) : new ArrayList<>();
            if (lines.isEmpty()) { if (!editor) continue; lines = List.of(m.name); icons = new ArrayList<>(); }
            int w = 0;
            for (int i = 0; i < lines.size(); i++) {
                boolean ic = i < icons.size() && icons.get(i) != null;
                w = Math.max(w, mc.font.width(lines.get(i)) + (ic ? ICON : 0));
            }
            w += 10;
            int h = lines.size() * 11;
            int x = 4, y = ly;
            if (m.hudX >= 0 && m.hudY >= 0) { x = m.hudX; y = m.hudY; } else ly += h + 3;
            out.add(new Box(m, x, y, w, h, List.copyOf(lines), icons));
        }
        return out;
    }

    public static void drawBox(GuiGraphicsExtractor g, Minecraft mc, Box b) {
        g.fill(b.x(), b.y() - 1, b.x() + b.w(), b.y() + b.h(), DARK);
        g.fill(b.x(), b.y() - 1, b.x() + 2, b.y() + b.h(), PURPLE);
        int y = b.y() + 1;
        for (int i = 0; i < b.lines().size(); i++) {
            int tx = b.x() + 5;
            PlayerInfo pi = i < b.icons().size() ? b.icons().get(i) : null;
            if (pi != null) { Gfx.face(g, pi.getSkin(), tx, y, 9); tx += ICON; }
            Gfx.text(g, mc.font, b.lines().get(i), tx, y + 1, 0xFFE9D5FF);
            y += 11;
        }
    }

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.fromNamespaceAndPath("l7n", "hud"), (g, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui || mc.player == null) return;
            var mm = L7NClient.modules;
            if (mm.get(WatermarkModule.class).isEnabled()) {
                g.fill(4, 4, 112, 24, DARK);
                g.fill(4, 4, 6, 24, PURPLE);
                Gfx.text(g, mc.font, "L7N CLIENT", 12, 10, PURPLE);
            }
            if (mm.get(CoordsModule.class).isEnabled()) {
                String s = String.format("XYZ %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
                Gfx.text(g, mc.font, s, 6, mc.getWindow().getGuiScaledHeight() - 12, 0xFFFFFFFF);
            }
            Projector pr = Projector.create(mc, delta.getGameTimeDeltaPartialTick(false));
            if (pr != null) {
                float pt = delta.getGameTimeDeltaPartialTick(false);
                for (Module m : mm.all) if (m.isEnabled()) m.renderOverlay(g, mc, pr, pt);
            }
            for (Box b : boxes(mc, false)) drawBox(g, mc, b);
            Notifier.render(g, mc);
            if (mm.get(ArrayListModule.class).isEnabled()) {
                int y = 4, w = mc.getWindow().getGuiScaledWidth();
                for (Module m : mm.all) {
                    if (!m.isEnabled()) continue;
                    int tw = mc.font.width(m.name);
                    g.fill(w - tw - 8, y, w, y + 11, DARK);
                    g.fill(w - 2, y, w, y + 11, PURPLE);
                    Gfx.text(g, mc.font, m.name, w - tw - 5, y + 2, PURPLE);
                    y += 11;
                }
            }
        });
    }
}
