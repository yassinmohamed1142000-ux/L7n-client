package com.l7n.client;

import java.lang.reflect.Method;

/**
 * Optional link to the Baritone mod. Everything goes through reflection, so L7N builds and runs without Baritone
 * and simply starts using it when a Baritone jar for your Minecraft version is in the mods folder.
 *
 * Only the long-stable entry point is used: BaritoneAPI.getProvider().getPrimaryBaritone(), then the command
 * manager (the same thing that handles "#goto", "#mine" ... in chat) and the process "isActive()" flags.
 */
public final class BaritoneBridge {
    private BaritoneBridge() {}

    private static final Class<?>[] NO_ARGS = new Class<?>[0];
    private static final String[] PROCESSES = {
            "getCustomGoalProcess", "getMineProcess", "getExploreProcess", "getFarmProcess",
            "getFollowProcess", "getGetToBlockProcess", "getBuilderProcess"
    };

    private static boolean checked;
    private static Class<?> api;

    /** @return true when Baritone's API is on the classpath. */
    public static boolean available() {
        if (!checked) {
            checked = true;
            try { api = Class.forName("baritone.api.BaritoneAPI"); }
            catch (Throwable t) { api = null; }
        }
        return api != null;
    }

    private static Object call(Object target, String name, Class<?>[] types, Object... args) throws ReflectiveOperationException {
        Method m = target.getClass().getMethod(name, types);
        m.setAccessible(true);
        return m.invoke(target, args);
    }

    private static Object baritone() throws ReflectiveOperationException {
        Object provider = api.getMethod("getProvider").invoke(null);
        return call(provider, "getPrimaryBaritone", NO_ARGS);
    }

    /** Runs a Baritone command without the chat prefix, e.g. "goto 100 64 -200", "mine diamond_ore", "explore", "cancel". */
    public static boolean run(String command) {
        if (!available()) return false;
        try {
            Object commandManager = call(baritone(), "getCommandManager", NO_ARGS);
            Object ok = call(commandManager, "execute", new Class<?>[]{String.class}, command);
            return !(ok instanceof Boolean b) || b;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Stops whatever Baritone is doing. */
    public static void cancel() { run("cancel"); }

    /** @return true while Baritone is pathing or any of its goal-driven processes (goto, mine, explore, farm, follow...) is active. */
    public static boolean busy() {
        if (!available()) return false;
        try {
            Object b = baritone();
            try {
                Object pathing = call(call(b, "getPathingBehavior", NO_ARGS), "isPathing", NO_ARGS);
                if (pathing instanceof Boolean p && p) return true;
            } catch (ReflectiveOperationException ignored) { /* fall through to the process checks */ }
            for (String getter : PROCESSES) {
                try {
                    Object active = call(call(b, getter, NO_ARGS), "isActive", NO_ARGS);
                    if (active instanceof Boolean a && a) return true;
                } catch (ReflectiveOperationException ignored) { /* this process does not exist in this Baritone build */ }
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }
}
