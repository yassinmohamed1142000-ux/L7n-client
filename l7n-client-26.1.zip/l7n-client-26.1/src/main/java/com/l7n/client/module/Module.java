package com.l7n.client.module;

import net.minecraft.client.Minecraft;
import java.util.*;

public abstract class Module {
    public final String name, description;
    public final Category category;
    private boolean enabled;
    public float anim;
    public int hudX = -1, hudY = -1; // -1 = automatic position
    public final Map<String, Double> settings = new LinkedHashMap<>();
    public final Map<String, Double> steps = new HashMap<>();
    public final Set<String> toggles = new HashSet<>();

    public enum Category { COMBAT, MOVEMENT, RENDER, MISC }

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }
    protected void addSetting(String n, double d) { addSetting(n, d, 0.1); }
    protected void addSetting(String n, double d, double step) { settings.put(n.toLowerCase(), d); steps.put(n.toLowerCase(), step); }
    protected void addToggle(String n, boolean d) { settings.put(n.toLowerCase(), d ? 1.0 : 0.0); toggles.add(n.toLowerCase()); }
    public double get(String n) { return settings.getOrDefault(n.toLowerCase(), 0.0); }
    public boolean on(String n) { return get(n) >= 1; }
    /** Extra lines shown on the HUD while the module is enabled. */
    public List<String> hudLines() { return List.of(); }

    public boolean hasHud() { return false; }
    /** Draw 3D-looking overlays (boxes, tracers, tags) projected onto the screen. */
    public void renderOverlay(net.minecraft.client.gui.GuiGraphicsExtractor g, Minecraft mc, com.l7n.client.gui.Projector p, float pt) {}
    /** Optional player head for each HUD line (same order as hudLines, null = no icon). */
    public List<net.minecraft.client.multiplayer.PlayerInfo> lineIcons() { return List.of(); }
    public void saveExtra(com.google.gson.JsonObject o) {}
    public void loadExtra(com.google.gson.JsonObject o) {}
    public void adjust(String s, int dir) {
        s = s.toLowerCase();
        if (toggles.contains(s)) { settings.put(s, get(s) >= 1 ? 0.0 : 1.0); return; }
        double step = steps.getOrDefault(s, 0.1);
        settings.put(s, Math.max(0, Math.round((get(s) + dir * step) * 100) / 100.0));
    }
    public String valueText(String s) {
        double v = get(s);
        return toggles.contains(s.toLowerCase()) ? (v >= 1 ? "ON" : "OFF") : String.valueOf(Math.round(v * 100) / 100.0);
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }
    protected void onEnable() {}
    protected void onDisable() {}
    public void tick(Minecraft mc) {}
}
