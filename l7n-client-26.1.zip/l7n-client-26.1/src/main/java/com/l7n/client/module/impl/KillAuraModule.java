package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class KillAuraModule extends Module {
    public KillAuraModule() {
        super("KillAura", "Attacks the nearest entity in range", Category.COMBAT);
        addSetting("range", 3.8, 0.1); addToggle("players", true); addToggle("mobs", true); addToggle("rotate", true);
    }
    @Override public void tick(Minecraft mc) {
        if (mc.screen != null || mc.level == null || mc.gameMode == null) return;
        if (mc.player.getAttackStrengthScale(0f) < 1f) return;
        LivingEntity best = null; double bd = get("range");
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || le == mc.player || !le.isAlive() || le instanceof ArmorStand) continue;
            if (le instanceof Player fp && com.l7n.client.Data.isFriend(fp.getName().getString())) continue;
            boolean isPlayer = le instanceof Player;
            if (isPlayer && get("players") < 1) continue;
            if (!isPlayer && get("mobs") < 1) continue;
            double d = mc.player.distanceTo(le);
            if (d <= bd) { bd = d; best = le; }
        }
        if (best == null) return;
        if (get("rotate") >= 1) {
            Vec3 eye = mc.player.getEyePosition(), t = best.getBoundingBox().getCenter();
            double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z, h = Math.sqrt(dx * dx + dz * dz);
            mc.player.setYRot((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90));
            mc.player.setXRot((float) -Math.toDegrees(Math.atan2(dy, h)));
        }
        CombatModules.Criticals.apply(mc);
        mc.gameMode.attack(mc.player, best);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }
}
