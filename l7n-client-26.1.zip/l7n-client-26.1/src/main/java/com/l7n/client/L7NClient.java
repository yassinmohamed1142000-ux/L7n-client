package com.l7n.client;

import com.l7n.client.gui.ClickGuiScreen;
import com.l7n.client.gui.Hud;
import com.l7n.client.module.ModuleManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.network.chat.Component;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class L7NClient implements ClientModInitializer {
    public static final String NAME = "L7N CLIENT";
    public static final Identifier LOGO = Identifier.fromNamespaceAndPath("l7n", "textures/gui/logo.png");
    public static final int LOGO_W = 556, LOGO_H = 370; // actual size of logo.png
    public static ModuleManager modules;
    private static KeyMapping openGui, panicKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        Config.load();
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("l7n", "main"));
        openGui = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.l7n.gui", InputConstants.KEY_RSHIFT, cat));
        panicKey = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.l7n.panic", -1, cat)); // unbound: choose your key in Controls
        Hud.register();
        // Touch-friendly: an "L7N" button in the pause menu opens the ClickGUI (no keyboard needed)
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof PauseScreen)
                Screens.getWidgets(screen).add(Button.builder(Component.literal("L7N"), b -> client.setScreen(new ClickGuiScreen())).bounds(4, 4, 70, 20).build());
        });
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !CommandManager.handle(msg));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.consumeClick()) mc.setScreen(new ClickGuiScreen());
            while (panicKey.consumeClick()) {
                for (var m : modules.all) m.setEnabled(false);
                BaritoneBridge.cancel();
                CommandManager.info("§cAll modules disabled");
            }
            if (mc.player != null) modules.tick(mc);
        });
    }
}
