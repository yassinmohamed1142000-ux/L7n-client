package com.l7n.client.module.impl;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
public class FlightModule extends Module {
    public FlightModule() { super("Flight", "Creative-style flight (works where the server allows it)", Category.MOVEMENT); }
    @Override public void tick(Minecraft mc) { mc.player.getAbilities().mayfly = true; }
    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().mayfly = false; mc.player.getAbilities().flying = false;
        }
    }
}
