package com.l7n.client.module;

import com.l7n.client.module.impl.*;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ModuleManager {
    public final List<Module> all = new ArrayList<>();

    public ModuleManager() {
        // Combat
        all.add(new KillAuraModule());
        all.add(new CombatModules.Criticals());
        all.add(new CombatModules.TriggerBot());
        all.add(new CombatModules.Mace());
        all.add(new CombatModules.CrystalAura());
        all.add(new CombatModules.AnchorAura());
        all.add(new CombatModules.AutoTotem());
        all.add(new CombatModules.LegitTotem());
        // Movement
        all.add(new SprintModule());
        all.add(new FlightModule());
        all.add(new SpeedModule());
        all.add(new StepModule());
        all.add(new NoFallModule());
        all.add(new MovementModules.Spider());
        all.add(new MovementModules.Glide());
        all.add(new MovementModules.ElytraTarget());
        all.add(new MovementModules.Freecam());
        all.add(new PlayerModules.HighJump());
        all.add(new PlayerModules.FastFall());
        all.add(new PlayerModules.ElytraBoost());
        all.add(new PlayerModules.Jesus());
        all.add(new PlayerModules.Parkour());
        // Render
        all.add(new EspModule());
        all.add(new RenderModules.Nametags());
        all.add(new FullbrightModule());
        all.add(new CoordsModule());
        all.add(new ArrayListModule());
        all.add(new WatermarkModule());
        all.add(new RenderModules.Radar());
        all.add(new RenderModules.Speedometer());
        all.add(new RenderModules.Keystrokes());
        all.add(new StaffModules.StaffList());
        // Misc / World
        all.add(new WorldModules.BaseFinder());
        all.add(new WorldModules.ChestFinder());
        all.add(new WorldModules.SpawnerEsp());
        all.add(new WorldModules.StorageEsp());
        all.add(new WorldModules.ShulkerFinder());
        all.add(new WorldModules.BlockEsp());
        all.add(new WorldModules.AutoMine());
        all.add(new WorldModules.Scaffold());
        all.add(new WorldModules.LimitlessBuilder());
        all.add(new MiscModules.AutoWalk());
        all.add(new MiscModules.AutoJump());
        all.add(new MiscModules.AutoSneak());
        all.add(new MiscModules.AntiAFK());
        all.add(new MiscModules.AutoRespawn());
        all.add(new StaffModules.AntiVanish());
        all.add(new StaffModules.Inspector());

        get(WatermarkModule.class).setEnabled(true);
        get(ArrayListModule.class).setEnabled(true);
    }
    public List<Module> in(Module.Category c) { return all.stream().filter(m -> m.category == c).toList(); }
    public <T extends Module> T get(Class<T> c) { for (Module m : all) if (c.isInstance(m)) return c.cast(m); return null; }
    public Optional<Module> byName(String n) { return all.stream().filter(m -> m.name.equalsIgnoreCase(n)).findFirst(); }
    public void tick(Minecraft mc) { for (Module m : all) if (m.isEnabled()) m.tick(mc); }
}
