package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

public class NoFallModule extends Module {
    public NoFallModule() { super("NoFall", "Cancel fall damage", Category.MOVEMENT); }
    @Override public void tick(Minecraft mc) {
        if (mc.player.fallDistance > 2.0 && !mc.player.isFallFlying())
            mc.player.connection.send(new ServerboundMovePlayerPacket.StatusOnly(true, mc.player.horizontalCollision));
    }
}
