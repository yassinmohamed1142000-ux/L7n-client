package com.l7n.client.module.impl;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
public class SprintModule extends Module {
    public SprintModule() { super("Sprint", "Always sprint while moving forward", Category.MOVEMENT); }
    @Override public void tick(Minecraft mc) {
        if (mc.options.keyUp.isDown() && !mc.player.isShiftKeyDown()) mc.player.setSprinting(true);
    }
}
